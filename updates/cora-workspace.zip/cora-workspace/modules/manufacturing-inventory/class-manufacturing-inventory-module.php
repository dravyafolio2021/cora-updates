<?php
/**
 * Cora Stationery Manufacturing & Field Sales Inventory Module
 * 
 * Provides single point of control for stationery manufacturing plants,
 * dynamic mobile van sales consignment allocations (₹1k to ₹10L+), live GPS route tracking,
 * multimodal AI invoice OCR parsing, and automated 24-hour daily audit reports.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cora_Manufacturing_Inventory_Module implements Cora_Module_Interface {
    
    public function get_module_id() : string {
        return 'stationery_inventory';
    }

    public function get_display_name() : string {
        return 'Stationery Manufacturing & Van Sales';
    }

    public function get_navigation_groups(string $active_role) : array {
        if ( $active_role === 'cora_field_vendor' ) {
            return array(
                array(
                    'label' => 'Field Operations',
                    'items' => array(
                        'plant_inventory' => array(
                            'title' => 'Van Sales & Route',
                            'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>'
                        )
                    )
                )
            );
        }

        $enabled = function_exists( 'cora_get_custom_enabled_features' ) ? cora_get_custom_enabled_features() : array();
        
        $is_enabled = function( $slug ) use ( $enabled ) {
            return in_array( $slug, $enabled, true );
        };

        $groups = array();

        // 1. Core Workspace Group (Platform Foundation - permanently active)
        $workspace_items = array(
            'dashboard' => array(
                'title' => 'Dashboard',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"></rect><rect x="14" y="3" width="7" height="5" rx="1"></rect><rect x="14" y="12" width="7" height="9" rx="1"></rect><rect x="3" y="16" width="7" height="5" rx="1"></rect></svg>'
            ),
            'blogs' => array(
                'title' => 'Content Suite',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>'
            ),
            'forms' => array(
                'title' => 'Forms',
                'badge' => 'v1.0',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M9 15l2 2 4-4"></path></svg>'
            ),
            'team-roles' => array(
                'title' => 'User & Roles',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>'
            ),
            'media' => array(
                'title' => 'Media Manager',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>'
            ),
            'vault' => array(
                'title' => 'File Manager',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>'
            ),
            'affiliates' => array(
                'title' => 'Affiliates & Referrals',
                'badge' => '40%',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><line x1="19" y1="8" x2="19" y2="14"></line><line x1="22" y1="11" x2="16" y2="11"></line></svg>'
            ),
        );

        $groups[] = array(
            'label' => 'Workspace',
            'items' => $workspace_items
        );

        // 2. CRM Group (Independent)
        $crm_items = array();
        if ( $is_enabled( 'leads' ) ) {
            $crm_items['leads'] = array(
                'title' => 'Leads',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"></rect><rect x="14" y="3" width="7" height="9" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect></svg>'
            );
        }
        if ( $is_enabled( 'clients' ) || $is_enabled( 'client_portal' ) ) {
            $crm_items['clients'] = array(
                'title' => 'Clients',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>'
            );
        }
        if ( $is_enabled( 'tasks' ) || $is_enabled( 'client_tasks' ) ) {
            $crm_items['tasks'] = array(
                'title' => 'Tasks',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>'
            );
        }
        if ( $is_enabled( 'calendar' ) ) {
            $crm_items['calendar'] = array(
                'title' => 'Calendar',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
            );
        }
        if ( $is_enabled( 'financials' ) ) {
            $crm_items['financials'] = array(
                'title' => 'Financial Overview',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>'
            );
        }
        if ( ! empty( $crm_items ) ) {
            $groups[] = array(
                'label' => 'CRM',
                'items' => $crm_items
            );
        }

        // 3. Operations Group
        $ops_items = array();
        if ( $is_enabled( 'plant_inventory' ) || $is_enabled( 'stationery_inventory' ) || $is_enabled( 'inventory_management' ) || $is_enabled( 'inventory' ) ) {
            $ops_items['plant_inventory'] = array(
                'title' => 'Inventory',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>'
            );
        }
        if ( $is_enabled( 'crew_scheduler' ) ) {
            $ops_items['crew_scheduler'] = array(
                'title' => 'Team Scheduler',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>'
            );
        }

        if ( ! empty( $ops_items ) ) {
            $groups[] = array(
                'label' => 'Operations',
                'items' => $ops_items
            );
        }

        // 4. Sales Channel Group
        $sales_items = array();
        if ( $is_enabled( 'canvas' ) ) {
            $sales_items['canvas'] = array(
                'title' => 'Canvas',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>'
            );
        }
        if ( $is_enabled( 'emails' ) ) {
            $sales_items['emails'] = array(
                'title' => 'Emails',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>'
            );
        }
        if ( $is_enabled( 'review_acquisition' ) ) {
            $sales_items['review_acquisition'] = array(
                'title' => 'Reviews & Feedback',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="M9 12l2 2 4-4"></path></svg>'
            );
        }
        if ( ! empty( $sales_items ) ) {
            $groups[] = array(
                'label' => 'Sales Channel',
                'items' => $sales_items
            );
        }

        // 5. AI Marketing Group
        $ai_items = array();
        if ( $is_enabled( 'gbp' ) ) {
            $ai_items['gbp'] = array(
                'title' => 'Google Profile',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" class="shrink-0" style="stroke: none !important; fill: none !important;"><circle cx="12" cy="12" r="11" fill="#ffffff" style="fill: #ffffff !important; stroke: #e4e4e7 !important; stroke-width: 0.8px !important;"></circle><g transform="matrix(0.55 0 0 0.55 5.4 5.4)"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" style="fill: #4285F4 !important; stroke: none !important;"></path><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" style="fill: #34A853 !important; stroke: none !important;"></path><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05" style="fill: #FBBC05 !important; stroke: none !important;"></path><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335" style="fill: #EA4335 !important; stroke: none !important;"></path></g></svg>'
            );
        }
        if ( $is_enabled( 'mcp' ) ) {
            $ai_items['mcp'] = array(
                'title' => 'AI Tools MCP',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="15" x2="23" y2="15"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="15" x2="4" y2="15"></line></svg>'
            );
        }
        if ( $is_enabled( 'knowledge-base' ) ) {
            $ai_items['knowledge-base'] = array(
                'title' => 'RAG Knowledge Base',
                'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>'
            );
        }
        if ( ! empty( $ai_items ) ) {
            $groups[] = array(
                'label' => 'AI Marketing',
                'items' => $ai_items
            );
        }

        // 6. Settings Group
        $groups[] = array(
            'label' => 'Settings',
            'items' => array(
                'feature-hub' => array(
                    'title' => 'App Modules',
                    'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>'
                ),
                'settings-suite' => array(
                    'title' => 'Settings',
                    'icon'  => '<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06-.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06-.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>'
                )
            )
        );

        return $groups;
    }

    public function get_industry_roles() : array {
        return array(
            'cora_manager'       => 'Logistics & Warehouse Manager',
            'cora_plant_manager' => 'Plant / Operations Director',
            'cora_field_vendor'  => 'Field Sales / Mobile Vendor'
        );
    }

    public function get_crm_stages() : array {
        return array(
            'inquiry'           => 'Dealer Inquiry',
            'sample_kit'        => 'Sample Kit Dispatched',
            'bulk_quotation'    => 'Wholesale Quotation',
            'order_contract'    => 'Contract & Advance',
            'active_dealer'     => 'Active Recurring Dealer'
        );
    }

    public function setup_database_tables() {
        if ( function_exists( 'cora_create_custom_tables' ) ) {
            cora_create_custom_tables();
        }
    }
}
