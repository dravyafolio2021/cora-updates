import re

with open('admin-dashboard.php', 'r') as f:
    content = f.read()

# Remove anything that matches: 
# .cora-dark-theme <any characters until {> { <any characters until }> }
# But we need to handle nested braces or multiple selectors.
# Actually, CSS here doesn't seem to have nested braces (it's plain CSS, not SCSS).
# We can just match `.cora-dark-theme[^\{]*\{[^}]*\}`

# Let's write a loop to find .cora-dark-theme and remove the whole CSS rule.
# To handle multiple selectors starting with .cora-dark-theme:
# We can match from the start of the line where .cora-dark-theme appears, until the next `}`
# Since all selectors in the block start with `.cora-dark-theme` (as seen in the comma list),
# we can just use a regex:
# r'(?m)^\s*\.cora-dark-theme[^\{]*\{[^}]*\}'

new_content = re.sub(r'(?m)^\s*\.?cora-dark-theme[^\{]*\{[^}]*\}', '', content)
# wait, what if the comma list has some lines starting with .cora-dark-theme and others not?
# Let's just remove any rule block that CONTAINS .cora-dark-theme before the {
# A rule block in CSS is generally: `selector { body }`

# Regex for CSS rule: `([^{}]+)\{([^{}]+)\}`
def replacer(match):
    selector = match.group(1)
    if 'cora-dark-theme' in selector:
        return ''
    return match.group(0)

new_content = re.sub(r'([^{}]+)\{([^{}]+)\}', replacer, content)

# Check if there are still any cora-dark-theme left
import sys
if 'cora-dark-theme' in new_content:
    leftovers = new_content.count('cora-dark-theme')
    print(f"Still {leftovers} left after first pass")
    # if it's in JS or something else
    # Let's remove any line that contains cora-dark-theme if any left
    lines = new_content.split('\n')
    lines = [l for l in lines if 'cora-dark-theme' not in l]
    new_content = '\n'.join(lines)

with open('admin-dashboard.php', 'w') as f:
    f.write(new_content)

print("Done")
