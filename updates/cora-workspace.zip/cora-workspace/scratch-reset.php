<?php
  require_once dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';
  $u = get_user_by('login', 'studio_owner');
  if ($u) {
      delete_user_meta($u->ID, 'cora_onboarding_completed');
      delete_user_meta($u->ID, 'cora_onboarding_industry_selected');
      delete_user_meta($u->ID, 'cora_workspace_agency_name');
      echo "RESET_SUCCESS";
  } else {
      echo "USER_NOT_FOUND";
  }