<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── 1. Table Creation and Schema ──────────────────────────────────────────

if ( ! function_exists( 'cora_create_docs_tables' ) ) {
function cora_create_docs_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $t_versions = $wpdb->prefix . 'cora_docs_versions';
    $t_changelog = $wpdb->prefix . 'cora_docs_changelog';
    $t_api = $wpdb->prefix . 'cora_docs_api_endpoints';

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    // Table 1: Documentation Pages
    $sql_pages = "CREATE TABLE {$t_pages} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        slug varchar(255) NOT NULL,
        title varchar(255) NOT NULL,
        content longtext DEFAULT NULL,
        category varchar(50) NOT NULL,
        module_key varchar(50) DEFAULT NULL,
        status varchar(50) NOT NULL DEFAULT 'draft',
        created_by bigint(20) unsigned NOT NULL,
        updated_by bigint(20) unsigned NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY slug (slug)
    ) $charset_collate;";

    // Table 2: Version History
    $sql_versions = "CREATE TABLE {$t_versions} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        page_id bigint(20) unsigned NOT NULL,
        content longtext DEFAULT NULL,
        version_label varchar(50) NOT NULL,
        created_by bigint(20) unsigned NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY page_id (page_id)
    ) $charset_collate;";

    // Table 3: Changelog
    $sql_changelog = "CREATE TABLE {$t_changelog} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        module_key varchar(50) DEFAULT NULL,
        version varchar(50) NOT NULL,
        status varchar(50) NOT NULL DEFAULT 'released',
        title varchar(255) NOT NULL,
        description longtext DEFAULT NULL,
        ticket_id varchar(100) DEFAULT NULL,
        author_id bigint(20) unsigned NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // Table 4: API Endpoints Reference
    $sql_api = "CREATE TABLE {$t_api} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        method varchar(15) NOT NULL,
        path varchar(255) NOT NULL,
        description text DEFAULT NULL,
        required_permissions varchar(255) DEFAULT NULL,
        request_schema longtext DEFAULT NULL,
        response_schema longtext DEFAULT NULL,
        example longtext DEFAULT NULL,
        permission_level varchar(50) DEFAULT 'admin',
        mcp_compatible tinyint(1) DEFAULT 0,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY method_path (method,path)
    ) $charset_collate;";

    dbDelta( $sql_pages );
    dbDelta( $sql_versions );
    dbDelta( $sql_changelog );
    dbDelta( $sql_api );

    // Seed default data if pages table is empty
    cora_seed_docs_data();
}
}
add_action( 'init', 'cora_create_docs_tables' );

// ── 2. Data Seeding ───────────────────────────────────────────────────────

if ( ! function_exists( 'cora_seed_docs_data' ) ) {
function cora_seed_docs_data() {
    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $t_versions = $wpdb->prefix . 'cora_docs_versions';
    $t_changelog = $wpdb->prefix . 'cora_docs_changelog';
    $t_api = $wpdb->prefix . 'cora_docs_api_endpoints';

    $author_id = 1; // Default Admin user ID

    $user_mgmt_content = "# Module 01: User Management, Roles & AI Permissions\n\n## 1. Multi-Tenant Role Architecture\nCora manages user authentication and authorization at the tenant workspace level. The platform defines four standard system roles and supports custom role extensions:\n- **Super Admin (`cora_super_admin`)**: Globally locked. Enforces absolute control over backups, system configurations, billing, and plugin installations.\n- **Tenant Owner (`owner`)**: Dedicated manager of the workspace tenant. Can create and modify custom roles, save security permissions matrices, and authorize third-party keys.\n- **Administrator (`administrator`)**: Complete read/write access to operations and data modules (CRM Leads, Showings, Invoices) but restricted from altering core tenant database settings.\n- **Workspace Manager / Crew (`cora_member` / `cora_manager`)**: Scoped access tailored to operational tasks. Can only perform actions allowed by the Active Security Matrix.\n\n## 2. Security & Permissions Matrix\nThe workspace owner can save granular capability permissions across all operational sections:\n- **Core Navigation**: Dashboard, Showings CRM, Portfolio.\n- **Operational Modules**: Team & Roles, Listings/Gear.\n- **Sales Channels**: Canvas Web Creator, Forms & Contracts, SMTP Outbound Drips, Review Acquisition.\n- **Administrative Rights**: Financials, Audit Logs, and Developer Settings.\n\n## 3. AI Native Capabilities & MCP Gateway\nCora integrates a local Model Context Protocol (MCP) gateway to bind external LLM execution contexts:\n- **Bearer Token Authorization**: MCP servers connect securely using cryptographically generated REST tokens.\n- **Dynamic Token Regeneration**: Administrators can rotate security tokens instantly from the User Settings interface to revoke or refresh API access.\n- **Live Sync Indicator**: Visual indicator badge displays the state of dynamic RAG synchronizations and MCP connections in real-time.";

    $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t_pages}");
    if ( $count > 0 ) {
        // Upsert to ensure existing database page is updated to detailed description
        $existing_page_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", 'user-management-and-auth' ) );
        if ( $existing_page_id ) {
            $wpdb->update( $t_pages, array(
                'title'      => 'Module 01: User Management & AI Permissions',
                'content'    => $user_mgmt_content,
                'category'   => 'modules',
                'updated_at' => current_time('mysql')
            ), array( 'id' => $existing_page_id ) );
        }

        // ── Upsert all new pages added in v3.2.46 ─────────────────────────
        $new_pages = cora_docs_get_new_pages_v3246();
        foreach ( $new_pages as $p ) {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $p['slug'] ) );
            if ( ! $exists ) {
                $wpdb->insert( $t_pages, array_merge( $p, array(
                    'status'     => 'draft',
                    'created_by' => $author_id,
                    'updated_by' => $author_id,
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ) ) );
            } else {
                // Update content if page exists but was created with placeholder text
                $wpdb->update( $t_pages, array(
                    'title'      => $p['title'],
                    'content'    => $p['content'],
                    'category'   => $p['category'],
                    'updated_at' => current_time('mysql'),
                ), array( 'slug' => $p['slug'] ) );
            }
        }

        // ── Upsert v3.2.46 changelog entries ──────────────────────────────
        $v3246_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$t_changelog} WHERE version = %s AND title = %s",
            '3.2.46', 'PWA Install Prompt & Push Notifications'
        ) );
        if ( ! $v3246_exists ) {
            $pwa_changelog_entries = cora_docs_get_pwa_changelog_entries();
            foreach ( $pwa_changelog_entries as $entry ) {
                $wpdb->insert( $t_changelog, array_merge( $entry, array(
                    'author_id'  => $author_id,
                    'created_at' => current_time('mysql'),
                ) ) );
            }
        }

        // ── Upsert v4.9.364+ documentation pages ─────────────────────────
        if ( function_exists( 'cora_docs_get_new_pages_v49364' ) ) {
            $v49_pages = cora_docs_get_new_pages_v49364();
            foreach ( $v49_pages as $p ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $p['slug'] ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_pages, array_merge( $p, array(
                        'status'     => 'public_live',
                        'created_by' => $author_id,
                        'updated_by' => $author_id,
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql'),
                    ) ) );
                } else {
                    $wpdb->update( $t_pages, array(
                        'title'      => $p['title'],
                        'content'    => $p['content'],
                        'category'   => $p['category'],
                        'updated_at' => current_time('mysql'),
                    ), array( 'slug' => $p['slug'] ) );
                }
            }
        }

        // ── Upsert v4.9.364+ changelog entries ───────────────────────────
        if ( function_exists( 'cora_docs_get_v49364_changelog_entries' ) ) {
            $v49_entries = cora_docs_get_v49364_changelog_entries();
            foreach ( $v49_entries as $entry ) {
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$t_changelog} WHERE version = %s AND title = %s",
                    $entry['version'], $entry['title']
                ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_changelog, array_merge( $entry, array(
                        'author_id'  => $author_id,
                        'created_at' => current_time('mysql'),
                    ) ) );
                }
            }
        }

        // ── Upsert v4.9.374+ documentation pages ─────────────────────────
        if ( function_exists( 'cora_docs_get_new_pages_v49374' ) ) {
            $v49374_pages = cora_docs_get_new_pages_v49374();
            foreach ( $v49374_pages as $p ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $p['slug'] ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_pages, array_merge( $p, array(
                        'status'     => 'public_live',
                        'created_by' => $author_id,
                        'updated_by' => $author_id,
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql'),
                    ) ) );
                } else {
                    $wpdb->update( $t_pages, array(
                        'title'      => $p['title'],
                        'content'    => $p['content'],
                        'category'   => $p['category'],
                        'updated_at' => current_time('mysql'),
                    ), array( 'slug' => $p['slug'] ) );
                }
            }
        }

        // ── Upsert v4.9.374+ changelog entries ───────────────────────────
        if ( function_exists( 'cora_docs_get_v49374_changelog_entries' ) ) {
            $v49374_entries = cora_docs_get_v49374_changelog_entries();
            foreach ( $v49374_entries as $entry ) {
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$t_changelog} WHERE version = %s AND title = %s",
                    $entry['version'], $entry['title']
                ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_changelog, array_merge( $entry, array(
                        'author_id'  => $author_id,
                        'created_at' => current_time('mysql'),
                    ) ) );
                }
            }
        }

        // ── Upsert v4.9.380+ documentation pages ─────────────────────────
        if ( function_exists( 'cora_docs_get_new_pages_v49380' ) ) {
            $v49380_pages = cora_docs_get_new_pages_v49380();
            foreach ( $v49380_pages as $p ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $p['slug'] ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_pages, array_merge( $p, array(
                        'status'     => 'public_live',
                        'created_by' => $author_id,
                        'updated_by' => $author_id,
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql'),
                    ) ) );
                } else {
                    $wpdb->update( $t_pages, array(
                        'title'      => $p['title'],
                        'content'    => $p['content'],
                        'category'   => $p['category'],
                        'updated_at' => current_time('mysql'),
                    ), array( 'slug' => $p['slug'] ) );
                }
            }
        }

        // ── Upsert v4.9.380+ changelog entries ───────────────────────────
        if ( function_exists( 'cora_docs_get_v49380_changelog_entries' ) ) {
            $v49380_entries = cora_docs_get_v49380_changelog_entries();
            foreach ( $v49380_entries as $entry ) {
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$t_changelog} WHERE version = %s AND title = %s",
                    $entry['version'], $entry['title']
                ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_changelog, array_merge( $entry, array(
                        'author_id'  => $author_id,
                        'created_at' => current_time('mysql'),
                    ) ) );
                }
            }
        }

        // ── Upsert v4.9.381+ pages ─────────────────────────────────────────
        if ( function_exists( 'cora_docs_get_new_pages_v49381' ) ) {
            $v49381_pages = cora_docs_get_new_pages_v49381();
            foreach ( $v49381_pages as $p ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $p['slug'] ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_pages, array_merge( $p, array(
                        'status'     => 'public_live',
                        'created_by' => $author_id,
                        'updated_by' => $author_id,
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql'),
                    ) ) );
                } else {
                    $wpdb->update( $t_pages, array(
                        'title'      => $p['title'],
                        'content'    => $p['content'],
                        'category'   => $p['category'],
                        'updated_at' => current_time('mysql'),
                    ), array( 'slug' => $p['slug'] ) );
                }
            }
        }

        // ── Upsert v4.9.381+ changelog entries ───────────────────────────
        if ( function_exists( 'cora_docs_get_v49381_changelog_entries' ) ) {
            $v49381_entries = cora_docs_get_v49381_changelog_entries();
            foreach ( $v49381_entries as $entry ) {
                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$t_changelog} WHERE version = %s AND title = %s",
                    $entry['version'], $entry['title']
                ) );
                if ( ! $exists ) {
                    $wpdb->insert( $t_changelog, array_merge( $entry, array(
                        'author_id'  => $author_id,
                        'created_at' => current_time('mysql'),
                    ) ) );
                }
            }
        }

        return; // Already seeded, upserts done
    }


    // Seed 1: Platform Overview Page
    $wpdb->insert( $t_pages, array(
        'slug' => 'platform-overview',
        'title' => 'Platform Overview',
        'category' => 'overview',
        'content' => "# Platform Overview\n\nCora is a modular SaaS platform built for Indian service businesses (salons, dental clinics, gyms, restaurants). It leverages an enterprise-grade PHP framework backend and wraps it in a modern, lightweight, isolated multi-tenant architecture designed to scale to the first 100 enterprise customers.\n\n## Core Features\n- **Decoupled Architecture**: Isolation of workspaces and databases.\n- **Universal Auto-Save**: Background debounce auto-save utilizing high-performance transient buffers.\n- **MCP Ready**: Seamless connection of external LLM tools with inherited role permissions.\n- **Native AI RAG Layer**: Localized knowledge base synchronization per tenant workspace.\n\n## Tech Stack\n- **Backend**: High-Performance PHP 8.2+ Framework Foundation\n- **Client UI**: Vanilla CSS & HTML, Tailwind CSS overlays, and React custom integrations\n- **AI Infrastructure**: Gemini 3.5 Flash and Claude 3.5 Sonnet RAG context agents\n- **MCP Gateway**: Secure JSON-RPC over WebSockets connection portal",
        'status' => 'draft',
        'created_by' => $author_id,
        'updated_by' => $author_id,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ));
    $page_id = $wpdb->insert_id;
    $wpdb->insert( $t_versions, array(
        'page_id' => $page_id,
        'content' => "# Platform Overview\n\nCora is a modular SaaS platform built for Indian service businesses (salons, dental clinics, gyms, restaurants)...",
        'version_label' => 'v1.0.0',
        'created_by' => $author_id,
        'created_at' => current_time('mysql')
    ));

    // Seed 2: Workspace Config Guide Page
    $wpdb->insert( $t_pages, array(
        'slug' => 'workspace-configuration',
        'title' => 'Workspace Configuration Guide',
        'category' => 'guides',
        'content' => "# Workspace Configuration Guide\n\nLearn how to combine individual modules to create custom industry-scoped tenant workspaces.\n\n## Pre-built Industry Templates\n- **Salon Workspace**: Bundles User Management, Forms & Reviews, Media Module, and WhatsApp Automations.\n- **Dental Clinic Workspace**: Bundles User Management, Client Scheduling, Document Studio Vault, and E-Sign registry.\n- **Content Agency Workspace**: Bundles User Management, CRM Lead Funnels, AI Content Suite, and SMTP outbound drip queues.\n\n## Combination Logic\nWorkspaces are configured at provisioning time. Modules are loaded dynamically based on active metadata query flags (e.g. `?industry=photography_studio`).\n\n## AI Quota Tiers\n- **Beta**: 500 AI RAG tokens / month\n- **Starter**: 10,000 AI RAG tokens / month\n- **Pro**: 100,000 AI RAG tokens / month\n- **Enterprise**: Custom unmetered limits",
        'status' => 'draft',
        'created_by' => $author_id,
        'updated_by' => $author_id,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ));
    $page_id2 = $wpdb->insert_id;
    $wpdb->insert( $t_versions, array(
        'page_id' => $page_id2,
        'content' => "# Workspace Configuration Guide...",
        'version_label' => 'v1.0.0',
        'created_by' => $author_id,
        'created_at' => current_time('mysql')
    ));

    // Seed 3: Roadmap Page
    $wpdb->insert( $t_pages, array(
        'slug' => 'roadmap',
        'title' => 'Roadmap',
        'category' => 'roadmap',
        'content' => "# Roadmap & Milestones\n\nTrack the implementation phases and module development updates across Cora Platform.\n\n## Platform Milestones\n### Phase 1: Core Platform Foundation\n- **Status**: SHIPPED\n- **Items**: Core DB architecture, JWT authentication, and tenant workspace routing.\n\n### Phase 2: AI Integration & Leads Funnel\n- **Status**: IN PROGRESS\n- **Items**: Dynamic Kanban lead board, debounced AI auto-save engine, and Google Business profile sync.\n\n### Phase 3: Document Vault & E-Sign\n- **Status**: NEXT\n- **Items**: 5-step Document Studio Wizard, GST verification API, and watermarked PDF renderer.\n\n### Phase 4: Decentralized Decoupling\n- **Status**: BACKLOG\n- **Items**: Migrating core schemas into standalone microservices, WebSocket RPC proxies.",
        'status' => 'draft',
        'created_by' => $author_id,
        'updated_by' => $author_id,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ));

    // Seed 4: Module 01 User Management Documentation Page
    $wpdb->insert( $t_pages, array(
        'slug' => 'user-management-and-auth',
        'title' => 'Module 01: User Management & AI Permissions',
        'category' => 'modules',
        'module_key' => 'user-management',
        'content' => $user_mgmt_content,
        'status' => 'draft',
        'created_by' => $author_id,
        'updated_by' => $author_id,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ));

    // Seed Changelog Entries
    $wpdb->insert( $t_changelog, array(
        'module_key' => null,
        'version' => '2.2.1',
        'status' => 'released',
        'title' => 'Platform Navigation Shift',
        'description' => 'Shifted Emails navigation item into the unified Sales Channel menu grouping inside sidebar container to streamline CRM layouts.',
        'ticket_id' => 'CORA-882',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.26',
        'status' => 'released',
        'title' => 'Desktop Header Refined & AI Stack Restored',
        'description' => 'Removed the page title user icon container in the desktop view, aligning the "User Management" title cleanly with the left edge of the page. Restored the overlapping AI brand platform stack next to the "Invite User" desktop button wrapper.',
        'ticket_id' => 'CORA-916',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.25',
        'status' => 'released',
        'title' => 'Mobile AI Shortcuts Stack Integrated',
        'description' => 'Added the compact overlapping AI brand stack shortcuts next to the Invite button in the mobile header, keeping the interface visual system unified without crowding the text fields or breaking the grid layout.',
        'ticket_id' => 'CORA-915',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.24',
        'status' => 'released',
        'title' => 'Mobile Header Padding Optimization',
        'description' => 'Removed horizontal edge padding (px-4 to px-0) from the mobile view header container to ensure content aligns perfectly flush with page margins.',
        'ticket_id' => 'CORA-914',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.23',
        'status' => 'released',
        'title' => 'Mobile Tabs Padding Optimization',
        'description' => 'Removed horizontal edge padding (px-4 to px-0) from the mobile sub-navigation tabs container, ensuring full-width layout boundaries on narrow viewports.',
        'ticket_id' => 'CORA-913',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.22',
        'status' => 'released',
        'title' => 'Mobile Tabs Baseline Alignment',
        'description' => 'Fixed vertical misalignment of mobile tabs by removing the bottom-padding helper pb-2, allowing the active bottom accent border to sit flush on the horizontal menu divider.',
        'ticket_id' => 'CORA-912',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.21',
        'status' => 'released',
        'title' => 'Mobile Tabs Outline & Background Removal',
        'description' => 'Completely removed the heavy box outline borders and grey background from the mobile sub-navigation dropdown button, rendering it fully borderless.',
        'ticket_id' => 'CORA-911',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.20',
        'status' => 'released',
        'title' => 'Attendance Logs 2-Column Mobile Grid',
        'description' => 'Optimized mobile analytics cards by converting the 4-cards stack into a 2x2 grid (grid-cols-2) on mobile, preserving screen real estate.',
        'ticket_id' => 'CORA-910',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.18',
        'status' => 'released',
        'title' => 'Attendance Logs Mobile Redesign',
        'description' => 'Redesigned Attendance Logs stat cards and overhauled the mobile punch list into premium card layouts with navigation chevron indicators.',
        'ticket_id' => 'CORA-908',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.17',
        'status' => 'released',
        'title' => 'Attendance Logs Cards Uniformity',
        'description' => 'Standardized attendance cards with consistent border weights, box shadow elevations, and strict minimum height bounds.',
        'ticket_id' => 'CORA-907',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '3.2.15',
        'status' => 'released',
        'title' => 'Permissions Matrix Mobile Redesign',
        'description' => 'Re-engineered the mobile Permissions Matrix tab into a premium accordion-based card layout with collapsible category rows and custom SVG status indicators.',
        'ticket_id' => 'CORA-905',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_changelog, array(
        'module_key' => 'user-management',
        'version' => '1.0.0',
        'status' => 'released',
        'title' => 'Initial Module Release',
        'description' => 'Completed User Management & Auth module base layer, including password recovery, login logs, and session handlers.',
        'ticket_id' => 'CORA-010',
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));

    // Seed API Endpoints
    $wpdb->insert( $t_api, array(
        'method' => 'POST',
        'path' => '/api/v1/auth/login',
        'description' => 'Authenticates a user using username and password, returning active JWT credentials.',
        'required_permissions' => 'public',
        'request_schema' => "{\n  \"username\": \"string\",\n  \"password\": \"string\"\n}",
        'response_schema' => "{\n  \"token\": \"string\",\n  \"expires_in\": \"int\"\n}",
        'example' => "Request:\nPOST /api/v1/auth/login\n{\n  \"username\": \"admin\",\n  \"password\": \"pass\"\n}\n\nResponse:\n200 OK\n{\n  \"token\": \"jwt_abc123\",\n  \"expires_in\": 3600\n}",
        'permission_level' => 'public',
        'mcp_compatible' => 1,
        'updated_at' => current_time('mysql')
    ));

    $wpdb->insert( $t_api, array(
        'method' => 'GET',
        'path' => '/api/v1/workspaces',
        'description' => 'Returns a list of all active workspaces mapped to the logged-in administrator.',
        'required_permissions' => 'read_workspaces',
        'request_schema' => '{}',
        'response_schema' => "[\n  {\n    \"id\": \"int\",\n    \"name\": \"string\",\n    \"slug\": \"string\",\n    \"plan\": \"string\"\n  }\n]",
        'example' => "Request:\nGET /api/v1/workspaces\n\nResponse:\n200 OK\n[\n  {\n    \"id\": 1,\n    \"name\": \"Apex Realty Group\",\n    \"slug\": \"apex-realty\",\n    \"plan\": \"enterprise\"\n  }\n]",
        'permission_level' => 'owner',
        'mcp_compatible' => 1,
        'updated_at' => current_time('mysql')
    ));
}
}

// ── 3. Simple Markdown Parser ─────────────────────────────────────────────

if ( ! function_exists( 'cora_markdown_to_html' ) ) {
function cora_markdown_to_html( $markdown ) {
    if ( empty( $markdown ) ) return '';
    
    // Safely encode characters to prevent issues
    $html = esc_html( $markdown );
    
    // Decode basic tags and markdown formatters
    $html = preg_replace('/^\#\#\# (.*?)$/m', '<h3 class="text-sm font-bold text-zinc-950 mt-6 mb-2 flex items-center gap-1">$1</h3>', $html);
    $html = preg_replace('/^\#\# (.*?)$/m', '<h2 class="text-base font-bold text-zinc-950 border-b border-zinc-200/80 pb-1 mt-7 mb-3 flex items-center gap-1.5">$1</h2>', $html);
    $html = preg_replace('/^\# (.*?)$/m', '<h1 class="text-xl font-extrabold text-zinc-950 tracking-tight mt-4 mb-4 flex items-center gap-2">$1</h1>', $html);
    
    // Strong & Emphasis
    $html = preg_replace('/\*\*(.*?)\*\*/', '<strong class="font-bold text-zinc-900">$1</strong>', $html);
    $html = preg_replace('/\*(.*?)\*/', '<em class="italic text-zinc-800">$1</em>', $html);
    
    // Code Blocks
    $html = preg_replace('/\`\`\`(.*?)\n([\s\S]*?)\`\`\`/m', '<pre class="bg-zinc-955 text-zinc-50 p-4 rounded-xl font-mono text-[11px] overflow-x-auto my-4 border border-zinc-900">$2</pre>', $html);
    $html = preg_replace('/\`(.*?)\`/', '<code class="bg-zinc-100 border border-zinc-200/60 text-zinc-800 px-1.5 py-0.5 rounded font-mono text-[10.5px]">$1</code>', $html);
    
    // GitHub block style alerts
    $html = preg_replace('/^&gt; \[!IMPORTANT\]\n&gt; (.*?)$/m', '<div class="my-4 p-4 bg-zinc-50 border border-zinc-950 rounded-lg text-xs text-zinc-800"><span class="font-bold uppercase tracking-wider block mb-1 text-[10px]">Important</span>$1</div>', $html);
    $html = preg_replace('/^&gt; \[!NOTE\]\n&gt; (.*?)$/m', '<div class="my-4 p-4 bg-zinc-150/40 border border-zinc-300 rounded-lg text-xs text-zinc-850"><span class="font-bold uppercase tracking-wider block mb-1 text-[10px] text-zinc-500">Note</span>$1</div>', $html);
    $html = preg_replace('/^&gt; (.*?)$/m', '<blockquote class="border-l-2 border-zinc-400 pl-4 py-0.5 my-4 italic text-zinc-500 text-xs">$1</blockquote>', $html);
    
    // List elements
    $html = preg_replace('/^\- (.*?)$/m', '<li class="ml-4 list-disc text-xs text-zinc-700 my-1">$1</li>', $html);
    
    // Assemble text lines
    $lines = explode("\n", $html);
    $processed = array();
    $in_list = false;
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (empty($trimmed)) {
            if ($in_list) {
                $processed[] = '</ul>';
                $in_list = false;
            }
            continue;
        }
        
        if (strpos($trimmed, '<li') === 0) {
            if (!$in_list) {
                $processed[] = '<ul class="space-y-1 my-3">';
                $in_list = true;
            }
            $processed[] = $line;
        } else {
            if ($in_list) {
                $processed[] = '</ul>';
                $in_list = false;
            }
            
            if (strpos($trimmed, '<h') === 0 || strpos($trimmed, '<div') === 0 || strpos($trimmed, '<pre') === 0 || strpos($trimmed, '<blockquote') === 0 || strpos($trimmed, '<table') === 0 || strpos($trimmed, '<ul') === 0) {
                $processed[] = $line;
            } else {
                $processed[] = '<p class="text-xs leading-relaxed text-zinc-700 my-2.5">' . $line . '</p>';
            }
        }
    }
    if ($in_list) {
        $processed[] = '</ul>';
    }
    
    return implode("\n", $processed);
}
}

// ── 4. AJAX Endpoints ─────────────────────────────────────────────────────

/**
 * AJAX: Save Documentation Page
 */
if ( ! function_exists( 'cora_ajax_save_doc_page' ) ) {
function cora_ajax_save_doc_page() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized access.' ) );
    }

    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $t_versions = $wpdb->prefix . 'cora_docs_versions';

    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    $slug = sanitize_title( $_POST['slug'] ?? '' );
    $title = sanitize_text_field( $_POST['title'] ?? '' );
    $content = wp_kses_post( $_POST['content'] ?? '' );
    $category = sanitize_key( $_POST['category'] ?? '' );
    $module_key = isset( $_POST['module_key'] ) && ! empty( $_POST['module_key'] ) ? sanitize_key( $_POST['module_key'] ) : null;
    $status = sanitize_key( $_POST['status'] ?? 'draft' );
    $author_id = get_current_user_id();

    if ( empty( $slug ) || empty( $title ) || empty( $category ) ) {
        wp_send_json_error( array( 'message' => 'Please fill in all required parameters.' ) );
    }

    if ( $id > 0 ) {
        // Fetch old content to check for diff/version creation
        $old_content = $wpdb->get_var( $wpdb->prepare( "SELECT content FROM {$t_pages} WHERE id = %d", $id ) );
        
        $wpdb->update( $t_pages, array(
            'slug' => $slug,
            'title' => $title,
            'content' => $content,
            'category' => $category,
            'module_key' => $module_key,
            'status' => $status,
            'updated_by' => $author_id,
            'updated_at' => current_time('mysql')
        ), array( 'id' => $id ) );

        // If content changed, create version backup
        if ( $old_content !== $content ) {
            $wpdb->insert( $t_versions, array(
                'page_id' => $id,
                'content' => $old_content,
                'version_label' => 'Backup ' . date('M j, Y H:i'),
                'created_by' => $author_id,
                'created_at' => current_time('mysql')
            ));
        }
        $saved_id = $id;
    } else {
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE slug = %s", $slug ) );
        if ( $exists ) {
            wp_send_json_error( array( 'message' => 'Slug already exists. Choose a unique slug.' ) );
        }

        $wpdb->insert( $t_pages, array(
            'slug' => $slug,
            'title' => $title,
            'content' => $content,
            'category' => $category,
            'module_key' => $module_key,
            'status' => $status,
            'created_by' => $author_id,
            'updated_by' => $author_id,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ));
        $saved_id = $wpdb->insert_id;
    }

    wp_send_json_success( array( 'message' => 'Page saved successfully.', 'id' => $saved_id ) );
}
}
add_action( 'wp_ajax_cora_save_doc_page', 'cora_ajax_save_doc_page' );

/**
 * AJAX: Retrieve Version History
 */
if ( ! function_exists( 'cora_ajax_get_doc_history' ) ) {
function cora_ajax_get_doc_history() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized access.' ) );
    }

    global $wpdb;
    $t_versions = $wpdb->prefix . 'cora_docs_versions';
    $page_id = isset( $_GET['page_id'] ) ? intval( $_GET['page_id'] ) : 0;

    $history = $wpdb->get_results( $wpdb->prepare(
        "SELECT v.id, v.version_label, v.created_at, u.display_name 
         FROM {$t_versions} v 
         LEFT JOIN {$wpdb->users} u ON v.created_by = u.ID 
         WHERE v.page_id = %d 
         ORDER BY v.created_at DESC",
        $page_id
    ), ARRAY_A );

    wp_send_json_success( $history );
}
}
add_action( 'wp_ajax_cora_get_doc_history', 'cora_ajax_get_doc_history' );

/**
 * AJAX: Revert Page Version
 */
if ( ! function_exists( 'cora_ajax_revert_doc_page' ) ) {
function cora_ajax_revert_doc_page() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized access.' ) );
    }

    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $t_versions = $wpdb->prefix . 'cora_docs_versions';

    $version_id = isset( $_POST['version_id'] ) ? intval( $_POST['version_id'] ) : 0;
    
    // Fetch version data
    $version = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t_versions} WHERE id = %d", $version_id ), ARRAY_A );
    if ( ! $version ) {
        wp_send_json_error( array( 'message' => 'Version backup not found.' ) );
    }

    // Get current content before reverting, to save it as backup
    $current_page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t_pages} WHERE id = %d", $version['page_id'] ), ARRAY_A );
    
    $author_id = get_current_user_id();

    // Revert target page
    $wpdb->update( $t_pages, array(
        'content' => $version['content'],
        'updated_by' => $author_id,
        'updated_at' => current_time('mysql')
    ), array( 'id' => $version['page_id'] ) );

    // Backup current before reverting
    $wpdb->insert( $t_versions, array(
        'page_id' => $version['page_id'],
        'content' => $current_page['content'],
        'version_label' => 'Backup before revert (' . date('M j H:i') . ')',
        'created_by' => $author_id,
        'created_at' => current_time('mysql')
    ));

    wp_send_json_success( array( 'message' => 'Reverted version successfully.', 'content' => $version['content'] ) );
}
}
add_action( 'wp_ajax_cora_revert_doc_page', 'cora_ajax_revert_doc_page' );

/**
 * AJAX: Publish / Change Status
 */
if ( ! function_exists( 'cora_ajax_publish_doc_page' ) ) {
function cora_ajax_publish_doc_page() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized access.' ) );
    }

    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    $status = sanitize_key( $_POST['status'] ?? '' );

    if ( ! in_array( $status, array( 'draft', 'internal_review', 'approved_internal', 'staged_public', 'public_live' ) ) ) {
        wp_send_json_error( array( 'message' => 'Invalid publish status.' ) );
    }

    $wpdb->update( $t_pages, array(
        'status' => $status,
        'updated_by' => get_current_user_id(),
        'updated_at' => current_time('mysql')
    ), array( 'id' => $id ) );

    wp_send_json_success( array( 'message' => "Publish status updated to: " . str_replace('_', ' ', $status) ) );
}
}
add_action( 'wp_ajax_cora_publish_doc_page', 'cora_ajax_publish_doc_page' );

/**
 * AJAX: Save/Edit Changelog entry
 */
if ( ! function_exists( 'cora_ajax_save_changelog' ) ) {
function cora_ajax_save_changelog() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
    }

    global $wpdb;
    $t_changelog = $wpdb->prefix . 'cora_docs_changelog';

    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    $module_key = isset( $_POST['module_key'] ) && ! empty( $_POST['module_key'] ) ? sanitize_key( $_POST['module_key'] ) : null;
    $version = sanitize_text_field( $_POST['version'] ?? '1.0.0' );
    $status = sanitize_key( $_POST['status'] ?? 'released' );
    $title = sanitize_text_field( $_POST['title'] ?? '' );
    $description = wp_kses_post( $_POST['description'] ?? '' );
    $ticket_id = sanitize_text_field( $_POST['ticket_id'] ?? '' );
    $author_id = get_current_user_id();

    if ( empty( $title ) ) {
        wp_send_json_error( array( 'message' => 'Changelog title is required.' ) );
    }

    $data = array(
        'module_key' => $module_key,
        'version' => $version,
        'status' => $status,
        'title' => $title,
        'description' => $description,
        'ticket_id' => $ticket_id,
        'author_id' => $author_id
    );

    if ( $id > 0 ) {
        $wpdb->update( $t_changelog, $data, array( 'id' => $id ) );
    } else {
        $data['created_at'] = current_time('mysql');
        $wpdb->insert( $t_changelog, $data );
    }

    wp_send_json_success( array( 'message' => 'Changelog entry saved successfully.' ) );
}
}
add_action( 'wp_ajax_cora_save_changelog', 'cora_ajax_save_changelog' );

/**
 * AJAX: Save/Edit API Registry Endpoint
 */
if ( ! function_exists( 'cora_ajax_save_api_endpoint' ) ) {
function cora_ajax_save_api_endpoint() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
    }

    global $wpdb;
    $t_api = $wpdb->prefix . 'cora_docs_api_endpoints';

    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    $method = sanitize_text_field( $_POST['method'] ?? 'GET' );
    $path = sanitize_text_field( $_POST['path'] ?? '' );
    $description = sanitize_textarea_field( $_POST['description'] ?? '' );
    $required_permissions = sanitize_text_field( $_POST['required_permissions'] ?? '' );
    $request_schema = $_POST['request_schema'] ?? '';
    $response_schema = $_POST['response_schema'] ?? '';
    $example = $_POST['example'] ?? '';
    $permission_level = sanitize_key( $_POST['permission_level'] ?? 'admin' );
    $mcp_compatible = isset( $_POST['mcp_compatible'] ) ? intval( $_POST['mcp_compatible'] ) : 0;

    if ( empty( $path ) || empty( $method ) ) {
        wp_send_json_error( array( 'message' => 'Method and Path are required parameters.' ) );
    }

    $data = array(
        'method' => strtoupper( $method ),
        'path' => $path,
        'description' => $description,
        'required_permissions' => $required_permissions,
        'request_schema' => $request_schema,
        'response_schema' => $response_schema,
        'example' => $example,
        'permission_level' => $permission_level,
        'mcp_compatible' => $mcp_compatible,
        'updated_at' => current_time('mysql')
    );

    if ( $id > 0 ) {
        $wpdb->update( $t_api, $data, array( 'id' => $id ) );
    } else {
        $wpdb->insert( $t_api, $data );
    }

    wp_send_json_success( array( 'message' => 'API endpoint reference saved successfully.' ) );
}
}
add_action( 'wp_ajax_cora_save_api_endpoint', 'cora_ajax_save_api_endpoint' );

// ── 5. Auto-Update Event Hooks ────────────────────────────────────────────

/**
 * Triggered when a module status is updated
 */
if ( ! function_exists( 'cora_docs_module_status_trigger' ) ) {
function cora_docs_module_status_trigger( $module_key, $old_status, $new_status, $version ) {
    global $wpdb;
    $t_changelog = $wpdb->prefix . 'cora_docs_changelog';
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    
    $author_id = get_current_user_id() ?: 1;
    $title = "Module " . esc_html($module_key) . " status updated to " . esc_html($new_status);
    $desc = "The status of the " . esc_html($module_key) . " module was updated from " . esc_html($old_status) . " to " . esc_html($new_status) . " (Version " . esc_html($version) . ").";
    
    // Create draft changelog entry
    $wpdb->insert( $t_changelog, array(
        'module_key' => $module_key,
        'version' => $version,
        'status' => 'released',
        'title' => $title,
        'description' => $desc,
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));
    
    // Automatically set page back to draft for super admin review/updating
    $wpdb->update( $t_pages, 
        array( 'status' => 'draft', 'updated_at' => current_time('mysql') ), 
        array( 'module_key' => $module_key )
    );
}
}
add_action( 'cora_module_status_changed', 'cora_docs_module_status_trigger', 10, 4 );

/**
 * Triggered when a feature is marked as complete
 */
if ( ! function_exists( 'cora_docs_feature_completed_trigger' ) ) {
function cora_docs_feature_completed_trigger( $module_key, $feature_name, $version ) {
    global $wpdb;
    $t_changelog = $wpdb->prefix . 'cora_docs_changelog';
    
    $author_id = get_current_user_id() ?: 1;
    $wpdb->insert( $t_changelog, array(
        'module_key' => $module_key,
        'version' => $version,
        'status' => 'released',
        'title' => "Feature Shipped: " . esc_html($feature_name),
        'description' => "Successfully integrated and verified feature: " . esc_html($feature_name) . " in version " . esc_html($version) . ".",
        'author_id' => $author_id,
        'created_at' => current_time('mysql')
    ));
}
}
add_action( 'cora_module_feature_completed', 'cora_docs_feature_completed_trigger', 10, 3 );

/**
 * Triggered when a new module is registered/scaffolded
 */
if ( ! function_exists( 'cora_docs_module_registered_trigger' ) ) {
function cora_docs_module_registered_trigger( $module_key, $title, $version ) {
    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t_pages} WHERE module_key = %s", $module_key ) );
    if ( ! $exists ) {
        $slug = sanitize_title( $module_key );
        $content = "# " . esc_html( $title ) . "\n\nWelcome to the module documentation page for " . esc_html( $title ) . " (v" . esc_html( $version ) . ").\n\n## Module Overview\nDescribe module purpose here.\n\n## Features List\n- Feature 1 (Planned)\n\n## Permissions Reference\n- `administrator`: Full access\n\n## AI Layer Description\nRAG context details.";
        
        $wpdb->insert( $t_pages, array(
            'slug' => $slug,
            'title' => $title,
            'content' => $content,
            'category' => 'modules',
            'module_key' => $module_key,
            'status' => 'draft',
            'created_by' => 1,
            'updated_by' => 1,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ));
    }
}
}
add_action( 'cora_module_registered', 'cora_docs_module_registered_trigger', 10, 3 );

/**
 * Triggered when an API endpoint changes
 */
if ( ! function_exists( 'cora_docs_api_endpoint_trigger' ) ) {
function cora_docs_api_endpoint_trigger( $method, $path, $description, $required_permissions, $request_schema, $response_schema, $example, $mcp_compatible ) {
    global $wpdb;
    $t_api = $wpdb->prefix . 'cora_docs_api_endpoints';
    
    $wpdb->replace( $t_api, array(
        'method' => strtoupper( $method ),
        'path' => $path,
        'description' => $description,
        'required_permissions' => $required_permissions,
        'request_schema' => $request_schema,
        'response_schema' => $response_schema,
        'example' => $example,
        'permission_level' => 'admin',
        'mcp_compatible' => $mcp_compatible ? 1 : 0,
        'updated_at' => current_time('mysql')
    ));
}
}
add_action( 'cora_api_endpoint_changed', 'cora_docs_api_endpoint_trigger', 10, 8 );

/**
 * Intercept /docs/ requests to display public facing documentation
 */
if ( ! function_exists( 'cora_docs_handle_public_route' ) ) {
function cora_docs_handle_public_route() {
    $request_uri = $_SERVER['REQUEST_URI'];
    $home_path = parse_url( home_url(), PHP_URL_PATH ) ?: '';
    $path = substr( $request_uri, strlen( $home_path ) );
    $path = trim( parse_url( $path, PHP_URL_PATH ), '/' );

    $path_parts = explode( '/', $path );

    if ( isset( $path_parts[0] ) && 'docs' === $path_parts[0] ) {
        global $wpdb, $active_page;
        $t_pages = $wpdb->prefix . 'cora_docs_pages';
        $t_changelog = $wpdb->prefix . 'cora_docs_changelog';
        $t_api = $wpdb->prefix . 'cora_docs_api_endpoints';

        // Check if viewing a specific slug
        // e.g. /docs/v1/user-management or /docs/user-management or /docs
        $sub_slug = isset( $path_parts[1] ) ? sanitize_title( $path_parts[1] ) : '';
        
        $version = '';
        if ( preg_match( '/^v[0-9]+$/', $sub_slug ) ) {
            $version = $sub_slug;
            $sub_slug = isset( $path_parts[2] ) ? sanitize_title( $path_parts[2] ) : '';
        }

        // Fetch all pages (including drafts, since we want a single unified public docs portal)
        $pages = $wpdb->get_results(
            "SELECT * FROM {$t_pages} ORDER BY category, title",
            ARRAY_A
        );

        // Fetch changelogs
        $changelogs = $wpdb->get_results(
            "SELECT * FROM {$t_changelog} WHERE status = 'released' ORDER BY created_at DESC",
            ARRAY_A
        );

        // Fetch APIs
        $apis = $wpdb->get_results(
            "SELECT * FROM {$t_api} ORDER BY path, method",
            ARRAY_A
        );

        $active_page = null;
        if ( ! empty( $sub_slug ) ) {
            foreach ( $pages as $p ) {
                if ( $p['slug'] === $sub_slug ) {
                    $active_page = $p;
                    break;
                }
            }
        }
        
        if ( ! $active_page && ! empty( $pages ) ) {
            // Find platform-overview or overview category page
            foreach ( $pages as $p ) {
                if ( $p['slug'] === 'platform-overview' || $p['category'] === 'overview' ) {
                    $active_page = $p;
                    break;
                }
            }
            if ( ! $active_page ) {
                $active_page = $pages[0];
            }
        }

        nocache_headers();
        status_header( 200 );
        
        // Include HTML layout
        include CORA_WORKSPACE_PATH . 'views/view-public-docs.php';
        exit;
    }
}
}

/**
 * AJAX: Simulate Documentation Update triggers
 */
if ( ! function_exists( 'cora_ajax_simulate_doc_trigger' ) ) {
function cora_ajax_simulate_doc_trigger() {
    check_ajax_referer( 'cora_ajax_nonce', 'nonce' );
    if ( ! cora_is_super_owner() ) {
        wp_send_json_error( array( 'message' => 'Unauthorized.' ) );
    }

    $event = sanitize_key( $_POST['event'] ?? '' );

    if ( $event === 'register_module' ) {
        do_action( 'cora_module_registered', 'billing-engine', 'Billing & Invoicing Engine', 'v1.0.0' );
        wp_send_json_success( array( 'message' => 'Simulated: cora_module_registered hook triggered for billing-engine.' ) );
    } elseif ( $event === 'status_changed' ) {
        do_action( 'cora_module_status_changed', 'user-management', 'in_build', 'released', 'v1.2.0' );
        wp_send_json_success( array( 'message' => 'Simulated: cora_module_status_changed hook triggered for user-management.' ) );
    } elseif ( $event === 'feature_completed' ) {
        do_action( 'cora_module_feature_completed', 'user-management', 'SMS OTP verification gateway', 'v1.2.1' );
        wp_send_json_success( array( 'message' => 'Simulated: cora_module_feature_completed hook triggered.' ) );
    } else {
        wp_send_json_error( array( 'message' => 'Invalid event key.' ) );
    }
}
}
add_action( 'wp_ajax_cora_simulate_doc_trigger', 'cora_ajax_simulate_doc_trigger' );

/**
 * AJAX: Fetch page content for public view
 */
if ( ! function_exists( 'cora_ajax_public_get_page' ) ) {
function cora_ajax_public_get_page() {
    $slug = sanitize_title( $_GET['slug'] ?? '' );
    if ( empty( $slug ) ) {
        wp_send_json_error( array( 'message' => 'Missing slug.' ) );
    }

    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    $page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t_pages} WHERE slug = %s", $slug ), ARRAY_A );

    if ( ! $page ) {
        wp_send_json_error( array( 'message' => 'Page not found.' ) );
    }

    // Convert markdown to HTML
    $html = cora_markdown_to_html( $page['content'] );

    wp_send_json_success( array(
        'title' => $page['title'],
        'category' => $page['category'],
        'updated_at' => date( 'M j, Y H:i', strtotime( $page['updated_at'] ) ),
        'html' => $html
    ) );
}
}
add_action( 'wp_ajax_cora_public_get_page', 'cora_ajax_public_get_page' );
add_action( 'wp_ajax_nopriv_cora_public_get_page', 'cora_ajax_public_get_page' );

/**
 * AJAX: Public search documentation pages
 */
if ( ! function_exists( 'cora_ajax_public_search_docs' ) ) {
function cora_ajax_public_search_docs() {
    global $wpdb;
    $t_pages = $wpdb->prefix . 'cora_docs_pages';
    
    $term = isset( $_GET['q'] ) ? sanitize_text_field( $_GET['q'] ) : '';
    if ( strlen( $term ) < 2 ) {
        wp_send_json_success( array() );
        exit;
    }
    
    $like = '%' . $wpdb->esc_like( $term ) . '%';
    $results = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, slug, title, content, category 
         FROM {$t_pages} 
         WHERE title LIKE %s OR content LIKE %s 
         ORDER BY category, title ASC LIMIT 20",
        $like, $like
    ), ARRAY_A );
    
    $grouped = array();
    foreach ( $results as $row ) {
        $category = $row['category'];
        if ( ! isset( $grouped[$category] ) ) {
            $grouped[$category] = array();
        }
        
        // Generate snippet
        $snippet = '';
        $content = strip_tags( $row['content'] );
        $pos = stripos( $content, $term );
        if ( $pos !== false ) {
            $start = max( 0, $pos - 30 );
            $length = 80;
            $snippet = substr( $content, $start, $length );
            if ( $start > 0 ) $snippet = '...' . $snippet;
            if ( strlen( $content ) > $start + $length ) $snippet .= '...';
        } else {
            $snippet = substr( $content, 0, 80 );
            if ( strlen( $content ) > 80 ) $snippet .= '...';
        }
        
        $grouped[$category][] = array(
            'id' => $row['id'],
            'slug' => $row['slug'],
            'title' => $row['title'],
            'snippet' => esc_html( trim( $snippet ) )
        );
    }
    
    wp_send_json_success( $grouped );
    exit;
}
}
add_action( 'wp_ajax_cora_public_search_docs', 'cora_ajax_public_search_docs' );
add_action( 'wp_ajax_nopriv_cora_public_search_docs', 'cora_ajax_public_search_docs' );

/**
 * AJAX: Public query RAG knowledge base for Cora AI chatbot
 */
if ( ! function_exists( 'cora_ajax_public_query_rag' ) ) {
function cora_ajax_public_query_rag() {
    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
    if ( ! wp_verify_nonce( $nonce, 'cora_public_docs_nonce' ) ) {
        wp_send_json_error( array( 'message' => 'Security validation failed.' ) );
    }

    $question = isset( $_POST['question'] ) ? sanitize_text_field( wp_unslash( $_POST['question'] ) ) : '';
    if ( empty( $question ) ) {
        wp_send_json_error( array( 'message' => 'Question is required.' ) );
    }

    global $wpdb;
    $table = $wpdb->prefix . 'cora_docs_pages';
    
    $context_text = '';
    
    if ( cora_table_exists( $table ) ) {
        $keywords = explode( ' ', $question );
        $like_conditions = array();
        $params = array();
        foreach ( $keywords as $kw ) {
            $kw = trim( $kw );
            if ( strlen( $kw ) > 2 ) {
                $like_conditions[] = "(title LIKE %s OR content LIKE %s)";
                $params[] = '%' . $wpdb->esc_like( $kw ) . '%';
                $params[] = '%' . $wpdb->esc_like( $kw ) . '%';
            }
        }
        
        if ( ! empty( $like_conditions ) ) {
            $sql = "SELECT title, content FROM {$table} WHERE (" . implode( ' OR ', $like_conditions ) . ") LIMIT 4";
            $results = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
            if ( $results ) {
                foreach ( $results as $row ) {
                    $context_text .= "Resource: " . $row['title'] . "\nContent: " . wp_strip_all_tags( $row['content'] ) . "\n\n";
                }
            }
        }
    }
    
    $system_prompt = "You are Cora AI, a virtual consultant and expert developer advisor for the Cora Platform.
Your goal is to make discussions completely effortless for the user. Do not write long paragraphs or essays.
Follow these strict output rules:
1. ACT AS A CONSULTANT: Provide a practical, direct, step-by-step guide to solve the user's query.
2. BE EXTREMELY CONCISE: Limit your entire response to a maximum of 3-4 short, clear bullet points or steps (max 100 words).
3. ACTION-FIRST: Start immediately with the steps/actions. Do not include introductory text, conversational fluff, or sign-offs.
4. GENERAL KNOWLEDGE FALLBACK: If the retrieved context below is insufficient or irrelevant, use your general platform knowledge (bookings, crew scheduler, geofencing, invoice GST structures, e-signing vault registry, white-labeled Elementor themes, PWA wizard, etc.) to give the steps. Do not say you cannot answer.

Retrieved Context:
" . ( $context_text ? $context_text : "No specific documentation context was found in the RAG database." );

    $reply = '';
    
    if ( function_exists( 'cora_rag_call_ai_api' ) ) {
        $reply = cora_rag_call_ai_api( "Question: " . $question, $system_prompt );
    }
    
    if ( empty( $reply ) ) {
        $reply = "I parsed the context but could not reach the LLM provider. The Cora platform features active modules: Bookings (calendar & client slots), Leads (Kanban board), Financials (CGST/SGST ledger invoice splits), Document Vault (e-sign contracts), and CRM. Please configure your Gemini API Key in the RAG Knowledge base settings to enable full chatbot interactivity.";
    }

    wp_send_json_success( array(
        'reply' => $reply
    ) );
    exit;
}
}
add_action( 'wp_ajax_cora_public_query_rag', 'cora_ajax_public_query_rag' );
add_action( 'wp_ajax_nopriv_cora_public_query_rag', 'cora_ajax_public_query_rag' );

// ── 7. New Pages Registry (v3.2.46) ──────────────────────────────────────

function cora_docs_get_new_pages_v3246() {
    return array(

        // ── Overview ──────────────────────────────────────────────────────
        array(
            'slug'     => 'architecture-overview',
            'title'    => 'Architecture & Stack',
            'category' => 'overview',
            'content'  => "# Architecture & Stack\n\nCora is an enterprise-grade PHP SaaS platform. All tenant workspaces, modules, and REST routes live inside a modular PHP framework architecture deployed on a high-performance VPS.\n\n## Routing Layer\nAll inbound HTTP requests pass through the framework routing lifecycle. Routes are matched by inspecting the request URI path segments:\n- `/workspace/**` → Workspace SPA shell\n- `/docs/**` → Public developer documentation\n- `/cora-manifest.json` → Dynamic PWA manifest\n- `/cora-service-worker.js` → Service Worker served at root scope\n- `/api/v1/**` → JSON REST endpoints\n\n## Database Layer\nCora uses custom relational database tables with the `cora_` prefix. All queries are tenant-scoped by `agency_id` to enforce multi-tenant data isolation.\n\n## AI Layer\n- **RAG**: Retrieval-Augmented Generation via `cora_rag_knowledge` table. Syncs agency documents for in-context retrieval.\n- **LLM**: Google Gemini Flash and Anthropic Claude Sonnet via REST API calls from PHP.\n- **MCP**: JSON-RPC 2.0 over WebSockets, allowing external LLM agents to call Cora AJAX actions with inherited role permissions.\n\n## PWA Layer (v3.2.46)\n- **Manifest**: Dynamically generated via `/cora-manifest.json` with agency-branded icons.\n- **Service Worker**: Registered at root scope. Handles offline caching (Cache-First for assets, Network-First for API), background push notification delivery, and click-to-focus routing.\n- **VAPID**: ES256 self-signed JWT push authorization for all Web Push subscriptions."
        ),
        array(
            'slug'     => 'workspace-roles',
            'title'    => 'Roles & Permissions',
            'category' => 'overview',
            'content'  => "# Roles & Permissions\n\nCora enforces a 4-tier role hierarchy across all workspace tenants.\n\n## Role Levels\n- **`cora_super_admin`**: Global super administrator. Access to all workspaces, billing, system settings, and plugin configurations. Cannot be restricted.\n- **`owner`**: Tenant workspace owner. Creates and manages roles, security matrix, API keys, and authorizes third-party integrations.\n- **`administrator`**: Full read/write on all operational modules (CRM, Financials, Media, Crew). Cannot alter core tenant DB settings or billing.\n- **`cora_member` / `cora_manager`**: Scoped per the active Security Permissions Matrix set by the owner.\n- **`cora_branch_manager`**: Read-only across all modules. Cannot create, edit, or delete any records.\n\n## Security Permissions Matrix\nOwners define capability grants per module section:\n\n| Section | Capabilities |\n|---|---|\n| CRM Leads | view_leads, edit_leads, delete_leads |\n| Financials | view_invoices, create_invoices, mark_paid |\n| Crew Scheduler | view_crew, assign_shifts, manage_crew |\n| Document Vault | upload_docs, sign_docs, share_docs |\n| Canvas Builder | view_canvas, publish_theme |\n\n## Access Control Implementation\nAll AJAX handlers gate access using `cora_is_super_owner()`, `current_user_can()`, and agency-level `agency_id` filtering on all database queries."
        ),

        // ── CRM ────────────────────────────────────────────────────────────
        array(
            'slug'     => 'crm-client-tasks',
            'title'    => 'Client Task Manager',
            'category' => 'crm',
            'content'  => "# Client Task Manager\n\nThe Client Task Manager enables agencies to assign, track, and communicate deliverables directly to clients through a dedicated task board integrated into the CRM.\n\n## Overview\nTasks are structured as deliverables linked to a CRM lead or contact. Each task has a priority level, deadline, assignee, and real-time status.\n\n## Task Lifecycle\n1. **Created**: Task assigned by admin, visible to client in portal.\n2. **In Progress**: Assignee marks task as started.\n3. **Review**: Submitted for client approval or internal review.\n4. **Completed**: Signed off by admin or client.\n5. **Overdue**: Auto-flagged when deadline passes without completion.\n\n## Push Notifications (v3.2.46)\nHigh-priority task updates (status change, new assignments, deadline approaching) now trigger Web Push notifications to subscribed agency staff via the VAPID push system.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_get_client_tasks` | `nonce`, `lead_id` | Returns all tasks for a lead |\n| `cora_ajax_create_client_task` | `nonce`, `lead_id`, `title`, `priority`, `due_date` | Creates a new task |\n| `cora_ajax_update_task_status` | `nonce`, `task_id`, `status` | Updates task status and triggers push notification |\n\n## Database Schema\n### `cora_client_tasks`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `lead_id` | bigint | Associated CRM lead |\n| `title` | varchar(255) | Task title |\n| `status` | varchar(50) | pending/in_progress/completed/overdue |\n| `priority` | varchar(20) | low/medium/high/urgent |\n| `due_date` | date | Deadline |\n| `assigned_to` | bigint | System user ID |"
        ),

        // ── Finance AI Co-founder (v3.4.44) ───────────────────────────────
        array(
            'slug'     => 'finance-ai-cofounder',
            'title'    => 'Finance AI Co-founder',
            'category' => 'finance',
            'content'  => "# Finance AI Co-founder\n\nStarting in v3.4.44, Cora replaces traditional static accounting dashboards with an **AI Financial Co-founder** that watches cash flow, alerts founders to revenue risks, and prepares next actions.\n\n## Core Pillars\n- **Cora's Morning Take**: Proactive plain-English analysis comparing liquid cash buffer with monthly operational burn rate.\n- **Action-Oriented Attention Cards**: Surfaces overdue invoices with 1-click multi-channel follow-ups (Email / WhatsApp Direct).\n- **Cash Flow Trajectory (Chart.js)**: 6-month historical inflow/outflow ledger combined with a 90-day predictive runway forecast.\n- **Ask Cora Copilot**: Context-aware AI assistant answering queries on owner draw limits, upcoming renewals, and tax liabilities.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_finance_ask_cora` | `security`, `query` | AI copilot query processor |\n| `cora_ajax_finance_send_reminder` | `security`, `invoice_id`, `recipient_email`, `tone`, `message` | Dispatches client payment reminder |"
        ),
        array(
            'slug'     => 'finance-gst-invoicing',
            'title'    => 'Indian GST Invoicing & Vault Linking',
            'category' => 'finance',
            'content'  => "# Indian GST Invoicing & Vault Linking\n\nThe 3-step GST Invoice Creator allows solo founders to issue compliant invoices with automatic tax detection and E-Sign contract linking.\n\n## Multi-Step Creator\n1. **Client & Place of Supply**: Auto-populates contact details from CRM (`wp_cora_leads`) and determines Intra-State (CGST 9% + SGST 9%) vs Inter-State (IGST 18%).\n2. **SAC Codes & Line Items**: Dynamic line item calculation with Service Accounting Codes (`998386`, `998314`) and real-time tax math summary.\n3. **Terms & Document Vault**: Links legal E-Sign agreements from the Document Vault directly to invoice payment milestones.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_create_invoice` | `security`, `client_name`, `client_email`, `total_amount`, `tax_pct`, `line_items` | Generates new GST invoice and stores in `cora_invoices` |\n| `cora_ajax_finance_record_income` | `security`, `client_name`, `amount`, `date`, `invoice_id` | Reconciles invoice balance and writes inflow to master ledger |"
        ),
        array(
            'slug'     => 'finance-deal-simulator',
            'title'    => 'Deal Feasibility Simulator',
            'category' => 'finance',
            'content'  => "# Deal Feasibility Simulator\n\nThe Deal Feasibility Simulator evaluates prospective project quotes against direct subcontractor costs, equipment rentals, travel expenses, and mandatory 18% GST reserves before a founder signs a client contract.\n\n## Scoring Model\n- **Net Profit & Margin %**: Calculates exact bottom-line take-home profit.\n- **AI Feasibility Verdict**: Evaluates margins against agency profitability benchmarks (High Margin Go > 45%, Moderate Margin Review 30-45%, Low Margin Warning < 30%).\n- **1-Click Conversion**: Generates a pre-filled client invoice proposal directly from approved simulator numbers."
        ),
        array(
            'slug'     => 'finance-reports',
            'title'    => 'Tax, GST & Accountant Pack',
            'category' => 'finance',
            'content'  => "# Tax, GST & Accountant Pack\n\nThe Financials module automates tax reserve calculations and provides 1-click export packs for external Chartered Accountants (CAs).\n\n## Features\n- **Output vs Input GST**: Compares collected GST against Input Tax Credit (ITC) from eligible expense receipts.\n- **Quarterly Advance Tax Reserve**: Recommended 15% income tax reserve allocation.\n- **Customizable Expense Categories**: User-defined category creation via `+ Custom` with server persistence.\n- **1-Click Accountant Export**: Downloads a bundled ZIP with itemized CSV ledgers formatted for CA audit.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_finance_save_category` | `security`, `category` | Saves user custom category |\n| `cora_ajax_finance_export_pack` | `security`, `period`, `include_invoices`, `include_expenses` | Generates CA ZIP audit pack |"
        ),

        // ── Operations ────────────────────────────────────────────────────
        array(
            'slug'     => 'ops-crew-scheduler',
            'title'    => 'Crew Scheduler',
            'category' => 'operations',
            'content'  => "# Crew Scheduler\n\nThe Crew Scheduler is a visual shift management board for scheduling and tracking agency team members across bookings and events.\n\n## Architecture\nThe scheduler is built as a custom calendar grid rendering crew member availability across days/weeks. Shifts are stored in `cora_crew_shifts` and linked to both a user and a booking/event record.\n\n## Features\n- **Drag-and-drop shift assignment**: Assign crew members to bookings visually.\n- **Availability matrix**: Set crew member working hours and days off.\n- **Conflict detection**: Prevents double-booking of crew across overlapping shifts.\n- **Mobile-first view**: Card-based compact view on mobile.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_get_crew_schedule` | `nonce`, `week_start` | Returns all shifts for a given week |\n| `cora_ajax_assign_crew_shift` | `nonce`, `booking_id`, `user_id`, `date`, `time_start`, `time_end` | Assigns a shift |\n| `cora_ajax_remove_crew_shift` | `nonce`, `shift_id` | Removes a shift assignment |\n\n## Database Schema\n### `cora_crew_shifts`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `user_id` | bigint | Assigned crew member |\n| `booking_id` | bigint | Linked booking |\n| `shift_date` | date | Date of shift |\n| `time_start` | time | Shift start time |\n| `time_end` | time | Shift end time |\n| `role_label` | varchar(100) | Crew role for this shift |"
        ),
        array(
            'slug'     => 'ops-equipment',
            'title'    => 'Equipment Management',
            'category' => 'operations',
            'content'  => "# Equipment Management\n\nThe Equipment module tracks physical gear inventory, assignments, condition logs, and maintenance schedules.\n\n## Features\n- **Inventory Registry**: Full gear catalog with serial numbers, purchase dates, and current condition.\n- **Assignment Tracking**: Link equipment items to bookings and shoots.\n- **Maintenance Logs**: Record service events, repairs, and replacements.\n- **Availability Calendar**: Visual view of which items are booked vs. available.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_get_equipment_list` | `nonce` | Returns all equipment records |\n| `cora_ajax_add_equipment` | `nonce`, `name`, `serial`, `condition`, `category` | Adds new equipment item |\n| `cora_ajax_assign_equipment` | `nonce`, `equipment_id`, `booking_id` | Assigns equipment to a booking |\n| `cora_ajax_log_maintenance` | `nonce`, `equipment_id`, `note`, `date` | Adds maintenance log entry |\n\n## Database Schema\n### `cora_equipment`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `name` | varchar(255) | Equipment name |\n| `serial_number` | varchar(100) | Serial/model number |\n| `category` | varchar(100) | camera/lens/lighting/audio/etc. |\n| `condition` | varchar(50) | excellent/good/fair/damaged |\n| `purchase_date` | date | Date of purchase |\n| `notes` | text | Additional notes |"
        ),
        array(
            'slug'     => 'ops-event-timeline',
            'title'    => 'Event Timeline',
            'category' => 'operations',
            'content'  => "# Event Timeline\n\nThe Event Timeline module provides a chronological view of all bookings, shoots, and milestones for the agency, enabling high-level scheduling awareness.\n\n## Features\n- **Gantt-style timeline**: Visualize overlapping bookings across a date range.\n- **Filter by status**: View confirmed, tentative, completed, or cancelled events.\n- **Quick preview**: Click any event to see client, crew, equipment, and financial summary.\n\n## Integration\nTimeline data is pulled from the `cora_bookings` table and cross-referenced with crew shifts and equipment assignments to provide a complete operational picture per event."
        ),

        // ── Media & Assets ────────────────────────────────────────────────
        array(
            'slug'     => 'media-library',
            'title'    => 'Media Library',
            'category' => 'media',
            'content'  => "# Media Library\n\nThe Cora Media Library is a workspace-scoped asset management system that provides a tenant-isolated, AI-enhanced file management interface.\n\n## Features\n- **Folder Organization**: Hierarchical folder tree for organizing shoots, projects, and brands.\n- **AI Tagging**: Auto-generated semantic tags on uploaded images using the Gemini Vision API.\n- **Client Sharing**: Generate time-limited secure share links for client gallery delivery.\n- **Bulk Operations**: Select multiple files for batch download, delete, or move.\n- **Search**: Full-text and tag-based search across the entire media library.\n\n## Architecture\nMedia metadata is stored in `cora_media_assets`. Files are stored in protected storage partitions. The library renders as a responsive grid SPA inside the workspace sidebar navigation.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_get_media_library` | `nonce`, `folder_id`, `page` | Paginated media list |\n| `cora_ajax_upload_media` | `nonce`, `file`, `folder_id` | Handles file upload |\n| `cora_ajax_delete_media` | `nonce`, `media_id` | Permanently deletes a file |\n| `cora_ajax_share_media` | `nonce`, `media_id`, `expiry_days` | Generates secure share link |\n\n## Database Schema\n### `cora_media_assets`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `wp_attachment_id` | bigint | File asset ID |\n| `folder_id` | bigint | Parent folder |\n| `title` | varchar(255) | Display name |\n| `tags` | text | JSON array of AI-generated tags |\n| `file_type` | varchar(50) | image/video/pdf/raw |\n| `file_size` | bigint | File size in bytes |"
        ),
        array(
            'slug'     => 'media-editor',
            'title'    => 'Media Editor',
            'category' => 'media',
            'content'  => "# Media Editor\n\nThe Media Editor provides in-browser image editing and annotation capabilities for agency-uploaded files.\n\n## Features\n- **Crop & Resize**: Aspect-ratio-locked crop presets (1:1, 4:3, 16:9) or freeform.\n- **Rotate & Flip**: 90-degree rotations, horizontal/vertical flip.\n- **Annotation Canvas**: Draw text labels, arrows, and highlights for feedback and delivery.\n- **Export**: Save edits as a new copy or overwrite the original.\n\n## Implementation\nThe editor is built on the HTML5 Canvas API with a custom rendering pipeline. It is accessible from within the Media Library by clicking any image asset."
        ),
        array(
            'slug'     => 'media-gallery',
            'title'    => 'Public Gallery Portal',
            'category' => 'media',
            'content'  => "# Public Gallery Portal\n\nThe Public Gallery Portal is a client-facing hosted gallery page that allows agencies to share curated photo/video collections with their clients via a secure URL.\n\n## Features\n- **Password Protection**: Optional PIN or password access to gallery.\n- **Download Control**: Toggle whether clients can download individual files or albums.\n- **Branded Landing Page**: Agency logo, header, and watermark configuration.\n- **Review & Approval**: Clients can mark favorite/approved selects directly in the gallery.\n\n## URL Structure\nGallery URLs are served at `/gallery/{share-hash}`, resolved through the custom routing layer in `cora-workspace.php`."
        ),

        // ── Client Portal ─────────────────────────────────────────────────
        array(
            'slug'     => 'portal-client-tasks',
            'title'    => 'Client Task Manager (Portal)',
            'category' => 'client-portal',
            'content'  => "# Client Task Manager — Portal View\n\nThe client-facing task interface allows external clients to view their assigned deliverables and provide approvals or comments without needing a full workspace login.\n\n## Access\nClients access their task portal via a magic-link URL generated by the agency. No password is required — authentication uses a one-time URL token.\n\n## Capabilities\n- View all tasks assigned to their project\n- Mark tasks as reviewed/approved\n- Leave inline comments per task\n- Download attached deliverables"
        ),
        array(
            'slug'     => 'portal-forms',
            'title'    => 'Forms Builder',
            'category' => 'client-portal',
            'content'  => "# Forms Builder\n\nThe Forms Builder is a no-code drag-and-drop form creation system for lead capture, client onboarding questionnaires, and contract agreements.\n\n## Field Types\n- Text, Email, Phone, Number\n- Dropdown Select, Multi-checkbox, Radio\n- Date Picker, File Upload\n- Signature Pad\n- GST Calculation Block\n\n## Features\n- **Multi-step Forms**: Group fields into tabbed steps with progress indicators.\n- **Conditional Logic**: Show/hide fields based on previous answers.\n- **E-Sign Integration**: Embed a signature pad and pipe submissions directly into the Document Vault.\n- **CRM Mapping**: Auto-create a CRM lead from a form submission.\n- **Webhook Export**: POST form responses to external endpoints (Zapier, Make, custom APIs).\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_get_forms_list` | `nonce` | Returns all forms for the agency |\n| `cora_ajax_create_form` | `nonce`, `title`, `fields_json` | Creates a new form |\n| `cora_ajax_get_form_submissions` | `nonce`, `form_id` | Returns submissions for a form |\n\n## Database Schema\n### `cora_forms`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `title` | varchar(255) | Form title |\n| `fields` | longtext | JSON schema of all fields |\n| `settings` | longtext | JSON settings (redirects, webhooks, CRM mapping) |\n| `status` | varchar(50) | draft/active/archived |"
        ),
        array(
            'slug'     => 'portal-reviews',
            'title'    => 'Review Acquisition',
            'category' => 'client-portal',
            'content'  => "# Review Acquisition\n\nThe Review Acquisition module automates post-service review campaigns to collect Google, Facebook, and platform-native testimonials from clients.\n\n## Workflow\n1. **Trigger**: Admin marks a booking as completed.\n2. **Delay**: Configurable wait period (1–7 days) before sending review request.\n3. **Channel**: Email or WhatsApp review invitation sent automatically.\n4. **Redirect**: Positive sentiment (4–5 stars) redirects to Google Business Profile. Negative sentiment (1–3 stars) routes to an internal feedback form.\n5. **Dashboard**: Aggregated review scores and testimonial cards in the workspace.\n\n## Integration\n- Syncs collected reviews to **Google Business Profile** via the GBP Review API.\n- Displays public testimonials on agency's Canvas-built website via shortcode.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_send_review_request` | `nonce`, `booking_id`, `channel` | Sends review invitation |\n| `cora_ajax_get_review_stats` | `nonce` | Returns aggregate review scores |"
        ),
        array(
            'slug'     => 'portal-comments',
            'title'    => 'Comments System',
            'category' => 'client-portal',
            'content'  => "# Comments System\n\nThe Comments module provides threaded inline commenting across deliverables, tasks, and document vault items, enabling async collaboration between agency teams and clients.\n\n## Features\n- **Inline Comments**: Attach comments to specific media files, tasks, or document sections.\n- **@Mentions**: Tag specific workspace users for notifications.\n- **Resolved State**: Mark comment threads as resolved to maintain clean audit trails.\n- **Client Access**: Clients can comment via the portal without a platform login barrier.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_post_comment` | `nonce`, `entity_type`, `entity_id`, `message` | Posts a comment |\n| `cora_ajax_resolve_comment` | `nonce`, `comment_id` | Marks comment as resolved |\n| `cora_ajax_get_comments` | `nonce`, `entity_type`, `entity_id` | Returns all comments for an entity |"
        ),

        // ── Document Vault ────────────────────────────────────────────────
        array(
            'slug'     => 'vault-overview',
            'title'    => 'Vault Overview',
            'category' => 'vault',
            'content'  => "# Document Vault — Overview\n\nThe Document Vault is a secure, agency-scoped document management and e-signature registry. It is the centerpiece of Cora's legal and compliance workflow.\n\n## Architecture\nVault documents are stored as secure platform file attachments with metadata in `cora_workspace_vault_docs`. Each document has a full lifecycle from draft through e-signature to archived.\n\n## Document Lifecycle\n1. **Draft**: Created, edited, or uploaded by agency.\n2. **Staged**: Shared with client for review via a secure share link.\n3. **Signed**: Client applies digital signature through the e-sign pad.\n4. **Archived**: Final signed copy stored with a PDF watermark and timestamp.\n\n## Document Types\n- **Contracts**: Service agreements, NDAs, model releases.\n- **Invoices**: Linked to the Financials module.\n- **GST Certificates**: Generated from the GST Math Engine.\n- **Custom PDFs**: Upload any PDF for client e-signature.\n\n## Multi-tenant Isolation\nAll vault queries filter by `agency_id`. Documents from one tenant are never accessible to another."
        ),
        array(
            'slug'     => 'vault-esign',
            'title'    => 'E-Sign Registry',
            'category' => 'vault',
            'content'  => "# E-Sign Registry\n\nThe E-Sign Registry implements a 5-step guided signing workflow with GST verification, legally-compliant digital signature capture, and PDF rendering.\n\n## 5-Step Wizard\n1. **Details**: Document title, parties, and description.\n2. **Terms**: Full document preview with scroll-to-bottom acknowledgment requirement.\n3. **GST Math**: Real-time CGST/SGST/IGST breakdown verification.\n4. **E-Sign**: Canvas-based signature pad with typed name alternative.\n5. **Complete**: Timestamped signed PDF generated and stored.\n\n## Signature Capture\nSignatures are captured as base64 PNG via the HTML5 Canvas API and embedded into a server-rendered PDF alongside the document body.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_sign_document` | `nonce`, `doc_id`, `signature_data`, `signer_name` | Records e-signature and generates PDF |\n| `cora_ajax_get_vault_documents` | `nonce` | Returns all vault documents for the agency |\n| `cora_ajax_share_document_email` | `nonce`, `doc_id`, `recipient_email` | Emails secure sign link to client |\n\n## Database Schema\n### `cora_workspace_vault_docs`\n| Column | Type | Description |\n|---|---|---|\n| `id` | varchar(36) | UUID Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `title` | varchar(255) | Document title |\n| `status` | varchar(50) | draft/staged/signed/archived |\n| `file_url` | varchar(500) | Signed PDF URL |\n| `signed_at` | datetime | Signature timestamp |\n| `signer_name` | varchar(255) | Signatory full name |\n| `secured_shares` | longtext | JSON array of share tokens |"
        ),
        array(
            'slug'     => 'vault-storage',
            'title'    => 'Document Storage',
            'category' => 'vault',
            'content'  => "# Document Storage\n\nThe Document Storage layer handles all file persistence, retrieval, and secure access control within the Vault.\n\n## Storage Backend\nFiles are stored in protected vault storage (`/uploads/cora-vault/{agency_id}/`). Each file is inaccessible directly — all downloads are routed through a PHP proxy that verifies agency_id scope before serving the binary.\n\n## Features\n- **Versioning**: Every re-upload creates a versioned snapshot.\n- **Encryption at Rest**: Sensitive PDFs can be optionally AES-256 encrypted.\n- **Expiring Links**: Secure share URLs include a hash and expiry timestamp.\n- **Audit Log**: All access events (view, download, sign) are logged to `cora_vault_audit_log`."
        ),

        // ── Communications ────────────────────────────────────────────────
        array(
            'slug'     => 'comms-email-studio',
            'title'    => 'Email Studio',
            'category' => 'communications',
            'content'  => "# Email Studio\n\nThe Email Studio is an SMTP-backed outbound email marketing and transactional messaging system for agencies.\n\n## Features\n- **Template Builder**: Drag-and-drop HTML email builder with agency branding.\n- **Sequences**: Multi-step drip campaigns with configurable delays.\n- **Transactional Triggers**: Auto-send emails on booking confirmation, invoice creation, and review requests.\n- **Personalization Tokens**: `{{client_name}}`, `{{booking_date}}`, `{{invoice_amount}}`.\n- **Open & Click Tracking**: Pixel-based open tracking and link click analytics.\n\n## SMTP Configuration\nEmail is sent via the SMTP server configured in Workspace Settings. Supports Gmail, Outlook, SendGrid, and Mailgun relay.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_send_email` | `nonce`, `to`, `subject`, `template_id`, `variables` | Sends a templated email |\n| `cora_ajax_get_email_templates` | `nonce` | Returns all email templates |\n| `cora_ajax_create_email_sequence` | `nonce`, `name`, `steps_json` | Creates a drip sequence |"
        ),
        array(
            'slug'     => 'comms-comments',
            'title'    => 'Comments Thread',
            'category' => 'communications',
            'content'  => "# Comments Thread\n\nSee **Comments System** in the Client Portal section for full documentation. The Communications module exposes the same comment infrastructure from the agency's internal workflow perspective.\n\n## Additional Features for Agency Staff\n- **Notification digests**: Daily or real-time digest emails for unread comments.\n- **Team assignment**: Route comment threads to specific team members.\n- **Internal notes**: Private comment mode visible only to agency staff, hidden from clients."
        ),
        array(
            'slug'     => 'comms-push-notifications',
            'title'    => 'Push Notifications (VAPID)',
            'category' => 'communications',
            'content'  => "# Push Notifications — VAPID Implementation\n\nShipped in **v3.2.46**, Cora's Web Push system delivers real-time alerts to subscribed agency staff on desktop and mobile browsers without requiring the app to be open.\n\n## Architecture\nCora implements the W3C Web Push Protocol using Voluntary Application Server Identification (VAPID) for authentication.\n\n## Flow\n1. **Key Generation**: On plugin activation, a VAPID ES256 key pair is generated and stored in `wp_options`.\n2. **Subscription**: The service worker registers a push subscription with the browser's push service (FCM for Chrome, Mozilla for Firefox). The subscription endpoint + auth keys are stored via the REST API.\n3. **Notification Dispatch**: PHP constructs a JWT signed with the private VAPID key, sends an HTTP POST to the browser's push service endpoint.\n4. **Service Worker**: Receives the `push` event, fetches notification details from the REST API, displays the notification.\n5. **Click Handler**: `notificationclick` event focuses the workspace or navigates to the relevant module.\n\n## REST API Endpoints\n| Method | Path | Description |\n|---|---|---|\n| POST | `/wp-json/cora-pwa/v1/save-subscription` | Stores a new push subscription |\n| GET | `/wp-json/cora-pwa/v1/get-notification` | Returns pending notification data for service worker |\n\n## Trigger Events\nPush notifications are automatically dispatched on:\n- New CRM lead saved\n- Booking/showing record created\n- High-priority client task updated\n\n## VAPID Signature (PHP)\nCora uses a self-contained ASN.1 DER-encoded ES256 JWT generator without requiring any external PHP extension."
        ),

        // ── Content & SEO ─────────────────────────────────────────────────
        array(
            'slug'     => 'content-suite',
            'title'    => 'Content Suite',
            'category' => 'content',
            'content'  => "# Content Suite\n\nThe Content Suite is an AI-powered content creation and publishing hub for agencies managing social media, blog posts, and marketing copy.\n\n## Features\n- **AI Content Generation**: Generate captions, blog posts, and email copy using the configured LLM (Gemini/Claude).\n- **WhatsApp-Style AI Chat**: Conversational short-bubble chat interface (max 2-3 sentences per bubble) designed for quick founder decisions.\n- **RCS Card Formatter**: Automatically parses structured lists and action recommendations into neat checklist cards with vector checkmarks and gray borders.\n- **Real-Time Credits Widget**: Displays session token credit usage in a sticky progress bar synchronized with `localStorage` (`cora_ai_credits_used`).\n- **Width-Locked Suggestions Toggle**: Supports collapsing the suggestions sidebar (saving state to `localStorage` under `cora_suggestions_collapsed`) and applies a locked width grid system (`max-w-[720px]` open, `max-w-[500px]` collapsed).\n- **Clean Drawer Redirects**: Strips URL query parameters (`action` and `post_id`) before reload redirection to ensure the slide-out editor drawer closes on save, submission, or approval.\n- **Content Calendar**: Visual monthly publishing calendar.\n- **Platform Publishing**: Direct publish to Instagram (via Meta API), LinkedIn, and native blog posts.\n- **Brand Voice**: Per-agency brand voice configuration saved to the RAG layer for consistent AI tone.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_generate_content` | `nonce`, `type`, `prompt`, `brand_voice` | Generates AI content |\n| `cora_ajax_schedule_post` | `nonce`, `content_id`, `platform`, `publish_at` | Schedules a post |\n| `cora_ajax_get_content_calendar` | `nonce`, `month`, `year` | Returns publishing calendar |"
        ),
        array(
            'slug'     => 'content-seo-geo',
            'title'    => 'SEO & GEO Inspector',
            'category' => 'content',
            'content'  => "# SEO & GEO Inspector\n\nThe SEO & GEO Inspector audits agency website pages for both traditional Search Engine Optimization (SEO) and Generative Engine Optimization (GEO) — optimizing content for retrieval by AI language model search engines.\n\n## SEO Audit Features\n- Meta title and description validation\n- H1/H2/H3 hierarchy checker\n- Image alt text coverage\n- Page load performance score\n- Schema.org structured data detection\n\n## GEO Optimization Features\n- Answer-style content density scoring\n- Entity recognition and knowledge graph alignment\n- Citation-friendly paragraph formatting suggestions\n- FAQ schema generator for voice and AI search\n\n## Implementation\nAudit scans are run via server-side curl requests against the agency's Canvas-published pages. Results are stored per-page in `cora_seo_audits`."
        ),
        array(
            'slug'     => 'content-google-profile',
            'title'    => 'Google Business Profile',
            'category' => 'content',
            'content'  => "# Google Business Profile\n\nThe Google Business Profile module connects the agency's Google Business listing directly to the Cora workspace, enabling centralized management of business info, posts, Q&A, and review responses.\n\n## Features\n- **Profile Sync**: Pull current business name, address, hours, and categories.\n- **Post Publisher**: Create Google Business Posts (offers, events, updates) directly from Cora.\n- **Review Monitor**: View new reviews with AI-suggested response drafts.\n- **Photo Upload**: Upload photos to the Google listing from the Media Library.\n- **Q&A Manager**: Answer questions from the Google Maps listing panel.\n\n## OAuth Integration\nConnection uses Google's OAuth 2.0 flow with Business Profile API scopes. Tokens are stored encrypted in `wp_options`."
        ),

        // ── AI & Automation ────────────────────────────────────────────────
        array(
            'slug'     => 'ai-rag-knowledge-base',
            'title'    => 'RAG Knowledge Base',
            'category' => 'ai',
            'content'  => "# RAG Knowledge Base\n\nThe RAG (Retrieval-Augmented Generation) Knowledge Base stores agency-specific reference material that is automatically injected into AI context windows for accurate, personalized responses.\n\n## How It Works\n1. **Ingestion**: Agency documents, SOPs, FAQs, and client notes are uploaded or synced into `cora_rag_knowledge`.\n2. **Chunking**: Long documents are split into 512-token chunks with overlapping windows.\n3. **Retrieval**: On each AI query, the top-N most relevant chunks are fetched using keyword overlap scoring.\n4. **Augmentation**: Retrieved context is prepended to the system prompt before the LLM call.\n\n## Sync Sources\n- Document Vault items (contracts, SOPs)\n- Manual knowledge entries (FAQs, pricing, policies)\n- Google Business Profile reviews and Q&A\n\n## Database Schema\n### `cora_rag_knowledge`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `title` | varchar(255) | Document title |\n| `content` | longtext | Full text content |\n| `source` | varchar(100) | vault/manual/google_profile |\n| `indexed_at` | datetime | Last indexed timestamp |"
        ),

        // ── Settings & Tools ──────────────────────────────────────────────
        array(
            'slug'     => 'settings-audit-panel',
            'title'    => 'Audit Panel',
            'category' => 'settings',
            'content'  => "# Audit Panel\n\nThe Audit Panel provides a complete, tamper-evident log of all user actions and system events across the workspace.\n\n## Logged Events\n- User logins and session terminations\n- CRM record creates, updates, and deletes\n- Document vault access, downloads, and signatures\n- Financial record mutations\n- Permission matrix changes\n- API token rotations\n- MCP gateway connections\n\n## Features\n- **Date range filtering**: Narrow logs by custom date range.\n- **User filter**: View audit trail for a specific workspace user.\n- **Action type filter**: Filter by module or action category.\n- **Export**: Download full audit log as CSV for compliance reporting.\n\n## Database Schema\n### `cora_audit_log`\n| Column | Type | Description |\n|---|---|---|\n| `id` | bigint | Primary Key |\n| `agency_id` | bigint | Tenant isolation |\n| `user_id` | bigint | Acting user |\n| `action` | varchar(100) | Action label |\n| `entity_type` | varchar(50) | lead/document/invoice/etc. |\n| `entity_id` | bigint | Affected record |\n| `meta` | longtext | JSON details |\n| `created_at` | datetime | Event timestamp |"
        ),
        array(
            'slug'     => 'settings-roles',
            'title'    => 'Role Management',
            'category' => 'settings',
            'content'  => "# Role Management\n\nThe Role Management view allows workspace owners to define custom roles and assign fine-grained capability permissions to each role.\n\n## Built-in Roles\n- `cora_super_admin` — Global admin (immutable)\n- `owner` — Tenant owner (immutable)\n- `administrator` — Full workspace access\n- `cora_manager` — Configurable by owner\n- `cora_member` — Configurable by owner\n- `cora_branch_manager` — Read-only across all modules\n\n## Custom Roles\nOwners can create additional roles (e.g. `junior_editor`, `accounts_team`) with custom capability subsets.\n\n## Capability Matrix\nEach role is configured against a permissions matrix that maps capabilities to modules. Changes are saved to `cora_role_permissions` and immediately enforced on all AJAX actions via `current_user_can()` checks."
        ),

        // ── PWA & Mobile ──────────────────────────────────────────────────
        array(
            'slug'     => 'pwa-setup',
            'title'    => 'PWA Setup & Install',
            'category' => 'pwa',
            'content'  => "# PWA Setup & Install\n\nCora ships as a full Progressive Web App (PWA), enabling one-tap installation to the home screen on both Android and iOS devices.\n\n## Technical Requirements\n- HTTPS connection (required by all browsers)\n- Valid `cora-manifest.json` served at root scope\n- Service Worker registered at `/cora-service-worker.js`\n\n## Manifest Configuration\nThe PWA manifest is dynamically generated at `/cora-manifest.json` with:\n- `name`: Cora Workspace\n- `short_name`: Cora\n- `start_url`: `/workspace/dashboard`\n- `display`: `standalone`\n- `icons`: 192x192 and 512x512 PNG icons from the plugin assets\n\n## Install Prompt Banner (v3.2.46)\nThe workspace now shows a slide-in install prompt banner on first visit (bottom-right corner) with three options:\n- **Install App**: Triggers the browser `BeforeInstallPromptEvent`\n- **Later**: Dismisses for the current session\n- **Don't ask again**: Sets `localStorage.cora_pwa_never_prompt = true` permanently\n\nThe banner does not appear if:\n- The app is already running in `standalone` display mode\n- The user has previously selected 'Don't ask again'\n- The browser does not support PWA installation\n\n## iOS Install\nSafari on iOS does not fire `BeforeInstallPromptEvent`. The banner detects iOS and shows manual instructions ('Tap the Share icon → Add to Home Screen')."
        ),
        array(
            'slug'     => 'pwa-push-notifications',
            'title'    => 'Push Notifications (VAPID)',
            'category' => 'pwa',
            'content'  => "# Push Notifications — VAPID\n\nSee **Communications → Push Notifications (VAPID)** for the full technical reference. This page covers the PWA-specific setup and subscription management.\n\n## Enabling Push on a Device\n1. Open the workspace on the target device.\n2. When prompted for notification permission, click **Allow**.\n3. The service worker registers a Push subscription and posts it to `/wp-json/cora-pwa/v1/save-subscription`.\n\n## Subscription Storage\nSubscriptions are stored per-user in `wp_options` under `cora_pwa_subscriptions_{user_id}`. Multiple subscriptions (across different devices/browsers) are supported per user.\n\n## Managing Subscriptions\nUsers can revoke push permission at any time via browser notification settings. The service worker detects failed pushes and automatically cleans up stale subscriptions."
        ),
        array(
            'slug'     => 'pwa-service-worker',
            'title'    => 'Service Worker',
            'category' => 'pwa',
            'content'  => "# Service Worker\n\nThe Cora Service Worker (`/cora-service-worker.js`) is the backbone of the PWA layer, handling offline caching, background sync, and push notification delivery.\n\n## Registration\nThe service worker is registered at root scope (`/`) to intercept all workspace requests:\n```javascript\nnavigator.serviceWorker.register('/cora-service-worker.js', { scope: '/' });\n```\n\n## Caching Strategy\n- **Cache-First**: Static assets (JS, CSS, images) served from cache with background revalidation.\n- **Network-First**: AJAX/REST API requests always attempt network first, falling back to cache.\n- **Offline Page**: Uncached navigation requests fall back to `/cora-offline.html`.\n\n## Push Event Handler\nOn receiving a push event, the service worker:\n1. Fetches notification details from `/wp-json/cora-pwa/v1/get-notification?token={token}`.\n2. Displays the system notification with title, body, icon, and a `data.url` click action.\n\n## notificationclick Handler\nClicking the notification:\n1. Closes the notification.\n2. Attempts to focus an existing workspace window if open.\n3. Otherwise opens a new tab to the `data.url` destination."
        ),

        // ── Modules ───────────────────────────────────────────────────────
        array(
            'slug'     => 'module-vault',
            'title'    => 'Module: Document Vault',
            'category' => 'modules',
            'content'  => "# Module: Document Vault\n\nThe Document Vault module is Cora's legal and compliance layer. It provides e-signature workflows, secure document storage, GST verification, and client sharing for Indian service businesses.\n\n## Key Capabilities\n- **5-Step E-Sign Wizard**: Guided signing with GST math, terms acknowledgment, and canvas signature.\n- **PDF Renderer**: Server-side PDF generation from document templates.\n- **Secure Sharing**: Time-limited signed URLs for external document access.\n- **Agency Isolation**: All documents scoped by `agency_id`.\n\n## Integration Points\n- **CRM**: Automatically generates contracts from CRM lead data.\n- **Financials**: Invoice PDFs are archived directly into the Vault.\n- **RAG Layer**: Vault documents are indexed into the agency's RAG knowledge base.\n\n## Access Control\n- `administrator` / `owner`: Full CRUD on all vault documents.\n- `cora_branch_manager`: Read-only view of signed documents.\n- Clients: Access via secure share URL only (no workspace login required).\n\nSee **Document Vault** section in the sidebar for detailed sub-module documentation."
        ),
        array(
            'slug'     => 'module-content-suite',
            'title'    => 'Module: Content Suite',
            'category' => 'modules',
            'content'  => "# Module: Content Suite\n\nThe Content Suite module consolidates all content creation, publishing, SEO optimization, and Google Business Profile management into a single workspace panel.\n\n## Sub-Modules\n- **AI Content Generator**: LLM-powered caption, blog, and email copy creation.\n- **Publishing Calendar**: Visual scheduling across social platforms.\n- **SEO & GEO Inspector**: Page audit for traditional SEO and AI-search optimization.\n- **Google Business Profile**: Centralized GBP post, photo, and review management.\n\n## Industry Contexts\n- **Photography Studio**: Generates shoot portfolios, behind-the-scenes reels captions, and booking promo posts.\n- **Real Estate**: Generates property listing descriptions, neighborhood highlights, and open house announcements.\n\nSee the **Content & SEO** section in the sidebar for detailed sub-module documentation."
        ),
        array(
            'slug'     => 'module-forms',
            'title'    => 'Module: Forms Builder',
            'category' => 'modules',
            'content'  => "# Module: Forms Builder\n\nThe Forms Builder module enables agencies to create, deploy, and analyze custom forms for lead capture, onboarding, contracts, and feedback.\n\n## Key Capabilities\n- **No-code form builder** with drag-and-drop field layout\n- **Conditional logic** for dynamic form flows\n- **E-Sign integration** piping directly to Document Vault\n- **CRM lead creation** from form submissions\n- **Webhook export** for third-party automation\n- **Multi-step forms** with animated progress stepper\n\nSee the **Client Portal → Forms Builder** section in the sidebar for the full AJAX API and database schema reference."
        ),
        array(
            'slug'     => 'module-visual-builder',
            'title'    => 'Module: Visual Builder',
            'category' => 'modules',
            'content'  => "# Module: Visual Builder\n\nThe Visual Builder module provides a standalone page and layout design environment built on top of Elementor, with Cora-branded controls and white-labeling.\n\n## Relationship to Canvas\nThe Visual Builder is a simplified entry-point into the Canvas & Frontend Module. While Canvas manages full themes, Canvas Pages, and menus, the Visual Builder focuses on the in-browser drag-and-drop editing experience.\n\n## Features\n- Custom Cora 2-row toolbar overlaid on Elementor's editor\n- White-labeled exit to eliminate Elementor branding\n- Git integration drawer for version-controlled commits\n- Save Draft / Publish split button\n- Theme settings panel for global CSS and colors\n\nSee **Canvas & Frontend Module** in the sidebar for full technical documentation."
        ),
        array(
            'slug'     => 'module-pwa',
            'title'    => 'Module: PWA & Mobile Shell',
            'category' => 'modules',
            'content'  => "# Module: PWA & Mobile Shell\n\nShipped in **v3.2.46**, the PWA & Mobile Shell module transforms the Cora workspace into a fully installable Progressive Web App with offline support and real-time push notifications.\n\n## Components\n- **PWA Manifest**: Dynamic `/cora-manifest.json` with branded icons.\n- **Service Worker**: Caching, offline fallback, and push notification delivery.\n- **VAPID Push**: ES256 self-signed JWT push authorization.\n- **Install Prompt Banner**: Slide-in UI prompting users to install the app, with persistent 'never remind' option.\n- **REST API**: `/wp-json/cora-pwa/v1/` endpoints for subscription management and notification dispatch.\n\n## Access Control\n- Push subscription registration: Any authenticated workspace user.\n- Notification dispatch: Triggered server-side by CRM, Bookings, and Task Manager event hooks.\n- VAPID key management: Super Admin only.\n\nSee **PWA & Mobile** in the sidebar for detailed sub-module documentation."
        ),

        // ── Comprehensive 20-Module Ecosystem Updates (v3.4.46) ──────────
        array(
            'slug'     => 'ai-cofounder',
            'title'    => 'AI Co-Founder & Operations Agent',
            'category' => 'ai',
            'content'  => "# AI Co-Founder & Operations Agent\n\nThe Cora AI Co-Founder is an autonomous reasoning agent that qualifies leads, prepares production budgets, identifies calendar overlaps, and drafts commercial service contracts.\n\n## Core Capabilities\n- **Autonomous Scoping**: Converts client emails and unstructured messages into formal shoot briefs.\n- **Rate Card Intelligence**: Automatically applies your studio day rates, gear line items, and 18% GST margins.\n- **WhatsApp Triage**: Short conversational chat bubbles with interactive RCS action cards for 1-tap approvals.\n\n## AJAX API Reference\n| Action | Parameters | Description |\n|---|---|---|\n| `cora_ajax_ai_cofounder_query` | `nonce`, `message`, `context_type` | Process prompt with RAG memory injection |\n| `cora_ajax_ai_approve_action` | `nonce`, `action_id`, `approved` | Execute approved action card |"
        ),
        array(
            'slug'     => 'rag-mcp',
            'title'    => 'RAG Memory & Model Context Protocol (MCP)',
            'category' => 'ai',
            'content'  => "# RAG Memory & Model Context Protocol (MCP)\n\nCora integrates a local Model Context Protocol (MCP) server gateway allowing external LLM clients (Cursor, Claude Desktop, Antigravity) to read and manipulate studio records securely.\n\n## Features\n- **Keyword-Dense RAG**: Zero-dependency SQLite/MySQL semantic chunking.\n- **JSON-RPC 2.0 Gateway**: Bidirectional WebSocket and REST tool execution.\n- **Dynamic Token Rotation**: Revoke and regenerate bearer keys from the admin popover."
        ),
        array(
            'slug'     => 'voice-to-scope',
            'title'    => 'Voice-to-Scope Audio Briefs',
            'category' => 'ai',
            'content'  => "# Voice-to-Scope Audio Briefs\n\nConverts client voice memos and audio recordings into structured deliverables lists, shoot agendas, and GST proposals using Gemini Multimodal Audio analysis."
        ),
        array(
            'slug'     => 'lead-crm',
            'title'    => 'Kanban Lead CRM',
            'category' => 'crm',
            'content'  => "# Kanban Lead CRM\n\nNotion-styled drag-and-drop lead board tailored for high-ticket commercial shoots, wedding productions, and agency retainers with automated WhatsApp follow-up triggers."
        ),
        array(
            'slug'     => 'canvas-builder',
            'title'    => 'Funnel Canvas Builder',
            'category' => 'content',
            'content'  => "# Funnel Canvas Builder\n\nVisual landing page and conversion funnel designer with monochromatic theme tokens, responsive mobile previews, and white-labeled client editing."
        ),
        array(
            'slug'     => 'esign-vault',
            'title'    => 'SHA-256 E-Sign Vault',
            'category' => 'vault',
            'content'  => "# SHA-256 E-Sign Vault\n\nIndian IT Act 2000 compliant digital signature registry with 5-step guided wizard (Details → Terms → GST Math → E-Sign → Watermarked PDF)."
        ),
        array(
            'slug'     => 'crew-dispatch',
            'title'    => 'Crew & Gear Dispatch',
            'category' => 'operations',
            'content'  => "# Crew & Gear Dispatch\n\nAutomated call sheet generator with shoot location maps, call times, crew roles, and 1-click WhatsApp broadcast alerts."
        ),
        array(
            'slug'     => 'master-calendar',
            'title'    => 'Master Shoot Calendar',
            'category' => 'operations',
            'content'  => "# Master Shoot Calendar\n\nCentralized multi-location booking calendar tracking shoot statuses, equipment reservations, and two-way Google/Apple Calendar sync."
        ),
        array(
            'slug'     => 'gst-invoicing',
            'title'    => '18% GST Invoicing & Math',
            'category' => 'finance',
            'content'  => "# 18% GST Invoicing & Math\n\nAutomated tax engine calculating Intra-State CGST (9%) + SGST (9%) vs. Inter-State IGST (18%) with SAC 998381 code pre-seeding and CA export packs."
        ),
        array(
            'slug'     => 'asset-gear',
            'title'    => 'Gear & Inventory Management',
            'category' => 'operations',
            'content'  => "# Gear & Inventory Management\n\nComplete equipment registry with serial numbers, condition tracking, maintenance logs, and shoot checkout reservation conflict alerts."
        ),
        array(
            'slug'     => 'media-hub',
            'title'    => 'Media Hub & 4K RAW Proofing',
            'category' => 'media',
            'content'  => "# Media Hub & 4K RAW Proofing\n\nWorkspace asset library with Gemini AI image tagging, client gallery password portals, download controls, and in-browser canvas photo editor."
        ),
        array(
            'slug'     => 'rbac-system',
            'title'    => 'Multi-Tenant RBAC & Security',
            'category' => 'overview',
            'content'  => "# Multi-Tenant RBAC & Security\n\n30-point granular capability security matrix with strict tenant database isolation by agency_id and tamper-evident audit trails."
        ),
        array(
            'slug'     => 'pwa-architecture',
            'title'    => 'PWA Architecture & Service Worker',
            'category' => 'pwa',
            'content'  => "# PWA Architecture & Service Worker\n\nFull Progressive Web App specifications with root-scoped Service Worker, Network-First API navigation, Cache-First static assets, and VAPID Web Push alerts."
        ),
    );
}

// ── 8. PWA Changelog Entries (v3.2.46) ───────────────────────────────────

if ( ! function_exists( 'cora_docs_get_pwa_changelog_entries' ) ) {
function cora_docs_get_pwa_changelog_entries() {
    return array(
        array(
            'module_key'  => 'pwa',
            'version'     => '3.2.46',
            'status'      => 'released',
            'title'       => 'PWA Install Prompt & Push Notifications',
            'description' => 'Shipped the complete PWA layer. Service Worker now registered at root scope with Cache-First/Network-First strategies and offline fallback. VAPID ES256 key pair auto-generated on activation. Push subscription REST endpoints added. Slide-in install prompt banner implemented with localStorage-backed dismiss persistence.',
            'ticket_id'   => 'CORA-1001',
        ),
        array(
            'module_key'  => 'pwa',
            'version'     => '3.2.46',
            'status'      => 'released',
            'title'       => 'VAPID Backend Key System',
            'description' => 'Implemented self-contained ES256 ASN.1 DER VAPID JWT generator in PHP with no external library dependencies. VAPID public/private key pair stored in wp_options. Push subscription save and notification retrieval REST endpoints registered under /wp-json/cora-pwa/v1/.',
            'ticket_id'   => 'CORA-1002',
        ),
        array(
            'module_key'  => 'pwa',
            'version'     => '3.2.46',
            'status'      => 'released',
            'title'       => 'CRM & Bookings Push Triggers',
            'description' => 'Hooked push notification dispatch to CRM lead save, bookings/showings database insertion, and high-priority client task status updates. All triggers call cora_pwa_notify_agency() which fans out to all subscribed users.',
            'ticket_id'   => 'CORA-1003',
        ),
        array(
            'module_key'  => 'deploy',
            'version'     => '3.2.46',
            'status'      => 'released',
            'title'       => 'Deployment Pipeline CageFS Fix',
            'description' => 'Resolved unzip failures on Hostinger shared hosting caused by CageFS virtual /tmp isolation. Changed REMOTE_TMP path in deploy.sh from /tmp/ to /home/u484406462/ to guarantee write access across all SSH sessions.',
            'ticket_id'   => 'CORA-1004',
        ),
        array(
            'module_key'  => 'docs',
            'version'     => '3.2.46',
            'status'      => 'released',
            'title'       => 'Public Docs — Full Module Coverage',
            'description' => 'Expanded the public developer documentation to cover all 11 platform categories and 11 module pages. Added comprehensive architecture overviews, AJAX API reference tables, database schema documentation, and access control notes for Media, Operations, Client Portal, Document Vault, Communications, Content & SEO, and PWA modules.',
            'ticket_id'   => 'CORA-1005',
        ),
    );
}
}

// ── 9. New Documentation Pages (v4.9.364 + Marketing Site Reform) ────────

if ( ! function_exists( 'cora_docs_get_new_pages_v49364' ) ) {
function cora_docs_get_new_pages_v49364() {
    return array(
        array(
            'slug'     => 'marketing-site-reform',
            'title'    => 'Marketing Site Reform & Tools & Templates Directory',
            'category' => 'overview',
            'content'  => "# Marketing Site Reform & Tools & Templates Directory\n\nCora's public marketing layer (`heycora.in`) communicates the unified platform value proposition across website generation and autonomous agency operations.\n\n## Homepage Hero Repositioning\n- **Headline**: \"Build websites. Run your business, with an AI co-founder.\"\n- **Subtitle**: \"The operating system for Indian service businesses and agencies. Invoicing, lead CRM, team dispatch, client portal, and custom websites — powered by your personal AI co-founder.\"\n- **Dual Conversion Pathways**:\n  1. **Primary High-Velocity CTA**: \"Sign in with Google\" — Fast, zero-friction OAuth onboarding creating instant production workspaces.\n  2. **Secondary Discovery CTA**: \"Explore free templates\" — Connects founders directly to the `/use-cases` directory showcasing 16+ turnkey pre-seeded website and workspace schemas.\n\n## Tools & Templates Directory\nElevated from traditional resources into a high-utility discovery layer:\n- **Free Agency Calculators**: 18% GST invoice simulator, retainer target margin calculator, and commercial proposal generator.\n- **Turnkey Website & Workspace Schemas**: Pre-seeded database and website templates across Photography Studios, Real Estate Brokerages, Marketing Agencies, Stationery & Van Sales, Consulting, Wedding Production, and Creative Retainers.\n- **Universal Lead Ingestion**: Static landing pages include embedded lead forms piping client inquiries directly into `wp_cora_leads`."
        ),
        array(
            'slug'     => 'canvas-resilience-shield',
            'title'    => 'Canvas Live HTML Preview Resilience Shield & Auto-Tailwind',
            'category' => 'content',
            'content'  => "# Canvas Live HTML Preview Resilience Shield & Auto-Tailwind\n\nShipped in **v4.9.358 - v4.9.363**, the Canvas Live Preview Resilience Shield provides a bulletproof editing and preview runtime for static HTML and Tailwind themes.\n\n## Automatic Tailwind CDN Injection\nWhen rendering preview iframes or exporting static bundles, the compiler scans markup for Tailwind utility classes. If a compiled stylesheet link is missing, the engine automatically injects:\n```html\n<script src=\"https://cdn.tailwindcss.com\"></script>\n```\ninto the `<head>`, guaranteeing 100% visual styling fidelity with zero Node.js compilation delay.\n\n## Iframe Error Boundaries & Zero Blank Sections\nPreview iframes are encapsulated in error boundaries. Broken JavaScript snippets, missing fonts, or malformed SVG graphics are isolated gracefully, preventing blank screen lockouts and layout freezes.\n\n## Unified 'Edit with AI' Toolbar (v4.9.362)\nThe Live Code Editor consolidates fragmented AI tools into a single, high-contrast 'Edit with AI' action bar supporting instant diff previews and 1-click code application into CodeMirror buffers.\n\n## Live Static Site Styling Parity (v4.9.363)\nPreview iframes strictly encapsulate host admin styles, ensuring that typography, grid layouts, and media queries in the editor look identical to exported production builds (`theme_{id}/out/index.html`)."
        ),
        array(
            'slug'     => 'ai-quotas-pacing',
            'title'    => 'AI Run Quotas & Fair Usage Pacing (15K Pro / 25K Scale)',
            'category' => 'ai',
            'content'  => "# AI Run Quotas & Fair Usage Pacing\n\nStarting in **v4.9.364**, Cora standardizes monthly AI computing quotas with weekly anti-burnout pacing to ensure consistent operational availability for agency teams.\n\n## Tiered Quota Matrix\n| Tier | Monthly AI Runs | Weekly Soft Pacing | Scope |\n|---|---|---|---|\n| Starter / Free | 500 runs/mo | 125 runs/wk | Solo founders, proof of concept |\n| Professional (Pro) | 15,000 runs/mo | 3,750 runs/wk | Growing agencies, client pipelines |\n| Scale | 25,000 runs/mo | 6,250 runs/wk | Multi-branch agencies, high-volume teams |\n| Enterprise | Custom | Unlimited | Dedicated compute clusters |\n\n## Anti-Burnout Weekly Pacing\nThe engine evaluates `ceil(\$monthly_quota / 4)`. If an agency consumes over 100% of their weekly allocation, non-blocking telemetry warning banners appear in the dashboard, preventing accidental month-end depletion.\n\n## Super Admin & Admin Role Bypass\nSuper Admins and users with `manage_options` capability are exempt from all rate limiting, weekly pacing caps, and artificial 6-hour session timeouts."
        ),
        array(
            'slug'     => 'mcp-openapi-301',
            'title'    => 'Universal Remote MCP & OpenAPI 3.0.1 Specification',
            'category' => 'ai',
            'content'  => "# Universal Remote MCP & OpenAPI 3.0.1 Specification\n\nCora provides a standards-compliant Model Context Protocol gateway allowing external AI assistants (ChatGPT, Claude, Google Gemini, Cursor) to securely inspect and operate workspace records.\n\n## OpenAPI 3.0.1 Upgrade & Curated 28 Tools Ceiling (v4.9.355 - v4.9.357)\n- **OpenAPI 3.0.1 Compliant**: Replaced OpenAPI 3.1.0 output in `cora_rest_mcp_openapi_handler()` to strictly comply with OpenAI Custom GPT Actions validation.\n- **Curated 28 Core Actions Ceiling**: Capped default exposed tools to 28 operations (staying safely below OpenAI's ~30 action limitation).\n- **Purged Emojis**: Descriptions and summaries are strictly alphanumeric and clean vector-safe.\n\n## Interactive OAuth 2.1 Consent Panel (v4.9.354)\nUser-friendly authorization screen featuring a master 'Universal Full Access' switch, 10 categorized permission cards, quick presets (`All Tools`, `Read-Only`, `Website Only`), and live selection counters.\n\n## Zero-Copy Native MCP File Management (v4.9.349)\nTools such as `cora_canvas_update_page_html` write directly to static distribution directories (`theme_{id}/out/index.html`) and database registries simultaneously, delivering instantaneous production publishing without rebuild delays."
        ),
        array(
            'slug'     => 'endorsely-affiliate-suite',
            'title'    => 'Endorsely Affiliate & Conversion Tracking Suite',
            'category' => 'finance',
            'content'  => "# Endorsely Affiliate & Conversion Tracking Suite\n\nShipped in **v4.9.364**, Cora integrates an enterprise affiliate attribution engine across public marketing funnels and workspace checkout flows.\n\n## Technical Integration\n- **Client Script**: Dynamically injected into `cora-frontend/app/layout.tsx` (`https://app.endorsely.com/assets/affiliate-tracking.js`).\n- **Affiliate ID**: `d56e72c8-89fa-47cb-bc87-920aa9e3a6bb`.\n- **Conversion Trigger**: Fired via `window.endorsely?.trackConversion()` upon successful payment capture in Razorpay modals and checkout sheets.\n\n## Partner Reward Architecture\n- **Free Signups**: +100 Free AI Runes awarded immediately on referral signup.\n- **Paid Subscriptions**: 20% Monthly / 30% Annual recurring revenue share.\n- **Milestone Bonuses**: Cash rewards at referral thresholds (₹1,000 for 10, ₹5,000 for 50, ₹10,000 for 100 paid referrals)."
        ),
        array(
            'slug'     => 'forms-embedding-suite',
            'title'    => 'Forms Embedding Suite & Static Site Lead Bridge',
            'category' => 'client-portal',
            'content'  => "# Forms Embedding Suite & Static Site Lead Bridge\n\nThe Forms Embedding Suite enables agency founders to embed dynamic Form AI Architect lead intake forms into any static Canvas landing page or external website.\n\n## Shortcode & Iframe Generators\n- **Embed Shortcode**: `[cora-form id=\"{form_id}\" theme=\"light\"]`\n- **Responsive Iframe Embed**:\n```html\n<iframe src=\"https://app.heycora.in/workspace/forms/embed?id={form_id}\" class=\"w-full border-0 rounded-2xl min-h-[480px]\" loading=\"lazy\"></iframe>\n```\n\n## Automatic CRM Routing\nAll submissions automatically ingest into `wp_cora_leads`, trigger instant in-app toasts, and dispatch Web Push notifications to subscribed agency devices."
        ),
        array(
            'slug'     => 'cora-ai-sdr',
            'title'    => 'Sticky Conversational AI SDR & Objection Engine',
            'category' => 'ai',
            'content'  => "# Sticky Conversational AI SDR & Objection Engine\n\nMounted via React Portal into `document.body` on the public marketing site (`heycora.in`), the Cora AI SDR acts as an autonomous sales co-founder.\n\n## Portaled Viewport Docking\n- **True Viewport Docking**: Positioned sticky bottom-center (`bottom-0 sm:bottom-4`) portaled to `document.body`, eliminating parent container clipping and layout jumps.\n- **Zero Backdrop Overlay**: Floats freely above the web canvas without dimming background content.\n\n## Objection Handling & Conversion Incentives\n- **Pre-Configured Objection Vectors**: Handles common founder switching doubts (Notion/HoneyBook comparisons, white-glove site migrations, annual discount negotiation, legacy multi-plugin instability).\n- **Dynamic Discount Coupons**: Generates actionable promotional offer cards with direct checkout links (`MIGRATEFREE`, `CORA10`) that auto-apply discount parameters into `/pricing`.\n\n## Industry Quick-Pills\nProvides 1-tap inquiries tailored for Web Design, Creative & Branding, Performance & SEO, App Dev, and Media Production."
        ),
        array(
            'slug'     => 'templates-asset-library',
            'title'    => '16+ Multi-Format Template & Theme Asset Library',
            'category' => 'canvas',
            'content'  => "# 16+ Multi-Format Template & Theme Asset Library\n\nThe Template & Theme Library at `/templates` provides 16+ production-grade frontend assets across 4 interoperable format standards.\n\n## 4 Distribution Formats\n1. **Native Landing Pages (`native_page`)**: Pure Tailwind CSS and Next.js 15 pages featuring sub-50ms paint times and accessible components.\n2. **AI Section Prompts (`section_prompts`)**: Token-engineered prompts for Claude 3.5 Sonnet and Cursor Composer.\n3. **Elementor Template Kits (`elementor_kit`)**: Standardized Elementor JSON blueprints for instant page builder import.\n4. **Lovable & React Projects (`lovable_project`)**: Rapid full-stack scaffolding configurations for Lovable.dev and v0.dev.\n\n## Interactive Modal Previews & Direct Code Copy\n- Sandboxed live preview with responsive viewport switchers (`Desktop`, `Tablet`, `Mobile`).\n- 1-click clipboard prompt export and raw asset download actions.\n- Direct lead capture bridge routing inquiries into `wp_cora_leads`."
        )
    );
}
}

// ── 10. Latest Changelog Entries (v4.9.364 + Marketing Site Reform) ───────

if ( ! function_exists( 'cora_docs_get_v49364_changelog_entries' ) ) {
function cora_docs_get_v49364_changelog_entries() {
    return array(
        array(
            'module_key'  => 'marketing',
            'version'     => '4.9.364-sdr',
            'status'      => 'released',
            'title'       => 'Sticky Conversational AI SDR & Objection Handling Engine',
            'description' => 'Portaled floating AI SDR bar to document.body for true bottom-center docking with zero backdrop overlay. Integrated automated objection handling vectors and dynamic checkout coupon generation (MIGRATEFREE, CORA10).',
            'ticket_id'   => 'CORA-1212',
        ),
        array(
            'module_key'  => 'templates',
            'version'     => '4.9.364-tmpl',
            'status'      => 'released',
            'title'       => '16+ Multi-Format Template & Asset Library across 4 Standards',
            'description' => 'Deployed full template distribution engine at /templates with 16+ production assets across Native Landing Pages, AI Section Prompts, Elementor Kits, and Lovable React projects, complete with live modal preview.',
            'ticket_id'   => 'CORA-1213',
        ),
        array(
            'module_key'  => 'marketing',
            'version'     => '4.9.364-mkt',
            'status'      => 'released',
            'title'       => 'Marketing Site Reform: Homepage Hero & Tools & Templates',
            'description' => 'Repositioned homepage hero headline to \"Build websites. Run your business, with an AI co-founder.\" Implemented dual high-velocity CTAs (Google Sign-In & Explore Free Templates). Overhauled navbar Resources card into \"Tools & Templates\" connecting directly to 16+ turnkey industry schemas at /use-cases.',
            'ticket_id'   => 'CORA-1201',
        ),
        array(
            'module_key'  => 'ai',
            'version'     => '4.9.364',
            'status'      => 'released',
            'title'       => 'AI Run Quotas Standardization & Fair Usage Pacing',
            'description' => 'Standardized monthly quotas to 15,000 runs/mo (Pro) and 25,000 runs/mo (Scale). Introduced weekly soft-limit pacing (3,750 Pro / 6,250 Scale runs/wk) to prevent token burnout. Super Admins bypass all rate limits and artificial 6-hour session timeouts.',
            'ticket_id'   => 'CORA-1202',
        ),
        array(
            'module_key'  => 'affiliates',
            'version'     => '4.9.364',
            'status'      => 'released',
            'title'       => 'Endorsely Affiliate Tracking Suite & Conversion Bridge',
            'description' => 'Integrated Endorsely affiliate script (app.endorsely.com/assets/affiliate-tracking.js) across public layouts and checkout flows. Connected window.endorsely.trackConversion() upon verified Razorpay payment capture with automatic 18% GST calculation.',
            'ticket_id'   => 'CORA-1203',
        ),
        array(
            'module_key'  => 'canvas',
            'version'     => '4.9.363',
            'status'      => 'released',
            'title'       => 'Live Static Site Styling Parity & Auto-Tailwind CDN Injection',
            'description' => 'Guaranteed 100% visual fidelity between local preview iframes and exported static bundles. Automated Tailwind CSS CDN injection and encapsulated host styles to prevent admin CSS leaks into sandboxed preview DOM.',
            'ticket_id'   => 'CORA-1204',
        ),
        array(
            'module_key'  => 'canvas',
            'version'     => '4.9.362',
            'status'      => 'released',
            'title'       => 'Unified Edit with AI Toolbar in Live Code Editor',
            'description' => 'Consolidated fragmented AI editing triggers in the Live Code Editor into a unified Edit with AI action bar with context-aware prompt parsing, instant diff previewing, and 1-click code application.',
            'ticket_id'   => 'CORA-1205',
        ),
        array(
            'module_key'  => 'canvas',
            'version'     => '4.9.361',
            'status'      => 'released',
            'title'       => 'Workspace Forms Embedding Suite & Static Site Lead Bridge',
            'description' => 'Engineered shortcode ([cora-form id=\"...\"]) and responsive iframe generator allowing founders to embed Form AI Architect forms into static landing pages with automated CRM lead ingestion.',
            'ticket_id'   => 'CORA-1206',
        ),
        array(
            'module_key'  => 'canvas',
            'version'     => '4.9.360',
            'status'      => 'released',
            'title'       => 'Streamlined Live Code Editor Minimalist Header',
            'description' => 'Eliminated redundant portrait and viewport switcher controls from Live Code Editor header bar for clean, distraction-free editing.',
            'ticket_id'   => 'CORA-1207',
        ),
        array(
            'module_key'  => 'mcp',
            'version'     => '4.9.357',
            'status'      => 'released',
            'title'       => 'ChatGPT Action Discovery & Curated 28 Core Tools Ceiling',
            'description' => 'Resolved ChatGPT custom action import validation by capping default exposed tools to 28 core actions, upgrading schema generation to OpenAPI 3.0.1, and purging emojis from all summaries.',
            'ticket_id'   => 'CORA-1208',
        ),
        array(
            'module_key'  => 'mcp',
            'version'     => '4.9.354',
            'status'      => 'released',
            'title'       => 'Universal Read/Write OAuth 2.1 Consent Panel with Presets',
            'description' => 'Deployed user-friendly OAuth 2.1 consent panel featuring a master Universal Full Access toggle, 10 categorized domain scope cards, quick presets, and live scope counters.',
            'ticket_id'   => 'CORA-1209',
        ),
        array(
            'module_key'  => 'pwa',
            'version'     => '4.9.342',
            'status'      => 'released',
            'title'       => 'Universal In-App PWA Install Suite & Admin Popover Trigger',
            'description' => 'Exposed in-app PWA install triggers in System Settings Suite and sticky sidebar admin popover with BeforeInstallPromptEvent interception and iOS WebClip guides.',
            'ticket_id'   => 'CORA-1210',
        ),
        array(
            'module_key'  => 'pwa',
            'version'     => '4.9.341',
            'status'      => 'released',
            'title'       => 'Official Cora Super Admin PWA App Icon Suite with Dynamic ADMIN Badging',
            'description' => 'Shipped dynamic ADMIN badging across 512/192/Apple/Favicon icons for Super Admins with role-scoped Web App Manifest (CORA Workspace (Admin)) and emerald active status indicator.',
            'ticket_id'   => 'CORA-1211',
        ),
    );
}
}

// ── 11. New Documentation Pages (v4.9.374) ───────────────────────────────

if ( ! function_exists( 'cora_docs_get_new_pages_v49374' ) ) {
function cora_docs_get_new_pages_v49374() {
    return array(
        array(
            'slug'     => 'forms-cards-all-entries',
            'title'    => 'Forms Overhaul & Universal All Entries Registry',
            'category' => 'forms',
            'content'  => "# Forms Overhaul & Universal All Entries Registry\n\nShipped in **v4.9.372**, this release revamps the Form AI Architect cards and introduces the universal All Entries 5th tab.\n\n## Form Card Padding & Mobile Unlocking\n- **Expanded Padding**: Card internal padding is expanded to `p-5 sm:p-6` with dedicated `p-3.5` inner container for campaign details and `px-3 py-1.5` status chips, preventing text from colliding with borders.\n- **Full Card Clickability**: Clicking anywhere on `.form-card` or the form title navigates directly to `#edit/\${form.id}`.\n- **Mobile Editing Unlocked**: Removed `< 1024px` viewport blockers in routing and form loading, allowing full form editing on mobile and tablet devices.\n\n## In-App Interactive Form Live Preview Modal\n- Sandboxed preview modal (`#cora-form-preview-modal`) allowing founders to test forms with responsive viewport toggles (`Desktop`, `Mobile`) and an external tab launcher.\n\n## Universal 5th Tab: All Entries Registry (`#all-entries`)\n- **Metric Summary Strip**: Real-time KPI counter cards for Total Submissions, Active Forms with Entries, Completion Rate, and Latest Activity.\n- **Notion-Style Filter Toolbar**: Form source selector dropdown, Status dropdown (Completed vs. Partial), live search input, 1-click CSV export, and refresh button.\n- **Table Layout Hardening**: Implemented `table-fixed` and rigid explicit column widths preventing horizontal blowout.\n- **REST Endpoints**:\n  - `GET /wp-json/cora/v1/forms/all-submissions`: Returns all agency submissions with form title, form key, and settings JOINed.\n  - `DELETE /wp-json/cora/v1/forms/submissions/{id}`: Secure REST deletion endpoint with multi-tenant tenancy verification."
        ),
        array(
            'slug'     => 'edge-docked-entry-inspector',
            'title'    => 'Universal Edge-Docked Entry Inspector & Zero-Backdrop Shield',
            'category' => 'forms',
            'content'  => "# Universal Edge-Docked Entry Inspector & Zero-Backdrop Shield\n\nDeployed in **v4.9.374**, the Entry Inspector (`#cora-entry-inspector`) provides an ergonomic detail viewer across all form entries:\n\n## Edge-Docked Responsive Layout\n- **Desktop Viewports (>= 768px)**: Slides smoothly from the right edge (`top-0 right-0 bottom-0 w-[480px] max-w-[90vw] border-l border-zinc-200 bg-white translate-x-0`).\n- **Mobile Viewports (< 768px)**: Slides up from the bottom as a high-density sheet (`inset-x-0 bottom-0 h-[85vh] max-h-[85vh] rounded-t-3xl border-t border-zinc-200 bg-white translate-y-0`).\n\n## Zero-Backdrop Overlay Clarity\n- Completely purged dark and blurred backdrop overlays. The underlying submissions table remains 100% visible, sharp, and readable.\n- Dismissed smoothly via outside document clicks.\n\n## Submitter Quick Overview & Inline Signatures\n- Renders avatar initials, primary submitter name, and email/phone quick chips.\n- Inspects field values for image MIME types and base64 digital signatures (`data:image/...`), rendering inline `<img src=\"...\">` previews instead of dumping raw text blobs.\n- Sticky footer with 1-click 'Copy Raw JSON', 'Delete Entry', and 'Done' actions."
        ),
        array(
            'slug'     => 'client-timezone-engine',
            'title'    => 'Client Timezone Engine & Localized Timestamps',
            'category' => 'overview',
            'content'  => "# Client Timezone Engine & Localized Timestamps\n\nStarting in **v4.9.374**, Cora integrates an automatic client timezone detection and formatting engine.\n\n## Automatic Browser Detection\n- Dynamically evaluates `Intl.DateTimeFormat().resolvedOptions().timeZone` upon client hydration.\n- Automatically translates UTC server timestamps into localized operational dates across tables, entry inspectors, and audit feeds.\n\n## Dual-Format Display\n- Renders relative timestamps (\"15 minutes ago\", \"Yesterday at 3:30 PM\") with localized full datetime tooltips on hover."
        ),
        array(
            'slug'     => 'affiliate-referral-tracking',
            'title'    => 'Dynamic Affiliate Referral Tracking & Checkout Discounts',
            'category' => 'finance',
            'content'  => "# Dynamic Affiliate Referral Tracking & Checkout Discounts\n\nShipped in **v4.9.374**, Cora enhances its affiliate architecture with automated tracking APIs and checkout coupon deductions.\n\n## Referral Tracking REST API\n- `POST /wp-json/cora/v1/referrals/track`: Records referral code impressions, page URLs, referrers, and conversions.\n- Frontend proxy route at `cora-frontend/app/api/referral/track/route.ts` bridging public marketing visitors with backend attribution.\n\n## Multi-Parameter Ingestion & 30-Day Cookies\n- Captures referral query parameters: `cora_ref`, `ref`, `via`, `partner` via `cora-frontend/lib/referral.ts`.\n- Persists active tokens across 30-day secure cookies and `localStorage`.\n\n## Automated Checkout Coupon Discount Application\n- Checkout modals (`CheckoutSheet.tsx`, `FastRazorpayModal.tsx`, `PricingSection.tsx`) automatically detect active referral codes and deduct 10%–20% coupon discounts from plan totals.\n- Fires dual attribution hooks: Endorsely tracking (`window.endorsely?.trackConversion()`) and backend conversion logging."
        ),
        array(
            'slug'     => 'global-resources-hero',
            'title'    => 'Unified Global Resources Hero & Knowledge Directory',
            'category' => 'overview',
            'content'  => "# Unified Global Resources Hero & Knowledge Directory\n\nDeployed across the Cora public frontend, `GlobalResourcesHero.tsx` unifies the top header presentation across Templates, Tools, Guides, Blog, Newsletter, and Articles.\n\n## Design System Consistency\n- Shared typography, subtle monochromatic badges, centered search input with keyboard shortcut hints (`⌘K`), and fluid category pills.\n- Responsive layout scaling cleanly from mobile devices to 4K ultra-wide displays."
        ),
        array(
            'slug'     => 'pricing-hierarchy-specs',
            'title'    => 'Pricing SaaS Hierarchy & Bandwidth/Storage Specifications',
            'category' => 'finance',
            'content'  => "# Pricing SaaS Hierarchy & Bandwidth/Storage Specifications\n\nOverhauled public pricing matrix adhering to Notion/Shopify monochromatic design:\n\n## SaaS Hierarchy Pills & Resource Specs\n- **Starter**: 5GB Cloud Storage, 25GB Monthly Bandwidth.\n- **Professional (Pro)**: 15GB Cloud Storage, 100GB Monthly Bandwidth.\n- **Scale**: 50GB Cloud Storage, 500GB Monthly Bandwidth.\n- **Enterprise**: Custom High-Performance Storage & Unmetered Bandwidth.\n\n## Scale Plan Free Site Migration\n- Floats an external 'Free Site Migration' badge above the Scale card frame to accelerate agency migration from legacy stacks."
        ),
        array(
            'slug'     => 'partner-coaching-portal',
            'title'    => 'Partner & Coaching Accelerator Portal (VNX Digital)',
            'category' => 'marketing',
            'content'  => "# Partner & Coaching Accelerator Portal (VNX Digital)\n\nCustom co-branded partner landing page for VNX Digital members (`/vnxdigital`, `/vanshrajput`):\n\n## Key Features\n- Co-branded hero section, creator social proof, and video walkthroughs.\n- Locked 3-day trial granting full access to the Coaching Accelerator and Cora Studio operational suite."
        )
    );
}
}

// ── 12. Latest Changelog Entries (v4.9.374) ───────────────────────────────

if ( ! function_exists( 'cora_docs_get_v49374_changelog_entries' ) ) {
function cora_docs_get_v49374_changelog_entries() {
    return array(
        array(
            'module_key'  => 'forms',
            'version'     => '4.9.374',
            'status'      => 'released',
            'title'       => 'Universal Edge-Docked Entry Inspector & Client Timezone Engine',
            'description' => 'Docked entry inspector cleanly to right edge on desktop and bottom on mobile with zero backdrop blur. Integrated automatic client timezone engine for localized relative and absolute timestamps.',
            'ticket_id'   => 'CORA-1214',
        ),
        array(
            'module_key'  => 'affiliates',
            'version'     => '4.9.374-aff',
            'status'      => 'released',
            'title'       => 'Dynamic Affiliate Referral Tracking API & Checkout Coupon Deductions',
            'description' => 'Implemented POST /wp-json/cora/v1/referrals/track, multi-cookie referral ingestion (cora_ref, ref, via, partner), automated 10%-20% coupon discount deductions in checkout sheets, and dual conversion attribution.',
            'ticket_id'   => 'CORA-1215',
        ),
        array(
            'module_key'  => 'forms',
            'version'     => '4.9.372',
            'status'      => 'released',
            'title'       => 'Forms Cards Overhaul & Universal 5th Tab All Entries Registry',
            'description' => 'Redesigned form cards with p-5 sm:p-6 padding, full card clickability, unlocked mobile form editing, live preview modal, 5th All Entries tab with metric summary strip, Notion filter toolbar, table-fixed columns, and dynamic multi-form CSV export.',
            'ticket_id'   => 'CORA-1216',
        ),
        array(
            'module_key'  => 'pricing',
            'version'     => '4.9.370',
            'status'      => 'released',
            'title'       => 'Pricing Page Overhaul: Webflow/Framer Hierarchy & Explicit Specs',
            'description' => 'Implemented SaaS hierarchy pills, explicit storage (5-50GB) and bandwidth (25-500GB) specs, floating Free Site Migration badge on Scale, and active-voice copy.',
            'ticket_id'   => 'CORA-1217',
        ),
        array(
            'module_key'  => 'partner',
            'version'     => '4.9.368',
            'status'      => 'released',
            'title'       => 'VNX Digital Coaching Accelerator Partner Landing Page',
            'description' => 'Launched co-branded partner landing page at /vnxdigital and /vanshrajput with creator social proof and locked 3-day trial to Full Coaching Accelerator.',
            'ticket_id'   => 'CORA-1218',
        ),
        array(
            'module_key'  => 'design-system',
            'version'     => '4.9.366',
            'status'      => 'released',
            'title'       => 'Unified Global Resources Hero Section across Knowledge Directories',
            'description' => 'Deployed standardized GlobalResourcesHero across Templates, Tools, Guides, Blog, Newsletter, and Articles with unified typography, search, and category pills.',
            'ticket_id'   => 'CORA-1219',
        ),
    );
}
}

// ── 13. New Documentation Pages (v4.9.380) ───────────────────────────────

if ( ! function_exists( 'cora_docs_get_new_pages_v49380' ) ) {
function cora_docs_get_new_pages_v49380() {
    return array(
        array(
            'slug'     => 'industry-verticals-directory',
            'title'    => 'Industry Solutions Directory & 301 Redirect Architecture',
            'category' => 'overview',
            'content'  => "# Industry Solutions Directory & 301 Redirect Architecture\n\nShipped in **v4.9.380**, this release establishes `/industries` as the canonical industry directory for Cora, migrating all legacy `/use-cases` endpoints while preserving 100% SEO link equity.\n\n## 10+ Production Industry Solutions\nEach vertical provides bespoke operational tools, tax configurations, and client interfaces:\n1. **Real Estate & Property Developers** (`/industries/real-estate`): Geocoded property listings, virtual site tour schedules, WhatsApp showing alerts, and client inquiry pipelines.\n2. **Photography & Film Studios** (`/industries/photography-studio`): Full-resolution media proofing, digital client contracts, multi-ratio crop presets, and shoot gear custody registries.\n3. **Architecture & Interior Design** (`/industries/architecture-interior-design`): Material moodboards, revision milestone sign-offs, contractor tenders, and project phase tracking.\n4. **Digital Marketing & Creative Agencies** (`/industries/creative-agency`): Retainer margin calculators, commercial proposals, multi-client campaign tracking, and GST SAC 9983 tax invoicing.\n5. **Consulting & Professional Services** (`/industries/consulting`): Advisory engagement logs, client milestone deliverables, confidential vault contracts, and auto-scheduled call links.\n6. **Salons, Spas & Wellness Clinics** (`/industries/salon-wellness`): Chair/therapist booking slots, customer loyalty memberships, automated reminder WhatsApps, and spot UPI billing.\n7. **Fitness Studios & Personal Trainers** (`/industries/fitness-studio`): Session packs, automated membership renewals, client progress metrics, and trainer shift coordination.\n8. **Event Production & Wedding Management** (`/industries/events-weddings`): Multi-vendor dispatch schedules, client milestone approvals, budget reconciliation, and run-sheet coordination.\n9. **Hospitality & Boutique Restaurants** (`/industries/hospitality`): Table reservation workflows, private event catering agreements, distributor inventory tracking, and daily reconciliation sheets.\n10. **E-Commerce & DTC Brands** (`/industries/ecommerce-dtc`): SKU catalog management, volume discount tiers, factory van sales dispatch, and automated GST billing.\n\n## Canonical 301 Redirect Architecture\n- Configured in `.htaccess` and Next.js route mapping, ensuring `/use-cases` and `/use-cases/*` permanently redirect to `/industries` without 404 dead ends or link dilution.\n\n## Refined Desktop Mega-Menu\n- High-density multi-column dropdown in `Navbar.tsx` featuring dedicated vertical icon tiles, subtle pill indicators, and synchronized mobile drawer navigation."
        ),
        array(
            'slug'     => 'autonomous-ai-workforce',
            'title'    => 'Autonomous AI Multi-Agent Workforce & Skills Marquee',
            'category' => 'intelligence',
            'content'  => "# Autonomous AI Multi-Agent Workforce & Skills Marquee\n\nDeployed in **v4.9.379**, the AI Workforce canvas (`/ai-agent`) visualizes Cora's multi-agent autonomous operational model.\n\n## High-Resolution Neural Portrait & Blended Canvas\n- Features neural portrait cutout assets (`cora_hero_agent_cutout.png`) seamlessly integrated with subtle container gradient lighting.\n\n## 4-Row Infinite Skills Marquee\n- Hardware-accelerated CSS marquee (`InfiniteSkillsSection.tsx`) highlighting verified production capabilities across 4 operational streams:\n  * **Stream 1: Operations & Logistics**: Shift scheduling, resource custody, attendance validation, and plant restock triggers.\n  * **Stream 2: CRM & Sales Pipeline**: Lead scoring, WhatsApp automation, proposals, and call synthesis.\n  * **Stream 3: Finance & Legal Vault**: GST SAC 9983 calculations, spot billing, e-sign SHA-256 logs, and daily PDF briefs.\n  * **Stream 4: Creative Delivery**: Watermark proofing, storage accounting, client selections, and multi-ratio cropping."
        ),
        array(
            'slug'     => 'features-catalog-lenis',
            'title'    => 'Features Capability Directory & Lenis Scroll Boundary Isolation',
            'category' => 'overview',
            'content'  => "# Features Capability Directory & Lenis Scroll Boundary Isolation\n\nShipped in **v4.9.378**, this major architectural update standardizes the `/features` catalog.\n\n## Lenis Smooth-Scroll Boundary Isolation (`data-lenis-prevent`)\n- Wraps the interactive sidebar with `data-lenis-prevent` and explicit height boundaries (`max-h-[calc(100vh-120px)] overflow-y-auto`).\n- Prevents wheel-scroll trapping by keeping inner sidebar scrolling independent from global Lenis page scrolling.\n\n## Compact Single-Line Navigation\n- High-density list items with icon glyphs and segmented status filters (*All*, *Released*, *Beta*, *Upcoming*).\n- Search input with positioned vector SVG preventing text overlap.\n\n## Active-Voice Visual Capability Cards\n- Over 40+ module cards rewritten with punchy active voice descriptions and a unified 'Get Started for Free' call-to-action."
        ),
        array(
            'slug'     => 'brand-asset-registry',
            'title'    => 'Enterprise Brand Asset Registry & Turnkey SVG Kit',
            'category' => 'marketing',
            'content'  => "# Enterprise Brand Asset Registry & Turnkey SVG Kit\n\nDeployed in **v4.9.377**, the Brand Asset Registry (`/brand`) centralizes Cora design guidelines.\n\n## Turnkey Vector SVG Download Kit\n- 1-click clipboard SVG markup copy and instant `.svg` file download for Primary Wordmark, Inverted Wordmark, and Symbol Mark.\n\n## Official Design Tokens Reference\n- Complete specifications for the 11-step neutral zinc color scale, typography scale, co-branding guidelines, and logo clearspace rules adhering strictly to Rule 13 zero-outline styling."
        ),
        array(
            'slug'     => 'about-story-timeline',
            'title'    => 'Agency Story Canvas & Chronological Journey Ribbon',
            'category' => 'overview',
            'content'  => "# Agency Story Canvas & Chronological Journey Ribbon\n\nShipped in **v4.9.376**, the redesigned `/about` page communicates Cora's agency operating philosophy.\n\n## Connected Chronological Timeline Ribbon\n- Continuous vertical milestone rail with unified rail segments, completely eliminating floating tick gaps.\n- Mobile timeline spine layout ensuring responsive narrative flow on screens `< 768px`.\n\n## Structured Bento Grid Architecture\n- Core Values bento grid (`CoreValuesSection.tsx`) and dynamic operational week calendar (`DynamicWeekCalendar.tsx`)."
        ),
        array(
            'slug'     => 'contact-validation-suite',
            'title'    => 'Contact Form Multi-Field Input Validation Suite',
            'category' => 'forms',
            'content'  => "# Contact Form Multi-Field Input Validation Suite\n\nDeployed in **v4.9.375**, this release reinforces the public inquiry pipeline (`/contact`).\n\n## Multi-Field Validation Matrix\n- Enforces strict validation across Full Name (length >= 2), RFC 5322 Work Email, numeric Phone regex (`/^[0-9+ -]{7,15}$/`), Company/Studio, and Topic dropdown.\n\n## Accessible Monochromatic Feedback\n- Inline error notifications, accessible ARIA live attributes, and top-floating monochromatic toast dispatch (`window.coraShowToast`)."
        )
    );
}
}

// ── 14. Latest Changelog Entries (v4.9.380) ───────────────────────────────

if ( ! function_exists( 'cora_docs_get_v49380_changelog_entries' ) ) {
function cora_docs_get_v49380_changelog_entries() {
    return array(
        array(
            'module_key'  => 'industries',
            'version'     => '4.9.380',
            'status'      => 'released',
            'title'       => 'Canonical Industry Directory Overhaul & Slug Migration',
            'description' => 'Migrated primary industry vertical directory from /use-cases to canonical /industries with 301 redirect parity, refined desktop mega-menu with dedicated icon tiles and colored pill indicators, 10+ plain-English vertical directories, and dynamic industry comparison table.',
            'ticket_id'   => 'CORA-1220',
        ),
        array(
            'module_key'  => 'ai-agent',
            'version'     => '4.9.379',
            'status'      => 'released',
            'title'       => 'Autonomous AI Workforce & 4-Row Infinite Skills Marquee',
            'description' => 'Deployed dedicated /ai-agent landing canvas, high-resolution neural portrait cutout asset with smooth canvas blend, 4-row infinite skills marquee across operations, sales, finance, and creative delivery, and automated deployment health check.',
            'ticket_id'   => 'CORA-1221',
        ),
        array(
            'module_key'  => 'features',
            'version'     => '4.9.378',
            'status'      => 'released',
            'title'       => 'Features Catalog & Lenis Smooth-Scroll Boundary Isolation',
            'description' => 'Overhauled /features capability catalog, compact single-line sidebar navigation with segmented status filters, Lenis scroll isolation via data-lenis-prevent eliminating wheel-scroll trapping, search icon overlap fix, and 40+ active-voice visual capability cards.',
            'ticket_id'   => 'CORA-1222',
        ),
        array(
            'module_key'  => 'brand',
            'version'     => '4.9.377',
            'status'      => 'released',
            'title'       => 'Enterprise Brand Asset Registry & Turnkey SVG Kit',
            'description' => 'Modernized /brand center with latest agency positioning, 1-click turnkey SVG vector download kit for Primary, Inverted, and Symbol wordmarks, complete design tokens reference, and authentic production UI captures adhering strictly to Rule 13 zero-outline styling.',
            'ticket_id'   => 'CORA-1223',
        ),
        array(
            'module_key'  => 'about',
            'version'     => '4.9.376',
            'status'      => 'released',
            'title'       => 'Agency Story Canvas & Connected Chronological Journey Ribbon',
            'description' => 'Redesigned /about page with full-width narrative layout, connected chronological timeline ribbon with seamless rail segments eliminating floating tick gaps, responsive mobile spine on 375px+ screens, Core Values bento cards, and dynamic operational week calendar.',
            'ticket_id'   => 'CORA-1224',
        ),
        array(
            'module_key'  => 'contact',
            'version'     => '4.9.375',
            'status'      => 'released',
            'title'       => 'Contact Form Validation & Documentation Mobile Layout Polish',
            'description' => 'Shipped robust multi-field client/server validation suite on /contact with monochromatic alerts and ARIA accessibility, streamlined docs sidebar navigation and badge wrapping in DocsClient.tsx, and mobile floating island clearance (pb-28).',
            'ticket_id'   => 'CORA-1225',
        ),
        array(
            'module_key'  => 'nav',
            'version'     => '4.9.375-nav',
            'status'      => 'released',
            'title'       => 'Global Navigation Synchronization & React Hook Integrity',
            'description' => 'Synchronized all desktop, mobile, resources, company, and footer navlinks across Navbar.tsx and Footer.tsx, and resolved React Hook order violation in Navbar.tsx.',
            'ticket_id'   => 'CORA-1226',
        ),
    );
}
}

// ── 15. New Documentation Pages (v4.9.381) ────────────────────────────────

if ( ! function_exists( 'cora_docs_get_new_pages_v49381' ) ) {
function cora_docs_get_new_pages_v49381() {
    return array(
        array(
            'slug'     => 'projects-portfolio-module',
            'title'    => 'Agency Projects & Portfolio Case Studies Module',
            'category' => 'sales',
            'content'  => "# Agency Projects & Portfolio Case Studies Module\n\nShipped in **v4.9.381**, the Projects & Portfolio Case Studies Module empowers marketing agencies and studio workspaces to curate and publish enterprise-grade case studies from the workspace to a high-converting frontend portfolio.\n\n## 6-Tab Drawer Editor Workflow\n- **Tab 1: Overview & Metadata**: Title, slug, client name, industry, and stealth NDA confidentiality masking.\n- **Tab 2: 4-Act Story Narrative**: Executive Summary, The Challenge, The Solution, and Deliverables scope.\n- **Tab 3: Numerical KPI Metrics**: Big numerical KPI stat pills displayed in JetBrains Mono with delta benchmarks.\n- **Tab 4: Media Assets & Visual Gallery**: Hero cover photo URL and multi-asset gallery grid.\n- **Tab 5: Verified Client Testimonial**: Quote text, client name, executive role, and company avatar.\n- **Tab 6: Conversion Bridge & Strategy Audit CTA**: Direct link to free strategy audit or inquiry form.\n\n## Database & API Architecture\n- Managed via `wp_cora_projects` table and AJAX endpoints (`cora_get_projects`, `cora_save_project`, `cora_delete_project`, `cora_toggle_project_publish`, `cora_duplicate_project`).\n- Public headless API at `/cora-api/v1/projects` with Next.js SSG fallback at `/projects`."
        ),
        array(
            'slug'     => 'micro-tools-growth-engine',
            'title'    => 'Public Micro-Tools Growth Engine & Canonical Tool Registry',
            'category' => 'growth',
            'content'  => "# Public Micro-Tools Growth Engine & Canonical Tool Registry\n\nIntroduced in **v4.9.381**, the Cora Public Micro-Tools Growth Engine serves as a top-of-funnel acquisition channel delivering un-gated operational utility directly in the browser.\n\n## Canonical Tool Registry & Inventory\n- 63 verified public micro-tools across 10 problem domains cataloged in `tools-canonical-registry.ts`.\n- Browser-only local computational execution with zero server data transmission for financial inputs.\n\n## 6 Priority Flagship Tools\n1. **WordPress Plugin Stack Cost Calculator** (`/tools/wp-plugin-cost-calculator`): Total Cost of Ownership analysis for plugin maintenance and renewals.\n2. **Website Lead-Leakage Calculator** (`/tools/lead-leakage-calculator`): Measures revenue loss from response latency.\n3. **Agency Scope-Creep Calculator** (`/tools/scope-creep-calculator`): Models unbilled revision hours and EHR erosion.\n4. **Service Project Pricing Calculator** (`/tools/service-pricing-calculator`): Margin modeling and milestone proposal generator.\n5. **WordPress Publishing Friction Calculator** (`/tools/wp-publishing-friction-calculator`): Quantifies copy-paste handoff bottlenecks.\n6. **AI Crawler Access Checker** (`/tools/ai-crawler-checker`): Tests `robots.txt` compliance for OpenAI, Claude, and Perplexity bots.\n\n## Zero-PII Analytics Governance\n- Non-sensitive telemetry strictly restricted to tool execution start, finish, and anonymous diagnostic tier."
        ),
        array(
            'slug'     => 'canvas-github-cicd',
            'title'    => 'Canvas Themes GitHub CI/CD Full-Lifecycle Engine',
            'category' => 'websites',
            'content'  => "# Canvas Themes GitHub CI/CD Full-Lifecycle Engine\n\nHardened in **v4.9.381**, the Canvas Themes workspace module provides bidirectional synchronization between the visual canvas and GitHub repositories.\n\n## Analytical KPI Dashboard & Navigation\n- 4 High-Density KPI cards: PageSpeed Performance Score, LCP Speed, Total Themes/Versions, and Storage Footprint.\n- Sticky 3-subtab navigation: Theme Library, Speed & Core Web Vitals, and Migration & Tools.\n\n## GitHub CI/CD Full-Lifecycle Engine\n- **Device Flow & PAT Auth**: Secure OAuth 2.0 device flow and Personal Access Token storage with dual authentication headers (`Bearer` / `token`).\n- **Branch Management & Automated PRs**: One-click branch creation (`cora_github_create_branch`), automated PR creation (`cora_github_create_pr`), and PR list inspection (`cora_github_get_prs`).\n- **1-Click Merge & Rollback**: Safe PR merge (`cora_github_merge_pr`), instant commit rollback (`cora_github_revert_commit`), and full workspace synchronization (`cora_github_sync_entire_workspace`)."
        ),
        array(
            'slug'     => 'forms-crm-lead-pipeline',
            'title'    => 'Forms to CRM Lead Pipeline Automation & All-Submissions API',
            'category' => 'forms',
            'content'  => "# Forms to CRM Lead Pipeline Automation & All-Submissions API\n\nDeployed in **v4.9.381**, this engine bridges external web intake directly into the Cora Lead CRM with zero manual data entry.\n\n## Automated Lead Ingestion Pipeline\n- On form submission via `cora_rest_submit_form()`, user inputs are sanitized and automatically converted into normalized leads in `wp_cora_leads`.\n- Preserves tenant isolation via workspace `agency_id`, normalizes pipeline stage, and assigns leads to configured team members.\n- Triggers immediate lead cache invalidation (`cora_db_get_leads(true)`), reflecting new leads on the Kanban board with zero page reload.\n\n## Universal Aggregated Submissions REST Endpoint\n- `GET /wp-json/cora/v1/forms/all-submissions` (`cora_rest_get_all_form_submissions`): Cross-form aggregated view across all workspace forms with search, pagination, and tenant isolation."
        )
    );
}
}

// ── 16. Latest Changelog Entries (v4.9.381) ───────────────────────────────

if ( ! function_exists( 'cora_docs_get_v49381_changelog_entries' ) ) {
function cora_docs_get_v49381_changelog_entries() {
    return array(
        array(
            'module_key'  => 'projects',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Agency Projects & Portfolio Case Studies Module',
            'description' => 'Shipped dedicated Projects & Portfolio module with wp_cora_projects schema, 6-tab drawer editor, 5 KPI analytical scorecards, confidentiality/stealth NDA toggle, JetBrains Mono stats, 4-act storytelling layout, and public Next.js frontend portfolio at /projects.',
            'ticket_id'   => 'CORA-1227',
        ),
        array(
            'module_key'  => 'tools',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Public Micro-Tools Growth Engine & Canonical Tool Registry',
            'description' => 'Reconciled 63 public micro-tools across 10 problem domains in tools-canonical-registry.ts, deployed 6 priority flagship calculators (WordPress Plugin Cost, Lead Leakage, Scope Creep, Service Pricing, Publishing Friction, AI Crawler Checker), and zero-PII telemetry governance.',
            'ticket_id'   => 'CORA-1228',
        ),
        array(
            'module_key'  => 'canvas',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Canvas Themes GitHub CI/CD Full-Lifecycle PR & Rollback Engine',
            'description' => 'Overhauled view-canvas.php with 4 KPI analytical cards, sticky 3-subtab bar, and full GitHub integration in Cora_GitHub_Integration: Device Flow, branch creation, automated PR generation, 1-click merge, commit rollback, and full workspace sync.',
            'ticket_id'   => 'CORA-1229',
        ),
        array(
            'module_key'  => 'forms',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Forms to CRM Lead Pipeline Automation & All-Submissions REST Endpoint',
            'description' => 'Automated inbound form submission conversion to CRM leads in cora_rest_submit_form() with stage normalization, tenant isolation, and cache invalidation; added aggregate submissions REST route GET /wp-json/cora/v1/forms/all-submissions.',
            'ticket_id'   => 'CORA-1230',
        ),
        array(
            'module_key'  => 'content',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Editorial Knowledge Engine & High-Authority Article Library',
            'description' => 'Expanded cora-frontend/lib/articles-data.ts with 15+ high-authority guides and teardowns covering WordPress plugin TCO, agency scope creep, speed-to-lead benchmarks, autonomous studio AI, MCP guides, and IT Act 2000 digital contracts.',
            'ticket_id'   => 'CORA-1231',
        ),
        array(
            'module_key'  => 'emails',
            'version'     => '4.9.381',
            'status'      => 'released',
            'title'       => 'Content Suite & Email Infrastructure Hardening',
            'description' => 'Refined publishing workflow in view-content-suite.php and stabilized transactional SMTP relay logging, bounce rate monitoring, and CRM contact auto-suggest in view-emails.php.',
            'ticket_id'   => 'CORA-1232',
        ),
    );
}
}




