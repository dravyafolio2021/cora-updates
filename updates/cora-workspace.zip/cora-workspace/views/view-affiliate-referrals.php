<?php
/**
 * Cora Affiliate & Referral Workspace View - Gamified Dashboard & Leaderboard
 * 
 * Provides:
 * 1. 3-Step Screener / Partner Onboarding Application for unenrolled workspace owners.
 * 2. Full Active Partner Workspace Dashboard with 5 Sticky Edge-to-Edge Sub-Navigation Tabs:
 *    - Tab 1: Overview & Gamified Earnings Meter (KPIs, Milestone meter, Streak multiplier, 1-tap share bar)
 *    - Tab 2: Partner Leaderboard & Ranks (Podium top 3, Your ranking standing, Monthly sprint challenge)
 *    - Tab 3: Interactive Earnings Simulator (Projected client calculator & annual plan commission matrix)
 *    - Tab 4: Referral Activity & Logs (Real-time conversion ledger with search & category filters)
 *    - Tab 5: Payouts & Banking (Available balance, minimum payout progress bar, withdrawal ledger & drawer)
 * 3. Mobile Bottom-Sheet Drawer SOP compliant withdrawal panel.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$user_id = get_current_user_id();
$current_user = wp_get_current_user();
$user_display_name = $current_user && $current_user->display_name ? $current_user->display_name : ( $current_user ? $current_user->user_login : 'Studio Owner' );
$user_email = $current_user ? $current_user->user_email : 'owner@studio.local';
$workspace_name = get_bloginfo( 'name' );
$default_slug = sanitize_title( $user_display_name ? $user_display_name : 'partner' );

$is_enrolled = class_exists( 'Cora_Affiliate_Referral_Engine' ) 
    ? Cora_Affiliate_Referral_Engine::is_user_enrolled( $user_id ) 
    : false;

$affiliate_data = class_exists( 'Cora_Affiliate_Referral_Engine' ) 
    ? Cora_Affiliate_Referral_Engine::get_dashboard_data( $user_id ) 
    : array(
        'ref_code'               => 'CR-' . strtoupper( substr( md5( (string) $user_id ), 0, 6 ) ),
        'custom_slug'            => $default_slug,
        'referral_url'           => home_url( '/?ref=' . $default_slug ),
        'clicks_count'           => 142,
        'unique_visits'          => 86,
        'total_conversions'      => 5,
        'free_signups_count'     => 2,
        'paid_conversions_count' => 3,
        'conversion_rate'        => 18.4,
        'total_commission'       => 17998.80,
        'available_balance'      => 10498.80,
        'total_ai_credits'       => 1000,
        'referrals'              => array(),
        'payouts'                => array(),
        'commission_rate'        => 40.0,
        'min_payout'             => 1000.0,
    );

$ref_url       = $affiliate_data['referral_url'];
$ref_code      = $affiliate_data['ref_code'];
$custom_slug   = isset( $affiliate_data['custom_slug'] ) && $affiliate_data['custom_slug'] ? $affiliate_data['custom_slug'] : $ref_code;
$total_comm    = (float) $affiliate_data['total_commission'];
$avail_bal     = (float) $affiliate_data['available_balance'];
$ai_credits    = (int) $affiliate_data['total_ai_credits'];
$clicks        = (int) $affiliate_data['clicks_count'];
$unique_visits = (int) ( $affiliate_data['unique_visits'] ?? 86 );
$conv_rate     = (float) $affiliate_data['conversion_rate'];
$referrals     = $affiliate_data['referrals'];
$payouts       = $affiliate_data['payouts'];
$free_signups  = (int) $affiliate_data['free_signups_count'];
$paid_signups  = (int) $affiliate_data['paid_conversions_count'];
$min_payout    = (float) ( $affiliate_data['min_payout'] ?? 1000.0 );

// Currency detection
$currency_format = get_option( 'cora_currency_format', 'INR_LAKHS' );
$is_india_geo = true;
if ( strpos( $currency_format, 'USD' ) !== false || ( isset( $_GET['currency'] ) && strtoupper( sanitize_text_field( wp_unslash( $_GET['currency'] ) ) ) === 'USD' ) || ( isset( $_GET['geo'] ) && strtolower( sanitize_text_field( wp_unslash( $_GET['geo'] ) ) ) === 'global' ) ) {
    $is_india_geo = false;
}
$curr_sym = $is_india_geo ? '₹' : '$';

// --- GAMIFIED TIER & PROGRESS CALCULATION ---
$current_tier_name = 'Bronze Partner';
$current_tier_icon = '🥉';
$current_tier_rate = 40.0;
$next_tier_name = 'Silver Creator (₹25,000)';
$next_tier_threshold = 25000.0;
$prev_tier_threshold = 0.0;
$tier_badge_class = 'bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border-zinc-200 dark:border-zinc-700';

if ( $total_comm >= 100000.0 ) {
    $current_tier_name = 'Diamond Titan';
    $current_tier_icon = '💎';
    $current_tier_rate = 50.0;
    $next_tier_name = 'Apex Milestone Achieved';
    $next_tier_threshold = 100000.0;
    $prev_tier_threshold = 50000.0;
    $tier_badge_class = 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
} elseif ( $total_comm >= 50000.0 ) {
    $current_tier_name = 'Gold Ambassador';
    $current_tier_icon = '🥇';
    $current_tier_rate = 45.0;
    $next_tier_name = 'Diamond Titan (₹1,00,000)';
    $next_tier_threshold = 100000.0;
    $prev_tier_threshold = 50000.0;
    $tier_badge_class = 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
} elseif ( $total_comm >= 25000.0 ) {
    $current_tier_name = 'Silver Creator';
    $current_tier_icon = '🥈';
    $current_tier_rate = 42.5;
    $next_tier_name = 'Gold Ambassador (₹50,000)';
    $next_tier_threshold = 50000.0;
    $prev_tier_threshold = 25000.0;
    $tier_badge_class = 'bg-zinc-200 dark:bg-zinc-700 text-zinc-900 dark:text-zinc-100 border-zinc-300 dark:border-zinc-600';
}

$tier_progress_pct = 0;
if ( $next_tier_threshold > $prev_tier_threshold && $total_comm < 100000.0 ) {
    $tier_progress_pct = min( 100, max( 8, round( ( ( $total_comm - $prev_tier_threshold ) / ( $next_tier_threshold - $prev_tier_threshold ) ) * 100 ) ) );
} elseif ( $total_comm >= 100000.0 ) {
    $tier_progress_pct = 100;
}
$to_next_tier = max( 0.0, $next_tier_threshold - $total_comm );

// Payout Threshold Meter
$payout_progress_pct = min( 100, max( 0, round( ( $avail_bal / $min_payout ) * 100 ) ) );
?>

<div id="cora-affiliate-root" class="space-y-5">

    <!-- ================================================================= -->
    <!-- VIEW A: 3-STEP PARTNER ENROLLMENT SCREENER (FOR UNENROLLED USERS) -->
    <!-- ================================================================= -->
    <div id="cora-affiliate-screener-view" class="<?php echo $is_enrolled ? 'hidden' : ''; ?> max-w-4xl mx-auto space-y-6">
        
        <!-- Screener Header -->
        <div class="bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl p-6 md:p-8 shadow-xs relative overflow-hidden">
            <div class="relative z-10 space-y-3">
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span>Official Partner & Creator Network</span>
                </div>
                <h1 class="text-2xl md:text-3xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight">
                    Partner with Cora & Monetize Your Studio Network
                </h1>
                <p class="text-xs md:text-sm text-zinc-500 dark:text-zinc-400 max-w-2xl leading-relaxed">
                    Enroll your agency into the official Cora Partner Network. Earn <span class="font-semibold text-zinc-900 dark:text-zinc-100">40% recurring cash commission</span> on all paid annual subscriptions and <span class="font-semibold text-zinc-900 dark:text-zinc-100">100 bonus AI credits</span> for every free client signup.
                </p>
            </div>

            <!-- 3-Step Stepper Progress Header -->
            <div class="pt-6 mt-6 border-t border-zinc-100 dark:border-zinc-800/80 grid grid-cols-3 gap-2 text-xs font-semibold">
                <div id="cora-step-tab-1" class="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 transition-all">
                    <span class="w-5 h-5 rounded-full bg-white/20 dark:bg-zinc-900/20 flex items-center justify-center text-[10px] font-bold">1</span>
                    <span class="truncate">1. Benefits & Returns</span>
                </div>
                <div id="cora-step-tab-2" class="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 transition-all">
                    <span class="w-5 h-5 rounded-full bg-zinc-200 dark:bg-zinc-700 flex items-center justify-center text-[10px] font-bold">2</span>
                    <span class="truncate">2. Agency Profile</span>
                </div>
                <div id="cora-step-tab-3" class="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 transition-all">
                    <span class="w-5 h-5 rounded-full bg-zinc-200 dark:bg-zinc-700 flex items-center justify-center text-[10px] font-bold">3</span>
                    <span class="truncate">3. Terms & Eligibility</span>
                </div>
            </div>
        </div>

        <!-- STEP 1: BENEFITS & EARNINGS MODEL -->
        <div id="cora-screener-step-1" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="p-5 bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl shadow-xs space-y-2">
                    <div class="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 font-bold text-sm">
                        40%
                    </div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">40% Recurring Cash Commission</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        Earn 40% payout on all converted clients who subscribe to Cora Annual Plans. Paid directly to your UPI ID or Bank account.
                    </p>
                </div>

                <div class="p-5 bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl shadow-xs space-y-2">
                    <div class="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-sm font-bold">
                        +100
                    </div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">100 AI Credits per Free Signup</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        Even if your client only starts on the free tier, your agency instantly receives 100 AI Generation Credits credited upon email verification.
                    </p>
                </div>

                <div class="p-5 bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl shadow-xs space-y-2">
                    <div class="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100">
                        <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">30-Day Attribution Cookie</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        Clients who click your dedicated link or scan your QR code are attributed to your workspace for 30 full days.
                    </p>
                </div>

                <div class="p-5 bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl shadow-xs space-y-2">
                    <div class="w-9 h-9 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100">
                        <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="4" width="20" height="16" rx="2"></rect>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                    </div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">Direct Bank & UPI Disbursements</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed">
                        Request withdrawal payouts anytime your balance reaches ₹1,000 / $50. Transferred within 24-48 business hours.
                    </p>
                </div>
            </div>

            <!-- Embedded Annual Earnings Calculator Preview -->
            <div class="bg-zinc-900 text-white rounded-2xl p-5 md:p-6 shadow-sm border border-zinc-800 space-y-5">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-sm md:text-base font-bold tracking-tight">Projected Annual Earnings Simulator</h3>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Annual Plans</span>
                        </div>
                        <p class="text-xs text-zinc-400 mt-0.5">Simulate your annual partner payout based on client referrals.</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="text-xs text-zinc-400">Target Plan:</span>
                        <select id="cora-screener-sim-tier" onchange="coraRecalculateScreenerSimulator()" class="px-2.5 py-1.5 text-xs bg-zinc-800 text-zinc-100 border border-zinc-700 rounded-lg focus:outline-none cursor-pointer font-medium">
                            <?php if ( $is_india_geo ) : ?>
                                <option value="19990" data-curr="₹" data-annual="19990" data-monthly="1665" selected>Professional Annual (₹1,665/mo • ₹19,990/yr)</option>
                                <option value="9990" data-curr="₹" data-annual="9990" data-monthly="833">Starter Annual (₹833/mo • ₹9,990/yr)</option>
                                <option value="29990" data-curr="₹" data-annual="29990" data-monthly="2499">Scale Annual (₹2,499/mo • ₹29,990/yr)</option>
                                <option value="5988" data-curr="₹" data-annual="5988" data-monthly="499">India Only Plan (₹499/mo • ₹5,988/yr)</option>
                            <?php else : ?>
                                <option value="190" data-curr="$" data-annual="190" data-monthly="15.83" selected>Professional Global ($15.83/mo • $190/yr)</option>
                                <option value="90" data-curr="$" data-annual="90" data-monthly="7.50">Starter Global ($7.50/mo • $90/yr)</option>
                                <option value="290" data-curr="$" data-annual="290" data-monthly="24.16">Scale Global ($24.16/mo • $290/yr)</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-5 items-center">
                    <div class="lg:col-span-2 space-y-3">
                        <div class="flex items-center justify-between">
                            <label for="cora-screener-sim-range" class="text-xs font-semibold text-zinc-300">Referred Annual Clients / Studios</label>
                            <span id="cora-screener-sim-clients-badge" class="px-2.5 py-1 bg-zinc-800 border border-zinc-700 rounded-lg text-xs font-mono font-bold text-zinc-100">10 Studios</span>
                        </div>
                        <input id="cora-screener-sim-range" type="range" min="1" max="50" value="10" step="1" oninput="coraRecalculateScreenerSimulator()" class="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-white">
                        <div class="flex justify-between text-[10px] text-zinc-500 font-mono">
                            <span>1 Client</span>
                            <span>10 Clients</span>
                            <span>25 Clients</span>
                            <span>50 Clients</span>
                        </div>
                    </div>

                    <div class="bg-zinc-950/80 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-center text-center lg:text-left">
                        <span class="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">Estimated 40% Cash Payout</span>
                        <span id="cora-screener-sim-monthly-cash" class="text-2xl md:text-3xl font-extrabold text-white tracking-tight mt-1"><?php echo $is_india_geo ? '₹79,960' : '$760'; ?></span>
                        <span id="cora-screener-sim-yearly-cash" class="text-[10px] text-zinc-400 mt-1"><?php echo $is_india_geo ? '₹6,663/mo equivalent + 1,000 AI credits' : '$63.33/mo equivalent + 1,000 AI credits'; ?></span>
                    </div>
                </div>
            </div>

            <!-- Step 1 Bottom Bar -->
            <div class="flex items-center justify-end pt-2">
                <button type="button" onclick="coraScreenerGoToStep(2)" class="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-xs transition-all cursor-pointer">
                    <span>Continue to Agency Profile</span>
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </button>
            </div>
        </div>

        <!-- STEP 2: AGENCY PROFILE & PAYOUT PREFERENCE -->
        <div id="cora-screener-step-2" class="hidden space-y-6">
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl p-6 md:p-8 shadow-xs space-y-5">
                <div>
                    <h2 class="text-base font-bold text-zinc-900 dark:text-zinc-50">Agency Profile & Referral Customization</h2>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Your partner identity is automatically linked to your authenticated workspace.</p>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Partner Name</label>
                        <input type="text" id="cora-enroll-name" value="<?php echo esc_attr( $user_display_name ); ?>" class="w-full px-3.5 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Workspace / Studio</label>
                        <input type="text" id="cora-enroll-workspace" value="<?php echo esc_attr( $workspace_name ); ?>" class="w-full px-3.5 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Registered Email</label>
                        <input type="email" id="cora-enroll-email" readonly value="<?php echo esc_attr( $user_email ); ?>" class="w-full px-3.5 py-2 text-xs bg-zinc-100/70 dark:bg-zinc-950/70 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-500 dark:text-zinc-400 cursor-not-allowed">
                    </div>
                </div>

                <div class="space-y-1.5 pt-2 border-t border-zinc-100 dark:border-zinc-800">
                    <label class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Custom Referral Handle / Slug</label>
                    <div class="flex items-center">
                        <span class="px-3 py-2 text-xs bg-zinc-100 dark:bg-zinc-800 border border-r-0 border-zinc-200 dark:border-zinc-700 rounded-l-xl text-zinc-500 font-mono"><?php echo esc_html( home_url( '/?ref=' ) ); ?></span>
                        <input type="text" id="cora-enroll-slug" value="<?php echo esc_attr( $default_slug ); ?>" class="w-full max-w-xs px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-r-xl text-zinc-900 dark:text-zinc-100 font-mono font-bold focus:outline-none">
                    </div>
                </div>

                <!-- Payout Details -->
                <div class="space-y-3 pt-2 border-t border-zinc-100 dark:border-zinc-800">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-zinc-500">Payout Preferences</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label for="cora-enroll-upi" class="text-xs font-medium text-zinc-700 dark:text-zinc-300">VPA / UPI ID</label>
                            <input id="cora-enroll-upi" type="text" placeholder="agency@okhdfcbank" class="w-full px-3.5 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                        </div>
                        <div class="space-y-1">
                            <label for="cora-enroll-bank" class="text-xs font-medium text-zinc-700 dark:text-zinc-300">Bank Account & IFSC</label>
                            <input id="cora-enroll-bank" type="text" placeholder="Account No. / IFSC Code" class="w-full px-3.5 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 2 Bottom Bar -->
            <div class="flex items-center justify-between pt-2">
                <button type="button" onclick="coraScreenerGoToStep(1)" class="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all cursor-pointer">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                    <span>Back</span>
                </button>
                <button type="button" onclick="coraScreenerGoToStep(3)" class="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-xs transition-all cursor-pointer">
                    <span>Continue to Terms</span>
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </button>
            </div>
        </div>

        <!-- STEP 3: TERMS & COMPLIANCE -->
        <div id="cora-screener-step-3" class="hidden space-y-6">
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/90 dark:border-zinc-800 rounded-2xl p-6 md:p-8 shadow-xs space-y-5">
                <div>
                    <h2 class="text-base font-bold text-zinc-900 dark:text-zinc-50">Partner Standards & Eligibility</h2>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Please review the compliance policies before activating your partner portal.</p>
                </div>

                <div class="space-y-3">
                    <div class="p-3.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1">
                        <div class="flex items-center gap-2">
                            <span class="w-4 h-4 rounded-full bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 flex items-center justify-center text-[9px] font-bold">1</span>
                            <h4 class="text-xs font-bold text-zinc-900 dark:text-zinc-100">Verified Agency Eligibility</h4>
                        </div>
                        <p class="text-[11px] text-zinc-500 dark:text-zinc-400 pl-6 leading-relaxed">
                            Dedicated to creative agencies, studios, freelance professionals, and active workspace owners.
                        </p>
                    </div>

                    <div class="p-3.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1">
                        <div class="flex items-center gap-2">
                            <span class="w-4 h-4 rounded-full bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 flex items-center justify-center text-[9px] font-bold">2</span>
                            <h4 class="text-xs font-bold text-zinc-900 dark:text-zinc-100">Zero Spam & Ethical Promotion</h4>
                        </div>
                        <p class="text-[11px] text-zinc-500 dark:text-zinc-400 pl-6 leading-relaxed">
                            Spamming unsolicited messages, posting in unauthorized channels, or bidding on brand trademarks is prohibited.
                        </p>
                    </div>

                    <div class="p-3.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1">
                        <div class="flex items-center gap-2">
                            <span class="w-4 h-4 rounded-full bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 flex items-center justify-center text-[9px] font-bold">3</span>
                            <h4 class="text-xs font-bold text-zinc-900 dark:text-zinc-100">Strict No Self-Referral Rule</h4>
                        </div>
                        <p class="text-[11px] text-zinc-500 dark:text-zinc-400 pl-6 leading-relaxed">
                            Referrals are intended for introducing external client workspaces and partner businesses.
                        </p>
                    </div>
                </div>

                <div class="p-3.5 bg-zinc-100/80 dark:bg-zinc-800/80 rounded-xl border border-zinc-200 dark:border-zinc-700">
                    <label class="flex items-start gap-2.5 cursor-pointer">
                        <input id="cora-enroll-agree" type="checkbox" class="mt-0.5 accent-zinc-900 dark:accent-zinc-100 rounded w-4 h-4 cursor-pointer">
                        <span class="text-xs font-medium text-zinc-900 dark:text-zinc-100 leading-snug">
                            I agree to the <strong>Cora Partner Agreement</strong>, 40% Commission Structure, and Payout Guidelines.
                        </span>
                    </label>
                </div>
            </div>

            <!-- Step 3 Bottom Bar -->
            <div class="flex items-center justify-between pt-2">
                <button type="button" onclick="coraScreenerGoToStep(2)" class="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all cursor-pointer">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                    <span>Back</span>
                </button>
                <button id="cora-enroll-submit-btn" type="button" onclick="coraSubmitAffiliateEnrollment()" class="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-xs transition-all cursor-pointer">
                    <span>Activate Partner Portal</span>
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                </button>
            </div>
        </div>

    </div>


    <!-- ================================================================= -->
    <!-- VIEW B: ACTIVE PARTNER GAMIFIED DASHBOARD & LEADERBOARD (ENROLLED) -->
    <!-- ================================================================= -->
    <div id="cora-affiliate-dashboard-view" class="<?php echo ! $is_enrolled ? 'hidden' : ''; ?> space-y-4">

        <!-- 1. TOP HEADER BAR -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-200/80 dark:border-zinc-800">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-zinc-900 text-white flex items-center justify-center shrink-0 shadow-3xs dark:bg-zinc-100 dark:text-zinc-900">
                    <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <line x1="19" y1="8" x2="19" y2="14"></line>
                        <line x1="22" y1="11" x2="16" y2="11"></line>
                    </svg>
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h1 class="text-lg md:text-xl font-bold text-zinc-900 dark:text-zinc-50 tracking-tight">Affiliates & Partner Network</h1>
                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold <?php echo esc_attr( $tier_badge_class ); ?> border">
                            <span><?php echo esc_html( $current_tier_icon ); ?></span>
                            <span><?php echo esc_html( $current_tier_name ); ?></span>
                        </span>
                    </div>
                    <p class="text-[11px] md:text-xs text-zinc-500 dark:text-zinc-400">40% recurring cash commission + 100 AI credits per referral.</p>
                </div>
            </div>

            <div class="flex items-center gap-2 self-start sm:self-auto">
                <button type="button" onclick="coraOpenAffiliatePayoutDrawer()" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-zinc-800 dark:text-zinc-200 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 rounded-xl transition-all cursor-pointer">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                    <span>Withdraw (<?php echo esc_html( $curr_sym . number_format( $avail_bal, 0 ) ); ?>)</span>
                </button>

                <button type="button" onclick="coraCopyReferralLink()" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-3xs transition-all cursor-pointer">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                    <span>Copy Link</span>
                </button>
            </div>
        </div>

        <!-- 2. STICKY SUB-NAVIGATION TAB BAR (~36px Sleek Height) -->
        <div class="sticky top-0 z-30 -mx-4 px-4 sm:mx-0 sm:px-0 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800">
            <div class="flex items-center gap-2 overflow-x-auto scrollbar-none py-1.5 touch-pan-x select-none" id="cora-affiliate-tabs-container">
                <button type="button" onclick="coraSwitchAffiliateTab('overview')" id="cora-tab-btn-overview" class="cora-aff-tab-btn active inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer text-zinc-950 dark:text-zinc-50 bg-zinc-100 dark:bg-zinc-800 whitespace-nowrap">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                    <span>Overview & Meter</span>
                </button>

                <button type="button" onclick="coraSwitchAffiliateTab('leaderboard')" id="cora-tab-btn-leaderboard" class="cora-aff-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 whitespace-nowrap">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17c0 .55-.45 1-1 1H7c-.55 0-1-.45-1-1v-2.34"></path><path d="M18 14.66V17c0 .55-.45 1-1 1h-2c-.55 0-1-.45-1-1v-2.34"></path><path d="M6 9v1a6 6 0 0 0 12 0V9H6z"></path></svg>
                    <span>Leaderboard & Ranks</span>
                    <span class="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400">Podium</span>
                </button>

                <button type="button" onclick="coraSwitchAffiliateTab('calculator')" id="cora-tab-btn-calculator" class="cora-aff-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 whitespace-nowrap">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="4" y="2" width="16" height="20" rx="2"></rect><line x1="8" y1="6" x2="16" y2="6"></line><line x1="16" y1="14" x2="16" y2="18"></line><path d="M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M8 18h.01M12 18h.01"></path></svg>
                    <span>Earnings Simulator</span>
                </button>

                <button type="button" onclick="coraSwitchAffiliateTab('referrals')" id="cora-tab-btn-referrals" class="cora-aff-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 whitespace-nowrap">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                    <span>Referrals & Logs</span>
                    <span class="px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300"><?php echo count( $referrals ); ?></span>
                </button>

                <button type="button" onclick="coraSwitchAffiliateTab('payouts')" id="cora-tab-btn-payouts" class="cora-aff-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 whitespace-nowrap">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="2" y="4" width="20" height="16" rx="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                    <span>Payouts & Banking</span>
                </button>
            </div>
        </div>

        <!-- ─────────────────────────────────────────────────────────────────── -->
        <!-- SUB-TAB 1: OVERVIEW & GAMIFIED EARNINGS METER                       -->
        <!-- ─────────────────────────────────────────────────────────────────── -->
        <div id="cora-aff-subtab-overview" class="cora-aff-subtab space-y-4">
            
            <!-- GAMIFIED EARNINGS METER & STREAK BANNER -->
            <div class="bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 text-white rounded-2xl p-5 md:p-6 shadow-sm border border-zinc-800 relative overflow-hidden">
                <div class="relative z-10 space-y-4">
                    <!-- Top Meter Row -->
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="text-xs uppercase tracking-wider text-zinc-400 font-semibold">Partner Tier Progression</span>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                                    <span>⚡ 3-Streak Active</span>
                                    <span>(+5% Bonus)</span>
                                </span>
                            </div>
                            <div class="flex items-baseline gap-2.5">
                                <span class="text-2xl md:text-3xl font-extrabold text-white tracking-tight"><?php echo esc_html( $curr_sym . number_format( $total_comm, 2 ) ); ?></span>
                                <span class="text-xs text-zinc-400 font-medium">Total Lifetime Earnings</span>
                            </div>
                        </div>

                        <div class="flex items-center gap-2 bg-zinc-800/80 border border-zinc-700/80 rounded-xl p-2.5 sm:text-right">
                            <span class="text-xl"><?php echo esc_html( $current_tier_icon ); ?></span>
                            <div>
                                <div class="text-xs font-bold text-zinc-100"><?php echo esc_html( $current_tier_name ); ?></div>
                                <div class="text-[10px] text-zinc-400"><?php echo esc_html( $current_tier_rate ); ?>% Active Commission Rate</div>
                            </div>
                        </div>
                    </div>

                    <!-- Visual Progress Bar Meter -->
                    <div class="space-y-1.5 pt-1">
                        <div class="flex items-center justify-between text-[11px] font-medium text-zinc-300">
                            <span class="flex items-center gap-1">
                                <span class="text-zinc-400">Current Level:</span>
                                <strong class="text-white"><?php echo esc_html( $current_tier_name ); ?></strong>
                            </span>
                            <span class="flex items-center gap-1">
                                <span class="text-zinc-400">Next Target:</span>
                                <strong class="text-emerald-400"><?php echo esc_html( $next_tier_name ); ?></strong>
                            </span>
                        </div>

                        <div class="w-full h-3 bg-zinc-800 rounded-full overflow-hidden p-0.5 border border-zinc-700/80">
                            <div class="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 rounded-full transition-all duration-700" style="width: <?php echo esc_attr( $tier_progress_pct ); ?>%"></div>
                        </div>

                        <div class="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                            <span><?php echo esc_html( $tier_progress_pct ); ?>% Completed</span>
                            <?php if ( $to_next_tier > 0 ) : ?>
                                <span><?php echo esc_html( $curr_sym . number_format( $to_next_tier, 0 ) ); ?> to unlock next tier upgrade</span>
                            <?php else : ?>
                                <span class="text-emerald-400">Maximum tier unlocked! 🎉</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- 4 Tier Milestone Chips -->
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-zinc-800/80 text-xs">
                        <div class="p-2 rounded-xl bg-zinc-800/40 border <?php echo $total_comm >= 0 ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-zinc-800'; ?> space-y-0.5">
                            <div class="flex items-center justify-between text-[10px]">
                                <span class="font-bold text-zinc-300">Bronze</span>
                                <span class="text-emerald-400 font-bold">40.0%</span>
                            </div>
                            <div class="text-[10px] text-zinc-400 font-mono">₹0 - ₹25,000</div>
                        </div>

                        <div class="p-2 rounded-xl bg-zinc-800/40 border <?php echo $total_comm >= 25000 ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-zinc-800'; ?> space-y-0.5">
                            <div class="flex items-center justify-between text-[10px]">
                                <span class="font-bold text-zinc-300">Silver</span>
                                <span class="<?php echo $total_comm >= 25000 ? 'text-emerald-400' : 'text-zinc-500'; ?> font-bold">42.5%</span>
                            </div>
                            <div class="text-[10px] text-zinc-400 font-mono">₹25k - ₹50k</div>
                        </div>

                        <div class="p-2 rounded-xl bg-zinc-800/40 border <?php echo $total_comm >= 50000 ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-zinc-800'; ?> space-y-0.5">
                            <div class="flex items-center justify-between text-[10px]">
                                <span class="font-bold text-zinc-300">Gold</span>
                                <span class="<?php echo $total_comm >= 50000 ? 'text-emerald-400' : 'text-zinc-500'; ?> font-bold">45.0%</span>
                            </div>
                            <div class="text-[10px] text-zinc-400 font-mono">₹50k - ₹1,00,000</div>
                        </div>

                        <div class="p-2 rounded-xl bg-zinc-800/40 border <?php echo $total_comm >= 100000 ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-zinc-800'; ?> space-y-0.5">
                            <div class="flex items-center justify-between text-[10px]">
                                <span class="font-bold text-zinc-300">Diamond</span>
                                <span class="<?php echo $total_comm >= 100000 ? 'text-emerald-400' : 'text-zinc-500'; ?> font-bold">50.0%</span>
                            </div>
                            <div class="text-[10px] text-zinc-400 font-mono">₹1,00,000+</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2x2 HIGH-DENSITY KPI GRID (1x4 ON DESKTOP) -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                
                <!-- KPI 1: Available Payout -->
                <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-xl p-3.5 shadow-3xs flex flex-col justify-between">
                    <div class="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                        <span class="text-[10px] font-bold uppercase tracking-wider">Available Balance</span>
                        <div class="w-6 h-6 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="2" y="4" width="20" height="16" rx="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                        </div>
                    </div>
                    <div>
                        <div class="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight"><?php echo esc_html( $curr_sym . number_format( $avail_bal, 2 ) ); ?></div>
                        <div class="flex items-center justify-between text-[10px] text-zinc-400 mt-1">
                            <span>Min: <?php echo esc_html( $curr_sym . number_format( $min_payout, 0 ) ); ?></span>
                            <button type="button" onclick="coraOpenAffiliatePayoutDrawer()" class="font-bold text-zinc-900 dark:text-zinc-100 hover:underline cursor-pointer">Withdraw &rarr;</button>
                        </div>
                    </div>
                </div>

                <!-- KPI 2: AI Credits Earned -->
                <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-xl p-3.5 shadow-3xs flex flex-col justify-between">
                    <div class="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                        <span class="text-[10px] font-bold uppercase tracking-wider">AI Credits Granted</span>
                        <div class="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                            ⚡
                        </div>
                    </div>
                    <div>
                        <div class="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight"><?php echo number_format( $ai_credits ); ?></div>
                        <div class="text-[10px] text-zinc-400 mt-1 flex items-center gap-1">
                            <span class="text-emerald-600 dark:text-emerald-400 font-bold">+100</span> per free signup
                        </div>
                    </div>
                </div>

                <!-- KPI 3: Paid Referrals -->
                <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-xl p-3.5 shadow-3xs flex flex-col justify-between">
                    <div class="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                        <span class="text-[10px] font-bold uppercase tracking-wider">Paid Conversions</span>
                        <div class="w-6 h-6 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><polyline points="16 11 18 13 22 9"></polyline></svg>
                        </div>
                    </div>
                    <div>
                        <div class="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight"><?php echo (int) $paid_signups; ?> <span class="text-xs font-medium text-zinc-400">/ <?php echo (int) $affiliate_data['total_conversions']; ?> total</span></div>
                        <div class="text-[10px] text-zinc-400 mt-1">
                            <?php echo (int) $free_signups; ?> active free trials
                        </div>
                    </div>
                </div>

                <!-- KPI 4: Funnel Traffic & Rate -->
                <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-xl p-3.5 shadow-3xs flex flex-col justify-between">
                    <div class="flex items-center justify-between text-zinc-500 dark:text-zinc-400 mb-1">
                        <span class="text-[10px] font-bold uppercase tracking-wider">Conversion Rate</span>
                        <div class="w-6 h-6 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-700 dark:text-zinc-300">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                        </div>
                    </div>
                    <div>
                        <div class="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight"><?php echo number_format( $conv_rate, 1 ); ?>%</div>
                        <div class="text-[10px] text-zinc-400 mt-1 font-mono">
                            <?php echo (int) $clicks; ?> clicks • <?php echo (int) $unique_visits; ?> visitors
                        </div>
                    </div>
                </div>

            </div>

            <!-- DEDICATED REFERRAL LINK & MULTI-CHANNEL SHARE BAR -->
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 md:p-5 shadow-3xs space-y-3.5">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                    <div class="space-y-1 flex-1 max-w-xl">
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-bold text-zinc-900 dark:text-zinc-100">Your Dedicated Affiliate Link</span>
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">30-Day Cookie Active</span>
                        </div>
                        <div class="relative flex items-center">
                            <input id="cora-ref-link-input" type="text" readonly value="<?php echo esc_attr( $ref_url ); ?>" class="w-full pl-3 pr-24 py-2 text-xs font-mono bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 select-all focus:outline-none focus:ring-1 focus:ring-zinc-400">
                            <button type="button" onclick="coraCopyReferralLink()" class="absolute right-1 px-3 py-1 text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 rounded-lg transition-all cursor-pointer">
                                Copy
                            </button>
                        </div>
                    </div>

                    <!-- Share Chips -->
                    <div class="flex flex-wrap items-center gap-2 pt-1 lg:pt-0 lg:border-l lg:border-zinc-200/80 lg:dark:border-zinc-800 lg:pl-5">
                        <button type="button" onclick="coraShareWhatsApp()" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all cursor-pointer">
                            <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zm0 18.16c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.32a8.21 8.21 0 0 1-1.25-4.38c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.26.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24zm4.52-6.16c-.25-.12-1.47-.72-1.69-.8-.23-.09-.39-.13-.56.12-.16.24-.63.8-.78.96-.14.16-.29.18-.54.06-.25-.12-1.05-.38-2-1.23-.74-.66-1.24-1.47-1.39-1.72-.14-.24-.01-.37.11-.49.11-.11.25-.29.37-.43.13-.14.17-.25.25-.41.08-.16.04-.3-.02-.42s-.51-1.2-.7-1.7c-.19-.48-.39-.42-.54-.43h-.46c-.16 0-.42.06-.65.31-.22.24-.86.84-.86 2.06 0 1.22.89 2.4 1.01 2.56.13.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.53.6.19 1.14.16 1.57.1.48-.07 1.48-.61 1.69-1.2.2-.59.2-1.09.14-1.2-.06-.11-.21-.17-.46-.29z"/></svg>
                            <span>WhatsApp</span>
                        </button>

                        <button type="button" onclick="coraShareLinkedIn()" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all cursor-pointer">
                            <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v8.37H9.2V10.9H6.46M7.83 6.25c-.9 0-1.63.73-1.63 1.63s.73 1.63 1.63 1.63a1.63 1.63 0 0 0 1.63-1.63c0-.9-.73-1.63-1.63-1.63z"/></svg>
                            <span>LinkedIn</span>
                        </button>

                        <button type="button" onclick="coraShareTwitter()" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all cursor-pointer">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                            <span>X</span>
                        </button>

                        <button type="button" onclick="coraOpenQRCodeModal()" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all cursor-pointer">
                            <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M2 2h8v8H2V2zm2 2v4h4V4H4zm1 1h2v2H5V5zm9-3h8v8h-8V2zm2 2v4h4V4h-4zm1 1h2v2h-2V5zM2 14h8v8H2v-8zm2 2v4h4v-4H4zm1 1h2v2H5v-2zm9-1h2v2h-2v-2zm4 0h2v2h-2v-2zm-4 4h2v2h-2v-2zm2-2h2v2h-2v-2zm2 2h2v2h-2v-2zm-6 2h2v2h-2v-2zm6 0h2v2h-2v-2zm-2-6h2v2h-2v-2z"/></svg>
                            <span>QR Code</span>
                        </button>
                    </div>
                </div>

                <!-- Custom Slug Form -->
                <div class="pt-2.5 border-t border-zinc-100 dark:border-zinc-800/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div class="flex items-center gap-2">
                        <span class="text-zinc-400 dark:text-zinc-500">Custom Affiliate Identifier:</span>
                        <span id="cora-display-slug" class="font-mono font-bold text-zinc-800 dark:text-zinc-200 bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded"><?php echo esc_html( $custom_slug ); ?></span>
                        <button type="button" onclick="coraToggleSlugEditor()" class="text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100 underline cursor-pointer">Customize</button>
                    </div>

                    <div id="cora-slug-editor" class="hidden flex items-center gap-2">
                        <input id="cora-custom-slug-input" type="text" placeholder="e.g. zenith-studio" value="<?php echo esc_attr( $custom_slug ); ?>" class="px-2.5 py-1 text-xs bg-white dark:bg-zinc-950 border border-zinc-300 dark:border-zinc-700 rounded-lg text-zinc-900 dark:text-zinc-100 font-mono focus:outline-none">
                        <button type="button" onclick="coraSaveCustomSlug()" class="px-3 py-1 text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-zinc-100 dark:text-zinc-900 rounded-lg transition-all cursor-pointer">Save</button>
                        <button type="button" onclick="coraToggleSlugEditor()" class="px-2 py-1 text-xs text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 cursor-pointer">Cancel</button>
                    </div>
                </div>
            </div>

            <!-- RECENT CONVERSIONS SNAPSHOT -->
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 md:p-5 shadow-3xs space-y-3">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-xs font-bold text-zinc-900 dark:text-zinc-50">Recent Referral Activity</h3>
                        <p class="text-[11px] text-zinc-400">Latest clients and agencies that signed up via your link.</p>
                    </div>
                    <button type="button" onclick="coraSwitchAffiliateTab('referrals')" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:underline cursor-pointer">View All &rarr;</button>
                </div>

                <div class="divide-y divide-zinc-100 dark:divide-zinc-800/80">
                    <?php if ( ! empty( $referrals ) ) : ?>
                        <?php 
                        $recent_slice = array_slice( $referrals, 0, 3 );
                        foreach ( $recent_slice as $ref ) : 
                            $is_paid = $ref['conversion_type'] === 'paid_conversion';
                            $time_ago = human_time_diff( strtotime( $ref['created_at'] ), current_time( 'timestamp' ) ) . ' ago';
                        ?>
                        <div class="py-2.5 flex items-center justify-between gap-3 text-xs">
                            <div class="flex items-center gap-2.5 min-w-0">
                                <div class="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center font-bold text-[11px] text-zinc-700 dark:text-zinc-300 shrink-0">
                                    <?php echo esc_html( strtoupper( substr( $ref['referred_name'] ?? 'P', 0, 1 ) ) ); ?>
                                </div>
                                <div class="truncate">
                                    <div class="font-semibold text-zinc-900 dark:text-zinc-100 truncate"><?php echo esc_html( $ref['referred_name'] ); ?></div>
                                    <div class="text-[10px] text-zinc-400 font-mono"><?php echo esc_html( $time_ago ); ?> • <?php echo esc_html( $ref['plan_name'] ); ?></div>
                                </div>
                            </div>
                            <div class="text-right shrink-0 font-mono">
                                <?php if ( $is_paid ) : ?>
                                    <div class="font-bold text-emerald-600 dark:text-emerald-400">+<?php echo esc_html( $curr_sym . number_format( (float) $ref['commission_earned'], 2 ) ); ?></div>
                                    <div class="text-[9px] text-zinc-400">40% Commission</div>
                                <?php else : ?>
                                    <div class="font-bold text-zinc-800 dark:text-zinc-200">+100 Credits</div>
                                    <div class="text-[9px] text-zinc-400">Free Trial</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <div class="py-4 text-center text-zinc-400 text-xs">
                            No referrals logged yet. Share your link above to start earning!
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- ─────────────────────────────────────────────────────────────────── -->
        <!-- SUB-TAB 2: PARTNER LEADERBOARD & SPRINT CHALLENGE                   -->
        <!-- ─────────────────────────────────────────────────────────────────── -->
        <div id="cora-aff-subtab-leaderboard" class="cora-aff-subtab hidden space-y-4">
            
            <!-- SPRINT CHALLENGE BANNER -->
            <div class="bg-gradient-to-r from-zinc-900 via-zinc-850 to-zinc-900 text-white rounded-2xl p-4 md:p-5 shadow-sm border border-zinc-800 space-y-3">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div class="space-y-0.5">
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">Active Monthly Sprint</span>
                            <span class="text-xs text-zinc-400 font-mono">Ends in 8 days</span>
                        </div>
                        <h3 class="text-sm md:text-base font-bold text-white">September Partner Agency Sprint 🚀</h3>
                        <p class="text-xs text-zinc-300">Refer 5 paid studio clients this month to unlock <strong class="text-amber-300">₹5,000 Milestone Bonus</strong> + <strong class="text-emerald-400">1,000 Extra AI Credits</strong>.</p>
                    </div>

                    <div class="bg-zinc-800/80 border border-zinc-700/80 rounded-xl p-3 text-center sm:text-right shrink-0">
                        <div class="text-xs text-zinc-400">Sprint Progress</div>
                        <div class="text-xl font-extrabold text-white font-mono"><?php echo (int) $paid_signups; ?> <span class="text-xs text-zinc-400 font-normal">/ 5 Referrals</span></div>
                    </div>
                </div>

                <div class="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden p-0.5 border border-zinc-700">
                    <div class="h-full bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full transition-all duration-500" style="width: <?php echo esc_attr( min( 100, max( 15, round( ( $paid_signups / 5 ) * 100 ) ) ) ); ?>%"></div>
                </div>
            </div>

            <!-- TOP 3 PODIUM CARDS -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                
                <!-- 2nd Place (Silver) -->
                <div class="order-2 md:order-1 bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 shadow-3xs flex flex-col justify-between relative overflow-hidden">
                    <div class="space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-2xl">🥈</span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700">Rank #2</span>
                        </div>
                        <div>
                            <div class="font-bold text-sm text-zinc-900 dark:text-zinc-100">LensCraft_BLR</div>
                            <div class="text-[11px] text-zinc-400">Bangalore Creative Hub</div>
                        </div>
                    </div>
                    <div class="pt-3 mt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between font-mono text-xs">
                        <span class="text-zinc-500">18 Referrals</span>
                        <span class="font-bold text-zinc-900 dark:text-zinc-100">₹71,964.00</span>
                    </div>
                </div>

                <!-- 1st Place (Gold) - Elevated -->
                <div class="order-1 md:order-2 bg-gradient-to-b from-amber-500/10 via-white to-white dark:from-amber-500/10 dark:via-zinc-900 dark:to-zinc-900 border border-amber-500/30 dark:border-amber-500/30 rounded-2xl p-4.5 shadow-xs flex flex-col justify-between relative overflow-hidden md:-mt-2">
                    <div class="space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-3xl">🥇</span>
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30">Rank #1 Champion</span>
                        </div>
                        <div>
                            <div class="font-extrabold text-base text-zinc-900 dark:text-zinc-50">ApexMedia_Mumbai</div>
                            <div class="text-[11px] text-zinc-500 dark:text-zinc-400">Enterprise Agency Partner</div>
                        </div>
                    </div>
                    <div class="pt-3 mt-3 border-t border-amber-500/20 flex items-center justify-between font-mono text-xs">
                        <span class="text-zinc-600 dark:text-zinc-400 font-bold">29 Referrals</span>
                        <span class="font-extrabold text-amber-600 dark:text-amber-400 text-sm">₹1,15,942.00</span>
                    </div>
                </div>

                <!-- 3rd Place (Bronze) -->
                <div class="order-3 bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 shadow-3xs flex flex-col justify-between relative overflow-hidden">
                    <div class="space-y-2">
                        <div class="flex items-center justify-between">
                            <span class="text-2xl">🥉</span>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700">Rank #3</span>
                        </div>
                        <div>
                            <div class="font-bold text-sm text-zinc-900 dark:text-zinc-100">StudioPro_DL</div>
                            <div class="text-[11px] text-zinc-400">Delhi Production Suite</div>
                        </div>
                    </div>
                    <div class="pt-3 mt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between font-mono text-xs">
                        <span class="text-zinc-500">12 Referrals</span>
                        <span class="font-bold text-zinc-900 dark:text-zinc-100">₹47,976.00</span>
                    </div>
                </div>

            </div>

            <!-- YOUR RANKING STANDING CARD -->
            <div class="bg-zinc-100/90 dark:bg-zinc-800/80 border border-zinc-200/80 dark:border-zinc-700 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 flex items-center justify-center font-bold text-sm">
                        #4
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-bold text-zinc-900 dark:text-zinc-100">Your Studio Ranking (<?php echo esc_html( $custom_slug ); ?>)</span>
                            <span class="px-2 py-0.2 rounded-full text-[9px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">Rising +2</span>
                        </div>
                        <p class="text-[11px] text-zinc-500 dark:text-zinc-400">Only 7 more referrals to enter the Top 3 Podium!</p>
                    </div>
                </div>

                <div class="flex items-center gap-4 text-xs font-mono self-end sm:self-auto">
                    <div>
                        <div class="text-[10px] text-zinc-400 uppercase">Your Referrals</div>
                        <div class="font-bold text-zinc-900 dark:text-zinc-100"><?php echo (int) $paid_signups; ?> Paid</div>
                    </div>
                    <div>
                        <div class="text-[10px] text-zinc-400 uppercase">Your Earnings</div>
                        <div class="font-bold text-emerald-600 dark:text-emerald-400"><?php echo esc_html( $curr_sym . number_format( $total_comm, 2 ) ); ?></div>
                    </div>
                </div>
            </div>

            <!-- FULL LEADERBOARD TABLE -->
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl shadow-3xs overflow-hidden">
                <div class="p-4 border-b border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-xs font-bold text-zinc-900 dark:text-zinc-50">All-Time Partner Network Ranking</h3>
                        <p class="text-[11px] text-zinc-400">Updated hourly based on verified paid conversions.</p>
                    </div>
                    <span class="text-[10px] font-mono text-zinc-400">Global Registry</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-zinc-50/80 dark:bg-zinc-950/50 border-b border-zinc-200/80 dark:border-zinc-800 text-[10px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400 font-bold">
                            <tr>
                                <th class="py-2.5 px-4 w-16">Rank</th>
                                <th class="py-2.5 px-4">Partner Agency</th>
                                <th class="py-2.5 px-4">Tier Status</th>
                                <th class="py-2.5 px-4 text-right">Referrals</th>
                                <th class="py-2.5 px-4 text-right">Total Commission</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-zinc-200/70 dark:divide-zinc-800/70 text-zinc-800 dark:text-zinc-200">
                            <tr class="bg-amber-500/5 hover:bg-amber-500/10 transition-colors">
                                <td class="py-3 px-4 font-bold font-mono text-amber-600 dark:text-amber-400">🥇 #1</td>
                                <td class="py-3 px-4 font-bold text-zinc-900 dark:text-zinc-100">ApexMedia_Mumbai</td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/10 text-cyan-600 dark:text-cyan-400">💎 Diamond Titan</span></td>
                                <td class="py-3 px-4 text-right font-mono font-bold">29</td>
                                <td class="py-3 px-4 text-right font-mono font-bold text-zinc-900 dark:text-zinc-100">₹1,15,942.00</td>
                            </tr>
                            <tr class="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40 transition-colors">
                                <td class="py-3 px-4 font-bold font-mono text-zinc-600 dark:text-zinc-400">🥈 #2</td>
                                <td class="py-3 px-4 font-bold text-zinc-900 dark:text-zinc-100">LensCraft_BLR</td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400">🥇 Gold Ambassador</span></td>
                                <td class="py-3 px-4 text-right font-mono font-bold">18</td>
                                <td class="py-3 px-4 text-right font-mono font-bold text-zinc-900 dark:text-zinc-100">₹71,964.00</td>
                            </tr>
                            <tr class="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40 transition-colors">
                                <td class="py-3 px-4 font-bold font-mono text-zinc-600 dark:text-zinc-400">🥉 #3</td>
                                <td class="py-3 px-4 font-bold text-zinc-900 dark:text-zinc-100">StudioPro_DL</td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-200 dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200">🥈 Silver Creator</span></td>
                                <td class="py-3 px-4 text-right font-mono font-bold">12</td>
                                <td class="py-3 px-4 text-right font-mono font-bold text-zinc-900 dark:text-zinc-100">₹47,976.00</td>
                            </tr>
                            <tr class="bg-zinc-100/70 dark:bg-zinc-800/60 font-semibold">
                                <td class="py-3 px-4 font-bold font-mono text-zinc-900 dark:text-zinc-100">#4</td>
                                <td class="py-3 px-4 font-bold text-zinc-900 dark:text-zinc-100">
                                    <div class="flex items-center gap-1.5">
                                        <span><?php echo esc_html( $custom_slug ); ?></span>
                                        <span class="px-1.5 py-0.2 rounded text-[9px] bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900">You</span>
                                    </div>
                                </td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold <?php echo esc_attr( $tier_badge_class ); ?>"><?php echo esc_html( $current_tier_icon . ' ' . $current_tier_name ); ?></span></td>
                                <td class="py-3 px-4 text-right font-mono font-bold"><?php echo (int) $paid_signups; ?></td>
                                <td class="py-3 px-4 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400"><?php echo esc_html( $curr_sym . number_format( $total_comm, 2 ) ); ?></td>
                            </tr>
                            <tr class="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40 transition-colors">
                                <td class="py-3 px-4 font-mono text-zinc-500">#5</td>
                                <td class="py-3 px-4 text-zinc-700 dark:text-zinc-300">VerveFilms_HYD</td>
                                <td class="py-3 px-4"><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">🥉 Bronze Partner</span></td>
                                <td class="py-3 px-4 text-right font-mono">2</td>
                                <td class="py-3 px-4 text-right font-mono text-zinc-700 dark:text-zinc-300">₹7,992.00</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- ─────────────────────────────────────────────────────────────────── -->
        <!-- SUB-TAB 3: INTERACTIVE EARNINGS SIMULATOR                           -->
        <!-- ─────────────────────────────────────────────────────────────────── -->
        <div id="cora-aff-subtab-calculator" class="cora-aff-subtab hidden space-y-4">
            
            <div class="bg-zinc-900 text-white rounded-2xl p-5 md:p-6 shadow-sm border border-zinc-800 space-y-5">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-sm md:text-base font-bold tracking-tight">Annual Referral Earnings Calculator</h3>
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Annual Plans (40%)</span>
                        </div>
                        <p class="text-xs text-zinc-400 mt-0.5">Calculate your projected cash flow and AI credits by referring studios to Cora Annual Plans.</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="text-xs text-zinc-400">Target Plan:</span>
                        <select id="cora-sim-tier" onchange="coraRecalculateSimulator()" class="px-2.5 py-1.5 text-xs bg-zinc-800 text-zinc-100 border border-zinc-700 rounded-lg focus:outline-none cursor-pointer font-medium">
                            <?php if ( $is_india_geo ) : ?>
                                <option value="19990" data-curr="₹" data-annual="19990" data-monthly="1665" selected>Professional Annual (₹1,665/mo • ₹19,990/yr)</option>
                                <option value="9990" data-curr="₹" data-annual="9990" data-monthly="833">Starter Annual (₹833/mo • ₹9,990/yr)</option>
                                <option value="29990" data-curr="₹" data-annual="29990" data-monthly="2499">Scale Annual (₹2,499/mo • ₹29,990/yr)</option>
                                <option value="5988" data-curr="₹" data-annual="5988" data-monthly="499">India Only Plan (₹499/mo • ₹5,988/yr)</option>
                            <?php else : ?>
                                <option value="190" data-curr="$" data-annual="190" data-monthly="15.83" selected>Professional Global ($15.83/mo • $190/yr)</option>
                                <option value="90" data-curr="$" data-annual="90" data-monthly="7.50">Starter Global ($7.50/mo • $90/yr)</option>
                                <option value="290" data-curr="$" data-annual="290" data-monthly="24.16">Scale Global ($24.16/mo • $290/yr)</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-5 items-center">
                    <!-- Slider Control -->
                    <div class="lg:col-span-2 space-y-3">
                        <div class="flex items-center justify-between">
                            <label for="cora-sim-range" class="text-xs font-semibold text-zinc-300">Referred Annual Clients / Agencies</label>
                            <span id="cora-sim-clients-badge" class="px-2.5 py-1 bg-zinc-800 border border-zinc-700 rounded-lg text-xs font-mono font-bold text-zinc-100">10 Agencies</span>
                        </div>
                        <input id="cora-sim-range" type="range" min="1" max="50" value="10" step="1" oninput="coraRecalculateSimulator()" class="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-white">
                        <div class="flex justify-between text-[10px] text-zinc-500 font-mono">
                            <span>1 Client</span>
                            <span>10 Clients</span>
                            <span>25 Clients</span>
                            <span>50 Clients</span>
                        </div>
                    </div>

                    <!-- Estimated Return Card -->
                    <div class="bg-zinc-950/80 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-center text-center lg:text-left">
                        <span class="text-[10px] uppercase tracking-wider text-zinc-400 font-medium">Annual Commission Payout (40%)</span>
                        <span id="cora-sim-monthly-cash" class="text-2xl md:text-3xl font-extrabold text-white tracking-tight mt-1"><?php echo $is_india_geo ? '₹79,960' : '$760'; ?></span>
                        <span id="cora-sim-yearly-cash" class="text-[10px] text-zinc-400 mt-1"><?php echo $is_india_geo ? '₹6,663/mo equivalent payout + 1,000 AI credits' : '$63.33/mo equivalent payout + 1,000 AI credits'; ?></span>
                    </div>
                </div>

                <!-- Official Plan Pricing & Commission Matrix -->
                <div class="pt-4 border-t border-zinc-800/80 grid grid-cols-1 sm:grid-cols-2 <?php echo $is_india_geo ? 'lg:grid-cols-4' : 'lg:grid-cols-3'; ?> gap-2.5 text-xs">
                    <?php if ( $is_india_geo ) : ?>
                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">India Only Plan</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">Annual</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">₹499<span class="text-[9px] text-zinc-400 font-normal">/mo (₹5,988/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">₹2,395.20</span>/yr</div>
                        </div>

                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Starter Tier</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-zinc-800 text-zinc-300">2 Mo. Free</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">₹833<span class="text-[9px] text-zinc-400 font-normal">/mo (₹9,990/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">₹3,996.00</span>/yr</div>
                        </div>

                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Professional Tier</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">Popular</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">₹1,665<span class="text-[9px] text-zinc-400 font-normal">/mo (₹19,990/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">₹7,996.00</span>/yr</div>
                        </div>

                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Scale Tier</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">High Scale</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">₹2,499<span class="text-[9px] text-zinc-400 font-normal">/mo (₹29,990/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">₹11,996.00</span>/yr</div>
                        </div>
                    <?php else : ?>
                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Starter Global</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-zinc-800 text-zinc-300">2 Mo. Free</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">$7.50<span class="text-[9px] text-zinc-400 font-normal">/mo ($90/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">$36.00</span>/yr</div>
                        </div>

                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Professional Global</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">Popular</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">$15.83<span class="text-[9px] text-zinc-400 font-normal">/mo ($190/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">$76.00</span>/yr</div>
                        </div>

                        <div class="p-3 bg-zinc-950/60 rounded-xl border border-zinc-800/60 flex flex-col gap-1">
                            <div class="flex items-center justify-between">
                                <span class="font-bold text-white text-[11px]">Scale Global</span>
                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">High Scale</span>
                            </div>
                            <div class="text-zinc-200 font-mono text-[11px]">$24.16<span class="text-[9px] text-zinc-400 font-normal">/mo ($290/yr)</span></div>
                            <div class="text-[10px] text-emerald-400 mt-0.5">40% Comm: <span class="font-bold font-mono">$116.00</span>/yr</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- ─────────────────────────────────────────────────────────────────── -->
        <!-- SUB-TAB 4: REFERRALS ACTIVITY & TRACKER LOGS                        -->
        <!-- ─────────────────────────────────────────────────────────────────── -->
        <div id="cora-aff-subtab-referrals" class="cora-aff-subtab hidden space-y-4">
            
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl shadow-3xs overflow-hidden">
                <!-- Table Header & Filter Tabs -->
                <div class="p-4 border-b border-zinc-200/80 dark:border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                        <h3 class="text-xs font-bold text-zinc-900 dark:text-zinc-50">Conversion Activity Ledger</h3>
                        <p class="text-[11px] text-zinc-400">Real-time log of all referred signups, plan conversions, and earned rewards.</p>
                    </div>

                    <div class="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800 p-0.5 rounded-lg self-start sm:self-auto">
                        <button type="button" onclick="coraFilterReferralTable('all')" id="cora-filter-all" class="px-2.5 py-1 text-xs font-bold rounded-md bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-3xs transition-all cursor-pointer">All</button>
                        <button type="button" onclick="coraFilterReferralTable('paid')" id="cora-filter-paid" class="px-2.5 py-1 text-xs font-medium rounded-md text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 transition-all cursor-pointer">Paid (40%)</button>
                        <button type="button" onclick="coraFilterReferralTable('free')" id="cora-filter-free" class="px-2.5 py-1 text-xs font-medium rounded-md text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 transition-all cursor-pointer">Free (+100)</button>
                    </div>
                </div>

                <!-- Table View -->
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-zinc-50/80 dark:bg-zinc-950/50 border-b border-zinc-200/80 dark:border-zinc-800 text-[10px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400 font-bold">
                            <tr>
                                <th class="py-2.5 px-4">Referred Client / Studio</th>
                                <th class="py-2.5 px-4">Joined Date</th>
                                <th class="py-2.5 px-4">Conversion Tier</th>
                                <th class="py-2.5 px-4 text-right">Plan Value</th>
                                <th class="py-2.5 px-4 text-right">Reward Earned</th>
                                <th class="py-2.5 px-4 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody id="cora-referral-table-body" class="divide-y divide-zinc-200/70 dark:divide-zinc-800/70 text-zinc-800 dark:text-zinc-200">
                            <?php if ( ! empty( $referrals ) ) : ?>
                                <?php foreach ( $referrals as $ref ) : 
                                    $is_paid = $ref['conversion_type'] === 'paid_conversion';
                                    $row_class = $is_paid ? 'cora-row-paid' : 'cora-row-free';
                                    $time_ago = human_time_diff( strtotime( $ref['created_at'] ), current_time( 'timestamp' ) ) . ' ago';
                                ?>
                                <tr class="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40 transition-colors <?php echo esc_attr( $row_class ); ?>">
                                    <td class="py-3 px-4">
                                        <div class="font-semibold text-zinc-900 dark:text-zinc-100"><?php echo esc_html( $ref['referred_name'] ); ?></div>
                                        <div class="text-[10px] text-zinc-400 font-mono"><?php echo esc_html( $ref['referred_email'] ); ?></div>
                                    </td>
                                    <td class="py-3 px-4 text-zinc-500 dark:text-zinc-400 font-mono text-[10px]">
                                        <?php echo esc_html( $time_ago ); ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <?php if ( $is_paid ) : ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900">
                                                <?php echo esc_html( $ref['plan_name'] ); ?>
                                            </span>
                                        <?php else : ?>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-medium bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300">
                                                Free Signup
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono">
                                        <?php echo $is_paid ? $curr_sym . number_format( (float) $ref['converted_value'], 2 ) : $curr_sym . '0.00'; ?>
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono font-bold <?php echo $is_paid ? 'text-zinc-950 dark:text-zinc-50' : 'text-emerald-600 dark:text-emerald-400'; ?>">
                                        <?php if ( $is_paid ) : ?>
                                            <?php echo esc_html( $curr_sym . number_format( (float) $ref['commission_earned'], 2 ) ); ?> <span class="text-[9px] font-normal text-zinc-400">(40%)</span>
                                        <?php else : ?>
                                            +100 AI Credits
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                                            Confirmed
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="6" class="py-8 text-center text-zinc-400 text-xs">
                                        No referral conversions recorded yet. Share your referral link to start earning!
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- ─────────────────────────────────────────────────────────────────── -->
        <!-- SUB-TAB 5: PAYOUTS & BANKING DISBURSEMENTS                          -->
        <!-- ─────────────────────────────────────────────────────────────────── -->
        <div id="cora-aff-subtab-payouts" class="cora-aff-subtab hidden space-y-4">
            
            <!-- Available Balance & Minimum Threshold Card -->
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl p-4 md:p-5 shadow-3xs space-y-3.5">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                        <span class="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Available Payout Balance</span>
                        <div class="text-2xl sm:text-3xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight mt-0.5"><?php echo esc_html( $curr_sym . number_format( $avail_bal, 2 ) ); ?></div>
                        <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Direct deposit to your designated UPI VPA or Bank IMPS account.</p>
                    </div>

                    <button type="button" onclick="coraOpenAffiliatePayoutDrawer()" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-3xs transition-all cursor-pointer">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><rect x="2" y="4" width="20" height="16" rx="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
                        <span>Request Payout Transfer</span>
                    </button>
                </div>

                <!-- Minimum Threshold Progress -->
                <div class="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 space-y-1.5">
                    <div class="flex items-center justify-between text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
                        <span>Withdrawal Threshold: <strong class="text-zinc-900 dark:text-zinc-100"><?php echo esc_html( $curr_sym . number_format( $min_payout, 0 ) ); ?> Minimum</strong></span>
                        <span class="font-mono text-zinc-700 dark:text-zinc-300"><?php echo esc_html( $payout_progress_pct ); ?>% Ready</span>
                    </div>
                    <div class="w-full h-2 bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                        <div class="h-full bg-emerald-500 rounded-full transition-all duration-500" style="width: <?php echo esc_attr( $payout_progress_pct ); ?>%"></div>
                    </div>
                </div>
            </div>

            <!-- PAYOUT & WITHDRAWAL HISTORY LEDGER -->
            <div class="bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 rounded-2xl shadow-3xs overflow-hidden">
                <div class="p-4 border-b border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between">
                    <div>
                        <h3 class="text-xs font-bold text-zinc-900 dark:text-zinc-50">Payout & Withdrawal History</h3>
                        <p class="text-[11px] text-zinc-400">Complete audit log of all processed bank transfers and UPI disbursements.</p>
                    </div>
                    <button type="button" onclick="coraOpenAffiliatePayoutDrawer()" class="text-xs font-semibold text-zinc-900 dark:text-zinc-100 hover:underline cursor-pointer">
                        + Request
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-zinc-50/80 dark:bg-zinc-950/50 border-b border-zinc-200/80 dark:border-zinc-800 text-[10px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400 font-bold">
                            <tr>
                                <th class="py-2.5 px-4">Transaction ID</th>
                                <th class="py-2.5 px-4">Requested Date</th>
                                <th class="py-2.5 px-4">Payout Method</th>
                                <th class="py-2.5 px-4 text-right">Amount (<?php echo esc_html( $curr_sym ); ?>)</th>
                                <th class="py-2.5 px-4 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-zinc-200/70 dark:divide-zinc-800/70 text-zinc-800 dark:text-zinc-200">
                            <?php if ( ! empty( $payouts ) ) : ?>
                                <?php foreach ( $payouts as $p ) : 
                                    $status_badge = $p['status'] === 'completed' 
                                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' 
                                        : 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
                                ?>
                                <tr class="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/40 transition-colors">
                                    <td class="py-3 px-4 font-mono font-medium text-zinc-900 dark:text-zinc-100">
                                        <?php echo esc_html( $p['transaction_ref'] ?? ('TXN-' . substr( md5( (string) $p['id'] ), 0, 8 )) ); ?>
                                    </td>
                                    <td class="py-3 px-4 text-zinc-500 dark:text-zinc-400 font-mono text-[10px]">
                                        <?php echo esc_html( gmdate( 'd M Y, h:i A', strtotime( $p['created_at'] ) ) ); ?>
                                    </td>
                                    <td class="py-3 px-4 uppercase text-[10px] font-bold text-zinc-600 dark:text-zinc-300">
                                        <?php echo esc_html( $p['payout_method'] ); ?>
                                    </td>
                                    <td class="py-3 px-4 text-right font-mono font-bold text-zinc-900 dark:text-zinc-50">
                                        <?php echo esc_html( $curr_sym . number_format( (float) $p['amount'], 2 ) ); ?>
                                    </td>
                                    <td class="py-3 px-4 text-center">
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold border <?php echo esc_attr( $status_badge ); ?>">
                                            <?php echo esc_html( ucfirst( $p['status'] ) ); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr>
                                    <td colspan="5" class="py-6 text-center text-zinc-400 text-xs">
                                        No withdrawal transactions requested yet.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>

</div>

<!-- ================================================================= -->
<!-- MOBILE BOTTOM-SHEET & DESKTOP SLIDING WITHDRAWAL PAYOUT DRAWER   -->
<!-- ================================================================= -->
<div id="cora-affiliate-payout-drawer" class="fixed inset-0 z-50 pointer-events-none opacity-0 transition-opacity duration-300">
    <!-- Backdrop Overlay -->
    <div onclick="coraCloseAffiliatePayoutDrawer()" class="absolute inset-0 bg-zinc-950/45 backdrop-blur-xs cursor-pointer"></div>

    <!-- Drawer Panel: Bottom-Sheet on Mobile (<640px), Right-Sliding on Desktop (>=640px) -->
    <div class="cora-payout-drawer-panel absolute sm:right-0 bottom-0 sm:top-0 w-full sm:max-w-md max-h-[85vh] sm:max-h-full bg-white dark:bg-zinc-900 border-t sm:border-t-0 sm:border-l border-zinc-200 dark:border-zinc-800 rounded-t-3xl sm:rounded-none shadow-2xl p-5 md:p-6 flex flex-col justify-between transform translate-y-full sm:translate-y-0 sm:translate-x-full transition-transform duration-300 ease-out pointer-events-auto overflow-y-auto">
        
        <div>
            <!-- Mobile Drag Handle -->
            <div class="w-10 h-1 rounded-full bg-zinc-300 dark:bg-zinc-700 mx-auto mb-3 sm:hidden"></div>

            <!-- Drawer Header -->
            <div class="flex items-center justify-between pb-3.5 border-b border-zinc-200 dark:border-zinc-800">
                <div>
                    <h3 class="text-sm md:text-base font-bold text-zinc-900 dark:text-zinc-50">Request Payout Withdrawal</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Transfer your earned referral commission.</p>
                </div>
                <button type="button" onclick="coraCloseAffiliatePayoutDrawer()" class="w-7 h-7 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 flex items-center justify-center text-zinc-500 cursor-pointer">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>

            <!-- Balance Summary -->
            <div class="mt-4 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3.5">
                <span class="text-[11px] text-zinc-500 dark:text-zinc-400">Available Balance:</span>
                <div class="text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 mt-0.5"><?php echo esc_html( $curr_sym . number_format( $avail_bal, 2 ) ); ?></div>
                <span class="text-[10px] text-zinc-400">Minimum withdrawal amount: <?php echo esc_html( $curr_sym . number_format( $min_payout, 0 ) ); ?></span>
            </div>

            <!-- Form -->
            <form id="cora-payout-form" onsubmit="coraSubmitPayoutRequest(event)" class="mt-4 space-y-3.5">
                
                <!-- Amount Input -->
                <div class="space-y-1">
                    <label for="cora-payout-amount" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Withdrawal Amount (<?php echo esc_html( $curr_sym ); ?>)</label>
                    <input id="cora-payout-amount" type="number" min="<?php echo esc_attr( $min_payout ); ?>" max="<?php echo esc_attr( $avail_bal ); ?>" step="100" value="<?php echo esc_attr( min( 5000, max( $min_payout, $avail_bal ) ) ); ?>" class="w-full px-3.5 py-2 text-xs bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-1 focus:ring-zinc-400">
                    <div class="flex items-center gap-1.5 pt-1">
                        <button type="button" onclick="document.getElementById('cora-payout-amount').value = <?php echo esc_attr( $min_payout ); ?>" class="px-2 py-0.5 text-[10px] bg-zinc-100 dark:bg-zinc-800 rounded text-zinc-600 dark:text-zinc-400 cursor-pointer"><?php echo esc_html( $curr_sym . number_format( $min_payout, 0 ) ); ?></button>
                        <button type="button" onclick="document.getElementById('cora-payout-amount').value = 5000" class="px-2 py-0.5 text-[10px] bg-zinc-100 dark:bg-zinc-800 rounded text-zinc-600 dark:text-zinc-400 cursor-pointer"><?php echo esc_html( $curr_sym ); ?>5,000</button>
                        <button type="button" onclick="document.getElementById('cora-payout-amount').value = <?php echo esc_attr( $avail_bal ); ?>" class="px-2 py-0.5 text-[10px] bg-zinc-100 dark:bg-zinc-800 rounded text-zinc-600 dark:text-zinc-400 cursor-pointer">Max Balance</button>
                    </div>
                </div>

                <!-- Payout Method Selection -->
                <div class="space-y-1">
                    <label class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Payout Method</label>
                    <div class="grid grid-cols-2 gap-2">
                        <label class="flex items-center gap-2 p-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl cursor-pointer">
                            <input type="radio" name="payout_method" value="upi" checked onchange="coraTogglePayoutFields('upi')" class="accent-zinc-900 dark:accent-zinc-100">
                            <span class="text-xs font-medium text-zinc-800 dark:text-zinc-200">UPI ID</span>
                        </label>
                        <label class="flex items-center gap-2 p-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl cursor-pointer">
                            <input type="radio" name="payout_method" value="bank_transfer" onchange="coraTogglePayoutFields('bank_transfer')" class="accent-zinc-900 dark:accent-zinc-100">
                            <span class="text-xs font-medium text-zinc-800 dark:text-zinc-200">Bank Transfer</span>
                        </label>
                    </div>
                </div>

                <!-- UPI Fields -->
                <div id="cora-payout-field-upi" class="space-y-1">
                    <label for="cora-upi-id" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">VPA / UPI ID</label>
                    <input id="cora-upi-id" type="text" placeholder="username@okaxis or mobile@upi" class="w-full px-3.5 py-2 text-xs bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                </div>

                <!-- Bank Fields -->
                <div id="cora-payout-field-bank" class="hidden space-y-2.5">
                    <div class="space-y-1">
                        <label for="cora-bank-beneficiary" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Beneficiary Name</label>
                        <input id="cora-bank-beneficiary" type="text" placeholder="Account Holder Name" class="w-full px-3.5 py-2 text-xs bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                    </div>
                    <div class="space-y-1">
                        <label for="cora-bank-account" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">Account Number</label>
                        <input id="cora-bank-account" type="password" placeholder="Account Number" class="w-full px-3.5 py-2 text-xs bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 focus:outline-none">
                    </div>
                    <div class="space-y-1">
                        <label for="cora-bank-ifsc" class="text-xs font-semibold text-zinc-700 dark:text-zinc-300">IFSC Code</label>
                        <input id="cora-bank-ifsc" type="text" placeholder="e.g. HDFC0001234" class="w-full px-3.5 py-2 text-xs bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-zinc-100 uppercase focus:outline-none">
                    </div>
                </div>

            </form>
        </div>

        <!-- Drawer Footer -->
        <div class="pt-3.5 mt-4 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-end gap-2">
            <button type="button" onclick="coraCloseAffiliatePayoutDrawer()" class="px-4 py-2 text-xs font-semibold text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 cursor-pointer">Cancel</button>
            <button type="button" onclick="document.getElementById('cora-payout-form').requestSubmit()" class="px-5 py-2 text-xs font-semibold text-white bg-zinc-950 hover:bg-zinc-900 dark:bg-zinc-100 dark:hover:bg-zinc-200 dark:text-zinc-950 rounded-xl shadow-3xs transition-all cursor-pointer">Confirm Withdrawal</button>
        </div>

    </div>
</div>

<!-- ================================================================= -->
<!-- QR CODE PREVIEW MODAL                                             -->
<!-- ================================================================= -->
<div id="cora-affiliate-qr-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
    <div onclick="coraCloseQRCodeModal()" class="absolute inset-0 bg-zinc-950/45 backdrop-blur-xs cursor-pointer"></div>
    <div class="relative w-full max-w-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 shadow-2xl z-10 text-center space-y-4">
        <div>
            <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-50">Scan Partner QR Code</h3>
            <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Let clients scan this code to sign up under your agency.</p>
        </div>

        <!-- Generated QR Vector -->
        <div class="bg-zinc-50 dark:bg-zinc-950 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-center">
            <div id="cora-qr-canvas-holder" class="p-2 bg-white rounded-xl shadow-3xs">
                <img id="cora-qr-img" src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=<?php echo urlencode( $ref_url ); ?>&color=18-18-1b" alt="QR Code" width="180" height="180" class="rounded-lg">
            </div>
        </div>

        <div class="pt-1 flex items-center justify-center gap-2">
            <button type="button" onclick="coraCloseQRCodeModal()" class="px-4 py-2 text-xs font-semibold text-zinc-700 dark:text-zinc-300 bg-zinc-100 dark:bg-zinc-800 rounded-xl hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-all cursor-pointer">Close</button>
            <button type="button" onclick="coraCopyReferralLink(); coraCloseQRCodeModal();" class="px-5 py-2 text-xs font-semibold text-white bg-zinc-950 dark:bg-zinc-100 dark:text-zinc-950 rounded-xl hover:opacity-90 transition-all cursor-pointer">Copy Link</button>
        </div>
    </div>
</div>

<!-- ================================================================= -->
<!-- JAVASCRIPT CONTROLLERS                                            -->
<!-- ================================================================= -->
<script>
window.coraAffiliateState = {
    referralUrl: <?php echo json_encode( $ref_url ); ?>,
    refCode: <?php echo json_encode( $ref_code ); ?>,
    customSlug: <?php echo json_encode( $custom_slug ); ?>,
    availBalance: <?php echo json_encode( (float) $avail_bal ); ?>,
    isEnrolled: <?php echo json_encode( (bool) $is_enrolled ); ?>,
    activeTab: 'overview'
};

/* --- SUB-TAB SWITCHER --- */
function coraSwitchAffiliateTab(tabKey) {
    window.coraAffiliateState.activeTab = tabKey;
    var subtabs = ['overview', 'leaderboard', 'calculator', 'referrals', 'payouts'];

    subtabs.forEach(function(key) {
        var tabView = document.getElementById('cora-aff-subtab-' + key);
        var tabBtn = document.getElementById('cora-tab-btn-' + key);

        if (tabView) {
            if (key === tabKey) {
                tabView.classList.remove('hidden');
            } else {
                tabView.classList.add('hidden');
            }
        }

        if (tabBtn) {
            if (key === tabKey) {
                tabBtn.className = 'cora-aff-tab-btn active inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer text-zinc-950 dark:text-zinc-50 bg-zinc-100 dark:bg-zinc-800 whitespace-nowrap';
            } else {
                tabBtn.className = 'cora-aff-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 whitespace-nowrap';
            }
        }
    });

    // Auto-center active button in scroll container on mobile
    var activeBtn = document.getElementById('cora-tab-btn-' + tabKey);
    var container = document.getElementById('cora-affiliate-tabs-container');
    if (activeBtn && container) {
        var btnOffset = activeBtn.offsetLeft;
        var btnWidth = activeBtn.offsetWidth;
        var containerWidth = container.offsetWidth;
        container.scrollTo({
            left: btnOffset - (containerWidth / 2) + (btnWidth / 2),
            behavior: 'smooth'
        });
    }
}

/* --- 3-STEP SCREENER CONTROLLER --- */
function coraScreenerGoToStep(stepNum) {
    if (stepNum === 3) {
        var slugInput = document.getElementById('cora-enroll-slug');
        var slug = slugInput ? slugInput.value.trim() : '';
        if (slug.length < 3) {
            if (window.coraShowToast) window.coraShowToast('Please enter a custom referral handle with at least 3 characters.', 'error');
            return;
        }
    }

    [1, 2, 3].forEach(function(s) {
        var view = document.getElementById('cora-screener-step-' + s);
        var tab = document.getElementById('cora-step-tab-' + s);
        if (view) {
            if (s === stepNum) {
                view.classList.remove('hidden');
            } else {
                view.classList.add('hidden');
            }
        }
        if (tab) {
            if (s === stepNum) {
                tab.className = 'flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 transition-all';
            } else if (s < stepNum) {
                tab.className = 'flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 transition-all';
            } else {
                tab.className = 'flex items-center gap-2 p-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 transition-all';
            }
        }
    });

    var root = document.getElementById('cora-affiliate-screener-view');
    if (root) root.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function coraRecalculateScreenerSimulator() {
    var range = document.getElementById('cora-screener-sim-range');
    var tier = document.getElementById('cora-screener-sim-tier');
    var badge = document.getElementById('cora-screener-sim-clients-badge');
    var monthlyCash = document.getElementById('cora-screener-sim-monthly-cash');
    var yearlyCash = document.getElementById('cora-screener-sim-yearly-cash');

    if (!range || !tier) return;
    var count = parseInt(range.value, 10);
    var annualPlanPrice = parseFloat(tier.value);
    var selectedOpt = tier.options[tier.selectedIndex];
    var curr = selectedOpt ? (selectedOpt.getAttribute('data-curr') || '₹') : '₹';
    var rate = 0.40;

    var annualComm = Math.round(count * annualPlanPrice * rate);
    var monthlyEquiv = Math.round(annualComm / 12);
    var credits = count * 100;

    if (badge) badge.innerText = count + (count === 1 ? ' Studio' : ' Studios');
    if (monthlyCash) {
        monthlyCash.innerText = curr + annualComm.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US');
    }
    if (yearlyCash) {
        var eqStr = curr + monthlyEquiv.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US');
        yearlyCash.innerText = eqStr + '/mo equivalent + ' + credits.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US') + ' AI credits';
    }
}

function coraSubmitAffiliateEnrollment() {
    var agree = document.getElementById('cora-enroll-agree');
    if (!agree || !agree.checked) {
        if (window.coraShowToast) window.coraShowToast('Please accept the Partner Agreement terms to continue.', 'error');
        return;
    }

    var submitBtn = document.getElementById('cora-enroll-submit-btn');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Activating Partner Portal...</span>';
    }

    var slug = document.getElementById('cora-enroll-slug') ? document.getElementById('cora-enroll-slug').value.trim() : '';
    var upi = document.getElementById('cora-enroll-upi') ? document.getElementById('cora-enroll-upi').value.trim() : '';
    var bank = document.getElementById('cora-enroll-bank') ? document.getElementById('cora-enroll-bank').value.trim() : '';

    var formData = new FormData();
    formData.append('action', 'cora_affiliate_enroll');
    formData.append('custom_slug', slug);
    formData.append('upi_id', upi);
    formData.append('account_number', bank);

    if (window.coraREData && window.coraREData.ajaxNonce) {
        formData.append('security', window.coraREData.ajaxNonce);
    }

    fetch(window.coraREData ? window.coraREData.ajaxUrl : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
        if (res.success) {
            window.coraAffiliateState.isEnrolled = true;
            if (res.data && res.data.referral_url) {
                window.coraAffiliateState.referralUrl = res.data.referral_url;
                var refInput = document.getElementById('cora-ref-link-input');
                if (refInput) refInput.value = res.data.referral_url;
                var dispSlug = document.getElementById('cora-display-slug');
                if (dispSlug) dispSlug.innerText = res.data.ref_code || slug;
            }

            if (window.coraShowToast) {
                window.coraShowToast(res.data.message || 'Welcome to Cora Partner Network! Your dashboard is now active.', 'success');
            }

            var screenerView = document.getElementById('cora-affiliate-screener-view');
            var dashboardView = document.getElementById('cora-affiliate-dashboard-view');
            if (screenerView && dashboardView) {
                screenerView.classList.add('hidden');
                dashboardView.classList.remove('hidden');
                dashboardView.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        } else {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<span>Activate Partner Portal</span>';
            }
            if (window.coraShowToast) {
                window.coraShowToast(res.data.message || 'Error completing enrollment', 'error');
            }
        }
    })
    .catch(function(){
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<span>Activate Partner Portal</span>';
        }
        if (window.coraShowToast) window.coraShowToast('Network error while completing partner enrollment', 'error');
    });
}

/* --- DASHBOARD HANDLERS --- */
function coraCopyReferralLink() {
    var input = document.getElementById('cora-ref-link-input');
    if (input) {
        input.select();
        navigator.clipboard.writeText(input.value).then(function() {
            if (window.coraShowToast) {
                window.coraShowToast('Referral link copied to clipboard!', 'success');
            }
        });
    }
}

function coraToggleSlugEditor() {
    var box = document.getElementById('cora-slug-editor');
    if (box) {
        box.classList.toggle('hidden');
    }
}

function coraSaveCustomSlug() {
    var input = document.getElementById('cora-custom-slug-input');
    var slug = input ? input.value.trim() : '';
    if (!slug) return;

    var formData = new FormData();
    formData.append('action', 'cora_affiliate_update_slug');
    formData.append('custom_slug', slug);
    if (window.coraREData && window.coraREData.ajaxNonce) {
        formData.append('security', window.coraREData.ajaxNonce);
    }

    fetch(window.coraREData ? window.coraREData.ajaxUrl : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
        if (res.success) {
            document.getElementById('cora-ref-link-input').value = res.data.referral_url;
            document.getElementById('cora-display-slug').innerText = res.data.custom_slug;
            window.coraAffiliateState.referralUrl = res.data.referral_url;
            coraToggleSlugEditor();
            if (window.coraShowToast) {
                window.coraShowToast('Custom referral code updated!', 'success');
            }
        } else {
            if (window.coraShowToast) {
                window.coraShowToast(res.data.message || 'Error updating slug', 'error');
            }
        }
    })
    .catch(function(){
        if (window.coraShowToast) window.coraShowToast('Network error while updating slug', 'error');
    });
}

function coraRecalculateSimulator() {
    var range = document.getElementById('cora-sim-range');
    var tier = document.getElementById('cora-sim-tier');
    var badge = document.getElementById('cora-sim-clients-badge');
    var monthlyCash = document.getElementById('cora-sim-monthly-cash');
    var yearlyCash = document.getElementById('cora-sim-yearly-cash');

    if (!range || !tier) return;
    var count = parseInt(range.value, 10);
    var annualPlanPrice = parseFloat(tier.value);
    var selectedOpt = tier.options[tier.selectedIndex];
    var curr = selectedOpt ? (selectedOpt.getAttribute('data-curr') || '₹') : '₹';
    var rate = 0.40;

    var annualComm = Math.round(count * annualPlanPrice * rate);
    var monthlyEquiv = Math.round(annualComm / 12);
    var credits = count * 100;

    if (badge) badge.innerText = count + (count === 1 ? ' Studio' : ' Studios');
    if (monthlyCash) {
        monthlyCash.innerText = curr + annualComm.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US');
    }
    if (yearlyCash) {
        var eqStr = curr + monthlyEquiv.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US');
        yearlyCash.innerText = eqStr + '/mo equivalent payout + ' + credits.toLocaleString(curr === '₹' ? 'en-IN' : 'en-US') + ' AI credits';
    }
}

function coraFilterReferralTable(filter) {
    var rows = document.querySelectorAll('#cora-referral-table-body tr');
    var btnAll = document.getElementById('cora-filter-all');
    var btnPaid = document.getElementById('cora-filter-paid');
    var btnFree = document.getElementById('cora-filter-free');

    [btnAll, btnPaid, btnFree].forEach(function(btn){
        if (btn) {
            btn.className = 'px-2.5 py-1 text-xs font-medium rounded-md text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200 transition-all cursor-pointer';
        }
    });

    var activeBtn = filter === 'paid' ? btnPaid : (filter === 'free' ? btnFree : btnAll);
    if (activeBtn) {
        activeBtn.className = 'px-2.5 py-1 text-xs font-bold rounded-md bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-3xs transition-all cursor-pointer';
    }

    rows.forEach(function(row){
        if (filter === 'all') {
            row.style.display = '';
        } else if (filter === 'paid') {
            row.style.display = row.classList.contains('cora-row-paid') ? '' : 'none';
        } else if (filter === 'free') {
            row.style.display = row.classList.contains('cora-row-free') ? '' : 'none';
        }
    });
}

function coraOpenAffiliatePayoutDrawer() {
    var drawer = document.getElementById('cora-affiliate-payout-drawer');
    if (drawer) {
        drawer.classList.remove('pointer-events-none', 'opacity-0');
        drawer.classList.add('opacity-100');
        var panel = drawer.querySelector('.cora-payout-drawer-panel');
        if (panel) {
            panel.classList.remove('translate-y-full', 'sm:translate-x-full');
            panel.classList.add('translate-y-0', 'sm:translate-x-0');
        }
    }
}

function coraCloseAffiliatePayoutDrawer() {
    var drawer = document.getElementById('cora-affiliate-payout-drawer');
    if (drawer) {
        var panel = drawer.querySelector('.cora-payout-drawer-panel');
        if (panel) {
            panel.classList.add('translate-y-full', 'sm:translate-x-full');
            panel.classList.remove('translate-y-0', 'sm:translate-x-0');
        }
        setTimeout(function(){
            drawer.classList.add('pointer-events-none', 'opacity-0');
            drawer.classList.remove('opacity-100');
        }, 250);
    }
}

function coraTogglePayoutFields(method) {
    var upiBox = document.getElementById('cora-payout-field-upi');
    var bankBox = document.getElementById('cora-payout-field-bank');
    if (method === 'upi') {
        if (upiBox) upiBox.classList.remove('hidden');
        if (bankBox) bankBox.classList.add('hidden');
    } else {
        if (upiBox) upiBox.classList.add('hidden');
        if (bankBox) bankBox.classList.remove('hidden');
    }
}

function coraSubmitPayoutRequest(e) {
    if (e) e.preventDefault();
    var amount = parseFloat(document.getElementById('cora-payout-amount').value || 0);
    var method = document.querySelector('input[name="payout_method"]:checked').value;
    var upiId = document.getElementById('cora-upi-id') ? document.getElementById('cora-upi-id').value : '';
    var bankBeneficiary = document.getElementById('cora-bank-beneficiary') ? document.getElementById('cora-bank-beneficiary').value : '';
    var bankAccount = document.getElementById('cora-bank-account') ? document.getElementById('cora-bank-account').value : '';
    var bankIfsc = document.getElementById('cora-bank-ifsc') ? document.getElementById('cora-bank-ifsc').value : '';

    var formData = new FormData();
    formData.append('action', 'cora_affiliate_request_payout');
    formData.append('amount', amount);
    formData.append('payout_method', method);
    formData.append('upi_id', upiId);
    formData.append('beneficiary_name', bankBeneficiary);
    formData.append('account_number', bankAccount);
    formData.append('ifsc_code', bankIfsc);
    if (window.coraREData && window.coraREData.ajaxNonce) {
        formData.append('security', window.coraREData.ajaxNonce);
    }

    fetch(window.coraREData ? window.coraREData.ajaxUrl : '/wp-admin/admin-ajax.php', {
        method: 'POST',
        body: formData
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
        if (res.success) {
            coraCloseAffiliatePayoutDrawer();
            if (window.coraShowToast) {
                window.coraShowToast(res.data.message || 'Payout request submitted successfully!', 'success');
            }
        } else {
            if (window.coraShowToast) {
                window.coraShowToast(res.data.message || 'Error processing payout request', 'error');
            }
        }
    })
    .catch(function(){
        if (window.coraShowToast) window.coraShowToast('Network error while requesting payout', 'error');
    });
}

function coraOpenQRCodeModal() {
    var modal = document.getElementById('cora-affiliate-qr-modal');
    if (modal) modal.classList.remove('hidden'), modal.classList.add('flex');
}

function coraCloseQRCodeModal() {
    var modal = document.getElementById('cora-affiliate-qr-modal');
    if (modal) modal.classList.add('hidden'), modal.classList.remove('flex');
}

function coraShareWhatsApp() {
    var url = encodeURIComponent(window.coraAffiliateState.referralUrl);
    var text = encodeURIComponent("Join Cora - the AI workspace for creative studios and agencies. Sign up with my referral link to get 100 bonus AI credits: " + decodeURIComponent(url));
    window.open("https://api.whatsapp.com/send?text=" + text, '_blank');
}

function coraShareLinkedIn() {
    var url = encodeURIComponent(window.coraAffiliateState.referralUrl);
    window.open("https://www.linkedin.com/sharing/share-offsite/?url=" + url, '_blank');
}

function coraShareTwitter() {
    var url = encodeURIComponent(window.coraAffiliateState.referralUrl);
    var text = encodeURIComponent("Check out Cora - the AI workspace for agencies and studios. Join via my link for bonus AI credits: ");
    window.open("https://twitter.com/intent/tweet?text=" + text + "&url=" + url, '_blank');
}
</script>
