<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$mcp_token = get_option( 'cora_mcp_access_token' );
if ( empty( $mcp_token ) ) {
    $mcp_token = bin2hex( wp_generate_password( 32, false ) );
    update_option( 'cora_mcp_access_token', $mcp_token );
}
$mcp_url = home_url( '/wp-json/cora/v1/mcp' );
?>
<style>
    /* AI Chat Workspace Scoped Styles */
    #cora-page-mcp {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }
    .cora-ai-tabs {
        display: flex;
        border-bottom: 1px solid var(--border-color, #e4e4e7);
        gap: 16px;
        margin-bottom: 8px;
    }
    .cora-ai-tab {
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 600;
        color: var(--text-secondary, #71717a);
        cursor: pointer;
        border-bottom: 2px solid transparent;
        transition: all 0.2s ease;
    }
    .cora-ai-tab.active {
        color: var(--text-primary, #09090b);
        border-bottom-color: var(--text-primary, #09090b);
    }
    .cora-ai-workspace {
        display: flex;
        flex-direction: column;
        min-height: 550px;
        background: #fff;
        border: 1px solid #e4e4e7;
        border-radius: 16px;
        overflow: hidden;
        position: relative;
    }
    .dark .cora-ai-workspace {
        background: #18181b;
        border-color: #27272a;
    }
    .cora-ai-sidebar {
        display: flex;
        flex-direction: column;
        gap: 16px;
        font-size: 12px;
    }
    .cora-chat-header {
        height: 52px;
        border-bottom: 1px solid #e4e4e7;
        padding: 0 16px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #fafafa;
    }
    .dark .cora-chat-header {
        border-bottom-color: #27272a;
        background: #121214;
    }
    .cora-ai-header-select {
        font-size: 11px;
        font-weight: 600;
        background: #fff;
        border: 1px solid #d4d4d8;
        color: #18181b;
        border-radius: 9999px;
        padding: 4px 10px;
        outline: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .dark .cora-ai-header-select {
        background: #18181b;
        border-color: #27272a;
        color: #f4f4f5;
    }
    .cora-ai-header-select:hover {
        background: #f4f4f5;
        border-color: #a1a1aa;
    }
    .dark .cora-ai-header-select:hover {
        background: #27272a;
        border-color: #3f3f46;
    }
    .cora-ai-chat-container {
        display: flex;
        flex-direction: column;
        height: 600px;
        position: relative;
    }
    .cora-ai-messages {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 16px;
    }
    .cora-ai-message {
        display: flex;
        flex-direction: column;
        max-width: 85%;
        border-radius: 12px;
        padding: 10px 14px;
        font-size: 13px;
        line-height: 1.5;
        animation: coraFadeIn 0.3s ease;
    }
    @keyframes coraFadeIn {
        from { opacity: 0; transform: translateY(5px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .cora-ai-message.user {
        align-self: flex-end;
        background: #09090b;
        color: #fff;
    }
    .dark .cora-ai-message.user {
        background: #f4f4f5;
        color: #09090b;
    }
    .cora-ai-message.assistant {
        align-self: flex-start;
        background: #f4f4f5;
        color: #18181b;
        border: 1px solid #e4e4e7;
    }
    .dark .cora-ai-message.assistant {
        background: #27272a;
        color: #f4f4f5;
        border-color: #3f3f46;
    }
    .cora-skeleton-chat {
        display: flex;
        flex-direction: column;
        gap: 8px;
        width: 180px;
        padding: 4px 0;
    }
    .cora-skeleton-line {
        height: 10px;
        background: #e4e4e7;
        border-radius: 4px;
        animation: coraSkeletonPulse 1.4s infinite ease-in-out;
    }
    .dark .cora-skeleton-line {
        background: #3f3f46;
    }
    .cora-skeleton-line.w-80 { width: 80%; }
    .cora-skeleton-line.w-95 { width: 95%; }
    .cora-skeleton-line.w-60 { width: 60%; }
    
    @keyframes coraSkeletonPulse {
        0%, 100% { opacity: 0.65; }
        50% { opacity: 1; }
    }
    @keyframes coraSpin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    .cora-ai-spin {
        animation: coraSpin 1.5s linear infinite;
    }
    .cora-ai-followup-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-top: 10px;
        border-top: 1px dashed #e4e4e7;
        padding-top: 8px;
    }
    .dark .cora-ai-followup-chips {
        border-top-color: #3f3f46;
    }
    .cora-ai-followup-chip {
        background: #f4f4f5;
        border: 1px solid #e4e4e7;
        border-radius: 9999px;
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 500;
        color: #52525b;
        cursor: pointer;
        transition: all 0.2s ease;
        text-align: left;
    }
    .dark .cora-ai-followup-chip {
        background: #27272a;
        border-color: #3f3f46;
        color: #a1a1aa;
    }
    .cora-ai-followup-chip:hover {
        background: #e4e4e7;
        color: #18181b;
        border-color: #d4d4d8;
    }
    .dark .cora-ai-followup-chip:hover {
        background: #3f3f46;
        color: #f4f4f5;
        border-color: #52525b;
    }
    .cora-ai-message-meta {
        font-size: 9px;
        opacity: 0.6;
        margin-top: 4px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .cora-ai-input-wrapper {
        padding: 16px;
        border-top: 1px solid #e4e4e7;
        display: flex;
        gap: 8px;
        align-items: center;
        background: #fff;
    }
    .dark .cora-ai-input-wrapper {
        border-top-color: #27272a;
        background: #18181b;
    }
    .cora-ai-input {
        flex: 1;
        border: 1px solid #e4e4e7;
        border-radius: 8px;
        padding: 10px 12px;
        font-size: 13px;
        outline: none;
        background: transparent;
        color: inherit;
    }
    .dark .cora-ai-input {
        border-color: #27272a;
    }
    .cora-ai-input:focus {
        border-color: #09090b;
    }
    .dark .cora-ai-input:focus {
        border-color: #f4f4f5;
    }
    .cora-ai-btn {
        padding: 10px;
        background: #09090b;
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background-color 0.2s;
    }
    .dark .cora-ai-btn {
        background: #f4f4f5;
        color: #09090b;
    }
    .cora-ai-btn:hover {
        opacity: 0.9;
    }
    .cora-ai-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    .cora-ai-welcome {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        text-align: center;
        padding: 40px;
        gap: 20px;
    }
    .cora-ai-chips {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        max-width: 500px;
        margin-top: 10px;
    }
    .cora-ai-chip {
        padding: 10px;
        border: 1px solid #e4e4e7;
        border-radius: 8px;
        cursor: pointer;
        font-size: 11px;
        text-align: left;
        transition: all 0.2s;
    }
    .dark .cora-ai-chip {
        border-color: #27272a;
    }
    .cora-ai-chip:hover {
        background: #f4f4f5;
    }
    .dark .cora-ai-chip:hover {
        background: #27272a;
    }
    .cora-ai-field {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    .cora-ai-field label {
        font-weight: 600;
        color: var(--text-primary);
    }
    .cora-ai-select, .cora-ai-textarea {
        width: 100%;
        padding: 6px 8px;
        border: 1px solid #e4e4e7;
        border-radius: 6px;
        font-size: 12px;
        background: #fff;
        color: inherit;
        outline: none;
    }
    .dark .cora-ai-select, .dark .cora-ai-textarea {
        border-color: #27272a;
        background: #18181b;
    }
    @media (max-width: 768px) {
        .cora-ai-tabs {
            overflow-x: auto;
            white-space: nowrap;
            padding-bottom: 4px;
        }
        .cora-ai-tab {
            flex-shrink: 0;
            padding: 8px 12px;
            font-size: 12px;
        }
        .cora-ai-workspace {
            min-height: auto;
        }
    }
    @media (max-width: 480px) {
        .cora-ai-chips {
            grid-template-columns: 1fr;
        }
        .cora-ai-welcome {
            padding: 20px;
        }
    }
    @media (max-width: 1023px) {
        .cora-ai-input-wrapper {
            display: none !important;
        }
        .cora-ai-messages {
            padding-bottom: 90px !important;
        }
    }
</style>

<!-- Tabs Navigation -->
<div class="cora-ai-tabs">
    <div class="cora-ai-tab active" onclick="coraSwitchAIPanel('chat')">AI Chat Assistant</div>
    <div class="cora-ai-tab" onclick="coraSwitchAIPanel('mcp-settings')">MCP Developer Gateway</div>
    <div class="cora-ai-tab" onclick="coraSwitchAIPanel('rag-settings')">RAG Knowledge Base</div>
</div>

<!-- Local backdrop for AI settings drawer -->
<div id="cora-ai-drawer-backdrop" onclick="coraToggleAISettingsDrawer(false)" class="hidden fixed inset-0 bg-black/30 z-[99988] backdrop-blur-[1.5px] transition-opacity duration-200 cursor-pointer"></div>

<!-- Right-Sliding AI Settings Drawer -->
<div id="cora-ai-settings-drawer" class="fixed inset-y-0 right-0 z-[99999] w-80 bg-white dark:bg-zinc-900 border-l border-zinc-200 dark:border-zinc-800 shadow-2xl flex flex-col transition-transform duration-300 translate-x-full">
    <div class="p-4 border-b border-zinc-150 dark:border-zinc-800 flex items-center justify-between">
        <h3 class="text-xs font-bold text-zinc-900 dark:text-zinc-100 uppercase tracking-wider">AI Model Settings</h3>
        <button type="button" class="text-zinc-400 hover:text-zinc-650 cursor-pointer p-1 border-none bg-transparent" onclick="coraToggleAISettingsDrawer(false)">
            <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
    </div>
    <div class="flex-1 p-5 overflow-y-auto space-y-5">
        <div class="cora-ai-field">
            <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1.5">Temperature (<span id="cora-ai-temp-val">0.7</span>)</label>
            <input type="range" id="cora-ai-temperature" min="0" max="1" step="0.1" value="0.7" oninput="document.getElementById('cora-ai-temp-val').innerText = this.value" class="w-full">
        </div>

        <div class="cora-ai-field border-t border-zinc-150 dark:border-zinc-800 pt-4">
            <label class="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-zinc-700 dark:text-zinc-300">
                <input type="checkbox" id="cora-ai-tts-toggle" class="rounded border-zinc-300 text-zinc-950 focus:ring-zinc-950">
                ElevenLabs Audio Output
            </label>
        </div>

        <div class="cora-ai-field border-t border-zinc-150 dark:border-zinc-800 pt-4">
            <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1.5">System Instructions</label>
            <textarea id="cora-ai-system" rows="6" class="w-full border border-zinc-200 dark:border-zinc-800 rounded-lg p-2.5 text-xs bg-white dark:bg-zinc-950 outline-none text-zinc-800 dark:text-zinc-200">You are Cora AI, the unified platform assistant for the Cora Workspace Platform. Help users with leads, billing calculations, and setting queries.</textarea>
        </div>
        
        <div class="pt-4 border-t border-zinc-150 dark:border-zinc-800">
            <button type="button" class="w-full px-4 py-2.5 bg-zinc-100 hover:bg-zinc-250 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-700 rounded-lg text-center font-bold text-xs transition-colors border-none" onclick="coraClearConversation(); coraToggleAISettingsDrawer(false);">Clear Conversation</button>
        </div>
    </div>
</div>

<!-- TAB 1: AI Chat Assistant -->
<div id="cora-ai-panel-chat" class="cora-ai-workspace">
    <!-- Chat Window -->
    <div class="cora-ai-chat-container">
        <!-- Chat Header -->
        <div class="cora-chat-header border-b border-zinc-200 dark:border-zinc-800 px-4 py-3 flex items-center justify-between bg-zinc-50/50 dark:bg-zinc-900/40 shrink-0">
            <!-- Left: Model selectors & Living Memory Badge -->
            <div class="flex items-center gap-2 flex-wrap">
                <div class="flex items-center gap-1.5">
                    <select id="cora-ai-provider" class="cora-ai-header-select text-xs font-bold bg-white border border-zinc-250 rounded-full px-3 py-1 outline-none cursor-pointer" onchange="coraOnProviderChange()">
                        <option value="gemini" selected>Google Gemini</option>
                        <option value="groq">Groq</option>
                        <option value="openrouter">OpenRouter</option>
                        <option value="llama_nv">Llama (NVIDIA)</option>
                        <option value="gpt_oss_nv">GPT OSS (NVIDIA)</option>
                    </select>
                    
                    <select id="cora-ai-model" class="cora-ai-header-select text-xs font-semibold bg-white border border-zinc-250 rounded-full px-3 py-1 outline-none cursor-pointer"></select>
                </div>

                <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/60 rounded-full text-[10px] font-bold tracking-wide">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Living Memory Active
                </span>
            </div>

            <!-- Right: Settings Drawer Trigger -->
            <div class="flex items-center gap-2">
                <button type="button" onclick="coraToggleAISettingsDrawer(true)" class="p-1.5 text-zinc-500 hover:text-zinc-850 dark:hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center border-none bg-transparent" title="AI Model Settings">
                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                </button>
            </div>
        </div>

        <div id="cora-ai-messages" class="cora-ai-messages">
            <!-- Welcome Screen -->
            <div class="cora-ai-welcome" id="cora-ai-welcome-screen">
                <div class="w-12 h-12 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 border border-zinc-200 dark:border-zinc-700 shadow-sm">
                    <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                </div>
                <div>
                    <h3 class="text-base font-bold text-zinc-900 dark:text-zinc-100">Cora AI Co-Founder</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 max-w-sm mt-1">Autonomous workspace intelligence continuously learning from your daily leads, invoices, bookings, and tasks.</p>
                </div>
                <div class="cora-ai-chips">
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Give me a full financial health breakdown with revenue, outstanding invoices, and runway analysis.')">
                        <strong>Financial Runway Analysis</strong>
                        <p class="text-zinc-400 mt-1">Audit revenue collected and unpaid client receivables.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Summarize our active CRM lead pipeline and highlight high-priority deals requiring follow-up.')">
                        <strong>CRM Pipeline Audit</strong>
                        <p class="text-zinc-400 mt-1">Identify high-intent deals in the conversion window.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Review upcoming shoot bookings and check crew call-times and location assignments.')">
                        <strong>Production Briefing</strong>
                        <p class="text-zinc-400 mt-1">Check scheduled sessions, call-times, and gear rosters.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Search the living knowledge base for our latest commercial photography contract terms.')">
                        <strong>Contract Knowledge Search</strong>
                        <p class="text-zinc-400 mt-1">Query indexed vault agreements and business rules.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Audio Playback element -->
        <audio id="cora-ai-audio-player" style="display:none;"></audio>

        <div class="cora-ai-input-wrapper">
            <input type="text" id="cora-ai-input" class="cora-ai-input" placeholder="Ask Cora AI Co-Founder about your workspace..." onkeydown="if(event.key==='Enter') coraSendChatMessage()">
            <button type="button" id="cora-ai-send-btn" class="cora-ai-btn" onclick="coraSendChatMessage()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            </button>
        </div>
    </div>
</div>

<!-- TAB 2: MCP Developer Gateway Settings -->
<div id="cora-ai-panel-mcp-settings" class="space-y-6 max-w-4xl" style="display:none;">
    
    <!-- Connector 1: ChatGPT Custom GPT Actions -->
    <div class="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-xs space-y-4">
        <div class="border-b border-zinc-100 dark:border-zinc-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-zinc-950 text-white flex items-center justify-center font-bold text-xs">
                    GPT
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">ChatGPT Custom GPT Connector (OpenAPI 3.1.0)</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Connect ChatGPT directly to your workspace using Actions & Bearer Token authentication.</p>
                </div>
            </div>
            <span class="px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold uppercase tracking-wider self-start sm:self-center">OpenAPI 3.1.0</span>
        </div>

        <div class="space-y-3">
            <div class="space-y-1.5">
                <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300">OpenAPI Schema URL</label>
                <div class="flex flex-col sm:flex-row gap-2">
                    <input type="text" id="cora-mcp-openapi-url" readonly value="<?php echo esc_url( home_url( '/wp-json/cora/v1/mcp/openapi.json' ) ); ?>" class="w-full font-mono bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg text-xs px-3 py-2 outline-none text-zinc-800 dark:text-zinc-200">
                    <button type="button" class="w-full sm:w-auto px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer shrink-0" onclick="coraCopyToClipboardDirect('cora-mcp-openapi-url')">Copy Schema URL</button>
                    <button type="button" class="w-full sm:w-auto px-4 py-2 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-bold text-xs rounded-lg transition-colors cursor-pointer shrink-0" onclick="coraFetchAndCopyOpenAPISchema()">Copy JSON Schema</button>
                </div>
            </div>

            <!-- ChatGPT Setup Instructions Accordion -->
            <details class="p-3 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50/50 dark:bg-zinc-950 text-xs text-zinc-650 dark:text-zinc-400 space-y-2 cursor-pointer">
                <summary class="font-bold text-zinc-900 dark:text-zinc-100 flex items-center justify-between">
                    <span>How to configure ChatGPT Custom GPT Actions</span>
                    <span class="text-[10px] text-zinc-400">Expand Guide ▾</span>
                </summary>
                <ol class="list-decimal list-inside space-y-1.5 pt-2 text-zinc-600 dark:text-zinc-400">
                    <li>In ChatGPT, go to <strong>Explore GPTs</strong> &rarr; <strong>Create a GPT</strong> &rarr; <strong>Configure</strong>.</li>
                    <li>Scroll down and click <strong>Create new action</strong>.</li>
                    <li>Click <strong>Import from URL</strong>, paste the OpenAPI Schema URL copied above, and click <strong>Import</strong>.</li>
                    <li>Under <strong>Authentication</strong>, select <strong>API Key</strong> &rarr; Auth Type: <strong>Bearer</strong> &rarr; paste your Secure Access Token below.</li>
                    <li>Save your GPT. You can now prompt ChatGPT: <em>"Check our workspace revenue"</em> or <em>"List my CRM leads"</em>!</li>
                </ol>
            </details>
        </div>
    </div>

    <!-- Connector 2: Claude Desktop, Cursor & Antigravity IDE -->
    <div class="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-xs space-y-4">
        <div class="border-b border-zinc-100 dark:border-zinc-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-zinc-950 text-white flex items-center justify-center font-bold text-xs">
                    MCP
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">Claude Desktop, Cursor & Antigravity IDE</h3>
                    <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Native JSON-RPC 2.0 stdio / SSE bridge configuration.</p>
                </div>
            </div>
            <a href="<?php echo esc_url( CORA_WORKSPACE_URL . 'cora-bridge.py' ); ?>" download class="w-full sm:w-auto justify-center px-3 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-850 dark:text-zinc-200 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5">
                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                Download Bridge Script
            </a>
        </div>

        <div class="space-y-2">
            <div class="bg-zinc-950 text-zinc-100 rounded-xl p-4 font-mono text-[11px] leading-relaxed overflow-x-auto shadow-inner relative border border-zinc-800">
                <button type="button" class="absolute top-3 right-3 px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-[10px] font-bold cursor-pointer transition-colors" onclick="coraCopyClaudeConfigDirect()">Copy Config</button>
                <pre id="cora-claude-config-code-direct"><code>{
  "mcpServers": {
    "cora-workspace": {
      "command": "python3",
      "args": [
        "/path/to/cora-bridge.py",
        "<?php echo esc_url( $mcp_url ); ?>",
        "<?php echo esc_attr( $mcp_token ); ?>"
      ]
    }
  }
}</code></pre>
            </div>
        </div>
    </div>

    <!-- Human-Friendly AI Action & Natural Language Command Playground -->
    <div class="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-xs space-y-4">
        <div class="border-b border-zinc-100 dark:border-zinc-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
                <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">AI Command Center & Action Playground</h3>
                <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Control your entire workspace using plain English natural language or guided actions.</p>
            </div>
            
            <!-- Mode Switcher Tabs -->
            <div class="inline-flex p-1 bg-zinc-100 dark:bg-zinc-800 rounded-xl gap-1 text-xs font-semibold">
                <button type="button" id="cora-mcp-mode-nl-btn" onclick="coraSetMCPPlaygroundMode('nl')" class="px-3 py-1 rounded-lg bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs cursor-pointer transition-all">
                    💬 Natural Language
                </button>
                <button type="button" id="cora-mcp-mode-guided-btn" onclick="coraSetMCPPlaygroundMode('guided')" class="px-3 py-1 rounded-lg text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer transition-all">
                    📋 Guided Actions
                </button>
                <button type="button" id="cora-mcp-mode-dev-btn" onclick="coraSetMCPPlaygroundMode('dev')" class="px-3 py-1 rounded-lg text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer transition-all">
                    ⚙️ Raw JSON
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Left Input Column -->
            <div class="space-y-4">
                
                <!-- MODE 1: Natural Language Commands (Default) -->
                <div id="cora-mcp-panel-nl" class="space-y-3">
                    <div>
                        <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1.5">What would you like Cora AI to do?</label>
                        <div class="relative">
                            <textarea id="cora-mcp-nl-input" rows="3" class="w-full text-xs font-medium bg-zinc-50 dark:bg-zinc-950 border border-zinc-250 dark:border-zinc-800 rounded-xl p-3 outline-none text-zinc-850 dark:text-zinc-100 focus:border-zinc-900 dark:focus:border-zinc-100 transition-all placeholder:text-zinc-400" placeholder="Type in plain English, e.g.: 'Show me all unpaid invoices for this month' or 'Search for Rahul in CRM leads' or 'What are our scheduled shoots this week?'..."></textarea>
                        </div>
                    </div>

                    <!-- Quick Natural Language Suggestion Chips -->
                    <div class="space-y-1.5">
                        <span class="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Try Natural Language Prompts:</span>
                        <div class="flex flex-wrap gap-1.5">
                            <button type="button" onclick="coraSetNLPrompt('Give me a full workspace health summary with total revenue, unpaid receivables, and active shoot bookings.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                📊 Health & Revenue Snapshot
                            </button>
                            <button type="button" onclick="coraSetNLPrompt('Check all unpaid client receivables and show overdue invoices.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                💰 Audit Unpaid Invoices
                            </button>
                            <button type="button" onclick="coraSetNLPrompt('List all active CRM deals and highlight hot leads.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                👥 High-Priority CRM Leads
                            </button>
                            <button type="button" onclick="coraSetNLPrompt('Show all upcoming shoot bookings, call-times, and locations.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                📅 Upcoming Shoot Schedule
                            </button>
                            <button type="button" onclick="coraSetNLPrompt('Search the living knowledge base for our latest commercial shoot contract terms.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                🧠 Search Contract Terms
                            </button>
                            <button type="button" onclick="coraSetNLPrompt('Show recent workspace activity pulse and audit trail.')" class="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-lg text-[11px] font-medium transition-colors cursor-pointer text-left">
                                ⚡ Activity Stream & Audit
                            </button>
                        </div>
                    </div>

                    <button type="button" id="cora-mcp-run-nl-btn" onclick="coraExecuteNaturalLanguageCommand()" class="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                        Execute Natural Language Command
                    </button>
                </div>

                <!-- MODE 2: Guided Action Presets -->
                <div id="cora-mcp-panel-guided" class="space-y-3" style="display: none;">
                    <div>
                        <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">Select Human-Friendly Action</label>
                        <select id="cora-mcp-guided-tool-select" class="w-full text-xs font-semibold bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-3 py-2 outline-none cursor-pointer text-zinc-850 dark:text-zinc-100" onchange="coraOnGuidedToolChange()">
                            <option value="cora_get_workspace_overview">📊 Workspace Overview & KPI Snapshot</option>
                            <option value="cora_search_knowledge_base">🧠 Search Living Memory & Documents</option>
                            <option value="cora_query_financials">💰 Check Financials & Invoices</option>
                            <option value="cora_record_financial_transaction">💳 Record Payment or Expense</option>
                            <option value="cora_manage_crm_leads">👥 Manage CRM Leads & Deals</option>
                            <option value="cora_manage_bookings">📅 Shoot Bookings & Schedule</option>
                            <option value="cora_manage_tasks">✅ Tasks & Client Deliverables</option>
                            <option value="cora_manage_documents">📁 Vault Documents & Contracts</option>
                            <option value="cora_manage_reviews">⭐ Client Reviews & AI Replies</option>
                            <option value="cora_get_activity_pulse">⚡ Real-time Activity Pulse</option>
                            <option value="cora_ask_workspace_copilot">🤖 Ask AI Co-Founder</option>
                        </select>
                    </div>

                    <!-- Dynamic Guided Form Fields -->
                    <div id="cora-mcp-guided-dynamic-fields" class="space-y-2 p-3 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50/50 dark:bg-zinc-950">
                        <!-- Populated by JS -->
                    </div>

                    <button type="button" onclick="coraExecuteGuidedTool()" class="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                        Run Guided Action
                    </button>
                </div>

                <!-- MODE 3: Developer JSON Mode -->
                <div id="cora-mcp-panel-dev" class="space-y-3" style="display: none;">
                    <div>
                        <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">Developer Tool Schema</label>
                        <select id="cora-mcp-test-tool-select" class="w-full text-xs font-semibold bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg px-3 py-2 outline-none cursor-pointer text-zinc-850 dark:text-zinc-100" onchange="coraOnMCPToolSelectChange()">
                            <option value="cora_get_workspace_overview">cora_get_workspace_overview</option>
                            <option value="cora_search_knowledge_base">cora_search_knowledge_base</option>
                            <option value="cora_query_financials">cora_query_financials</option>
                            <option value="cora_record_financial_transaction">cora_record_financial_transaction</option>
                            <option value="cora_manage_crm_leads">cora_manage_crm_leads</option>
                            <option value="cora_manage_bookings">cora_manage_bookings</option>
                            <option value="cora_manage_tasks">cora_manage_tasks</option>
                            <option value="cora_manage_documents">cora_manage_documents</option>
                            <option value="cora_manage_reviews">cora_manage_reviews</option>
                            <option value="cora_get_activity_pulse">cora_get_activity_pulse</option>
                            <option value="cora_ask_workspace_copilot">cora_ask_workspace_copilot</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">JSON Arguments</label>
                        <textarea id="cora-mcp-test-tool-args" rows="4" class="w-full font-mono text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg p-2.5 outline-none text-zinc-800 dark:text-zinc-200">{}</textarea>
                    </div>

                    <button type="button" onclick="coraExecuteMCPTestTool()" class="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                        Execute Raw Tool Call
                    </button>
                </div>

            </div>

            <!-- Right Results & Formatted Output Column -->
            <div class="space-y-2 flex flex-col">
                <div class="flex items-center justify-between">
                    <label class="block text-xs font-bold text-zinc-700 dark:text-zinc-300">Live Response</label>
                    <div class="inline-flex gap-1 text-[10px] font-bold">
                        <button type="button" id="cora-mcp-view-formatted-btn" onclick="coraSetOutputView('formatted')" class="px-2 py-0.5 bg-zinc-900 text-white rounded cursor-pointer">Formatted</button>
                        <button type="button" id="cora-mcp-view-raw-btn" onclick="coraSetOutputView('raw')" class="px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded cursor-pointer">Raw JSON</button>
                    </div>
                </div>

                <!-- Formatted Output Card -->
                <div id="cora-mcp-formatted-output" class="flex-1 min-h-[220px] bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 rounded-2xl p-4 text-xs leading-relaxed border border-zinc-200 dark:border-zinc-800 overflow-y-auto whitespace-pre-wrap">
Ready to run your first natural language command or guided action. Type a request on the left or select a prompt chip to begin.
                </div>

                <!-- Raw JSON Output Container -->
                <div id="cora-mcp-test-output" class="flex-1 min-h-[220px] bg-zinc-950 text-zinc-200 rounded-2xl p-4 font-mono text-[11px] leading-relaxed overflow-y-auto border border-zinc-800 whitespace-pre-wrap" style="display: none;">
Ready to execute tool call...
                </div>
            </div>
        </div>
    </div>

    <!-- Developer Token & Credentials -->
    <div class="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-xs space-y-4">
        <div class="border-b border-zinc-100 dark:border-zinc-800 pb-3">
            <h3 class="text-sm font-bold text-zinc-900 dark:text-zinc-100">MCP Secure Access Token</h3>
            <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Use this token to authenticate all external AI connections.</p>
        </div>

        <form id="cora-mcp-token-form" method="post" action="" class="space-y-4">
            <?php wp_nonce_field( 'cora_save_mcp_token_direct', 'cora_mcp_nonce' ); ?>
            <div class="space-y-2">
                <div class="flex flex-col sm:flex-row gap-2">
                    <input type="password" id="cora-mcp-access-token-direct" name="cora_mcp_access_token_direct" value="<?php echo esc_attr( $mcp_token ); ?>" class="w-full font-mono bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-lg text-xs px-3 py-2 outline-none cora-credential-input text-zinc-800 dark:text-zinc-200" oncopy="return false;" oncut="return false;" ondragstart="return false;" ondrop="return false;" autocomplete="off">
                    <div class="flex gap-2 w-full sm:w-auto shrink-0 justify-end">
                        <button type="button" class="flex-1 sm:flex-none px-3 py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-850 dark:text-zinc-200 font-bold text-xs rounded-lg transition-colors cursor-pointer" onclick="coraToggleTokenVisibilityDirect()">Show</button>
                        <button type="button" class="flex-1 sm:flex-none px-3 py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-850 dark:text-zinc-200 font-bold text-xs rounded-lg transition-colors cursor-pointer" onclick="coraGenerateNewMCPTokenDirect()">Regenerate</button>
                        <button type="submit" name="cora_save_mcp_token_direct_submit" class="flex-1 sm:flex-none px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm">
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                            Save Token
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- TAB 3: RAG Knowledge Base -->
<div id="cora-ai-panel-rag-settings" class="space-y-6 max-w-4xl" style="display:none;">
    <div class="flex items-center justify-between pb-4 border-b border-zinc-200 dark:border-zinc-800">
        <div>
            <h2 class="text-base font-bold text-zinc-900 dark:text-zinc-100">Living AI Memory & RAG Knowledge Engine</h2>
            <p class="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Isolated second brain automatically indexed from workspace daily flows.</p>
        </div>
        <button type="button" onclick="coraTriggerReindexLivingMemory(this)" class="inline-flex items-center gap-2 px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-xs">
            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
            Re-Index Workspace Knowledge
        </button>
    </div>
    <?php include CORA_WORKSPACE_PATH . 'views/view-rag.php'; ?>
</div>

<script>
    window.coraToggleAISettingsDrawer = function(open) {
        const drawer = document.getElementById('cora-ai-settings-drawer');
        const backdrop = document.getElementById('cora-ai-drawer-backdrop');
        if (!drawer || !backdrop) return;
        if (open) {
            drawer.classList.remove('translate-x-full');
            drawer.classList.add('translate-x-0');
            backdrop.classList.remove('hidden');
        } else {
            drawer.classList.remove('translate-x-0');
            drawer.classList.add('translate-x-full');
            backdrop.classList.add('hidden');
        }
    };

    // Models list mapping
    const coraAIModels = {
        groq: [
            { value: 'llama-3.1-8b-instant', label: 'Llama 3.1 8b Instant (Default)' },
            { value: 'mixtral-8x7b-32768', label: 'Mixtral 8x7b' }
        ],
        openrouter: [
            { value: 'meta-llama/llama-3.1-8b-instruct', label: 'Llama 3.1 8b Instruct (Default)' },
            { value: 'meta-llama/llama-3.1-70b-instruct', label: 'Llama 3.1 70b Instruct' }
        ],
        gemini: [
            { value: 'gemini-flash-latest', label: 'Gemini Flash (Default)' },
            { value: 'gemini-flash-lite-latest', label: 'Gemini Flash Lite' }
        ],
        llama_nv: [
            { value: 'meta/llama-3.1-70b-instruct', label: 'Llama 3.1 70b Instruct (Working - Default)' },
            { value: 'meta/llama-3.1-8b-instruct', label: 'Llama 3.1 8b Instruct (Working)' },
            { value: 'meta/llama-3.3-70b-instruct', label: 'Llama 3.3 70b Instruct' },
            { value: 'meta/llama-3.2-3b-instruct', label: 'Llama 3.2 3b Instruct' },
            { value: 'meta/llama-3.2-1b-instruct', label: 'Llama 3.2 1b Instruct' },
            { value: 'llama-guard-4-12b', label: 'Llama Guard 4 12b' }
        ],
        deepseek_nv: [
            { value: 'deepseek-ai/deepseek-v4-flash', label: 'DeepSeek v4 Flash' },
            { value: 'deepseek-ai/deepseek-v4-pro', label: 'DeepSeek v4 Pro' }
        ],
        gemma_nv: [
            { value: 'google/gemma-4-31b-it', label: 'Gemma 4 31b IT' }
        ],
        gpt_oss_nv: [
            { value: 'openai/gpt-oss-20b', label: 'GPT OSS 20b (Working - Default)' },
            { value: 'openai/gpt-oss-120b', label: 'GPT OSS 120b' }
        ],
        glm_nv: [
            { value: 'z-ai/glm-5.2', label: 'GLM 5.2' }
        ],
        minimax_nv: [
            { value: 'minimaxai/minimax-m3', label: 'Minimax M3' }
        ],
        moonshot_nv: [
            { value: 'moonshotai/kimi-k2.6', label: 'Moonshot kimi-k2.6' }
        ]
    };

    function coraOnProviderChange() {
        const provider = document.getElementById('cora-ai-provider').value;
        const modelSelect = document.getElementById('cora-ai-model');
        modelSelect.innerHTML = '';
        coraAIModels[provider].forEach(m => {
            const opt = document.createElement('option');
            opt.value = m.value;
            opt.innerText = m.label;
            modelSelect.appendChild(opt);
        });
    }

    // On page load setup models
    coraOnProviderChange();

    function coraSwitchAIPanel(panelId) {
        const tabs = document.querySelectorAll('.cora-ai-tab');
        const chatPanel = document.getElementById('cora-ai-panel-chat');
        const settingsPanel = document.getElementById('cora-ai-panel-mcp-settings');
        const ragPanel = document.getElementById('cora-ai-panel-rag-settings');

        tabs.forEach(t => t.classList.remove('active'));
        if (panelId === 'chat') {
            tabs[0].classList.add('active');
            chatPanel.style.display = 'grid';
            settingsPanel.style.display = 'none';
            if (ragPanel) ragPanel.style.display = 'none';
        } else if (panelId === 'mcp-settings') {
            tabs[1].classList.add('active');
            chatPanel.style.display = 'none';
            settingsPanel.style.display = 'block';
            if (ragPanel) ragPanel.style.display = 'none';
        } else if (panelId === 'rag-settings') {
            tabs[2].classList.add('active');
            chatPanel.style.display = 'none';
            settingsPanel.style.display = 'none';
            if (ragPanel) ragPanel.style.display = 'block';
        }
    }

    function coraCopyToClipboardDirect(inputId) {
        var copyText = document.getElementById(inputId);
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
        window.coraShowToast("Copied to clipboard.");
    }

    function coraToggleTokenVisibilityDirect() {
        var x = document.getElementById("cora-mcp-access-token-direct");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }

    function coraGenerateNewMCPTokenDirect() {
        window.coraConfirmAction(
            'Regenerate MCP Token',
            'Are you sure you want to regenerate the secure token? Current active AI tools connections will immediately fail authentication.',
            function() {
                var chars = 'abcdef0123456789';
                var newToken = '';
                for (var i = 0; i < 32; i++) {
                    newToken += chars.charAt(Math.floor(Math.random() * chars.length));
                }
                document.getElementById("cora-mcp-access-token-direct").value = newToken;
                window.coraShowToast("New secure token generated. Save to persist.");
            }
        );
    }

    function coraCopyClaudeConfigDirect() {
        var codeText = document.getElementById("cora-claude-config-code-direct").innerText;
        navigator.clipboard.writeText(codeText);
        window.coraShowToast("Claude configuration copied to clipboard.");
    }

    // Playground Mode Management
    let coraActiveMCPPlaygroundMode = 'nl';

    function coraSetMCPPlaygroundMode(mode) {
        coraActiveMCPPlaygroundMode = mode;
        const panelNL = document.getElementById('cora-mcp-panel-nl');
        const panelGuided = document.getElementById('cora-mcp-panel-guided');
        const panelDev = document.getElementById('cora-mcp-panel-dev');
        const btnNL = document.getElementById('cora-mcp-mode-nl-btn');
        const btnGuided = document.getElementById('cora-mcp-mode-guided-btn');
        const btnDev = document.getElementById('cora-mcp-mode-dev-btn');

        [panelNL, panelGuided, panelDev].forEach(p => { if (p) p.style.display = 'none'; });
        [btnNL, btnGuided, btnDev].forEach(b => {
            if (b) {
                b.className = 'px-3 py-1 rounded-lg text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 cursor-pointer transition-all';
            }
        });

        if (mode === 'nl') {
            if (panelNL) panelNL.style.display = 'block';
            if (btnNL) btnNL.className = 'px-3 py-1 rounded-lg bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs cursor-pointer transition-all font-bold';
        } else if (mode === 'guided') {
            if (panelGuided) panelGuided.style.display = 'block';
            if (btnGuided) btnGuided.className = 'px-3 py-1 rounded-lg bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs cursor-pointer transition-all font-bold';
            coraOnGuidedToolChange();
        } else if (mode === 'dev') {
            if (panelDev) panelDev.style.display = 'block';
            if (btnDev) btnDev.className = 'px-3 py-1 rounded-lg bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs cursor-pointer transition-all font-bold';
            coraOnMCPToolSelectChange();
        }
    }

    function coraSetNLPrompt(promptText) {
        const input = document.getElementById('cora-mcp-nl-input');
        if (input) {
            input.value = promptText;
            input.focus();
        }
    }

    function coraSetOutputView(view) {
        const formattedBox = document.getElementById('cora-mcp-formatted-output');
        const rawBox = document.getElementById('cora-mcp-test-output');
        const btnFormatted = document.getElementById('cora-mcp-view-formatted-btn');
        const btnRaw = document.getElementById('cora-mcp-view-raw-btn');

        if (view === 'formatted') {
            formattedBox.style.display = 'block';
            rawBox.style.display = 'none';
            btnFormatted.className = 'px-2 py-0.5 bg-zinc-900 text-white rounded cursor-pointer font-bold';
            btnRaw.className = 'px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded cursor-pointer font-medium';
        } else {
            formattedBox.style.display = 'none';
            rawBox.style.display = 'block';
            btnFormatted.className = 'px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 rounded cursor-pointer font-medium';
            btnRaw.className = 'px-2 py-0.5 bg-zinc-900 text-white rounded cursor-pointer font-bold';
        }
    }

    function coraEscapeHtml(str) {
        return (str || '').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // Execute Natural Language Command
    async function coraExecuteNaturalLanguageCommand() {
        const promptInput = document.getElementById('cora-mcp-nl-input');
        const query = (promptInput?.value || '').trim();
        if (!query) {
            window.coraShowToast("Please enter a natural language command.");
            return;
        }

        const runBtn = document.getElementById('cora-mcp-run-nl-btn');
        const formattedBox = document.getElementById('cora-mcp-formatted-output');
        const rawBox = document.getElementById('cora-mcp-test-output');
        const token = document.getElementById('cora-mcp-access-token-direct').value;
        const mcpUrl = '<?php echo esc_url( home_url( "/wp-json/cora/v1/mcp" ) ); ?>';

        if (runBtn) {
            runBtn.disabled = true;
            runBtn.innerHTML = '<span class="animate-spin inline-block mr-1">⟳</span> Executing command...';
        }

        formattedBox.innerHTML = '<div class="flex items-center gap-2 text-zinc-500"><span class="animate-spin text-sm">⟳</span> Analyzing request and running workspace intelligence...</div>';
        rawBox.innerText = 'Executing natural language query: ' + query + '...';

        try {
            // Send as direct AI QA / Copilot call over MCP
            const res = await fetch(mcpUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'tools/call',
                    params: {
                        name: 'cora_ask_workspace_copilot',
                        arguments: { question: query }
                    },
                    id: Date.now()
                })
            });

            const data = await res.json();
            rawBox.innerText = JSON.stringify(data, null, 2);

            if (data.result && data.result.content && data.result.content[0]) {
                const text = data.result.content[0].text;
                formattedBox.innerHTML = `<div class="font-sans text-xs text-zinc-800 dark:text-zinc-200 leading-relaxed whitespace-pre-wrap">${coraEscapeHtml(text)}</div>`;
                window.coraShowToast("Command executed successfully.");
            } else if (data.error) {
                formattedBox.innerHTML = `<div class="p-3 rounded-lg bg-red-50 text-red-700 text-xs font-medium">Error: ${coraEscapeHtml(data.error.message || 'Execution error')}</div>`;
                window.coraShowToast("Execution error: " + (data.error.message || 'Error'));
            } else {
                formattedBox.innerText = JSON.stringify(data, null, 2);
            }
        } catch (e) {
            formattedBox.innerHTML = `<div class="p-3 rounded-lg bg-red-50 text-red-700 text-xs font-medium">Connection failed: ${coraEscapeHtml(e.message)}</div>`;
            rawBox.innerText = "Network error: " + e.message;
            window.coraShowToast("Could not connect to workspace server.");
        } finally {
            if (runBtn) {
                runBtn.disabled = false;
                runBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> Execute Natural Language Command';
            }
        }
    }

    // Guided Tool Change Handler
    function coraOnGuidedToolChange() {
        const tool = document.getElementById('cora-mcp-guided-tool-select').value;
        const container = document.getElementById('cora-mcp-guided-dynamic-fields');
        if (!container) return;

        let html = '';
        if (tool === 'cora_get_workspace_overview') {
            html = `<p class="text-xs text-zinc-500">Fetches real-time workspace KPIs, revenue collected, outstanding receivables aging, active shoot bookings, and pending tasks.</p>`;
        } else if (tool === 'cora_search_knowledge_base') {
            html = `
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Search Query or Question</label>
                    <input type="text" id="cora-guided-search-query" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200" placeholder="e.g. photography commercial terms, client cancellation policy" value="commercial photography rates">
                </div>
            `;
        } else if (tool === 'cora_query_financials') {
            html = `
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Financial Filter</label>
                    <select id="cora-guided-fin-filter" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200">
                        <option value="all">All Invoices & Ledger</option>
                        <option value="unpaid">Unpaid Receivables Only</option>
                        <option value="paid">Paid Transactions Only</option>
                        <option value="overdue">Overdue Invoices</option>
                    </select>
                </div>
            `;
        } else if (tool === 'cora_record_financial_transaction') {
            html = `
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Type</label>
                        <select id="cora-guided-rec-type" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200">
                            <option value="expense">Expense Receipt</option>
                            <option value="payment">Invoice Payment</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Amount (₹)</label>
                        <input type="number" id="cora-guided-rec-amount" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200" value="3500">
                    </div>
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Client or Vendor Name</label>
                    <input type="text" id="cora-guided-rec-vendor" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200" placeholder="Vendor / Client" value="Camera Gear Depot">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Description / Notes</label>
                    <input type="text" id="cora-guided-rec-desc" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200" placeholder="Description" value="Studio softbox diffusers">
                </div>
            `;
        } else if (tool === 'cora_manage_crm_leads') {
            html = `
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Action</label>
                    <select id="cora-guided-lead-action" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200">
                        <option value="list">List Recent Leads & Deals</option>
                        <option value="search">Search Leads</option>
                    </select>
                </div>
            `;
        } else if (tool === 'cora_manage_bookings') {
            html = `<p class="text-xs text-zinc-500">Lists all upcoming scheduled sessions, call-times, shoot types, and location assignments.</p>`;
        } else if (tool === 'cora_manage_tasks') {
            html = `<p class="text-xs text-zinc-500">Lists client deliverable checklist tasks, priority flags, and deadlines.</p>`;
        } else if (tool === 'cora_manage_documents') {
            html = `<p class="text-xs text-zinc-500">Queries document vault for active agreements, proposals, and client e-signature status.</p>`;
        } else if (tool === 'cora_manage_reviews') {
            html = `<p class="text-xs text-zinc-500">Fetches Google reviews and generates automated professional replies.</p>`;
        } else if (tool === 'cora_get_activity_pulse') {
            html = `<p class="text-xs text-zinc-500">Retrieves real-time audit stream of all workspace actions and modifications.</p>`;
        } else if (tool === 'cora_ask_workspace_copilot') {
            html = `
                <div>
                    <label class="block text-[11px] font-bold text-zinc-700 dark:text-zinc-300 mb-1">Your Question to AI Co-Founder</label>
                    <input type="text" id="cora-guided-copilot-q" class="w-full text-xs p-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg outline-none text-zinc-800 dark:text-zinc-200" value="Summarize our current pipeline and financial cash runway.">
                </div>
            `;
        }

        container.innerHTML = html;
    }

    // Execute Guided Tool
    async function coraExecuteGuidedTool() {
        const tool = document.getElementById('cora-mcp-guided-tool-select').value;
        const formattedBox = document.getElementById('cora-mcp-formatted-output');
        const rawBox = document.getElementById('cora-mcp-test-output');
        const token = document.getElementById('cora-mcp-access-token-direct').value;
        const mcpUrl = '<?php echo esc_url( home_url( "/wp-json/cora/v1/mcp" ) ); ?>';

        let args = {};
        if (tool === 'cora_search_knowledge_base') {
            args = { query: document.getElementById('cora-guided-search-query')?.value || 'pricing', limit: 5 };
        } else if (tool === 'cora_query_financials') {
            args = { filter: document.getElementById('cora-guided-fin-filter')?.value || 'all', limit: 10 };
        } else if (tool === 'cora_record_financial_transaction') {
            args = {
                type: document.getElementById('cora-guided-rec-type')?.value || 'expense',
                amount: parseFloat(document.getElementById('cora-guided-rec-amount')?.value || 0),
                client_or_vendor: document.getElementById('cora-guided-rec-vendor')?.value || 'Vendor',
                description: document.getElementById('cora-guided-rec-desc')?.value || ''
            };
        } else if (tool === 'cora_manage_crm_leads') {
            args = { action: document.getElementById('cora-guided-lead-action')?.value || 'list', limit: 10 };
        } else if (tool === 'cora_ask_workspace_copilot') {
            args = { question: document.getElementById('cora-guided-copilot-q')?.value || 'Summarize workspace metrics.' };
        } else {
            args = { action: 'list' };
        }

        formattedBox.innerHTML = '<div class="flex items-center gap-2 text-zinc-500"><span class="animate-spin text-sm">⟳</span> Running action...</div>';
        rawBox.innerText = 'Calling ' + tool + '...';

        try {
            const res = await fetch(mcpUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'tools/call',
                    params: {
                        name: tool,
                        arguments: args
                    },
                    id: Date.now()
                })
            });

            const data = await res.json();
            rawBox.innerText = JSON.stringify(data, null, 2);

            if (data.result && data.result.content && data.result.content[0]) {
                const text = data.result.content[0].text;
                formattedBox.innerHTML = `<div class="font-sans text-xs text-zinc-800 dark:text-zinc-200 leading-relaxed whitespace-pre-wrap">${coraEscapeHtml(text)}</div>`;
                window.coraShowToast("Action completed.");
            } else if (data.error) {
                formattedBox.innerHTML = `<div class="p-3 rounded-lg bg-red-50 text-red-700 text-xs font-medium">Error: ${coraEscapeHtml(data.error.message || 'Execution error')}</div>`;
                window.coraShowToast("Action error: " + (data.error.message || 'Error'));
            } else {
                formattedBox.innerText = JSON.stringify(data, null, 2);
            }
        } catch (e) {
            formattedBox.innerHTML = `<div class="p-3 rounded-lg bg-red-50 text-red-700 text-xs font-medium">Connection failed: ${coraEscapeHtml(e.message)}</div>`;
            rawBox.innerText = "Network error: " + e.message;
            window.coraShowToast("Could not connect to workspace server.");
        }
    }

    // Tool argument templates
    const coraMCPToolArgTemplates = {
        cora_get_workspace_overview: '{}',
        cora_search_knowledge_base: JSON.stringify({ query: 'commercial photography rates', limit: 5 }, null, 2),
        cora_query_financials: JSON.stringify({ filter: 'all', limit: 10 }, null, 2),
        cora_record_financial_transaction: JSON.stringify({ type: 'expense', amount: 4500, client_or_vendor: 'Studio Lighting Depot', description: 'RGB Tube Lights' }, null, 2),
        cora_manage_crm_leads: JSON.stringify({ action: 'list', limit: 10 }, null, 2),
        cora_manage_bookings: JSON.stringify({ action: 'list' }, null, 2),
        cora_manage_tasks: JSON.stringify({ action: 'list' }, null, 2),
        cora_manage_documents: JSON.stringify({ action: 'list' }, null, 2),
        cora_manage_reviews: JSON.stringify({ action: 'list', limit: 10 }, null, 2),
        cora_get_activity_pulse: JSON.stringify({ limit: 15 }, null, 2),
        cora_ask_workspace_copilot: JSON.stringify({ question: 'Summarize our current pipeline and receivables status.' }, null, 2)
    };

    function coraOnMCPToolSelectChange() {
        const select = document.getElementById('cora-mcp-test-tool-select');
        const argsArea = document.getElementById('cora-mcp-test-tool-args');
        if (select && argsArea) {
            argsArea.value = coraMCPToolArgTemplates[select.value] || '{}';
        }
    }

    async function coraExecuteMCPTestTool() {
        const toolName = document.getElementById('cora-mcp-test-tool-select').value;
        const argsStr = document.getElementById('cora-mcp-test-tool-args').value;
        const formattedBox = document.getElementById('cora-mcp-formatted-output');
        const outputEl = document.getElementById('cora-mcp-test-output');
        const token = document.getElementById('cora-mcp-access-token-direct').value;
        const mcpUrl = '<?php echo esc_url( home_url( "/wp-json/cora/v1/mcp" ) ); ?>';

        let parsedArgs = {};
        try {
            parsedArgs = JSON.parse(argsStr || '{}');
        } catch (err) {
            window.coraShowToast("Invalid JSON arguments syntax.");
            return;
        }

        outputEl.innerText = "Executing tool call '" + toolName + "'...\nConnecting to " + mcpUrl;
        formattedBox.innerHTML = '<div class="flex items-center gap-2 text-zinc-500"><span class="animate-spin text-sm">⟳</span> Executing ' + toolName + '...</div>';

        try {
            const res = await fetch(mcpUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + token
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    method: 'tools/call',
                    params: {
                        name: toolName,
                        arguments: parsedArgs
                    },
                    id: Date.now()
                })
            });

            const data = await res.json();
            outputEl.innerText = JSON.stringify(data, null, 2);
            if (data.result && data.result.content && data.result.content[0]) {
                formattedBox.innerHTML = `<div class="font-sans text-xs text-zinc-800 dark:text-zinc-200 leading-relaxed whitespace-pre-wrap">${coraEscapeHtml(data.result.content[0].text)}</div>`;
            } else {
                formattedBox.innerText = JSON.stringify(data, null, 2);
            }
            window.coraShowToast("Tool call completed.");
        } catch (e) {
            outputEl.innerText = "Error executing tool call:\n" + e.message;
            formattedBox.innerHTML = `<div class="p-3 rounded-lg bg-red-50 text-red-700 text-xs font-medium">Connection failed: ${coraEscapeHtml(e.message)}</div>`;
            window.coraShowToast("Failed to connect to MCP endpoint.");
        }
    }

    async function coraFetchAndCopyOpenAPISchema() {
        const url = document.getElementById('cora-mcp-openapi-url').value;
        try {
            const res = await fetch(url);
            const data = await res.json();
            const jsonText = JSON.stringify(data, null, 2);
            navigator.clipboard.writeText(jsonText);
            window.coraShowToast("OpenAPI 3.1.0 JSON Schema copied to clipboard.");
        } catch (e) {
            window.coraShowToast("Could not fetch OpenAPI schema.");
        }
    }

    function coraTriggerReindexLivingMemory(btn) {
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="animate-spin inline-block mr-1">⟳</span> Indexing...';
        }
        jQuery.ajax({
            url: typeof cora_workspace_data !== 'undefined' ? cora_workspace_data.ajax_url : '<?php echo admin_url("admin-ajax.php"); ?>',
            type: 'POST',
            data: {
                action: 'cora_reindex_living_memory',
                nonce: typeof cora_workspace_data !== 'undefined' ? cora_workspace_data.nonce : '<?php echo wp_create_nonce("cora_ajax_nonce"); ?>'
            },
            success: function(resp) {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg> Re-Index Workspace Knowledge';
                }
                if (resp.success) {
                    window.coraShowToast(resp.data.message || "Living memory re-indexed.");
                    setTimeout(function() { location.reload(); }, 1200);
                } else {
                    window.coraShowToast(resp.data?.message || "Re-indexing failed.");
                }
            },
            error: function() {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = 'Re-Index Workspace Knowledge';
                }
                window.coraShowToast("Network error during re-indexing.");
            }
        });
    }

    // Conversation Management
    let conversationHistory = [];

    function coraClearConversation() {
        conversationHistory = [];
        const viewport = document.getElementById('cora-ai-messages');
        viewport.innerHTML = `
            <div class="cora-ai-welcome" id="cora-ai-welcome-screen">
                <div class="w-12 h-12 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-800 border border-zinc-200 shadow-sm">
                    <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                </div>
                <div>
                    <h3 class="text-base font-bold text-zinc-900 ">Welcome to Cora AI</h3>
                    <p class="text-xs text-zinc-500 max-w-sm mt-1">Ask questions, generate draft assets, or perform GST calculations in a few quick keystrokes.</p>
                </div>
                <div class="cora-ai-chips">
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Draft a contract for a property sale')">
                        <strong>Draft Contract</strong>
                        <p class="text-zinc-400 mt-1">Draft a contract for a property sale.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Calculate GST for a ₹50,000 booking split between Delhi and Jaipur')">
                        <strong>GST Split Math</strong>
                        <p class="text-zinc-400 mt-1">Calculate GST for ₹50,000 Delhi-Jaipur split.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('Explain the geofenced office location coordinate checking')">
                        <strong>Geofencing Help</strong>
                        <p class="text-zinc-400 mt-1">Explain coordinate checking bounds.</p>
                    </div>
                    <div class="cora-ai-chip" onclick="coraUsePromptChip('How do I manage workspace API roles?')">
                        <strong>Roles Governance</strong>
                        <p class="text-zinc-400 mt-1">How do I manage workspace API roles?</p>
                    </div>
                </div>
            </div>
        `;
        window.coraShowToast("Conversation cleared.");
    }

    function coraUsePromptChip(promptText) {
        document.getElementById('cora-ai-input').value = promptText;
        coraSendChatMessage();
    }

    function coraSendChatMessage() {
        const inputEl = document.getElementById('cora-ai-input');
        const promptText = inputEl.value.trim();
        if (!promptText) return;

        // Clear input and welcome screen
        inputEl.value = '';
        const welcomeScreen = document.getElementById('cora-ai-welcome-screen');
        if (welcomeScreen) {
            welcomeScreen.remove();
        }

        // Append user message
        coraAppendMessage('user', promptText);

        const startTime = Date.now();

        // Show loader indicator with a dynamic timer
        const loaderId = coraAppendMessage('assistant', `
            <div class="cora-skeleton-chat">
                <div class="cora-skeleton-line w-80"></div>
                <div class="cora-skeleton-line w-95"></div>
                <div class="cora-skeleton-line w-60"></div>
                <div class="text-[10px] text-zinc-400 mt-2 font-mono flex items-center gap-1.5">
                    <svg class="cora-ai-spin" viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                    <span>Generating... <span class="cora-ai-timer-sec">0.0</span>s elapsed</span>
                </div>
            </div>
        `);

        // Realtime ticking timer update
        const timerInterval = setInterval(() => {
            const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
            const timerEl = document.querySelector(`#${loaderId} .cora-ai-timer-sec`);
            if (timerEl) {
                timerEl.textContent = elapsed;
            }
        }, 100);

        // Disable controls during request
        const sendBtn = document.getElementById('cora-ai-send-btn');
        sendBtn.disabled = true;
        inputEl.disabled = true;

        // Gather parameters
        const provider = document.getElementById('cora-ai-provider').value;
        const model = document.getElementById('cora-ai-model').value;
        const temp = document.getElementById('cora-ai-temperature').value;
        const systemPrompt = document.getElementById('cora-ai-system').value;
        const ttsEnabled = document.getElementById('cora-ai-tts-toggle').checked;

        const ajaxUrlEndpoint = (typeof coraREData !== 'undefined' && coraREData.ajaxUrl) ? coraREData.ajaxUrl : (typeof coraREWPData !== 'undefined' ? coraREWPData.ajaxUrl : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php'));

        jQuery.post(ajaxUrlEndpoint, {
            action: 'cora_ai_chat_query',
            security: (typeof coraREData !== 'undefined' && coraREData.ajaxNonce) ? coraREData.ajaxNonce : (typeof coraREWPData !== 'undefined' ? coraREWPData.ajaxNonce : ''),
            message: promptText,
            provider: provider,
            model: model,
            temperature: temp,
            system_prompt: systemPrompt
        }, function(res) {
            clearInterval(timerInterval);
            const duration = ((Date.now() - startTime) / 1000).toFixed(1);

            // Enable inputs
            sendBtn.disabled = false;
            inputEl.disabled = false;
            inputEl.focus();

            const bubble = document.getElementById(loaderId);
            
            // Catch raw HTML or warning-wrapped responses and parse them safely
            let data = res;
            if (typeof res === 'string') {
                try {
                    data = JSON.parse(res);
                } catch(e) {
                    bubble.innerHTML = `<span style="color:var(--status-critical, #ef4444); font-weight:bold;">Parser Error: Invalid JSON response from server.</span><pre class="bg-zinc-100 p-2 rounded text-[10px] overflow-auto max-h-40 mt-2 font-mono border border-zinc-200 text-zinc-700 ">${res}</pre>`;
                    coraScrollToBottom();
                    return;
                }
            }

            if (data && data.success && data.data && data.data.reply) {
                const replyText = data.data.reply;
                bubble.innerHTML = coraFormatAIResponse(replyText);
                
                const chipsHtml = coraGetFollowupChips(promptText, replyText);

                let noticeHtml = '';
                if (data.data.fallback_notice) {
                    noticeHtml = `
                        <div class="mt-2 text-[10px] text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 flex items-start gap-1.5 font-medium max-w-md">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none" class="shrink-0 mt-0.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                            <span>${data.data.fallback_notice}</span>
                        </div>
                    `;
                }

                bubble.innerHTML += `
                    ${noticeHtml}
                    <div class="cora-ai-message-meta">
                        <span>${data.data.provider.toUpperCase()} / ${data.data.model} &bull; Response in ${duration}s</span>
                        <button type="button" class="cursor-pointer underline text-[9px] text-zinc-500 hover:text-zinc-700 bg-transparent border-none p-0" onclick="coraCopyMessageText(this)">Copy Text</button>
                    </div>
                    ${chipsHtml}
                `;

                // If TTS enabled, synthesize voice
                if (ttsEnabled) {
                    coraPlayResponseAudio(replyText, bubble);
                }
            } else {
                const errMsg = (data && data.data && data.data.message) ? data.data.message : 'Error retrieving chat completion.';
                bubble.innerHTML = `<span style="color:var(--status-critical, #ef4444); font-weight:bold;">API Error:</span> <span class="text-zinc-700 text-xs">${errMsg}</span>`;
            }
            coraScrollToBottom();
        }).fail(function(xhr, status, error) {
            clearInterval(timerInterval);
            sendBtn.disabled = false;
            inputEl.disabled = false;
            const bubble = document.getElementById(loaderId);
            bubble.innerHTML = `
                <span style="color:var(--status-critical, #ef4444); font-weight:bold;">Network Request Failed:</span>
                <div class="text-[11px] text-zinc-600 mt-2 font-mono p-2 bg-zinc-50 border border-zinc-200 rounded">
                    <div>HTTP Status: ${xhr.status} (${xhr.statusText || 'Unknown'})</div>
                    <div>Status Label: ${status}</div>
                    <div>Error detail: ${error || 'Connection refused or aborted'}</div>
                </div>
            `;
            coraScrollToBottom();
        });
    }

    function coraAppendMessage(role, content) {
        const viewport = document.getElementById('cora-ai-messages');
        const msgId = 'cora-msg-' + Math.random().toString(36).substr(2, 9);
        const msgDiv = document.createElement('div');
        msgDiv.className = `cora-ai-message ${role}`;
        msgDiv.id = msgId;
        msgDiv.innerHTML = content;
        viewport.appendChild(msgDiv);
        coraScrollToBottom();
        return msgId;
    }

    // Simple auto scroll helper
    function coraScrollToBottom() {
        const viewport = document.getElementById('cora-ai-messages');
        viewport.scrollTop = viewport.scrollHeight;
    }

    function coraFormatAIResponse(text) {
        // Simple markdown formatting helper
        let formatted = text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`([^`]+)`/g, '<code class="bg-zinc-100 px-1 py-0.5 rounded font-mono text-xs">$1</code>')
            .replace(/\n/g, '<br>');
        return formatted;
    }

    function coraCopyMessageText(btnEl) {
        const msgDiv = btnEl.closest('.cora-ai-message');
        // Get inner text excluding the metadata row
        const clone = msgDiv.cloneNode(true);
        const meta = clone.querySelector('.cora-ai-message-meta');
        if (meta) meta.remove();
        navigator.clipboard.writeText(clone.innerText.trim());
        window.coraShowToast("Message copied.");
    }

    function coraPlayResponseAudio(text, bubbleElement) {
        // Clean markdown or tags for clean speech
        const cleanedText = text.replace(/[*`#_]/g, '');

        window.coraShowToast("Synthesizing voice output...");

        const ajaxUrlEndpoint = (typeof coraREData !== 'undefined' && coraREData.ajaxUrl) ? coraREData.ajaxUrl : (typeof coraREWPData !== 'undefined' ? coraREWPData.ajaxUrl : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php'));

        jQuery.post(ajaxUrlEndpoint, {
            action: 'cora_ai_generate_tts',
            security: (typeof coraREData !== 'undefined' && coraREData.ajaxNonce) ? coraREData.ajaxNonce : (typeof coraREWPData !== 'undefined' ? coraREWPData.ajaxNonce : ''),
            text: cleanedText
        }, function(res) {
            if (res.success && res.data.audio) {
                const player = document.getElementById('cora-ai-audio-player');
                player.src = res.data.audio;
                player.play();
                window.coraShowToast("Playing audio response.");
            } else {
                console.error('TTS failed:', res.data);
            }
        });
    }

    function coraGetFollowupChips(prompt, reply) {
        let chips = [];
        const lowerPrompt = prompt.toLowerCase();
        const lowerReply = reply.toLowerCase();
        
        if (lowerPrompt.includes('contract') || lowerPrompt.includes('sale') || lowerPrompt.includes('agreement') || lowerPrompt.includes('draft') || lowerReply.includes('agreement') || lowerReply.includes('contract')) {
            chips = [
                'Summarize the critical dates and deadlines',
                'Add a severe breach and termination clause',
                'Translate this contract terms into plain English'
            ];
        } else if (lowerPrompt.includes('gst') || lowerPrompt.includes('tax') || lowerPrompt.includes('calculate') || lowerPrompt.includes('split') || lowerReply.includes('gst') || lowerReply.includes('tax')) {
            chips = [
                'Break down the exact SGST & CGST calculations',
                'Apply a 10% promotional discount and recalculate',
                'Draft a summary email to send to the client'
            ];
        } else if (lowerPrompt.includes('geofence') || lowerPrompt.includes('office') || lowerPrompt.includes('check-in') || lowerReply.includes('geofence')) {
            chips = [
                'Show me the JavaScript function bounding coordinates check',
                'Explain how to edit the location geofencing radius',
                'What happens if a check-in is logged outside the boundary?'
            ];
        } else {
            chips = [
                'Shorten this response for a quick briefing',
                'Elaborate in further detail with examples',
                'Provide the top 3 action items / next steps'
            ];
        }
        
        let html = '<div class="cora-ai-followup-chips">';
        chips.forEach(chip => {
            const escapedChip = chip.replace(/'/g, "\\'");
            html += `
                <button type="button" class="cora-ai-followup-chip" onclick="coraUsePromptChip('${escapedChip}')">
                    + ${chip}
                </button>
            `;
        });
        html += '</div>';
        return html;
    }

    // Expose send chat message globally
    window.coraSendChatMessage = coraSendChatMessage;

    // Check for pending prompt on page load
    jQuery(document).ready(function($) {
        const $islandInput = $('#cora-island-ai-input');
        if ($islandInput.length) {
            $islandInput.attr('placeholder', 'Ask Cora AI...');
        }

        const pendingPrompt = sessionStorage.getItem('cora_pending_ai_prompt');
        if (pendingPrompt) {
            sessionStorage.removeItem('cora_pending_ai_prompt');
            const inputEl = document.getElementById('cora-ai-input');
            if (inputEl) {
                inputEl.value = pendingPrompt;
                coraSendChatMessage();
            }
        }
    });
</script>
