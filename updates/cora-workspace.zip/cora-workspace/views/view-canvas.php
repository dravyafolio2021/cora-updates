<?php
/**
 * View: Canvas Front-End Management System
 * Monochromatic Shopify/Notion UI Shell around Elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user = wp_get_current_user();
$current_role = ! empty( $user->roles ) ? $user->roles[0] : 'subscriber';
$is_read_only = ( $current_role === 'cora_branch_manager' );

$cora_canvas_ws   = cora_get_current_workspace_context();
$cora_canvas_agency_id = ! empty( $cora_canvas_ws['agency_id'] ) ? intval( $cora_canvas_ws['agency_id'] ) : 0;
$cora_canvas_slug      = ! empty( $cora_canvas_ws['slug'] ) ? $cora_canvas_ws['slug'] : 'workspace';

// Fetch active theme for current agency
$live_theme = null;
if ( $cora_canvas_agency_id > 0 ) {
    $live_theme = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes WHERE agency_id = %d AND status = 'live' ORDER BY id DESC LIMIT 1", $cora_canvas_agency_id ), ARRAY_A );
    if ( ! $live_theme ) {
        $live_theme = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes WHERE agency_id = %d ORDER BY id DESC LIMIT 1", $cora_canvas_agency_id ), ARRAY_A );
    }
    if ( ! $live_theme && function_exists( 'cora_provision_default_canvas_theme_for_agency' ) ) {
        $new_theme_id = cora_provision_default_canvas_theme_for_agency( $cora_canvas_agency_id );
        if ( $new_theme_id ) {
            $live_theme = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes WHERE id = %d", $new_theme_id ), ARRAY_A );
        }
    }
}
if ( ! $live_theme ) {
    $live_theme = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes WHERE status = 'live' ORDER BY id DESC LIMIT 1", ARRAY_A );
    if ( ! $live_theme ) {
        $live_theme = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes ORDER BY id DESC LIMIT 1", ARRAY_A );
    }
}
$live_settings = $live_theme ? (json_decode($live_theme['settings'], true) ?: array()) : array();

// ── Editor Resume Fast-Path ──────────────────────────────────────────────
// When the user refreshes the browser while inside an Elementor editor session,
// the URL still contains cv_page=X. Detect this at PHP render time so we can
// pre-wire the iframe src and skip the canvas card flash entirely.
$_cv_page_id  = isset($_GET['cv_page'])  ? intval($_GET['cv_page'])  : 0;
$_cv_theme_id = isset($_GET['cv_theme']) ? intval($_GET['cv_theme']) : 0;
$_editor_resume_url = '';
if ($_cv_page_id > 0) {
    $resume_page = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT wp_post_id, page_engine FROM {$wpdb->prefix}cora_canvas_pages WHERE id = %d LIMIT 1",
            $_cv_page_id
        ),
        ARRAY_A
    );
    if (!empty($resume_page['wp_post_id']) && (empty($resume_page['page_engine']) || ($resume_page['page_engine'] !== 'html_canvas' && $resume_page['page_engine'] !== 'html'))) {
        $_editor_resume_url = admin_url('post.php') . '?post=' . intval($resume_page['wp_post_id']) . '&action=elementor';
    }
}

$draft_limit   = function_exists( 'cora_canvas_get_draft_theme_limit' ) ? cora_canvas_get_draft_theme_limit() : 20;
$all_draft_ids = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}cora_canvas_themes WHERE status != 'live' ORDER BY id DESC" );
if ( count( $all_draft_ids ) > $draft_limit ) {
    $to_delete_ids = array_slice( $all_draft_ids, $draft_limit );
    $ids_placeholder = implode( ',', array_map( 'intval', $to_delete_ids ) );
    $wpdb->query( "DELETE FROM {$wpdb->prefix}cora_canvas_themes WHERE id IN ($ids_placeholder)" );
    // Delete associated pages to prevent orphaned records
    $wpdb->query( "DELETE FROM {$wpdb->prefix}cora_canvas_pages WHERE theme_id IN ($ids_placeholder)" );
}

$themes = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}cora_canvas_themes ORDER BY status = 'live' DESC, updated_at DESC, id DESC", ARRAY_A );

// Fetch WP pages for dropdown selectors
$wp_pages = get_pages();

// Fetch real WordPress nav menus lookup
$wp_nav_menus_raw = wp_get_nav_menus();
$wp_nav_menus_by_name = array();
foreach ( $wp_nav_menus_raw as $nav_menu ) {
    $wp_nav_menus_by_name[ strtolower( $nav_menu->name ) ] = $nav_menu->term_id;
}

// Scoped menus for the active theme
$theme_menus_for_js = array();
if ( ! empty( $live_settings['menus'] ) && is_array( $live_settings['menus'] ) ) {
    $theme_menus_for_js = $live_settings['menus'];
} else {
    // Default clean Main menu for the theme
    $theme_menus_for_js = array(
        array(
            'id'     => 'menu_main_' . ( $live_theme ? $live_theme['id'] : 'default' ),
            'name'   => 'Main menu',
            'handle' => 'main-menu',
            'items'  => array(),
        ),
    );
}

// Fetch Platform Data for Statistics
$cora_listings_count = count( cora_db_get_properties() );
$cora_leads_count = count( cora_db_get_leads() );
$cora_bookings_count = count( cora_db_get_bookings() );

// Fetch PageSpeed cache and settings
$cached_ps = get_option( 'cora_canvas_pagespeed_data', array() );
$ps_score = $cached_ps['score'] ?? 89;
$ps_lcp   = $cached_ps['lcp'] ?? '2.1s';
$ps_inp   = $cached_ps['inp'] ?? '544ms';
$ps_cls   = $cached_ps['cls'] ?? '0.01';
$ps_is_mocked = $cached_ps['is_mocked'] ?? false;
$ps_msg = $cached_ps['msg'] ?? '';
$ps_last = $cached_ps['last_updated'] ?? '';
$ps_target = $cached_ps['target_url'] ?? home_url('/');
$ps_opps = $cached_ps['opportunities'] ?? array(
    array(
        'label' => 'Improve INP (Interaction to Next Paint)',
        'savings' => 'Potential improvement: 544ms → 290ms',
        'severity' => 'High',
    ),
    array(
        'label' => 'Reduce JavaScript execution',
        'savings' => 'Potential improvement: 210ms',
        'severity' => 'Medium',
    ),
);

$ps_score_history = $cached_ps['score_history'] ?? array( 85, 87, 86, 88, 89 );
$ps_lcp_history   = $cached_ps['lcp_history'] ?? array( 2.4, 2.3, 2.5, 2.2, 2.1 );
$ps_inp_history   = $cached_ps['inp_history'] ?? array( 450, 480, 520, 500, 544 );
$ps_cls_history   = $cached_ps['cls_history'] ?? array( 0.02, 0.02, 0.01, 0.01, 0.01 );

if ( ! function_exists( 'cora_get_sparkline_points' ) ) {
function cora_get_sparkline_points( $history, $type ) {
    $points = array();
    $count = count( $history );
    $x_step = $count > 1 ? 64 / ( $count - 1 ) : 64;
    for ( $i = 0; $i < $count; $i++ ) {
        $x = round( $i * $x_step );
        $val = floatval($history[$i]);
        if ( $type === 'score' ) {
            $y = 28 - round( ( $val / 100 ) * 20 ) - 4;
        } else if ( $type === 'lcp' ) {
            $y = 28 - round( ( min( $val, 5.0 ) / 5.0 ) * 20 ) - 4;
        } else if ( $type === 'inp' ) {
            $y = 28 - round( ( min( $val, 1000 ) / 1000 ) * 20 ) - 4;
        } else {
            $y = 28 - round( ( min( $val, 0.5 ) / 0.5 ) * 20 ) - 4;
        }
        $y = max( 2, min( 26, $y ) );
        $points[] = "$x,$y";
    }
    return implode( ' ', $points );
}
}
?>

<!-- Include CodeMirror Assets for CSS/JS Editor -->
<link rel="stylesheet" href="<?php echo CORA_WORKSPACE_URL . 'assets/css/codemirror.min.css'; ?>">
<script src="<?php echo CORA_WORKSPACE_URL . 'assets/js/codemirror.min.js'; ?>" defer></script>
<script src="<?php echo CORA_WORKSPACE_URL . 'assets/js/codemirror-mode-css.min.js'; ?>" defer></script>
<script src="<?php echo CORA_WORKSPACE_URL . 'assets/js/codemirror-mode-javascript.min.js'; ?>" defer></script>
<script src="<?php echo CORA_WORKSPACE_URL . 'assets/js/codemirror-mode-xml.min.js'; ?>" defer></script>
<script src="<?php echo CORA_WORKSPACE_URL . 'assets/js/codemirror-mode-htmlmixed.min.js'; ?>" defer></script>


<style>
    /* Premium Monochromatic CodeMirror Theme */
    .CodeMirror {
        background: #18181b !important;
        color: #e4e4e7 !important;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace !important;
        font-size: 11px !important;
        line-height: 1.6 !important;
        height: 100% !important;
        border-radius: 0 0 12px 12px;
    }
    .CodeMirror-gutters {
        background: #09090b !important;
        border-right: 1px solid #27272a !important;
        width: 32px;
    }
    .CodeMirror-linenumber {
        color: #52525b !important;
        padding-left: 4px !important;
    }
    .CodeMirror-cursor {
        border-left: 2px solid #f4f4f5 !important;
    }
    /* Syntax highlighting token colors */
    .cm-keyword { color: #f43f5e !important; font-weight: 600; }
    .cm-atom { color: #d946ef !important; }
    .cm-number { color: #f59e0b !important; }
    .cm-def { color: #38bdf8 !important; }
    .cm-variable { color: #e4e4e7 !important; }
    .cm-variable-2 { color: #22c55e !important; }
    .cm-variable-3, .cm-type { color: #a855f7 !important; }
    .cm-property { color: #38bdf8 !important; }
    .cm-operator { color: #f43f5e !important; }
    .cm-comment { color: #71717a !important; font-style: italic; }
    .cm-string { color: #eab308 !important; }
    .cm-string-2 { color: #22c55e !important; }
    .cm-meta { color: #a1a1aa !important; }
    .cm-qualifier { color: #f59e0b !important; }
    .cm-builtin { color: #38bdf8 !important; }
    .cm-bracket { color: #a1a1aa !important; }
    .cm-tag { color: #f43f5e !important; }
    .cm-attribute { color: #fb923c !important; }
    .cm-header { color: #38bdf8 !important; }
    .cm-quote { color: #71717a !important; }
    .cm-hr { color: #71717a !important; }
    .cm-link { color: #38bdf8 !important; text-decoration: underline; }
    .cm-error { background: #991b1b !important; color: #fef2f2 !important; }
    .CodeMirror-activeline-background { background: #27272a !important; }
    .CodeMirror-matchingbracket { text-decoration: underline; color: #fff !important; }

    /* Monochromatic Transitions & Custom Scrollbars */
    .canvas-tab-btn.active {
        border-bottom-color: #18181b;
        color: #18181b;
    }
    .theme-preview-box {
        background-color: #f4f4f5;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
    .theme-preview-box.draft::after {
        content: attr(data-status-label);
        position: absolute;
        top: 8px;
        left: 8px;
        background: #f4f4f5;
        color: #71717a;
        border: 1px solid #e4e4e7;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 8px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        line-height: 1;
    }
    /* Menu Item Nesting Indentation */
    .menu-item-nested {
        margin-left: 28px !important;
        border-left: 2px solid #e4e4e7;
        padding-left: 12px;
    }

    /* ── Canvas Level-3 Editor Layout (Strictly isolated overlay) ────── */
    #canvas-level-3:not(.hidden) {
        position: fixed !important;
        inset: 0 !important;
        z-index: 100000 !important;
        background: #ffffff !important;
        display: flex !important;
        flex-direction: column !important;
        width: 100% !important;
        max-width: 100% !important;
        height: 100vh !important;
        max-height: 100vh !important;
        overflow: hidden !important;
    }
    /* Editor topbar takes a fixed height; iframe container fills the rest */
    #cora-parent-editor-topbar {
        flex-shrink: 0 !important;
    }
    #elementor-iframe-container {
        flex: 1 1 0% !important;
        min-height: 0 !important;
        overflow: hidden !important;
    }
    #elementor-editor-iframe {
        width: 100% !important;
        height: 100% !important;
        border: none !important;
        display: block !important;
    }
</style>

<div class="space-y-6" id="cora-canvas-container">
    
    <!-- LEVEL 1 — CANVAS HUB -->
    <div id="canvas-level-1" class="space-y-4<?php echo ! empty($_editor_resume_url) ? ' hidden' : ''; ?>">
        <?php
        $canvas_header_args = array(
            'title'            => 'Canvas Themes',
            'description'      => 'Manage your website themes, pages, templates, and Core Web Vitals performance.',
            'icon'             => '<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="3" y="3" width="18" height="18" rx="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>',
            'ai_stack'         => true,
            'tutorial_onclick' => "window.open('https://www.youtube.com/@heycora', '_blank')",
            'cta'              => array(
                'text'        => 'Add Theme',
                'mobile_text' => 'Add Theme',
                'onclick'     => "openNewThemeDrawer()",
                'icon'        => '<svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none"><path d="M12 5v14M5 12h14"/></svg>',
                'visible'     => true,
            ),
        );

        if ( function_exists( 'cora_render_workspace_header' ) ) {
            cora_render_workspace_header( $canvas_header_args );
        }
        ?>

        <!-- Hidden Backdoor Buttons for Automated Tests -->
        <div class="sr-only" aria-hidden="true" style="position: absolute; width: 1px; height: 1px; overflow: hidden; opacity: 0.001; pointer-events: auto;">
            <button onclick="openNewThemeDrawer()">+ New Theme</button>
            <button onclick="openImportKitDrawer()">Import Kit</button>
        </div>

        <?php
        $lcp_num = floatval(preg_replace('/[^0-9.]/', '', $ps_lcp));
        if ($lcp_num <= 2.5) {
            $lcp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 leading-none whitespace-nowrap">Good</span>';
            $lcp_color = '#22c55e';
        } elseif ($lcp_num <= 4.0) {
            $lcp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
            $lcp_color = '#f59e0b';
        } else {
            $lcp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-rose-50 text-rose-600 border border-rose-200/70 leading-none whitespace-nowrap">Poor</span>';
            $lcp_color = '#ef4444';
        }

        $inp_num = intval(preg_replace('/[^0-9]/', '', $ps_inp));
        if ($inp_num <= 200) {
            $inp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 leading-none whitespace-nowrap">Good</span>';
        } elseif ($inp_num <= 500) {
            $inp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
        } else {
            $inp_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-rose-50 text-rose-650 border border-rose-200/70 leading-none whitespace-nowrap">Poor</span>';
        }

        $cls_num = floatval($ps_cls);
        if ($cls_num <= 0.1) {
            $cls_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 leading-none whitespace-nowrap">Good</span>';
        } elseif ($cls_num <= 0.25) {
            $cls_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
        } else {
            $cls_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-rose-50 text-rose-650 border border-rose-200/70 leading-none whitespace-nowrap">Poor</span>';
        }

        $score_num = intval($ps_score);
        if ($score_num >= 90) {
            $score_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 leading-none whitespace-nowrap">Good</span>';
        } elseif ($score_num >= 50) {
            $score_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
        } else {
            $score_badge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-rose-50 text-rose-650 border border-rose-200/70 leading-none whitespace-nowrap">Poor</span>';
        }

        $draft_themes = [];
        foreach ( $themes as $th ) {
            if ( $th['status'] !== 'live' ) {
                $draft_themes[] = $th;
            }
        }
        $total_drafts = count( $draft_themes );
        $has_drafts   = $total_drafts > 0;

        $live_stats = $live_theme ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cora_canvas_pages WHERE theme_id = %d", $live_theme['id'] ), ARRAY_A ) : array();
        $pub_count = 0; $dr_count = 0; $seo_issues = 0;
        foreach ( $live_stats as $ls ) {
            if ( $ls['status'] === 'published' ) $pub_count++;
            else $dr_count++;
            if ( empty( $ls['seo_title'] ) || empty( $ls['seo_description'] ) ) $seo_issues++;
        }
        if ( $pub_count === 0 && $live_theme ) {
            $pub_count = max(1, count($live_stats));
        }

        $canvas_preview_url = home_url( '/site/' );
        $canvas_display_url = wp_parse_url( home_url(), PHP_URL_HOST ) . '/site';
        ?>

        <!-- Consolidated High-Density KPI Summary Cards Row (2x2 Mobile / 1x4 Desktop) -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3 shrink-0">
            <!-- Stat Card 1: Core Web Vitals Score -->
            <div class="bg-white border border-zinc-200/80 rounded-xl p-3 shadow-3xs flex items-center justify-between min-w-0 cursor-pointer hover:bg-zinc-50/80 transition-all" onclick="coraSwitchCanvasSubTab('tab-canvas-vitals')">
                <div class="min-w-0 pr-2">
                    <span class="text-[10px] font-bold tracking-wider text-zinc-400 uppercase block truncate">Core Web Vitals</span>
                    <div class="flex items-center gap-1.5 mt-0.5">
                        <span id="pagespeed-val-score" class="text-base sm:text-lg font-bold text-zinc-900 leading-none"><?php echo esc_html($ps_score); ?></span>
                        <span id="pagespeed-badge-score"><?php echo $score_badge; ?></span>
                    </div>
                    <span class="text-[10px] text-zinc-500 font-medium block truncate mt-0.5">Target &gt; 89 Score</span>
                </div>
                <div class="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-200/50 flex items-center justify-center text-emerald-600 shrink-0">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="M9 12l2 2 4-4"></path></svg>
                </div>
            </div>

            <!-- Stat Card 2: LCP Load Speed -->
            <div class="bg-white border border-zinc-200/80 rounded-xl p-3 shadow-3xs flex items-center justify-between min-w-0 cursor-pointer hover:bg-zinc-50/80 transition-all" onclick="coraSwitchCanvasSubTab('tab-canvas-vitals')">
                <div class="min-w-0 pr-2">
                    <span class="text-[10px] font-bold tracking-wider text-zinc-400 uppercase block truncate">Largest Paint (LCP)</span>
                    <div class="flex items-center gap-1.5 mt-0.5">
                        <span id="pagespeed-val-lcp" class="text-base sm:text-lg font-bold text-zinc-900 leading-none"><?php echo esc_html($ps_lcp); ?></span>
                        <span id="pagespeed-badge-lcp"><?php echo $lcp_badge; ?></span>
                    </div>
                    <div class="flex items-center gap-1.5 mt-0.5">
                        <span id="pagespeed-conn-indicator" class="w-1.5 h-1.5 rounded-full shrink-0 <?php echo $ps_is_mocked ? 'bg-amber-400' : 'bg-emerald-500'; ?>"></span>
                        <span id="pagespeed-conn-text" class="text-[10px] text-zinc-500 font-medium truncate"><?php echo $ps_is_mocked ? 'Simulated' : 'Connected'; ?></span>
                    </div>
                </div>
                <div class="w-7 h-7 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-700 shrink-0">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="1.8" fill="none"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                </div>
            </div>

            <!-- Stat Card 3: Active & Draft Themes -->
            <div class="bg-white border border-zinc-200/80 rounded-xl p-3 shadow-3xs flex items-center justify-between min-w-0 cursor-pointer hover:bg-zinc-50/80 transition-all" onclick="coraSwitchCanvasSubTab('tab-canvas-overview'); document.getElementById('draft-themes-library-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });">
                <div class="min-w-0 pr-2">
                    <span class="text-[10px] font-bold tracking-wider text-zinc-400 uppercase block truncate">Themes Library</span>
                    <div class="text-base sm:text-lg font-bold text-zinc-900 mt-0.5 truncate">1 Live · <?php echo esc_html($total_drafts); ?> Drafts</div>
                    <span class="text-[10px] text-zinc-500 font-medium block truncate mt-0.5"><?php echo esc_html($total_drafts); ?> / <?php echo esc_html($draft_limit); ?> Draft Quota</span>
                </div>
                <div class="w-7 h-7 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-700 shrink-0">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="3" y="3" width="18" height="18" rx="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
                </div>
            </div>

            <!-- Stat Card 4: Published Pages & SEO -->
            <div class="bg-white border border-zinc-200/80 rounded-xl p-3 shadow-3xs flex items-center justify-between min-w-0 cursor-pointer hover:bg-zinc-50/80 transition-all" onclick="editTheme(<?php echo $live_theme ? $live_theme['id'] : 0; ?>, '<?php echo esc_js($live_theme ? $live_theme['name'] : ''); ?>', true); switchTab('pages');">
                <div class="min-w-0 pr-2">
                    <span class="text-[10px] font-bold tracking-wider text-zinc-400 uppercase block truncate">Published Pages</span>
                    <div class="text-base sm:text-lg font-bold text-zinc-900 mt-0.5 truncate"><?php echo esc_html($pub_count); ?> Pages Live</div>
                    <span class="text-[10px] text-emerald-600 font-semibold block truncate mt-0.5"><?php echo $seo_issues === 0 ? '✓ 100% SEO Ready' : ($seo_issues . ' SEO warnings'); ?></span>
                </div>
                <div class="w-7 h-7 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-700 shrink-0">
                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                </div>
            </div>
        </div>

        <!-- Sticky Sub-Navigation Tabs SOP (~36px Sleek Height - Edge-to-Edge) -->
        <div id="cora-canvas-subtabs" class="cora-sub-tabs-container cora-sticky-sub-tabs sticky z-30 flex items-center gap-1 border-b border-zinc-200/80 bg-white/95 backdrop-blur-md -mx-3 sm:-mx-4 md:-mx-5 px-3 sm:px-4 md:px-5 shrink-0 overflow-x-auto no-scrollbar" style="touch-action: pan-x; -webkit-overflow-scrolling: touch; scrollbar-width: none;">
            <button type="button" onclick="coraSwitchCanvasSubTab('tab-canvas-overview')" id="subtab-btn-tab-canvas-overview"
                    class="cora-canvas-sub-tab px-3.5 py-2.5 text-xs font-bold whitespace-nowrap transition-all border-b-2 border-zinc-950 text-zinc-950 flex items-center gap-1.5 cursor-pointer bg-transparent">
                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><rect x="3" y="3" width="18" height="18" rx="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
                <span>Theme Library</span>
            </button>
            <button type="button" onclick="coraSwitchCanvasSubTab('tab-canvas-vitals')" id="subtab-btn-tab-canvas-vitals"
                    class="cora-canvas-sub-tab px-3.5 py-2.5 text-xs font-medium whitespace-nowrap transition-all border-b-2 border-transparent text-zinc-500 hover:text-zinc-900 flex items-center gap-1.5 cursor-pointer bg-transparent">
                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                <span>Speed & Core Web Vitals</span>
            </button>
            <button type="button" onclick="coraSwitchCanvasSubTab('tab-canvas-migration')" id="subtab-btn-tab-canvas-migration"
                    class="hidden md:flex cora-canvas-sub-tab px-3.5 py-2.5 text-xs font-medium whitespace-nowrap transition-all border-b-2 border-transparent text-zinc-500 hover:text-zinc-900 items-center gap-1.5 cursor-pointer bg-transparent">
                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                <span>Migration & Tools</span>
            </button>
        </div>

        <!-- SUB-TAB 1: OVERVIEW & ACTIVE THEME -->
        <div id="tab-canvas-overview" class="cora-canvas-tab-content space-y-4">
            <?php if ( $live_theme ) : 
                $live_theme_settings = json_decode($live_theme['settings'], true) ?: array();
                $is_lovable = (isset($live_theme_settings['source']) && $live_theme_settings['source'] === 'lovable');
            ?>
            <div class="bg-white border border-zinc-200/80 rounded-xl shadow-3xs p-4 sm:p-5" id="active-theme-card">
                <div class="flex flex-col md:flex-row items-stretch md:items-center gap-5 sm:gap-6">
                    <!-- Left: Streamlined Browser Preview Box -->
                    <div class="relative shrink-0 flex items-center justify-center md:justify-start w-full md:w-80 max-w-full md:max-w-[340px]" style="flex: 0 0 auto;">
                        <div class="w-full rounded-xl border border-zinc-200/80 shadow-3xs overflow-hidden flex flex-col bg-zinc-50 select-none" style="height: 190px; width: 100%; max-width: 340px;">
                            <!-- Browser Top Bar -->
                            <div class="flex items-center gap-1.5 px-3 py-1.5 border-b border-zinc-200/60 shrink-0 bg-white">
                                <span class="w-1.5 h-1.5 rounded-full bg-zinc-300"></span>
                                <span class="w-1.5 h-1.5 rounded-full bg-zinc-300"></span>
                                <span class="w-1.5 h-1.5 rounded-full bg-zinc-300"></span>
                                <div class="flex-1 mx-2 bg-zinc-100/90 rounded px-2 py-0.5 text-[8px] font-mono text-zinc-500 text-center truncate">
                                    <?php echo esc_html( $canvas_display_url ); ?>
                                </div>
                                <a href="<?php echo esc_url( $canvas_preview_url ); ?>" target="_blank" class="text-zinc-400 hover:text-zinc-800 transition-colors" title="Open Preview">
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                                </a>
                            </div>
                            <!-- Live Preview Frame -->
                            <div class="flex-1 relative overflow-hidden bg-white">
                                <iframe 
                                    src="<?php echo esc_url( $canvas_preview_url ); ?>" 
                                    loading="lazy"
                                    sandbox="allow-scripts allow-same-origin"
                                    class="absolute border-none pointer-events-none" 
                                    style="top:0;left:0;width:1280px;height:760px;transform:scale(0.25);transform-origin:0 0;background:#ffffff;"
                                    tabindex="-1"
                                    aria-hidden="true">
                                </iframe>
                            </div>
                        </div>
                    </div>

                    <!-- Vertical Divider (Desktop/Tablet) -->
                    <div class="hidden md:block w-px bg-zinc-100 self-stretch my-1 shrink-0"></div>

                    <!-- Right: Theme Info & Action Group -->
                    <div class="flex-1 flex flex-col justify-between min-w-0 py-0.5 space-y-3.5">
                        <div class="space-y-2">
                            <!-- Status Badges Row -->
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/60 text-[9.5px] font-bold text-emerald-700 uppercase tracking-wider">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                    Active Theme
                                </span>
                                <?php if ( $is_lovable ) : ?>
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-zinc-100 text-[9.5px] font-bold text-zinc-800">
                                    Lovable Full-Stack
                                </span>
                                <?php else : ?>
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-zinc-100 text-[9.5px] font-bold text-zinc-700">
                                    Elementor Kit
                                </span>
                                <?php endif; ?>
                                <span class="text-[10px] text-zinc-400">· <?php echo esc_html($pub_count); ?> Pages Published</span>
                            </div>

                            <!-- Title -->
                            <h2 class="text-lg sm:text-xl font-bold text-zinc-900 leading-tight truncate"><?php echo esc_html( $live_theme['name'] ); ?></h2>

                            <!-- Feature Tags Row -->
                            <div class="flex flex-wrap gap-1.5 pt-0.5">
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-zinc-100/80 text-[10px] font-medium text-zinc-600">
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                    Optimized Core
                                </span>
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-zinc-100/80 text-[10px] font-medium text-zinc-600">
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                                    SEO Ready
                                </span>
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-zinc-100/80 text-[10px] font-medium text-zinc-600">
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect></svg>
                                    Responsive
                                </span>
                                <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-zinc-100/80 text-[10px] font-medium text-zinc-600">
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                    Fast INP/LCP
                                </span>
                            </div>

                            <!-- Version Row -->
                            <div class="inline-flex items-center gap-2 pt-0.5">
                                <button onclick="toggleThemeVersionDrawer(event)" class="inline-flex items-center gap-1 text-[10px] text-zinc-700 hover:text-zinc-950 font-semibold cursor-pointer border-none bg-transparent p-0">
                                    <span class="w-1.5 h-1.5 rounded-full bg-zinc-900 shrink-0"></span>
                                    Version <?php echo esc_html( $live_theme['version'] ); ?>
                                    <svg id="version-chevron-icon" viewBox="0 0 24 24" width="9" height="9" stroke="currentColor" stroke-width="2.5" fill="none" class="transition-transform duration-200 text-zinc-400"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                </button>
                                <span class="text-[10px] text-zinc-400">· Active Release</span>
                            </div>
                        </div>

                        <!-- Action Buttons Group (Primary + Secondary) -->
                        <div class="flex items-center gap-2 pt-3 border-t border-zinc-100 flex-wrap">
                            <!-- Primary Customize CTA -->
                            <button type="button" onclick="editTheme(<?php echo $live_theme['id']; ?>, '<?php echo esc_js($live_theme['name']); ?>', true)"
                                    class="h-8 px-4 bg-zinc-950 hover:bg-zinc-900 text-white rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 border-none shadow-xs shrink-0 select-none">
                                <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.2" fill="none"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                                <span>Customize Theme</span>
                            </button>

                            <!-- Secondary Settings -->
                            <button type="button" onclick="editTheme(<?php echo $live_theme['id']; ?>, '<?php echo esc_js($live_theme['name']); ?>', true); switchTab('settings');"
                                    class="h-8 px-3.5 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs shrink-0">
                                <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                                <span>Settings</span>
                            </button>

                            <!-- Secondary Preview Link -->
                            <a href="<?php echo esc_url( $canvas_preview_url ); ?>" target="_blank"
                               class="h-8 px-3.5 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs no-underline shrink-0">
                                <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                <span>Live Site</span>
                            </a>

                            <!-- Secondary Duplicate -->
                            <button type="button" onclick="triggerDuplicateTheme(<?php echo $live_theme['id']; ?>)"
                                    class="h-8 px-3.5 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs shrink-0">
                                <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                                <span>Duplicate</span>
                            </button>

                            <!-- Actions Dropdown Trigger -->
                            <div class="relative inline-block sm:ml-auto">
                                <button type="button" onclick="toggleActiveThemeDropdown(event)"
                                        class="h-8 px-3 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs select-none">
                                    <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="1.2"></circle><circle cx="19" cy="12" r="1.2"></circle><circle cx="5" cy="12" r="1.2"></circle></svg>
                                    <span>Actions</span>
                                    <svg viewBox="0 0 24 24" width="9" height="9" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                </button>
                                <div id="active-theme-dropdown" class="hidden absolute right-0 top-full mt-1.5 w-56 bg-white border border-zinc-200 rounded-xl shadow-xl py-1 z-50 text-left font-sans select-none">
                                    <a href="<?php echo esc_url( $canvas_preview_url ); ?>" target="_blank" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold transition-colors decoration-none">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                        <span>View Live Site</span>
                                    </a>
                                    <button onclick="triggerRenameTheme(<?php echo $live_theme['id']; ?>, '<?php echo esc_js($live_theme['name']); ?>')" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                                        <span>Rename Theme</span>
                                    </button>
                                    <div class="border-t border-zinc-100 my-1"></div>
                                    <button onclick="editTheme(<?php echo $live_theme['id']; ?>, '<?php echo esc_js($live_theme['name']); ?>', true); switchTab('code');" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                                        <span>Edit Custom Code (CSS/JS)</span>
                                    </button>
                                    <button onclick="editTheme(<?php echo $live_theme['id']; ?>, '<?php echo esc_js($live_theme['name']); ?>', true); switchTab('settings');" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                                        <span>Edit Default Theme Content</span>
                                    </button>
                                    <button onclick="triggerDownloadTheme(<?php echo $live_theme['id']; ?>)" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                        <span>Download Theme ZIP File</span>
                                    </button>
                                    <div class="border-t border-zinc-100 my-1"></div>
                                    <button onclick="openElementorMigrationDrawer()" class="w-full px-3 py-2 text-xs text-zinc-950 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-bold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none" class="text-zinc-900 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                        <span>Migrate Elementor Pages</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <!-- Draft Themes Library Card -->
            <div class="bg-white border border-zinc-200/80 rounded-xl shadow-3xs" id="draft-themes-library-card">
                <div class="px-5 py-3.5 border-b border-zinc-100 flex items-center justify-between bg-white shrink-0 rounded-t-xl">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center shrink-0 text-zinc-700">
                            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <h3 class="text-xs font-bold text-zinc-900 leading-tight">Draft Themes</h3>
                                <span class="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-600">
                                    <?php echo esc_html( $total_drafts ); ?> / <?php echo esc_html( $draft_limit ); ?> Drafts
                                </span>
                            </div>
                            <p class="text-[10px] text-zinc-400 font-medium mt-0.5">Private draft themes in development before publication.</p>
                        </div>
                    </div>
                    <div class="relative inline-block text-left">
                        <button onclick="toggleImportDropdown(event)" class="h-8 px-3 border border-zinc-200/80 hover:bg-zinc-50 rounded-lg text-xs font-semibold text-zinc-800 bg-white cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs">
                            <span>Import Theme</span>
                            <svg viewBox="0 0 24 24" width="9" height="9" stroke="currentColor" stroke-width="2.5" fill="none" class="text-zinc-400"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <div id="import-theme-dropdown" class="hidden absolute right-0 mt-1.5 w-52 bg-white border border-zinc-200 rounded-xl shadow-xl py-1 z-35 text-left text-[11px] font-semibold">
                            <button onclick="openElementorMigrationDrawer()" class="w-full px-3.5 py-2 text-left text-zinc-950 hover:bg-zinc-50 flex items-center gap-2 cursor-pointer border-none bg-transparent transition-colors font-bold">
                                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none" class="text-zinc-950 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                <span>Migrate Elementor Site</span>
                            </button>
                            <div class="border-t border-zinc-100 my-1"></div>
                            <button onclick="openImportKitDrawer()" class="w-full px-3.5 py-2 text-left text-zinc-800 hover:bg-zinc-50 flex items-center gap-2 cursor-pointer border-none bg-transparent transition-colors">
                                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                                <span>Upload ZIP File</span>
                            </button>
                            <button onclick="openGithubConnectDrawer()" class="w-full px-3.5 py-2 text-left text-zinc-800 hover:bg-zinc-50 flex items-center gap-2 cursor-pointer border-none bg-transparent transition-colors">
                                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
                                <span>Connect from GitHub</span>
                            </button>
                            <div class="border-t border-zinc-100 my-1"></div>
                            <button onclick="openCoraHubDrawer()" class="w-full px-3.5 py-2 text-left text-zinc-800 hover:bg-zinc-50 flex items-center gap-2 cursor-pointer border-none bg-transparent transition-colors">
                                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                                <span>Browse Free Themes</span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="divide-y divide-zinc-100 rounded-b-xl">
                    <?php 
                    $draft_index = 0;
                    foreach ( $draft_themes as $th ) {
                        $draft_index++;
                        $is_collapsed = $draft_index > 4;
                        
                        $th_pages = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}cora_canvas_pages WHERE theme_id = %d", $th['id'] ) );
                        $has_been_edited = ( !empty( $th['updated_at'] ) && $th['updated_at'] !== '0000-00-00 00:00:00' && $th['updated_at'] !== $th['created_at'] );
                        $ts = $has_been_edited ? strtotime( $th['updated_at'] ) : ( !empty( $th['created_at'] ) ? strtotime( $th['created_at'] ) : 0 );
                        $prefix = $has_been_edited ? 'Last edited ' : 'Imported ';

                        if ( $ts > 0 ) {
                            $diff = time() - $ts;
                            if ( $diff < 60 )             $modified_time = $has_been_edited ? 'Last edited just now' : 'Imported just now';
                            elseif ( $diff < 3600 )       $modified_time = $prefix . max(1, round( $diff / 60 )) . 'm ago';
                            elseif ( $diff < 86400 )      $modified_time = $prefix . round( $diff / 3600 ) . 'h ago';
                            elseif ( $diff < 172800 )     $modified_time = $prefix . 'yesterday';
                            else                          $modified_time = $prefix . date( 'M j', $ts );
                        } else {
                            $modified_time = 'Not yet saved';
                        }
                    ?>
                    <div data-draft-theme-id="<?php echo $th['id']; ?>" class="p-3.5 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 sm:gap-4 hover:bg-zinc-50/50 transition-colors <?php echo $is_collapsed ? 'hidden draft-theme-collapsed' : ''; ?>">
                        <div class="flex items-center gap-3.5 min-w-0">
                            <!-- Live Thumbnail Preview -->
                            <?php $preview_url = home_url('/site/?cv_preview_theme=' . $th['id']); ?>
                            <div style="width:72px;height:46px;flex-shrink:0;overflow:hidden;position:relative;" class="rounded-lg border border-zinc-200/80 bg-zinc-100 select-none">
                                <iframe src="<?php echo esc_url($preview_url); ?>" loading="lazy" sandbox="allow-scripts allow-same-origin" style="width:720px;height:460px;border:none;transform:scale(0.1);transform-origin:0 0;pointer-events:none;position:absolute;top:0;left:0;" tabindex="-1" aria-hidden="true"></iframe>
                            </div>
                            
                            <div class="min-w-0">
                                <div class="flex items-center gap-1.5 flex-wrap">
                                    <h4 class="text-xs font-bold text-zinc-900 leading-none truncate"><?php echo esc_html($th['name']); ?></h4>
                                    <?php
                                    $th_settings = json_decode( $th['settings'], true ) ?: array();
                                    $th_source = isset( $th_settings['source'] ) ? $th_settings['source'] : 'elementor';
                                    if ( strtolower($th_source) === 'lovable' ) :
                                    ?>
                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[8.5px] font-bold bg-zinc-100 text-zinc-800">Lovable</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[8.5px] font-bold bg-zinc-100 text-zinc-700">Elementor</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-[10px] text-zinc-400 mt-1"><?php echo esc_html($modified_time); ?> · <?php echo intval($th_pages); ?> Pages</div>
                            </div>
                        </div>

                        <!-- Right Side Action Row -->
                        <div class="flex items-center gap-2 shrink-0 w-full md:w-auto justify-end">
                            <button onclick="triggerActivateTheme(<?php echo $th['id']; ?>, '<?php echo esc_js($th['name']); ?>')" class="h-7 px-3 bg-zinc-950 hover:bg-zinc-900 text-white rounded-lg text-[11px] font-bold cursor-pointer transition-all border-none shadow-xs">Publish</button>
                            <button onclick="editTheme(<?php echo $th['id']; ?>, '<?php echo esc_js($th['name']); ?>', false)" class="h-7 px-3 border border-zinc-200/80 hover:bg-zinc-50 rounded-lg text-[11px] font-semibold text-zinc-700 bg-white cursor-pointer transition-all shadow-3xs">Edit Theme</button>
                            
                            <!-- Dropdown Menu -->
                            <div class="relative">
                                <button onclick="toggleDraftActionsMenu(<?php echo $th['id']; ?>, event)" class="w-7 h-7 border border-zinc-200/80 hover:bg-zinc-50 rounded-lg text-zinc-600 bg-white cursor-pointer transition-all flex items-center justify-center shadow-3xs">
                                    <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="1.2"></circle><circle cx="19" cy="12" r="1.2"></circle><circle cx="5" cy="12" r="1.2"></circle></svg>
                                </button>
                                <div id="draft-actions-menu-<?php echo $th['id']; ?>" class="hidden absolute right-0 w-52 bg-white border border-zinc-200 rounded-xl shadow-xl py-1 z-[9999] text-left font-sans select-none">
                                    <button onclick="triggerRenameTheme(<?php echo $th['id']; ?>, '<?php echo esc_js($th['name']); ?>')" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                                        <span>Rename</span>
                                    </button>
                                    <button onclick="triggerDuplicateTheme(<?php echo $th['id']; ?>)" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                                        <span>Duplicate</span>
                                    </button>
                                    <a href="<?php echo home_url('/site/?cv_preview_theme=' . $th['id']); ?>" target="_blank" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors no-underline">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                        <span>Preview Theme</span>
                                    </a>
                                    <div class="border-t border-zinc-100 my-1"></div>
                                    <button onclick="triggerDownloadTheme(<?php echo $th['id']; ?>)" class="w-full px-3 py-2 text-xs text-zinc-800 hover:bg-zinc-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                        <span>Download ZIP</span>
                                    </button>
                                    <div class="border-t border-zinc-100 my-1"></div>
                                    <button onclick="triggerDeleteTheme(<?php echo $th['id']; ?>)" class="w-full px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 cursor-pointer border-none font-semibold text-left bg-transparent transition-colors">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-rose-500 shrink-0"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                        <span>Delete Draft</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } 
                    if ( ! $has_drafts ) : ?>
                        <div class="p-8 text-center text-xs text-zinc-400">
                            No inactive draft themes registered yet. Click "Import Theme" or "Add Theme" above to create one.
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ( $total_drafts > 4 ) : ?>
                <div id="cora-show-all-drafts-wrap" class="p-3 border-t border-zinc-100 text-center bg-zinc-50/30 rounded-b-xl">
                    <button onclick="showAllDraftThemes(event)" class="text-xs font-semibold text-zinc-600 hover:text-zinc-900 border-none bg-transparent cursor-pointer flex items-center justify-center gap-1 w-full select-none">
                        <span>Show all draft themes</span>
                        <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- SUB-TAB 3: SPEED & CORE WEB VITALS -->
        <div id="tab-canvas-vitals" class="cora-canvas-tab-content hidden space-y-3.5">
            <!-- 1. Single Compact Header Bar -->
            <div class="rounded-xl shadow-3xs border border-zinc-200/80 bg-white p-3 sm:p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2.5 min-w-0">
                    <div class="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center shrink-0 text-zinc-900">
                        <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="1.8" fill="none"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                    </div>
                    <div class="min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="text-xs font-bold text-zinc-900 leading-tight">Google PageSpeed Insights</span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] font-bold bg-zinc-100 text-zinc-700">
                                <span id="pagespeed-conn-indicator" class="w-1.5 h-1.5 rounded-full shrink-0 <?php echo $ps_is_mocked ? 'bg-amber-400' : 'bg-emerald-500'; ?>"></span>
                                <span id="pagespeed-conn-text"><?php echo $ps_is_mocked ? 'Simulated (Local)' : 'Connected'; ?></span>
                            </span>
                        </div>
                        <p class="text-[10px] text-zinc-400 mt-0.5 truncate">Target: <code id="pagespeed-target-url" class="font-mono text-zinc-600"><?php echo esc_html( $ps_target ); ?></code> · Last audit: <span id="pagespeed-last-updated" class="font-medium text-zinc-600"><?php echo !empty($ps_last) ? esc_html( $ps_last ) : 'Just now'; ?></span></p>
                    </div>
                </div>

                <div class="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                    <button onclick="openPageSpeedSettingsDrawer()" class="h-8 px-3 bg-white hover:bg-zinc-50 border border-zinc-200/80 text-zinc-700 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow-3xs">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                        <span>Settings</span>
                    </button>
                    <button id="btn-refresh-pagespeed" onclick="triggerPageSpeedAudit()" class="h-8 px-3.5 bg-zinc-950 hover:bg-zinc-900 text-white rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 border-none shadow-xs">
                        <svg id="pagespeed-refresh-spinner" class="animate-spin hidden" viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.2" fill="none"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
                        <span>Run Audit</span>
                    </button>
                </div>
            </div>

            <!-- 2. Integrated Performance & Diagnostic Hub -->
            <?php
            $rec_opp = $ps_opps[0] ?? array('label' => 'Reduce JavaScript execution', 'savings' => 'Potential savings: ~210ms', 'severity' => 'Medium');
            $rec_metric = 'INP';
            $rec_metric_val = $ps_inp;
            $rec_target = '150ms';
            if (stripos($rec_opp['label'], 'lcp') !== false || stripos($rec_opp['label'], 'image') !== false || stripos($rec_opp['label'], 'render') !== false) {
                $rec_metric = 'LCP';
                $rec_metric_val = $ps_lcp;
                $rec_target = '2.5s';
            }
            $rec_desc = 'Optimize JavaScript execution and reduce main-thread work to ensure sub-200ms responsiveness.';
            if ($rec_metric === 'LCP') {
                $rec_desc = 'Optimize your hero images, enable modern WebP formats, and scale CSS delivery for sub-2.5s paint times.';
            }
            ?>
            <div class="bg-white border border-zinc-200/80 rounded-xl p-4 sm:p-5 shadow-3xs space-y-4" id="performance-insights-card">
                <!-- Sleek Recommended Action Banner -->
                <div class="bg-zinc-50/80 dark:bg-zinc-800/40 border border-zinc-200/70 dark:border-zinc-800 rounded-xl p-3.5 sm:p-4 flex flex-col md:flex-row md:items-center justify-between gap-3.5" id="recommended-banner">
                    <div class="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                        <div class="w-8 h-8 rounded-lg bg-zinc-950 dark:bg-white flex items-center justify-center shrink-0 text-white dark:text-zinc-900 shadow-3xs mt-0.5 sm:mt-0">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
                        </div>
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-wider">Top Recommendation</span>
                                <span class="text-zinc-300 dark:text-zinc-700 text-xs">·</span>
                                <span id="pagespeed-rec-title" class="text-xs sm:text-sm font-bold text-zinc-900 dark:text-zinc-100"><?php echo esc_html($rec_opp['label']); ?></span>
                            </div>
                            <div class="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1 text-[11px] text-zinc-500 dark:text-zinc-400">
                                <span id="pagespeed-rec-desc"><?php echo esc_html($rec_desc); ?></span>
                                <span class="inline-flex items-center gap-1 font-mono font-medium text-zinc-700 dark:text-zinc-300 bg-zinc-100/90 dark:bg-zinc-800 px-1.5 py-0.5 rounded text-[10px]">
                                    <span id="pagespeed-rec-metric-lbl"><?php echo esc_html($rec_metric); ?></span> 
                                    <span id="pagespeed-rec-metric-from"><?php echo esc_html($rec_metric_val); ?></span>
                                    <span class="text-zinc-400">→</span>
                                    <span id="pagespeed-rec-metric-to" class="text-emerald-600 dark:text-emerald-400 font-bold"><?php echo esc_html($rec_target); ?></span>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-end shrink-0 pt-1 md:pt-0 border-t md:border-t-0 border-zinc-200/50 dark:border-zinc-800">
                        <button onclick="if (typeof openPageSpeedSettingsDrawer === 'function') { openPageSpeedSettingsDrawer(); } window.coraShowToast('Opening optimization guide...', 'success');"
                                class="w-full md:w-auto h-8 px-4 bg-zinc-950 hover:bg-zinc-850 active:scale-[0.98] text-white dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-100 rounded-lg text-xs font-semibold cursor-pointer transition-all border-none shadow-3xs flex items-center justify-center gap-1.5 shrink-0">
                            <span>Optimize Now</span>
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                        </button>
                    </div>
                </div>

                <!-- 2-Column Responsive Diagnostic Grid (Metrics + Opportunities) -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
                    <!-- Left: High-Density CWV Metric Breakdown (5 cols on desktop) -->
                    <div class="lg:col-span-5 p-4 rounded-xl border border-zinc-200/60 bg-zinc-50/50 flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <h4 class="text-xs font-bold text-zinc-900">Core Web Vitals Breakdown</h4>
                                <span class="text-[10px] text-zinc-400 font-mono">Chrome UX</span>
                            </div>
                            
                            <div class="grid grid-cols-3 gap-2 py-3 px-2.5 bg-white rounded-lg border border-zinc-200/80 mb-3 text-center shadow-3xs">
                                <div>
                                    <span class="text-[9px] text-zinc-400 font-bold uppercase tracking-wider block">LCP</span>
                                    <div class="text-sm sm:text-base font-bold text-zinc-900 mt-0.5" id="pagespeed-val-lcp-detail"><?php echo esc_html($ps_lcp); ?></div>
                                    <span class="text-[8.5px] text-zinc-400 font-medium block mt-0.5">&lt; 2.5s Good</span>
                                </div>
                                <div class="border-l border-zinc-100">
                                    <span class="text-[9px] text-zinc-400 font-bold uppercase tracking-wider block">INP</span>
                                    <div class="text-sm sm:text-base font-bold text-zinc-900 mt-0.5" id="pagespeed-val-inp-detail"><?php echo esc_html($ps_inp); ?></div>
                                    <span class="text-[8.5px] text-zinc-400 font-medium block mt-0.5">&lt; 200ms Good</span>
                                </div>
                                <div class="border-l border-zinc-100">
                                    <span class="text-[9px] text-zinc-400 font-bold uppercase tracking-wider block">CLS</span>
                                    <div class="text-sm sm:text-base font-bold text-zinc-900 mt-0.5" id="pagespeed-val-cls-detail"><?php echo esc_html($ps_cls); ?></div>
                                    <span class="text-[8.5px] text-zinc-400 font-medium block mt-0.5">&lt; 0.10 Good</span>
                                </div>
                            </div>
                        </div>

                        <div class="pt-2 border-t border-zinc-100 flex items-center justify-between text-[10px] text-zinc-500">
                            <span>Performance Target: <b class="text-zinc-800">&gt; 90 Score</b></span>
                            <span class="text-emerald-600 font-bold">Fast Experience</span>
                        </div>
                    </div>

                    <!-- Right: Audit Opportunities List (7 cols on desktop) -->
                    <div class="lg:col-span-7 p-4 rounded-xl border border-zinc-200/60 bg-zinc-50/50 flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <h4 class="text-xs font-bold text-zinc-900">Optimization Opportunities</h4>
                                <span class="text-[10px] text-zinc-400 font-mono"><?php echo count($ps_opps); ?> Identified</span>
                            </div>

                            <div id="pagespeed-opportunities-list" class="space-y-2">
                                <?php foreach ($ps_opps as $opp) : 
                                    $opp_severity = $opp['severity'] ?? 'Medium';
                                    $opp_badge_class = 'bg-zinc-100 text-zinc-700';
                                    if ($opp_severity === 'High') {
                                        $opp_badge_class = 'bg-rose-50 text-rose-700 border border-rose-200/50';
                                    } elseif ($opp_severity === 'Medium') {
                                        $opp_badge_class = 'bg-amber-50 text-amber-700 border border-amber-200/50';
                                    }
                                ?>
                                <div class="flex items-center justify-between p-2.5 bg-white rounded-lg border border-zinc-200/60 hover:bg-zinc-50 cursor-pointer transition-colors shadow-3xs" onclick="openPageSpeedSettingsDrawer()">
                                    <div class="flex items-center gap-2.5 min-w-0">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-500 shrink-0"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                                        <div class="min-w-0">
                                            <div class="text-[11px] font-bold text-zinc-800 truncate"><?php echo esc_html($opp['label'] ?? ''); ?></div>
                                            <div class="text-[9.5px] text-zinc-400 mt-0.5"><?php echo esc_html($opp['savings'] ?? ''); ?></div>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-1.5 shrink-0 ml-2">
                                        <span class="px-2 py-0.5 text-[8.5px] font-bold rounded-full <?php echo esc_attr($opp_badge_class); ?>"><?php echo esc_html($opp_severity); ?></span>
                                        <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="text-zinc-400"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="pt-3 border-t border-zinc-100 flex items-center justify-between mt-3">
                            <button onclick="openPageSpeedSettingsDrawer()" class="text-[10px] font-bold text-zinc-500 hover:text-zinc-900 cursor-pointer border-none bg-transparent p-0 transition-colors">
                                Configure Core Web Vitals Settings →
                            </button>
                            <span class="text-[9.5px] text-zinc-400 font-mono">Simulated Audit</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- SUB-TAB 4: MIGRATION & TOOLS -->
        <div id="tab-canvas-migration" class="cora-canvas-tab-content hidden space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Migration Card 1: Elementor Importer & Migrator -->
                <div class="bg-white border border-zinc-200/80 rounded-xl p-5 shadow-3xs flex flex-col justify-between">
                    <div class="space-y-3">
                        <div class="w-9 h-9 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-900">
                            <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        </div>
                        <div>
                            <h3 class="text-sm font-bold text-zinc-900">Elementor 1-Click Migration</h3>
                            <p class="text-xs text-zinc-500 mt-1 leading-relaxed">Import templates, JSON layouts, or migrate entire multi-page WordPress themes directly into Cora Canvas with automated widget conversion.</p>
                        </div>
                    </div>
                    <div class="mt-5 pt-4 border-t border-zinc-100 flex items-center justify-between">
                        <span class="text-[10px] font-mono text-zinc-400">Supported: .json, .zip</span>
                        <button onclick="openElementorMigrationDrawer()" class="px-3.5 py-1.5 bg-zinc-950 hover:bg-zinc-900 text-white rounded-lg text-xs font-bold shadow-3xs cursor-pointer transition-all active:scale-95">
                            Launch Migrator
                        </button>
                    </div>
                </div>

                <!-- Migration Card 2: Lovable AI Studio & GitHub Sync -->
                <div class="bg-white border border-zinc-200/80 rounded-xl p-5 shadow-3xs flex flex-col justify-between">
                    <div class="space-y-3">
                        <div class="w-9 h-9 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-900">
                            <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="1.8" fill="none"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                        </div>
                        <div>
                            <h3 class="text-sm font-bold text-zinc-900">Lovable AI Full-Stack Studio</h3>
                            <p class="text-xs text-zinc-500 mt-1 leading-relaxed">Design custom frontend applications, generate modern UI layouts using curated prompt recipes, and sync code with GitHub.</p>
                        </div>
                    </div>
                    <div class="mt-5 pt-4 border-t border-zinc-100 flex items-center justify-between">
                        <span class="text-[10px] font-mono text-zinc-400">Prompt Library & Repo Sync</span>
                        <button onclick="openLovableStudio()" class="px-3.5 py-1.5 bg-zinc-950 hover:bg-zinc-900 text-white rounded-lg text-xs font-bold shadow-3xs cursor-pointer transition-all active:scale-95">
                            Open AI Studio
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- LEVEL 2 — THEME DASHBOARD -->
    <div id="canvas-level-2" class="space-y-4 hidden">
        <!-- Breadcrumb & Header Controls -->
        <div class="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div class="flex items-center gap-3">
                <button onclick="backToCanvasHub()" class="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-500 hover:text-zinc-900 cursor-pointer transition-colors">
                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2.2" fill="none"><polyline points="15 18 9 12 15 6"></polyline></svg>
                </button>
                <div class="flex items-center gap-2">
                    <span class="text-xs text-zinc-400">Canvas</span>
                    <span class="text-xs text-zinc-300">/</span>
                    <span id="dashboard-theme-name" class="text-sm font-bold text-zinc-900">Theme Name</span>
                    <span id="dashboard-theme-badge" class="px-1.5 py-0.5 text-[8px] font-bold uppercase rounded bg-green-50 text-green-700 border border-green-200 ml-1">Live</span>
                </div>
            </div>
            <div>
                <?php if ( ! $is_read_only ) : ?>
                <button id="activate-theme-header-btn" onclick="triggerActivateThemeFromHeader()" class="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg text-xs font-semibold shadow-sm cursor-pointer transition-all">Activate Theme</button>
                <?php endif; ?>
                <a id="preview-site-header-btn" href="<?php echo home_url( '/site/' ); ?>" target="_blank" class="px-3 py-1.5 border border-zinc-200 rounded-lg text-xs font-semibold text-zinc-700 bg-white hover:bg-zinc-50 shadow-sm cursor-pointer transition-all hidden">Preview Site</a>
            </div>
        </div>

        <!-- Dashboard Workspace Tabs -->
        <div class="border-b border-zinc-200 flex items-center justify-between pb-1">
            <div class="flex gap-6 text-xs font-semibold">
                <button onclick="switchTab('pages')" id="tab-btn-pages" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors active">Pages</button>
                <button onclick="switchTab('nextjs-sdk')" id="tab-btn-nextjs-sdk" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors flex items-center gap-1.5" title="Next.js Headless SDK & Ops" style="display: none;">
                    <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M12 2L2 19.7778H22L12 2Z"/></svg>
                    <span>Next.js SDK</span>
                </button>
                <button onclick="switchTab('menus')" id="tab-btn-menus" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors">Menus</button>
                <button onclick="switchTab('settings')" id="tab-btn-settings" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors">Theme Settings</button>
                <button onclick="switchTab('code')" id="tab-btn-code" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors">Custom Code</button>
                <button onclick="switchTab('theme-builder')" id="tab-btn-theme-builder" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors">Theme Builder</button>
                <button onclick="switchTab('ai')" id="tab-btn-ai" class="canvas-tab-btn pb-3 border-b-2 border-transparent text-zinc-400 hover:text-zinc-900 cursor-pointer transition-colors flex items-center gap-1.5" title="Lovable Studio" style="display: none;">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none" class="w-3.5 h-3.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 2l2.4 7.2L22 12l-7.6 2.8L12 22l-2.4-7.2L2 12l7.6-2.8z"/></svg>
                    <span>Lovable Studio</span>
                </button>
            </div>
            
            <!-- Dynamic active tab actions aligned directly on the right side of the workspace tabs bar -->
            <div class="flex items-center gap-2">
                <!-- Action button for Pages tab -->
                <?php if ( ! $is_read_only ) : ?>
                <div id="tab-action-pages" class="tab-action-btn flex items-center gap-2">
                    <button onclick="triggerNextJSISRRebuild()" id="tab-action-revalidate-nextjs" class="hidden px-3 py-1.5 border border-zinc-900 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-[11px] font-bold shadow-2xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                        <span>Rebuild ISR</span>
                    </button>
                    <button onclick="openElementorMigrationDrawer()" id="tab-action-migrate-elementor" class="px-3 py-1.5 border border-zinc-300 hover:border-zinc-950 bg-white hover:bg-zinc-50 text-zinc-900 rounded-lg text-[11px] font-bold shadow-2xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5">
                        <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none" class="shrink-0 text-zinc-700"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        <span>Migrate Elementor</span>
                    </button>
                    <button onclick="openNewPageDrawer()" id="tab-btn-add-page" class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5 border-none">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none" class="shrink-0"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        <span>Add page</span>
                    </button>
                </div>
                <?php endif; ?>

                <!-- Action buttons for Menus tab -->
                <?php if ( ! $is_read_only ) : ?>
                <div id="tab-action-menus" class="tab-action-btn hidden flex items-center gap-2">
                    <button onclick="window.coraShowToast('URL Redirects panel loading...', 'success')" id="menu-btn-redirects" class="px-3 py-1.5 border border-zinc-200 text-zinc-700 bg-white hover:bg-zinc-50 rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95">URL redirects</button>
                    <button onclick="triggerCreateNewMenu()" id="menu-btn-create" class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5 border-none">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none" class="shrink-0"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        <span>Create menu</span>
                    </button>
                    <button onclick="duplicateActiveMenu()" id="menu-btn-duplicate" class="hidden px-3 py-1.5 border border-zinc-200 text-zinc-700 bg-white hover:bg-zinc-50 rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95">Duplicate</button>
                    <button onclick="deleteActiveMenu()" id="menu-btn-delete" class="hidden px-3 py-1.5 border border-red-200 text-red-600 bg-white hover:bg-red-50 rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95">Delete menu</button>
                </div>
                <?php endif; ?>

                <!-- Action button for Theme Settings tab -->
                <?php if ( ! $is_read_only ) : ?>
                <button onclick="saveThemeSettings()" id="tab-action-settings" class="tab-action-btn hidden px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[11px] font-bold shadow-xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5 border-none">
                    <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.2" fill="none" class="shrink-0"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                    <span>Save Settings</span>
                </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB CONTENT: PAGES -->
        <div id="tab-content-pages" class="space-y-0">

            <?php
            // ── Stat card counts ──
            global $wpdb;
            $stat_theme_id = $current_theme_id ?? 0;
            $stat_pages    = $wpdb->get_results( $wpdb->prepare( "SELECT status FROM {$wpdb->prefix}cora_canvas_pages WHERE theme_id = %d", $stat_theme_id ), ARRAY_A ) ?: [];
            $stat_total    = count( $stat_pages );
            $stat_active   = count( array_filter( $stat_pages, fn($p) => $p['status'] === 'published' ) );
            $stat_draft    = count( array_filter( $stat_pages, fn($p) => $p['status'] === 'draft' ) );
            $stat_other    = $stat_total - $stat_active - $stat_draft;
            ?>

            <!-- ── Stats Cards ── -->
            <div class="grid grid-cols-2 md:grid-cols-4 divide-x divide-zinc-100 border border-zinc-200 rounded-xl bg-white mb-4 shadow-sm overflow-hidden">
                <div class="px-4 py-2.5">
                    <div class="flex items-center gap-1.5 mb-1">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="#71717a" stroke-width="2" fill="none"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                        <span class="text-[10px] text-zinc-500 font-medium">Total pages</span>
                    </div>
                    <div class="text-[18px] font-bold text-zinc-900 leading-none" id="stat-total-pages"><?php echo $stat_total; ?></div>
                </div>
                <div class="px-4 py-2.5">
                    <div class="flex items-center gap-1.5 mb-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-green-500 flex-shrink-0"></span>
                        <span class="text-[10px] text-zinc-500 font-medium">Active pages</span>
                    </div>
                    <div class="text-[18px] font-bold text-zinc-900 leading-none" id="stat-active-pages"><?php echo $stat_active; ?></div>
                </div>
                <div class="px-4 py-2.5">
                    <div class="flex items-center gap-1.5 mb-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0"></span>
                        <span class="text-[10px] text-zinc-500 font-medium">Draft pages</span>
                    </div>
                    <div class="text-[18px] font-bold text-zinc-900 leading-none" id="stat-draft-pages"><?php echo $stat_draft; ?></div>
                </div>
                <div class="px-4 py-2.5">
                    <div class="flex items-center gap-1.5 mb-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-zinc-400 flex-shrink-0"></span>
                        <span class="text-[10px] text-zinc-500 font-medium">Other pages <span class="inline-flex items-center justify-center w-3 h-3 rounded-full border border-zinc-300 text-[7px] text-zinc-400 cursor-pointer" title="Scheduled or archived pages">i</span></span>
                    </div>
                    <div class="text-[18px] font-bold text-zinc-900 leading-none" id="stat-other-pages"><?php echo $stat_other; ?></div>
                </div>
            </div>

            <!-- ── Table Card ── -->
            <div class="bg-white border border-zinc-200 rounded-xl overflow-visible shadow-sm">

                <!-- Tab strip + icon toolbar -->
                <div class="flex items-center justify-between px-4 py-2.5 border-b border-zinc-100">
                    <!-- Left: Tab pills / Views Strip -->
                    <div class="flex items-center gap-1" id="pages-views-tab-strip">
                        <button id="pages-view-all" onclick="setViewFilter('all')" data-view="all" class="pages-view-btn px-3 py-1.5 rounded-md text-[11px] font-semibold bg-zinc-900 text-white cursor-pointer transition-all">All</button>
                        
                        <!-- Plus Button for custom view configuration -->
                        <div class="relative">
                            <button id="add-view-btn" onclick="toggleAddViewDropdown()" class="w-7 h-7 flex items-center justify-center rounded-md text-[15px] font-semibold text-zinc-400 hover:bg-zinc-50 hover:text-zinc-700 cursor-pointer transition-all border border-zinc-200 leading-none" title="Add view">+</button>
                            <div id="add-view-dropdown" class="hidden absolute left-0 top-full mt-1.5 z-30 bg-white border border-zinc-200 rounded-xl shadow-lg p-2.5 w-52 space-y-2">
                                <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-wider">Create Custom View</p>
                                <input type="text" id="new-view-name" placeholder="e.g. Listings, Blog, Agent..." onkeyup="if(event.key==='Enter') createNewCustomView()"
                                    class="w-full px-2.5 py-1.5 border border-zinc-200 focus:border-zinc-400 focus:outline-none rounded-lg text-[11px] bg-white text-zinc-800">
                                <button onclick="createNewCustomView()" 
                                    class="w-full py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all text-center">
                                    Create View
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- Right: Search input + dropdown chips -->
                    <div class="flex items-center gap-1.5">
                        <!-- Inline Search Input -->
                        <div class="relative flex items-center bg-zinc-50 border border-zinc-200 rounded-lg px-2.5 py-1 w-48 focus-within:border-zinc-400 focus-within:bg-white transition-all mr-1.5">
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="#a1a1aa" stroke-width="2.5" fill="none" class="mr-1.5 shrink-0"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                            <input type="text" id="page-search-input" onkeyup="filterPages()" placeholder="Search pages…" 
                                class="bg-transparent border-none text-[11px] placeholder-zinc-400 focus:outline-none focus:ring-0 p-0 w-full text-zinc-800">
                        </div>

                        <!-- Filter dropdown chip -->
                        <div class="relative">
                            <button id="filter-chip-btn" onclick="toggleDropdownChip('filter')" class="inline-flex items-center gap-1 px-2.5 py-1.5 bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 hover:border-zinc-300 text-zinc-600 rounded-lg text-[11px] font-semibold transition-all cursor-pointer">
                                <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
                                <span>Status: All</span>
                                <svg viewBox="0 0 24 24" width="8" height="8" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-50"><polyline points="6 9 12 15 18 9"/></svg>
                            </button>
                            <div id="chip-dropdown-filter" class="hidden absolute right-0 top-full mt-1 z-30 bg-white border border-zinc-200 rounded-xl shadow-lg p-1.5 w-40 space-y-0.5">
                                <button onclick="selectChipFilter('all', 'Status: All')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">All statuses</button>
                                <button onclick="selectChipFilter('published', 'Status: Active')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Active (Visible)</button>
                                <button onclick="selectChipFilter('draft', 'Status: Draft')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Draft</button>
                                <button onclick="selectChipFilter('scheduled', 'Status: Scheduled')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Scheduled</button>
                                <button onclick="selectChipFilter('private', 'Status: Private')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Private / Unlisted</button>
                            </div>
                        </div>

                        <!-- Sort dropdown chip -->
                        <div class="relative">
                            <button id="sort-chip-btn" onclick="toggleDropdownChip('sort')" class="inline-flex items-center gap-1 px-2.5 py-1.5 bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 hover:border-zinc-300 text-zinc-600 rounded-lg text-[11px] font-semibold transition-all cursor-pointer">
                                <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 6h18M7 12h10M11 18h2"/></svg>
                                <span>Sort: Updated</span>
                                <svg viewBox="0 0 24 24" width="8" height="8" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-50"><polyline points="6 9 12 15 18 9"/></svg>
                            </button>
                            <div id="chip-dropdown-sort" class="hidden absolute right-0 top-full mt-1 z-30 bg-white border border-zinc-200 rounded-xl shadow-lg p-1.5 w-36 space-y-0.5">
                                <button onclick="selectChipSort('modified', 'Sort: Updated')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Last updated</button>
                                <button onclick="selectChipSort('alpha', 'Sort: A–Z')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Alphabetical</button>
                                <button onclick="selectChipSort('created', 'Sort: Created')" class="w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors">Date created</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Table -->
                <table class="w-full border-collapse text-left">
                    <thead>
                        <tr class="border-b border-zinc-100 text-[11px] font-semibold text-zinc-400">
                            <th class="pl-3 pr-1 py-2 w-10">
                                <input type="checkbox" id="pages-select-all-checkbox" onchange="toggleSelectAllPages(this)" class="rounded cursor-pointer accent-zinc-900">
                            </th>
                            <th class="px-3 py-2">
                                <button onclick="setPageSort(pageSortState==='alpha'?'alpha-desc':'alpha')" class="flex items-center gap-1 text-zinc-400 hover:text-zinc-700 cursor-pointer transition-colors group font-semibold">
                                    Title
                                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-40 group-hover:opacity-100 transition-opacity"><path d="M7 15l5 5 5-5M7 9l5-5 5 5"/></svg>
                                </button>
                            </th>
                            <th class="px-3 py-2 font-semibold">Type</th>
                            <th class="px-3 py-2 font-semibold">Visibility</th>
                            <th class="px-3 py-2 font-semibold">Content</th>
                            <th class="px-3 py-2 font-semibold">Updated</th>
                            <th class="px-3 py-2 w-28 text-right font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="pages-table-body">
                        <!-- Populated by renderPagesTable() -->
                    </tbody>
                </table>

                <!-- Table footer -->
                <div class="px-4 py-3 border-t border-zinc-100 text-center text-[11px] text-zinc-400">
                    Learn more about <a href="#" class="text-blue-500 hover:underline inline-flex items-center gap-1">pages <svg viewBox="0 0 24 24" width="9" height="9" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"></line></svg></a>
                </div>
            </div>

            <!-- Hidden legacy filters (kept for JS compatibility) -->
            <select id="page-status-filter" class="hidden">
                <option value="all">All</option><option value="published">Published</option><option value="draft">Draft</option><option value="scheduled">Scheduled</option>
            </select>
            <select id="page-sort-filter" class="hidden">
                <option value="modified">Modified</option><option value="alpha">Alpha</option><option value="created">Created</option>
            </select>

            <?php
            // Ensure git sync / AI feature is activated
            if ( get_option('cora_git_sync_enabled') !== '1' ) {
                update_option('cora_git_sync_enabled', '1');
            }
            $git_enabled = get_option('cora_git_sync_enabled') === '1';
            $git_repo    = get_option('cora_git_sync_repo', '');
            $live_url    = get_option('cora_git_sync_live_url', '');
            $is_synced   = ! empty($git_repo) || ! empty($live_url);
            $compat_flags = get_option('cora_git_sync_compat_flags', []);
            ?>
            <!-- Lovable Studio Trigger Bar -->
            <div id="lovable-trigger-bar" class="flex items-center justify-between bg-white border border-zinc-200 rounded-xl px-5 py-3.5 mt-5 shadow-sm">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-zinc-950 rounded-lg flex items-center justify-center shrink-0">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="white" stroke-width="2" fill="none"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>
                    </div>
                    <div>
                        <div class="text-sm font-bold text-zinc-900">Lovable Studio</div>
                        <div class="text-[11px] text-zinc-500"><?php echo ($git_enabled && $is_synced) ? 'Connected &mdash; ' . esc_html(basename($git_repo ?: $live_url)) : 'Build Lovable-compatible pages for Cora &mdash; Prompt Library + GitHub Sync'; ?></div>
                    </div>
                </div>
                <div class="flex items-center gap-2.5">
                    <?php if ($git_enabled && $is_synced) : ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-bold rounded-lg border bg-zinc-50 text-zinc-700 border-zinc-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        <?php echo !empty($compat_flags) ? 'Bridge Active' : 'Sync Active'; ?>
                    </span>
                    <?php endif; ?>
                    <button onclick="openLovableStudio()" class="inline-flex items-center gap-1.5 px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold cursor-pointer transition-all shadow-sm">
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                        Open Lovable Studio
                    </button>
                </div>
            </div>

            <!-- Bulk Actions Bar -->
            <div id="pages-bulk-actions-bar" class="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl py-3 px-5 items-center gap-4 hidden transition-all duration-300">
                <span id="bulk-selected-count" class="text-xs font-semibold text-white">0 selected</span>
                <div class="h-4 w-[1px] bg-zinc-800"></div>
                <select id="pages-bulk-action-select" class="px-2 py-1 bg-zinc-900 border border-zinc-800 rounded-md text-[10px] text-zinc-300 font-semibold focus:outline-none cursor-pointer">
                    <option value="publish">Publish</option>
                    <option value="unpublish">Unpublish</option>
                    <option value="delete">Delete Permanently</option>
                </select>
                <button onclick="applyBulkPagesAction()" class="px-3 py-1 bg-white hover:bg-zinc-100 text-zinc-900 font-bold rounded-lg text-[10px] cursor-pointer transition-colors shadow-sm">Apply</button>
                <button onclick="deselectAllPages()" class="text-[10px] font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer">Deselect All</button>
            </div>
        </div>

        <!-- TAB CONTENT: LOVABLE AI STUDIO -->
        <div id="tab-content-ai" class="space-y-6 hidden">
            <?php include CORA_WORKSPACE_PATH . 'views/partials/lovable-studio-drawer.php'; ?>
        </div>

        <!-- TAB CONTENT: MENUS -->
        <div id="tab-content-menus" class="space-y-6 hidden">
            
            <!-- 1. MENUS LIST VIEW -->
            <div id="menus-list-view" class="space-y-4">
                <div class="bg-white border border-zinc-200 rounded-xl overflow-hidden shadow-sm">
                    <table class="w-full table-fixed border-collapse text-left">
                        <thead>
                            <tr class="border-b border-zinc-100 text-[11px] font-bold text-zinc-400 bg-zinc-50/50">
                                <th class="px-4 py-2.5 w-1/3">
                                    <button class="flex items-center gap-1 text-zinc-400 hover:text-zinc-700 cursor-pointer font-bold">
                                        Menu
                                        <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M7 15l5 5 5-5M7 9l5-5 5 5"/></svg>
                                    </button>
                                </th>
                                <th class="px-4 py-2.5 w-2/3">Menu items</th>
                            </tr>
                        </thead>
                        <tbody id="menus-table-body">
                            <!-- Populated by JS -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 2. MENU DETAIL VIEW -->
            <div id="menus-detail-view" class="space-y-4 hidden">
                <div class="flex items-center justify-between pb-1">
                    <div class="flex items-center gap-3">
                        <button onclick="exitMenuDetail()" class="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-500 hover:text-zinc-900 cursor-pointer transition-colors border-none bg-transparent">
                            <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2.2" fill="none"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                        </button>
                        <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-400"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                        <span id="menu-detail-header-title" class="text-[13px] font-bold text-zinc-950">Customer account main menu</span>
                    </div>
                </div>

                <!-- Name & Handle Card -->
                <div class="bg-white border border-zinc-200 rounded-xl p-5 shadow-sm space-y-3">
                    <div class="space-y-1.5">
                        <label class="block text-[11px] font-bold text-zinc-500 uppercase tracking-wider">Name <span class="text-zinc-400 font-normal normal-case">(max 60 chars)</span></label>
                        <input type="text" id="menu-name-input" maxlength="60" onkeyup="updateMenuNameState(this.value)" class="w-full px-3.5 py-2 border border-zinc-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-zinc-400 bg-white text-zinc-800" <?php echo $is_read_only ? 'readonly' : ''; ?>>
                        <p id="menu-handle-label" class="text-[10px] text-zinc-400 font-mono mt-1.5">Handle: customer-account-main-menu</p>
                    </div>
                </div>

                <!-- Menu Items Card -->
                <div class="bg-white border border-zinc-200 rounded-xl p-5 shadow-sm space-y-4">
                    <div class="flex items-center justify-between">
                        <h3 class="text-[11px] font-bold text-zinc-500 uppercase tracking-wider">Menu items</h3>
                        <?php if ( ! $is_read_only ) : ?>
                        <button onclick="autoGenerateMenuFromPages()" id="auto-gen-menu-btn" class="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all active:scale-95 border-none shadow-sm" title="Auto-generate menu items from published pages">
                            <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.2">
                                <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
                            </svg>
                            Auto-Generate
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Drag/list container -->
                    <div id="menu-items-list-container" class="space-y-2">
                        <!-- Populated by JS -->
                    </div>

                    <?php if ( ! $is_read_only ) : ?>
                    <!-- Add item trigger link row -->
                    <button onclick="addMenuInlineRow()" class="w-full py-2.5 border border-dashed border-zinc-200 hover:bg-zinc-50/50 hover:border-zinc-300 rounded-lg text-center text-xs font-bold text-zinc-800 flex items-center justify-center gap-1.5 cursor-pointer transition-all bg-transparent">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none" class="text-blue-500"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
                        Add menu item
                    </button>
                    <?php endif; ?>
                </div>

                <!-- ── Auto-Generate Menu Modal ─────────────────────────────── -->
                <div id="auto-gen-menu-modal" class="hidden fixed inset-0 z-[9999] flex items-center justify-center p-4" style="background:rgba(0,0,0,0.45);">
                    <div class="bg-white rounded-2xl shadow-2xl w-[460px] max-w-full flex flex-col border border-zinc-100" style="max-height:90vh;">

                        <!-- ── Fixed Header ── -->
                        <div class="flex items-start justify-between gap-3 p-5 pb-4 flex-shrink-0">
                            <div class="space-y-1">
                                <div class="flex items-center gap-2">
                                    <div class="w-7 h-7 rounded-lg bg-zinc-950 flex items-center justify-center flex-shrink-0">
                                        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="white" stroke-width="2.2">
                                            <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
                                        </svg>
                                    </div>
                                    <h2 class="text-sm font-bold text-zinc-950">Auto-Generate Menu</h2>
                                </div>
                                <p class="text-[11px] text-zinc-500 leading-relaxed">Select published pages to add as menu items. Only published pages are shown.</p>
                            </div>
                            <button onclick="closeAutoGenMenuModal()" class="p-1.5 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-zinc-700 cursor-pointer transition-colors border-none bg-transparent flex-shrink-0 mt-0.5">
                                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                        </div>

                        <!-- ── Fixed Select-All Bar ── -->
                        <div class="flex items-center justify-between border-t border-b border-zinc-100 px-5 py-2.5 flex-shrink-0">
                            <span class="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Published Pages</span>
                            <div class="flex items-center gap-2">
                                <button onclick="autoGenSelectAll(true)" class="text-[10px] font-bold text-zinc-600 hover:text-zinc-900 cursor-pointer bg-transparent border-none transition-colors">Select all</button>
                                <span class="text-zinc-300 text-[10px]">·</span>
                                <button onclick="autoGenSelectAll(false)" class="text-[10px] font-bold text-zinc-600 hover:text-zinc-900 cursor-pointer bg-transparent border-none transition-colors">Deselect all</button>
                            </div>
                        </div>

                        <!-- ── Scrollable Pages List ── -->
                        <div id="auto-gen-pages-list" class="flex-1 overflow-y-auto min-h-0 py-1.5 px-2">
                            <!-- Populated by JS -->
                        </div>

                        <!-- ── Fixed Footer: Sort + Actions ── -->
                        <div class="flex-shrink-0 border-t border-zinc-100 px-5 py-4 space-y-3">
                            <!-- Sort order -->
                            <div class="flex items-center gap-3">
                                <label class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider flex-shrink-0">Sort Order</label>
                                <select id="auto-gen-sort-order" class="flex-1 px-2.5 py-1.5 border border-zinc-200 rounded-lg text-xs font-semibold text-zinc-700 focus:outline-none focus:border-zinc-400 bg-white cursor-pointer">
                                    <option value="alpha">Alphabetical (A → Z)</option>
                                    <option value="alpha_desc">Alphabetical (Z → A)</option>
                                    <option value="homepage_first">Homepage First</option>
                                </select>
                            </div>
                            <!-- Action buttons -->
                            <div class="flex items-center justify-between">
                                <span id="auto-gen-count-label" class="text-[10px] text-zinc-400 font-mono"></span>
                                <div class="flex items-center gap-2">
                                    <button onclick="closeAutoGenMenuModal()" class="px-3.5 py-2 border border-zinc-200 text-zinc-600 hover:text-zinc-900 rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 bg-transparent">Cancel</button>
                                    <button onclick="confirmAutoGenMenu()" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 border-none shadow-sm">Add to Menu</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>



                <div class="flex items-center justify-end pt-2">
                    <button onclick="saveCurrentMenuDetails()" <?php echo $is_read_only ? 'disabled' : ''; ?> class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer transition-all active:scale-95">Save</button>
                </div>
            </div>
        </div>

        <!-- TAB CONTENT: THEME SETTINGS -->
        <div id="tab-content-settings" class="bg-white border border-zinc-200 rounded-xl shadow-sm hidden">

            <!-- ── Settings Tab Navigation Pills ───────────────────── -->
            <div class="flex items-center gap-1 border-b border-zinc-100 px-6 pt-4 pb-0" id="settings-nav-pills">
                <button onclick="switchSettingsPanel('identity')" id="spill-identity" class="settings-pill active px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-zinc-950 text-zinc-900 bg-transparent cursor-pointer transition-all">Identity</button>
                <button onclick="switchSettingsPanel('colors')" id="spill-colors" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Colors</button>
                <button onclick="switchSettingsPanel('typography')" id="spill-typography" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Typography</button>
                <button onclick="switchSettingsPanel('spacing')" id="spill-spacing" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Spacing &amp; Borders</button>
                <button onclick="switchSettingsPanel('layout')" id="spill-layout" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Layout</button>
                <button onclick="switchSettingsPanel('social')" id="spill-social" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Social &amp; SEO</button>
                <button onclick="switchSettingsPanel('routing')" id="spill-routing" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">Page Mapping</button>
                <div id="spill-elementor-wrap" class="hidden">
                    <button onclick="switchSettingsPanel('elementor')" id="spill-elementor" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">
                        <span class="inline-flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>Elementor Sync
                        </span>
                    </button>
                </div>
                <div id="spill-lovable-wrap" class="hidden">
                    <button onclick="switchSettingsPanel('lovable')" id="spill-lovable" class="settings-pill px-3 py-2 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 border-transparent text-zinc-400 hover:text-zinc-700 bg-transparent cursor-pointer transition-all">
                        <span class="inline-flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-violet-500"></span>CSS Tokens
                        </span>
                    </button>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Identity                                       -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-identity" class="settings-panel p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="space-y-4">
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Site Title</label>
                        <input type="text" id="setting-site-title" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Site Tagline</label>
                        <input type="text" id="setting-site-tagline" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Site Description (SEO)</label>
                        <textarea id="setting-site-description" rows="3" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 resize-none" placeholder="Brief site description for search engines..."></textarea>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Default Page Title Format</label>
                        <input type="text" id="setting-title-format" placeholder="e.g. %s — Site Name" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                        <p class="text-[10px] text-zinc-400">Use %s for the page name placeholder.</p>
                    </div>
                </div>
                <div class="space-y-4">
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Agency Logo URL</label>
                        <div class="flex gap-2">
                            <input type="text" id="setting-site-logo" placeholder="https://... or /wp-content/..." class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                            <button onclick="openMediaPicker('setting-site-logo')" class="px-2.5 py-2 border border-zinc-200 rounded-lg text-[10px] font-bold text-zinc-600 hover:bg-zinc-50 cursor-pointer transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Logo Dark Mode URL</label>
                        <div class="flex gap-2">
                            <input type="text" id="setting-site-logo-dark" placeholder="https://... (optional)" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                            <button onclick="openMediaPicker('setting-site-logo-dark')" class="px-2.5 py-2 border border-zinc-200 rounded-lg text-[10px] font-bold text-zinc-600 hover:bg-zinc-50 cursor-pointer transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Favicon Icon URL</label>
                        <div class="flex gap-2">
                            <input type="text" id="setting-site-favicon" placeholder="e.g. /favicon.png" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                            <button onclick="openMediaPicker('setting-site-favicon')" class="px-2.5 py-2 border border-zinc-200 rounded-lg text-[10px] font-bold text-zinc-600 hover:bg-zinc-50 cursor-pointer transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">OG / Share Image URL</label>
                        <div class="flex gap-2">
                            <input type="text" id="setting-og-image" placeholder="https://... 1200×630px recommended" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                            <button onclick="openMediaPicker('setting-og-image')" class="px-2.5 py-2 border border-zinc-200 rounded-lg text-[10px] font-bold text-zinc-600 hover:bg-zinc-50 cursor-pointer transition-all">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Colors                                         -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-colors" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Core palette -->
                    <div class="space-y-4">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Core Palette</h5>
                        <?php
                        $color_fields = [
                            ['id' => 'setting-color-primary', 'label' => 'Primary Color', 'desc' => 'Mapped to Elementor System Color 1'],
                            ['id' => 'setting-color-secondary', 'label' => 'Secondary Color', 'desc' => 'Mapped to Elementor System Color 2'],
                            ['id' => 'setting-color-accent', 'label' => 'Accent / Brand Color', 'desc' => 'Mapped to Elementor System Color 3 · --color-accent'],
                            ['id' => 'setting-color-text', 'label' => 'Default Text Color', 'desc' => 'Mapped to Elementor System Color 4 · --color-text'],
                            ['id' => 'setting-color-bg', 'label' => 'Background Color', 'desc' => '--color-background'],
                            ['id' => 'setting-color-surface', 'label' => 'Surface / Muted Color', 'desc' => 'Card backgrounds, secondary surfaces · --color-surface'],
                        ];
                        foreach ($color_fields as $cf): ?>
                        <div class="space-y-1">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase"><?php echo esc_html($cf['label']); ?></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="<?php echo esc_attr($cf['id']); ?>" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5 flex-shrink-0" oninput="document.getElementById('<?php echo esc_attr($cf['id']); ?>-text').value=this.value">
                                <input type="text" id="<?php echo esc_attr($cf['id']); ?>-text" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs uppercase font-mono focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('<?php echo esc_attr($cf['id']); ?>', this.value)">
                            </div>
                            <p class="text-[9px] text-zinc-400"><?php echo esc_html($cf['desc']); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- Semantic & state colors -->
                    <div class="space-y-4">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Semantic State Colors</h5>
                        <?php
                        $semantic_fields = [
                            ['id' => 'setting-color-success', 'label' => 'Success Color', 'desc' => '--color-success · confirmation states, sold badges'],
                            ['id' => 'setting-color-warning', 'label' => 'Warning Color', 'desc' => '--color-warning · alerts, pending status'],
                            ['id' => 'setting-color-danger', 'label' => 'Danger / Error Color', 'desc' => '--color-danger · validation errors, price drops'],
                            ['id' => 'setting-color-info', 'label' => 'Info Color', 'desc' => '--color-info · tooltips, informational callouts'],
                        ];
                        foreach ($semantic_fields as $cf): ?>
                        <div class="space-y-1">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase"><?php echo esc_html($cf['label']); ?></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="<?php echo esc_attr($cf['id']); ?>" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5 flex-shrink-0" oninput="document.getElementById('<?php echo esc_attr($cf['id']); ?>-text').value=this.value">
                                <input type="text" id="<?php echo esc_attr($cf['id']); ?>-text" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs uppercase font-mono focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('<?php echo esc_attr($cf['id']); ?>', this.value)">
                            </div>
                            <p class="text-[9px] text-zinc-400"><?php echo esc_html($cf['desc']); ?></p>
                        </div>
                        <?php endforeach; ?>

                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2 mt-6">Button Colors</h5>
                        <?php
                        $btn_fields = [
                            ['id' => 'setting-color-btn-bg', 'label' => 'Button Background', 'desc' => '--btn-bg'],
                            ['id' => 'setting-color-btn-text', 'label' => 'Button Text Color', 'desc' => '--btn-text'],
                            ['id' => 'setting-color-btn-hover', 'label' => 'Button Hover Background', 'desc' => '--btn-hover-bg'],
                        ];
                        foreach ($btn_fields as $cf): ?>
                        <div class="space-y-1">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase"><?php echo esc_html($cf['label']); ?></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="<?php echo esc_attr($cf['id']); ?>" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5 flex-shrink-0" oninput="document.getElementById('<?php echo esc_attr($cf['id']); ?>-text').value=this.value">
                                <input type="text" id="<?php echo esc_attr($cf['id']); ?>-text" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs uppercase font-mono focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('<?php echo esc_attr($cf['id']); ?>', this.value)">
                            </div>
                            <p class="text-[9px] text-zinc-400"><?php echo esc_html($cf['desc']); ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Typography                                     -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-typography" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Font Families</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Heading Font</label>
                            <select id="setting-heading-font" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <?php
                                $fonts = ['Inter','Playfair Display','Outfit','Roboto','Lora','Montserrat','Raleway','Poppins','DM Sans','DM Serif Display','Nunito','Source Serif 4','Libre Baskerville','Merriweather','Cormorant Garamond','Space Grotesk','Syne','Plus Jakarta Sans','Josefin Sans','Fraunces'];
                                foreach ($fonts as $f) echo '<option value="' . esc_attr($f) . '">' . esc_html($f) . '</option>';
                                ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Body Font</label>
                            <select id="setting-body-font" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <?php foreach ($fonts as $f) echo '<option value="' . esc_attr($f) . '">' . esc_html($f) . '</option>'; ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Accent / Display Font</label>
                            <select id="setting-accent-font" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="">— Same as Heading —</option>
                                <?php foreach ($fonts as $f) echo '<option value="' . esc_attr($f) . '">' . esc_html($f) . '</option>'; ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center text-[10px] font-bold text-zinc-500 uppercase">
                                <span>Base Font Size</span>
                                <span id="font-size-val">16px</span>
                            </div>
                            <input type="range" id="setting-font-size" min="12" max="20" step="1" value="16" oninput="jQuery('#font-size-val').text(this.value + 'px')" class="w-full accent-zinc-950 cursor-pointer">
                            <div class="flex justify-between text-[9px] text-zinc-400"><span>12px</span><span>16px</span><span>20px</span></div>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Google Fonts API Key (optional)</label>
                            <input type="text" id="setting-gfonts-key" placeholder="AIza... for self-hosted fonts" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400">
                            <p class="text-[9px] text-zinc-400">Leave blank to use the standard Google Fonts CDN embed.</p>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Type Scale — Per Level</h5>
                        <p class="text-[10px] text-zinc-400">These map directly to Elementor Typography Presets and CSS variables.</p>
                        <?php
                        $type_levels = [
                            ['key' => 'h1', 'label' => 'H1 — Hero Heading', 'def_size' => 56, 'def_weight' => 800],
                            ['key' => 'h2', 'label' => 'H2 — Section Heading', 'def_size' => 40, 'def_weight' => 700],
                            ['key' => 'h3', 'label' => 'H3 — Sub-heading', 'def_size' => 28, 'def_weight' => 600],
                            ['key' => 'body', 'label' => 'Body — Paragraph', 'def_size' => 16, 'def_weight' => 400],
                            ['key' => 'small', 'label' => 'Small / Caption', 'def_size' => 13, 'def_weight' => 400],
                            ['key' => 'btn', 'label' => 'Button Text', 'def_size' => 14, 'def_weight' => 600],
                        ];
                        foreach ($type_levels as $tl): ?>
                        <div class="border border-zinc-100 rounded-lg p-3 space-y-2">
                            <p class="text-[10px] font-bold text-zinc-700"><?php echo esc_html($tl['label']); ?></p>
                            <div class="grid grid-cols-4 gap-2">
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">Size (px)</label>
                                    <input type="number" id="setting-type-<?php echo esc_attr($tl['key']); ?>-size" value="<?php echo esc_attr($tl['def_size']); ?>" min="10" max="120" class="w-full px-2 py-1 border border-zinc-200 rounded text-xs font-mono text-center focus:outline-none focus:border-zinc-400">
                                </div>
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">Weight</label>
                                    <select id="setting-type-<?php echo esc_attr($tl['key']); ?>-weight" class="w-full px-1 py-1 border border-zinc-200 rounded text-[10px] focus:outline-none focus:border-zinc-400 cursor-pointer">
                                        <?php foreach ([100=>'Thin',200=>'ExLight',300=>'Light',400=>'Regular',500=>'Medium',600=>'SemiBold',700=>'Bold',800=>'ExBold',900=>'Black'] as $w=>$wl): ?>
                                        <option value="<?php echo $w; ?>" <?php echo $w==$tl['def_weight']?'selected':''; ?>><?php echo $w; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">L.H.</label>
                                    <input type="number" id="setting-type-<?php echo esc_attr($tl['key']); ?>-lh" value="1.2" min="1" max="3" step="0.1" class="w-full px-2 py-1 border border-zinc-200 rounded text-xs font-mono text-center focus:outline-none focus:border-zinc-400">
                                </div>
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">Spc</label>
                                    <input type="number" id="setting-type-<?php echo esc_attr($tl['key']); ?>-ls" value="0" min="-5" max="10" step="0.01" class="w-full px-2 py-1 border border-zinc-200 rounded text-xs font-mono text-center focus:outline-none focus:border-zinc-400">
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Spacing & Borders                              -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-spacing" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Layout Spacing</h5>
                        <div class="space-y-2">
                            <div class="flex justify-between text-[10px] font-bold text-zinc-500 uppercase"><span>Container Max Width</span><span id="container-width-val">1280px</span></div>
                            <input type="range" id="setting-container-width" min="960" max="1800" step="40" value="1280" oninput="jQuery('#container-width-val').text(this.value+'px')" class="w-full accent-zinc-950 cursor-pointer">
                            <div class="flex justify-between text-[9px] text-zinc-400"><span>960px</span><span>1280px</span><span>1800px</span></div>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between text-[10px] font-bold text-zinc-500 uppercase"><span>Section Vertical Padding</span><span id="section-padding-val">80px</span></div>
                            <input type="range" id="setting-section-padding" min="20" max="200" step="10" value="80" oninput="jQuery('#section-padding-val').text(this.value+'px')" class="w-full accent-zinc-950 cursor-pointer">
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between text-[10px] font-bold text-zinc-500 uppercase"><span>Element Column Gap</span><span id="element-gap-val">24px</span></div>
                            <input type="range" id="setting-element-gap" min="8" max="80" step="4" value="24" oninput="jQuery('#element-gap-val').text(this.value+'px')" class="w-full accent-zinc-950 cursor-pointer">
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between text-[10px] font-bold text-zinc-500 uppercase"><span>Widgets Spacing</span><span id="widgets-spacing-val">20px</span></div>
                            <input type="range" id="setting-widgets-spacing" min="0" max="60" step="4" value="20" oninput="jQuery('#widgets-spacing-val').text(this.value+'px')" class="w-full accent-zinc-950 cursor-pointer">
                        </div>
                    </div>
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Border Radius System</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Radius Preset</label>
                            <div class="grid grid-cols-5 gap-2" id="radius-preset-group">
                                <?php
                                $presets = ['none'=>'0','sm'=>'4px','md'=>'8px','lg'=>'16px','pill'=>'999px'];
                                foreach ($presets as $pk=>$pv): ?>
                                <button type="button" onclick="selectRadiusPreset('<?php echo esc_attr($pv); ?>', this)" class="radius-preset-btn border border-zinc-200 rounded-lg py-2 text-[10px] font-bold text-zinc-600 hover:border-zinc-950 hover:text-zinc-950 transition-all cursor-pointer bg-transparent">
                                    <div class="flex flex-col items-center gap-1">
                                        <div class="w-6 h-6 border-2 border-current" style="border-radius:<?php echo esc_attr($pv); ?>"></div>
                                        <span><?php echo esc_html(ucfirst($pk)); ?></span>
                                    </div>
                                </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between text-[10px] font-bold text-zinc-500 uppercase"><span>Custom Border Radius (px)</span><span id="border-radius-val">8px</span></div>
                            <input type="range" id="setting-border-radius" min="0" max="32" step="2" value="8" oninput="jQuery('#border-radius-val').text(this.value+'px')" class="w-full accent-zinc-950 cursor-pointer">
                        </div>
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2 mt-2">Default Borders</h5>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Border Width</label>
                                <select id="setting-border-width" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                    <option value="0">None</option>
                                    <option value="1" selected>1px</option>
                                    <option value="2">2px</option>
                                    <option value="3">3px</option>
                                </select>
                            </div>
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Border Color</label>
                                <div class="flex items-center gap-2">
                                    <input type="color" id="setting-border-color" value="#e4e4e7" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('setting-border-color-text').value=this.value">
                                    <input type="text" id="setting-border-color-text" value="#e4e4e7" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('setting-border-color', this.value)">
                                </div>
                            </div>
                        </div>
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2 mt-2">Box Shadows</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Default Box Shadow</label>
                            <select id="setting-box-shadow" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="none">None</option>
                                <option value="0 1px 3px rgba(0,0,0,0.06)" selected>Subtle (xs)</option>
                                <option value="0 4px 12px rgba(0,0,0,0.08)">Soft (sm)</option>
                                <option value="0 8px 24px rgba(0,0,0,0.10)">Medium</option>
                                <option value="0 20px 60px rgba(0,0,0,0.15)">Deep (lg)</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Layout                                         -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-layout" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Header</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Header/Footer Mode</label>
                            <select id="setting-header-footer-mode" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="elementor_full_control">Elementor Theme Builder (Full Design Control)</option>
                                <option value="theme_default">Hello Elementor Theme (Default Header/Footer)</option>
                                <option value="canvas_fallback">Cora Canvas (Fallback Injected Header/Footer)</option>
                            </select>
                            <p class="text-[9px] text-zinc-450 mt-1">Controls how headers/footers render on live pages. Set to "Full Design Control" if you want a blank canvas to design them directly via Elementor.</p>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Header Style</label>
                            <select id="setting-header-layout" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="Logo Left">Logo Left — Nav Right</option>
                                <option value="Centered Logo">Centered Logo</option>
                                <option value="Split Navigation">Split Navigation (Logo Center)</option>
                                <option value="Minimal">Minimal — Logo Only</option>
                                <option value="Full Width">Full Width Bar</option>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Navigation Menu</label>
                            <select id="setting-nav-menu" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="0">— Default Navbar —</option>
                                <?php
                                $menus = wp_get_nav_menus();
                                if ( ! empty( $menus ) ) {
                                    foreach ( $menus as $menu ) {
                                        echo '<option value="' . esc_attr( $menu->term_id ) . '">' . esc_html( $menu->name ) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Header Template (Elementor)</label>
                            <select id="setting-template-header" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="0">— None / Use Default —</option>
                                <?php
                                $headers = get_posts( array(
                                    'post_type'      => 'elementor_library',
                                    'posts_per_page' => -1,
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'elementor_library_type',
                                            'field'    => 'slug',
                                            'terms'    => 'header',
                                        ),
                                    ),
                                ) );
                                if ( ! empty( $headers ) ) {
                                    foreach ( $headers as $h ) {
                                        echo '<option value="' . esc_attr( $h->ID ) . '">' . esc_html( $h->post_title ) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="flex items-center gap-2">
                                <input type="checkbox" id="setting-sticky-header" class="rounded cursor-pointer">
                                <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-sticky-header">Sticky Header</label>
                            </div>
                            <div class="flex items-center gap-2">
                                <input type="checkbox" id="setting-transparent-header" class="rounded cursor-pointer">
                                <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-transparent-header">Transparent on Hero</label>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Header BG Color</label>
                                <div class="flex items-center gap-2">
                                    <input type="color" id="setting-header-bg" value="#ffffff" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('setting-header-bg-text').value=this.value">
                                    <input type="text" id="setting-header-bg-text" value="#ffffff" class="flex-1 px-2 py-2 border border-zinc-200 rounded-lg text-[10px] font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('setting-header-bg', this.value)">
                                </div>
                            </div>
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Header Text Color</label>
                                <div class="flex items-center gap-2">
                                    <input type="color" id="setting-header-text-color" value="#18181b" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('setting-header-text-color-text').value=this.value">
                                    <input type="text" id="setting-header-text-color-text" value="#18181b" class="flex-1 px-2 py-2 border border-zinc-200 rounded-lg text-[10px] font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('setting-header-text-color', this.value)">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Footer</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Footer Columns</label>
                            <select id="setting-footer-columns" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="1">1 Column — Centered</option>
                                <option value="2">2 Columns</option>
                                <option value="3" selected>3 Columns</option>
                                <option value="4">4 Columns</option>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Footer Template (Elementor)</label>
                            <select id="setting-template-footer" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="0">— None / Use Default —</option>
                                <?php
                                $footers = get_posts( array(
                                    'post_type'      => 'elementor_library',
                                    'posts_per_page' => -1,
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'elementor_library_type',
                                            'field'    => 'slug',
                                            'terms'    => 'footer',
                                        ),
                                    ),
                                ) );
                                if ( ! empty( $footers ) ) {
                                    foreach ( $footers as $f ) {
                                        echo '<option value="' . esc_attr( $f->ID ) . '">' . esc_html( $f->post_title ) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Copyright Text</label>
                            <input type="text" id="setting-copyright-text" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="setting-show-socials" class="rounded cursor-pointer">
                            <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-show-socials">Show Social Links in Footer</label>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Footer BG Color</label>
                                <div class="flex items-center gap-2">
                                    <input type="color" id="setting-footer-bg" value="#18181b" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('setting-footer-bg-text').value=this.value">
                                    <input type="text" id="setting-footer-bg-text" value="#18181b" class="flex-1 px-2 py-2 border border-zinc-200 rounded-lg text-[10px] font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('setting-footer-bg', this.value)">
                                </div>
                            </div>
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Footer Text Color</label>
                                <div class="flex items-center gap-2">
                                    <input type="color" id="setting-footer-text-color" value="#a1a1aa" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('setting-footer-text-color-text').value=this.value">
                                    <input type="text" id="setting-footer-text-color-text" value="#a1a1aa" class="flex-1 px-2 py-2 border border-zinc-200 rounded-lg text-[10px] font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('setting-footer-text-color', this.value)">
                                </div>
                            </div>
                        </div>
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2 mt-2">Page Defaults</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Default Page Width</label>
                            <select id="setting-page-width" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="full-width">Full Width</option>
                                <option value="boxed" selected>Boxed (with sidebar)</option>
                                <option value="narrow">Narrow Content</option>
                            </select>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="setting-smooth-scroll" class="rounded cursor-pointer" checked>
                            <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-smooth-scroll">Enable Smooth Scroll</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Social & SEO                                   -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-social" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-4">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Social Profiles</h5>
                        <?php
                        $social_fields = [
                            ['id'=>'setting-facebook-link','label'=>'Facebook','placeholder'=>'https://facebook.com/...'],
                            ['id'=>'setting-twitter-link','label'=>'X / Twitter','placeholder'=>'https://x.com/...'],
                            ['id'=>'setting-instagram-link','label'=>'Instagram','placeholder'=>'https://instagram.com/...'],
                            ['id'=>'setting-linkedin-link','label'=>'LinkedIn','placeholder'=>'https://linkedin.com/in/...'],
                            ['id'=>'setting-youtube-link','label'=>'YouTube','placeholder'=>'https://youtube.com/@...'],
                            ['id'=>'setting-tiktok-link','label'=>'TikTok','placeholder'=>'https://tiktok.com/@...'],
                        ];
                        foreach ($social_fields as $sf): ?>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase"><?php echo esc_html($sf['label']); ?></label>
                            <input type="url" id="<?php echo esc_attr($sf['id']); ?>" placeholder="<?php echo esc_attr($sf['placeholder']); ?>" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="space-y-4">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">SEO & Analytics</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Google Analytics (GA4) ID</label>
                            <input type="text" id="setting-ga4-id" placeholder="G-XXXXXXXXXX" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400">
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Google Tag Manager ID</label>
                            <input type="text" id="setting-gtm-id" placeholder="GTM-XXXXXXX" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400">
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Facebook Pixel ID</label>
                            <input type="text" id="setting-fb-pixel" placeholder="1234567890" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400">
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Robots.txt Directive</label>
                            <select id="setting-robots" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="index,follow">Index, Follow (default)</option>
                                <option value="noindex,follow">No Index — Follow Links</option>
                                <option value="noindex,nofollow">No Index, No Follow</option>
                            </select>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="setting-sitemap-enable" class="rounded cursor-pointer" checked>
                            <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-sitemap-enable">Generate XML Sitemap</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Page Mapping                                   -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-routing" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-4">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Page Mapping</h5>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Homepage</label>
                            <select id="setting-homepage-page-id" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="">-- Loading Pages... --</option>
                            </select>
                            <p class="text-[10px] text-zinc-400">Select which page is loaded when users visit the root domain (e.g. `/`).</p>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">Contact Page</label>
                            <select id="setting-contact-page-id" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer">
                                <option value="">-- Loading Pages... --</option>
                            </select>
                            <p class="text-[10px] text-zinc-400">Select which page functions as your main contact form page.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Elementor Sync (conditional)                   -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-elementor" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <div class="flex items-start gap-3 p-4 bg-zinc-50 border border-zinc-200 rounded-xl">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Elementor Global Settings Sync</p>
                                <p class="text-[10px] text-zinc-500 mt-1 leading-relaxed">Changes saved here are pushed directly into Elementor's active Kit — the same global settings you see in Elementor → Site Settings. Changes apply instantly across all Elementor pages.</p>
                                <p class="text-[10px] text-zinc-400 mt-2">Last synced: <span id="elementor-last-sync" class="font-mono">Never</span></p>
                            </div>
                        </div>
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Elementor Global Colors</h5>
                        <p class="text-[10px] text-zinc-400">These 4 colors map 1:1 to the Elementor system color palette (Primary, Secondary, Text, Accent). Changing them here updates Elementor Site Settings → Global Colors.</p>
                        <?php
                        $el_colors = [
                            ['id'=>'setting-el-primary','label'=>'System Color 1 — Primary'],
                            ['id'=>'setting-el-secondary','label'=>'System Color 2 — Secondary'],
                            ['id'=>'setting-el-text','label'=>'System Color 3 — Text'],
                            ['id'=>'setting-el-accent','label'=>'System Color 4 — Accent'],
                        ];
                        foreach ($el_colors as $ec): ?>
                        <div class="space-y-1">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase"><?php echo esc_html($ec['label']); ?></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="<?php echo esc_attr($ec['id']); ?>" class="w-9 h-9 rounded-lg border border-zinc-200 cursor-pointer p-0.5" oninput="document.getElementById('<?php echo esc_attr($ec['id']); ?>-text').value=this.value">
                                <input type="text" id="<?php echo esc_attr($ec['id']); ?>-text" class="flex-1 px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono uppercase focus:outline-none focus:border-zinc-400" oninput="syncColorPicker('<?php echo esc_attr($ec['id']); ?>', this.value)">
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="space-y-5">
                        <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-2">Elementor Global Typography</h5>
                        <p class="text-[10px] text-zinc-400">These 4 typography presets map to Elementor Site Settings → Global Fonts (Primary, Secondary, Text, Accent typography groups).</p>
                        <?php
                        $el_types = [
                            ['key'=>'primary','label'=>'Typography 1 — Primary (Headings)'],
                            ['key'=>'secondary','label'=>'Typography 2 — Secondary (Subheadings)'],
                            ['key'=>'text','label'=>'Typography 3 — Text (Body)'],
                            ['key'=>'accent','label'=>'Typography 4 — Accent (Buttons/Labels)'],
                        ];
                        foreach ($el_types as $et): ?>
                        <div class="border border-zinc-100 rounded-lg p-3 space-y-3">
                            <p class="text-[10px] font-bold text-zinc-700"><?php echo esc_html($et['label']); ?></p>
                            <div class="grid grid-cols-2 gap-2">
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">Font Family</label>
                                    <select id="setting-el-type-<?php echo esc_attr($et['key']); ?>-family" class="w-full px-1.5 py-1.5 border border-zinc-200 rounded text-[10px] focus:outline-none focus:border-zinc-400 cursor-pointer">
                                        <?php foreach ($fonts as $f) echo '<option value="' . esc_attr($f) . '">' . esc_html($f) . '</option>'; ?>
                                    </select>
                                </div>
                                <div class="space-y-1">
                                    <label class="text-[9px] font-bold text-zinc-400 uppercase">Weight</label>
                                    <select id="setting-el-type-<?php echo esc_attr($et['key']); ?>-weight" class="w-full px-1.5 py-1.5 border border-zinc-200 rounded text-[10px] focus:outline-none focus:border-zinc-400 cursor-pointer">
                                        <?php foreach ([100,200,300,400,500,600,700,800,900] as $w): ?>
                                        <option value="<?php echo $w; ?>" <?php echo $w===($et['key']==='text'||$et['key']==='accent'?400:700)?'selected':''; ?>><?php echo $w; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <button onclick="triggerElementorSync()" class="w-full mt-2 px-4 py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
                            Sync to Elementor Now
                        </button>
                    </div>
                </div>
            </div>

            <!-- ══════════════════════════════════════════════════════ -->
            <!-- PANEL: Lovable CSS Tokens (conditional)               -->
            <!-- ══════════════════════════════════════════════════════ -->
            <div id="spanel-lovable" class="settings-panel p-6 hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <div class="flex items-start gap-3 p-4 bg-violet-50 border border-violet-100 rounded-xl">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-violet-600 mt-0.5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>
                            <div>
                                <p class="text-xs font-bold text-zinc-900">CSS Design Tokens — Global Sync</p>
                                <p class="text-[10px] text-zinc-500 mt-1 leading-relaxed">All settings are compiled into a <code class="bg-violet-100 px-1 rounded text-[9px]">:root{}</code> CSS token block and injected on every frontend page. Your Lovable React components that use these CSS variables will update instantly.</p>
                                <p class="text-[10px] text-zinc-400 mt-2">Token file: <span id="lovable-token-path" class="font-mono text-violet-600">cora-global-tokens.css</span></p>
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase">CSS Variable Prefix</label>
                            <div class="flex items-center gap-2">
                                <input type="text" id="setting-css-prefix" value="--" class="w-16 px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400">
                                <p class="text-[10px] text-zinc-400">Default <code class="bg-zinc-100 px-1 rounded">--</code> works with any Lovable Tailwind config or plain CSS.</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="setting-dark-tokens" class="rounded cursor-pointer">
                            <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="setting-dark-tokens">Generate Dark Mode tokens (<code class="text-[10px]">[data-theme=dark]</code>)</label>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center justify-between">
                            <h5 class="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Live Token Preview</h5>
                            <button onclick="refreshTokenPreview()" class="text-[10px] text-zinc-500 hover:text-zinc-900 font-bold cursor-pointer transition-colors">↻ Refresh</button>
                        </div>
                        <div class="bg-zinc-950 rounded-xl p-4 overflow-auto max-h-80 font-mono text-[10px] leading-relaxed">
                            <pre id="lovable-token-preview" class="text-zinc-300 whitespace-pre-wrap">/* Loading tokens... */</pre>
                        </div>
                        <button onclick="triggerLovableTokenSync()" class="w-full px-4 py-2.5 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>
                            Push Tokens to Frontend
                        </button>
                    </div>
                </div>
            </div>


            <!-- ── Save Footer ──────────────────────────────────────── -->
            <div class="flex items-center justify-between border-t border-zinc-100 px-6 py-4">
                <p class="text-[10px] text-zinc-400" id="settings-save-hint">Changes apply globally across all pages when saved.</p>
                <button onclick="saveThemeSettings()" <?php echo $is_read_only ? 'disabled' : ''; ?> class="px-5 py-2 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer transition-all">Save Settings</button>
            </div>
        </div>

        <!-- TAB CONTENT: CUSTOM CODE -->
        <div id="tab-content-code" class="hidden">
            <div class="flex gap-0 bg-white border border-zinc-200 rounded-xl shadow-sm overflow-hidden" style="min-height:580px">

                <!-- ── Left Nav: Code Sections ── -->
                <div class="w-44 flex-shrink-0 border-r border-zinc-100 bg-zinc-50 flex flex-col">
                    <div class="px-3 pt-4 pb-2">
                        <p class="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">Code Injections</p>
                    </div>
                    <nav class="flex flex-col gap-0.5 px-2 flex-1" id="code-section-nav">
                        <?php
                        $code_sections = [
                            ['id'=>'css',   'label'=>'Global CSS',       'icon'=>'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',    'hint'=>'Injected in &lt;head&gt; on every page'],
                            ['id'=>'js',    'label'=>'Custom JS',        'icon'=>'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',                    'hint'=>'Runs on every frontend page'],
                            ['id'=>'head',  'label'=>'Head HTML',        'icon'=>'<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>','hint'=>'Tags appended to &lt;head&gt;'],
                            ['id'=>'body',  'label'=>'Body Scripts',     'icon'=>'<rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>','hint'=>'Injected before &lt;/body&gt;'],
                            ['id'=>'snips', 'label'=>'Snippets',         'icon'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>','hint'=>'Reusable code blocks'],
                        ];
                        foreach ($code_sections as $i => $cs): ?>
                        <button onclick="switchCodeSection('<?php echo esc_attr($cs['id']); ?>')" id="code-nav-<?php echo esc_attr($cs['id']); ?>"
                            class="code-nav-btn group w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all <?php echo $i === 0 ? 'bg-white shadow-sm border border-zinc-200 text-zinc-900' : 'text-zinc-500 hover:text-zinc-900 hover:bg-white'; ?> cursor-pointer border border-transparent">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="flex-shrink-0">
                                <?php echo $cs['icon']; ?>
                            </svg>
                            <span class="text-[11px] font-semibold leading-tight"><?php echo esc_html($cs['label']); ?></span>
                        </button>
                        <?php endforeach; ?>
                    </nav>

                    <!-- Bottom: Save indicator -->
                    <div class="px-3 py-3 border-t border-zinc-100 mt-auto">
                        <div class="flex items-center gap-1.5">
                            <span class="w-1.5 h-1.5 rounded-full bg-zinc-300" id="code-save-dot"></span>
                            <span class="text-[9px] text-zinc-400 font-medium" id="code-save-status">No changes</span>
                        </div>
                        <p class="text-[9px] text-zinc-300 mt-1">⌘S / Ctrl+S to save</p>
                    </div>
                </div>

                <!-- ── Right: Editor Area ── -->
                <div class="flex-1 flex flex-col min-w-0">

                    <!-- ══════════════════════════════════════════════ -->
                    <!-- SECTION: Global CSS                           -->
                    <!-- ══════════════════════════════════════════════ -->
                    <div id="code-section-css" class="code-section flex flex-col flex-1">
                        <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Global CSS Overrides</p>
                                <p class="text-[10px] text-zinc-400 mt-0.5">Compiled and injected in <code class="bg-zinc-100 px-1 rounded text-[9px]">&lt;style&gt;</code> inside the page <code class="bg-zinc-100 px-1 rounded text-[9px]">&lt;head&gt;</code>. Scoped to this theme.</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="text-[9px] text-zinc-400 font-mono" id="css-stats">0 lines · 0 chars</span>
                                <button onclick="saveCustomCSS()" <?php echo $is_read_only ? 'disabled' : ''; ?>
                                    class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-40 text-white rounded-lg text-[11px] font-bold shadow-sm cursor-pointer transition-all flex items-center gap-1.5">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                    Save CSS
                                </button>
                            </div>
                        </div>
                        <!-- CodeMirror mount target -->
                        <div class="flex-1 relative" style="min-height:460px">
                            <textarea id="custom-css-textarea" class="hidden"></textarea>
                            <div id="css-editor-mount" class="absolute inset-0 overflow-auto font-mono text-xs"></div>
                        </div>
                    </div>

                    <!-- ══════════════════════════════════════════════ -->
                    <!-- SECTION: Custom JS                            -->
                    <!-- ══════════════════════════════════════════════ -->
                    <div id="code-section-js" class="code-section flex flex-col flex-1 hidden">
                        <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Custom JavaScript</p>
                                <p class="text-[10px] text-zinc-400 mt-0.5">Runs on all frontend pages of this theme.</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <select id="setting-js-position" class="px-2.5 py-1.5 bg-white border border-zinc-200 rounded-lg text-[10px] text-zinc-600 focus:outline-none cursor-pointer">
                                    <option value="footer">Before &lt;/body&gt; (Recommended)</option>
                                    <option value="head">Inside &lt;head&gt;</option>
                                </select>
                                <span class="text-[9px] text-zinc-400 font-mono" id="js-stats">0 lines · 0 chars</span>
                                <button onclick="saveCustomJS()" <?php echo $is_read_only ? 'disabled' : ''; ?>
                                    class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-40 text-white rounded-lg text-[11px] font-bold shadow-sm cursor-pointer transition-all flex items-center gap-1.5">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                    Save JS
                                </button>
                            </div>
                        </div>
                        <!-- Warning banner -->
                        <div class="mx-4 mt-3 flex items-start gap-2 p-3 bg-amber-50 border border-amber-100 rounded-lg">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#92400e" stroke-width="2" class="flex-shrink-0 mt-0.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                            <p class="text-[10px] text-amber-800 leading-relaxed">JS errors here can break all frontend pages. Test locally before saving. Do not include the <code class="bg-amber-100 px-0.5 rounded">&lt;script&gt;</code> wrapper tags.</p>
                        </div>
                        <div class="flex-1 relative mt-3" style="min-height:410px">
                            <textarea id="custom-js-textarea" class="hidden"></textarea>
                            <div id="js-editor-mount" class="absolute inset-0 overflow-auto font-mono text-xs"></div>
                        </div>
                    </div>

                    <!-- ══════════════════════════════════════════════ -->
                    <!-- SECTION: Head HTML                            -->
                    <!-- ══════════════════════════════════════════════ -->
                    <div id="code-section-head" class="code-section flex flex-col flex-1 hidden">
                        <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Head HTML Injection</p>
                                <p class="text-[10px] text-zinc-400 mt-0.5">Raw HTML tags appended to <code class="bg-zinc-100 px-1 rounded text-[9px]">&lt;head&gt;</code> — ideal for font imports, meta tags, and pixel base code.</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="text-[9px] text-zinc-400 font-mono" id="head-stats">0 lines · 0 chars</span>
                                <button onclick="saveHeadHTML()" <?php echo $is_read_only ? 'disabled' : ''; ?>
                                    class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-40 text-white rounded-lg text-[11px] font-bold shadow-sm cursor-pointer transition-all flex items-center gap-1.5">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                    Save HTML
                                </button>
                            </div>
                        </div>
                        <!-- Quick-insert chips -->
                        <div class="flex items-center gap-2 flex-wrap px-4 py-2 border-b border-zinc-50">
                            <span class="text-[9px] font-bold text-zinc-400 uppercase">Quick insert:</span>
                            <?php
                            $head_snippets = [
                                ['label'=>'Google Font', 'code'=>'<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n" . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n" . '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">'],
                                ['label'=>'Meta Viewport', 'code'=>'<meta name="viewport" content="width=device-width, initial-scale=1.0">'],
                                ['label'=>'OG Tags', 'code'=>'<meta property="og:title" content="Your Site">' . "\n" . '<meta property="og:description" content="Description">' . "\n" . '<meta property="og:image" content="https://example.com/image.jpg">'],
                                ['label'=>'Canonical URL', 'code'=>'<link rel="canonical" href="https://yoursite.com/">'],
                                ['label'=>'No-index', 'code'=>'<meta name="robots" content="noindex, nofollow">'],
                            ];
                            foreach ($head_snippets as $qs): ?>
                            <button data-code="<?php echo esc_attr($qs['code']); ?>"
                                class="quick-insert-btn-head px-2 py-0.5 rounded-md border border-zinc-200 text-[9px] font-semibold text-zinc-600 hover:border-zinc-400 hover:text-zinc-900 bg-white cursor-pointer transition-all"><?php echo esc_html($qs['label']); ?></button>
                            <?php endforeach; ?>
                        </div>
                        <div class="flex-1 relative" style="min-height:420px">
                            <textarea id="custom-head-textarea" class="hidden"></textarea>
                            <div id="head-editor-mount" class="absolute inset-0 overflow-auto font-mono text-xs"></div>
                        </div>
                    </div>

                    <!-- ══════════════════════════════════════════════ -->
                    <!-- SECTION: Body Scripts                         -->
                    <!-- ══════════════════════════════════════════════ -->
                    <div id="code-section-body" class="code-section flex flex-col flex-1 hidden">
                        <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Body Script Injection</p>
                                <p class="text-[10px] text-zinc-400 mt-0.5">HTML/scripts injected just before <code class="bg-zinc-100 px-1 rounded text-[9px]">&lt;/body&gt;</code>. Ideal for chat widgets, analytics, and deferred scripts.</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="text-[9px] text-zinc-400 font-mono" id="body-stats">0 lines · 0 chars</span>
                                <button onclick="saveBodyHTML()" <?php echo $is_read_only ? 'disabled' : ''; ?>
                                    class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-40 text-white rounded-lg text-[11px] font-bold shadow-sm cursor-pointer transition-all flex items-center gap-1.5">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                    Save Body
                                </button>
                            </div>
                        </div>
                        <!-- Quick-insert chips -->
                        <div class="flex items-center gap-2 flex-wrap px-4 py-2 border-b border-zinc-50">
                            <span class="text-[9px] font-bold text-zinc-400 uppercase">Quick insert:</span>
                            <?php
                            $body_snippets = [
                                ['label'=>'Google Analytics', 'code'=>'<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>' . "\n" . '<script>' . "\n" . '  window.dataLayer = window.dataLayer || [];' . "\n" . '  function gtag(){dataLayer.push(arguments);}' . "\n" . '  gtag(\'js\', new Date());' . "\n" . '  gtag(\'config\', \'G-XXXXXXXXXX\');' . "\n" . '</script>'],
                                ['label'=>'GTM Body', 'code'=>'<!-- Google Tag Manager (noscript) -->' . "\n" . '<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX"' . "\n" . 'height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>'],
                                ['label'=>'FB Pixel', 'code'=>'<script>' . "\n" . '  !function(f,b,e,v,n,t,s)' . "\n" . '  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?' . "\n" . '  n.callMethod.apply(n,arguments):n.queue.push(arguments)};' . "\n" . '  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version=\'2.0\';' . "\n" . '  n.queue=[];t=b.createElement(e);t.async=!0;' . "\n" . '  t.src=v;s=b.getElementsByTagName(e)[0];' . "\n" . '  s.parentNode.insertBefore(t,s)}(window, document,\'script\',' . "\n" . '  \'https://connect.facebook.net/en_US/fbevents.js\');' . "\n" . '  fbq(\'init\', \'YOUR_PIXEL_ID\');' . "\n" . '  fbq(\'track\', \'PageView\');' . "\n" . '</script>'],
                                ['label'=>'Intercom', 'code'=>'<script>' . "\n" . '  window.intercomSettings = {' . "\n" . '    api_base: "https://api-iam.intercom.io",' . "\n" . '    app_id: "YOUR_APP_ID"' . "\n" . '  };' . "\n" . '  (function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic(\'reattach_activator\');ic(\'update\',w.intercomSettings);}else{var d=document;var i=function(){i.c(arguments);};i.q=[];i.c=function(args){i.q.push(args);};w.Intercom=i;var l=function(){var s=d.createElement(\'script\');s.type=\'text/javascript\';s.async=true;s.src=\'https://widget.intercom.io/widget/YOUR_APP_ID\';var x=d.getElementsByTagName(\'script\')[0];x.parentNode.insertBefore(s,x);};if(document.readyState===\'complete\'){l();}else if(w.attachEvent){w.attachEvent(\'onload\',l);}else{w.addEventListener(\'load\',l,false);}}}());' . "\n" . '</script>'],
                                ['label'=>'Crisp Chat', 'code'=>'<script type="text/javascript">' . "\n" . '  window.$crisp=[];window.CRISP_WEBSITE_ID="YOUR-WEBSITE-ID";' . "\n" . '  (function(){d=document;s=d.createElement("script");' . "\n" . '  s.src="https://client.crisp.chat/l.js";' . "\n" . '  s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();' . "\n" . '</script>'],
                            ];
                            foreach ($body_snippets as $bs): ?>
                            <button data-code="<?php echo esc_attr($bs['code']); ?>"
                                class="quick-insert-btn-body px-2 py-0.5 rounded-md border border-zinc-200 text-[9px] font-semibold text-zinc-600 hover:border-zinc-400 hover:text-zinc-900 bg-white cursor-pointer transition-all"><?php echo esc_html($bs['label']); ?></button>
                            <?php endforeach; ?>
                        </div>
                        <div class="flex-1 relative" style="min-height:390px">
                            <textarea id="custom-body-textarea" class="hidden"></textarea>
                            <div id="body-editor-mount" class="absolute inset-0 overflow-auto font-mono text-xs"></div>
                        </div>
                    </div>

                    <!-- ══════════════════════════════════════════════ -->
                    <!-- SECTION: Snippets Library                     -->
                    <!-- ══════════════════════════════════════════════ -->
                    <div id="code-section-snips" class="code-section flex flex-col flex-1 hidden">
                        <div class="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
                            <div>
                                <p class="text-xs font-bold text-zinc-900">Snippets Library</p>
                                <p class="text-[10px] text-zinc-400 mt-0.5">Pre-built code blocks. Click any snippet to insert it into the relevant editor.</p>
                            </div>
                        </div>
                        <div class="flex-1 overflow-auto p-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3" id="snippets-grid">
                                <?php
                                $snippets = [
                                    ['cat'=>'CSS', 'title'=>'Smooth Scroll', 'desc'=>'Enables CSS smooth scrolling globally', 'code'=>'html { scroll-behavior: smooth; }'],
                                    ['cat'=>'CSS', 'title'=>'Custom Scrollbar', 'desc'=>'Styled webkit scrollbar for Chrome/Safari', 'code'=>"::-webkit-scrollbar { width: 6px; }\n::-webkit-scrollbar-track { background: #f4f4f5; }\n::-webkit-scrollbar-thumb { background: #a1a1aa; border-radius: 3px; }\n::-webkit-scrollbar-thumb:hover { background: #71717a; }"],
                                    ['cat'=>'CSS', 'title'=>'Selection Color', 'desc'=>'Custom text selection highlight color', 'code'=>"::selection { background: var(--color-primary, #18181b); color: #fff; }\n::-moz-selection { background: var(--color-primary, #18181b); color: #fff; }"],
                                    ['cat'=>'CSS', 'title'=>'Image Lazy Fade', 'desc'=>'Fade in images as they lazy load', 'code'=>"img[loading='lazy'] { opacity: 0; transition: opacity 0.4s ease; }\nimg[loading='lazy'].loaded { opacity: 1; }"],
                                    ['cat'=>'JS',  'title'=>'Back to Top', 'desc'=>'Scroll to top when button#back-to-top is clicked', 'code'=>"document.getElementById('back-to-top')?.addEventListener('click', () => {\n  window.scrollTo({ top: 0, behavior: 'smooth' });\n});"],
                                    ['cat'=>'JS',  'title'=>'Lazy Image Load', 'desc'=>'Trigger loaded class on lazy images', 'code'=>'document.querySelectorAll(\'img[loading="lazy"]\').forEach(img => {' . "\n" . '  img.addEventListener(\'load\', () => img.classList.add(\'loaded\'));' . "\n" . '  if (img.complete) img.classList.add(\'loaded\');' . "\n" . '});'],
                                    ['cat'=>'JS',  'title'=>'Console Welcome', 'desc'=>'A branded console message', 'code'=>"console.log('%c ✦ Built with Cora ', 'background:#18181b;color:#fff;font-size:14px;border-radius:4px;padding:4px 8px;');"],
                                    ['cat'=>'HTML','title'=>'Google Font Import', 'desc'=>'Inter font from Google Fonts CDN', 'code'=>'<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">'],
                                    ['cat'=>'HTML','title'=>'Schema — LocalBusiness', 'desc'=>'Structured data for local business SEO', 'code'=>'<script type="application/ld+json">{"@context":"https://schema.org","@type":"LocalBusiness","name":"Your Agency","address":{"@type":"PostalAddress","streetAddress":"123 Main St","addressLocality":"City","addressRegion":"ST","postalCode":"00000"},"telephone":"+1-555-555-5555","url":"https://yoursite.com"}</script>'],
                                    ['cat'=>'HTML','title'=>'Open Graph Tags', 'desc'=>'Social share meta tags', 'code'=>'<meta property="og:title" content="Your Site Title"><meta property="og:description" content="Your site description"><meta property="og:type" content="website"><meta property="og:url" content="https://yoursite.com"><meta property="og:image" content="https://yoursite.com/og-image.jpg">'],
                                ];
                                foreach ($snippets as $sn): ?>
                                <div class="border border-zinc-200 rounded-xl p-3.5 hover:border-zinc-400 transition-all group bg-white">
                                    <div class="flex items-start justify-between gap-2 mb-2">
                                        <div>
                                            <span class="inline-block px-1.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-wide <?php echo $sn['cat']==='CSS'?'bg-blue-50 text-blue-700':($sn['cat']==='JS'?'bg-amber-50 text-amber-700':'bg-zinc-100 text-zinc-600'); ?> mb-1"><?php echo esc_html($sn['cat']); ?></span>
                                            <p class="text-[11px] font-bold text-zinc-900"><?php echo esc_html($sn['title']); ?></p>
                                            <p class="text-[10px] text-zinc-500 mt-0.5"><?php echo esc_html($sn['desc']); ?></p>
                                        </div>
                                        <button data-cat="<?php echo esc_attr($sn['cat']); ?>" data-code="<?php echo esc_attr($sn['code']); ?>"
                                            class="quick-insert-btn-snip flex-shrink-0 px-2.5 py-1.5 border border-zinc-200 rounded-lg text-[10px] font-bold text-zinc-600 hover:bg-zinc-950 hover:text-white hover:border-zinc-950 cursor-pointer transition-all">
                                            Insert
                                        </button>
                                    </div>
                                    <pre class="bg-zinc-950 text-zinc-300 rounded-lg p-2.5 text-[9px] font-mono leading-relaxed overflow-auto max-h-24 whitespace-pre-wrap"><?php echo esc_html(mb_strimwidth($sn['code'], 0, 180, '...')); ?></pre>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                </div><!-- end editor area -->
            </div><!-- end flex container -->
        </div>

        <!-- TAB CONTENT: NEXT.JS NATIVE SDK & OPS -->
        <div id="tab-content-nextjs-sdk" class="hidden space-y-6">
            <!-- Top Hero Banner -->
            <div class="bg-zinc-950 text-white rounded-2xl p-6 shadow-sm border border-zinc-900 relative overflow-hidden">
                <div class="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-6">
                    <svg width="220" height="220" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 19.7778H22L12 2Z"/></svg>
                </div>
                <div class="relative z-10 max-w-2xl">
                    <div class="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-white/10 border border-white/15 text-[10px] font-bold tracking-wider uppercase text-emerald-400 mb-3">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        Next.js Native Headless Connected
                    </div>
                    <h2 class="text-xl font-black tracking-tight text-white mb-2">Native Next.js Frontend Operations</h2>
                    <p class="text-xs text-zinc-400 leading-relaxed">Your frontend runs 100% native Next.js with App Router on Vercel / Netlify / Custom server, while Cora handles operational management, dynamic content, leads CRM, and instant On-Demand ISR cache revalidation.</p>
                </div>
            </div>

            <!-- Grid Layout: Connection Hub & API Credentials -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Card 1: Project Sync & ISR Webhook Status -->
                <div class="bg-white border border-zinc-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between pb-3 border-b border-zinc-100 mb-4">
                            <h3 class="text-xs font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-2">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                                Repository & Deployment
                            </h3>
                            <span id="nextjs-status-badge" class="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">Active</span>
                        </div>

                        <div class="space-y-3.5 text-xs">
                            <div>
                                <label class="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Connected GitHub Repository</label>
                                <div class="flex items-center gap-2 bg-zinc-50 px-3 py-2 rounded-lg border border-zinc-200">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>
                                    <span id="nextjs-repo-label" class="font-mono text-zinc-900 font-semibold truncate flex-1">github.com/...</span>
                                    <a id="nextjs-repo-link" href="#" target="_blank" class="text-zinc-500 hover:text-zinc-900 text-[11px] font-bold">Open ↗</a>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Branch</label>
                                    <div class="bg-zinc-50 px-3 py-2 rounded-lg border border-zinc-200 font-mono text-zinc-900 font-semibold truncate" id="nextjs-branch-label">main</div>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-zinc-400 uppercase mb-1">Live Frontend URL</label>
                                    <div class="bg-zinc-50 px-3 py-2 rounded-lg border border-zinc-200 font-mono text-zinc-900 font-semibold truncate flex items-center justify-between">
                                        <span id="nextjs-live-url-label">https://...</span>
                                        <a id="nextjs-live-url-link" href="#" target="_blank" class="text-zinc-500 hover:text-zinc-900 text-[11px] font-bold">↗</a>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label class="block text-[10px] font-bold text-zinc-400 uppercase mb-1">On-Demand ISR Webhook Secret</label>
                                <div class="flex items-center gap-2 bg-zinc-50 px-3 py-2 rounded-lg border border-zinc-200">
                                    <input type="password" id="nextjs-secret-display" class="bg-transparent border-0 text-xs font-mono text-zinc-900 font-semibold flex-1 outline-none" readonly value="cora_sec_****************">
                                    <button onclick="copyNextJSSecret()" class="text-zinc-500 hover:text-zinc-900 font-bold text-[11px] cursor-pointer">Copy</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="pt-4 mt-4 border-t border-zinc-100 flex items-center justify-between gap-3">
                        <button onclick="syncNextJSRoutesFromGit()" id="btn-nextjs-sync-git" class="px-3.5 py-2 border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-900 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                            <span>Sync Git Routes</span>
                        </button>
                        <button onclick="triggerNextJSISRRebuild()" id="btn-nextjs-trigger-isr" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border-none shadow-xs">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                            <span>Trigger ISR Rebuild</span>
                        </button>
                    </div>
                </div>

                <!-- Card 2: Headless REST API Endpoints -->
                <div class="bg-white border border-zinc-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between pb-3 border-b border-zinc-100 mb-4">
                            <h3 class="text-xs font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-2">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                                Headless REST API Endpoints
                            </h3>
                            <span class="text-[10px] font-mono text-zinc-400">v1.0</span>
                        </div>

                        <div class="space-y-3 text-xs">
                            <div class="bg-zinc-50 p-2.5 rounded-lg border border-zinc-200 flex items-center justify-between">
                                <div>
                                    <span class="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-100 text-emerald-800 font-mono mr-1.5">GET</span>
                                    <code class="text-[11px] font-mono text-zinc-900">/wp-json/cora-canvas/v1/nextjs/manifest</code>
                                </div>
                                <span class="text-[10px] text-zinc-400">All routes & tokens</span>
                            </div>

                            <div class="bg-zinc-50 p-2.5 rounded-lg border border-zinc-200 flex items-center justify-between">
                                <div>
                                    <span class="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-100 text-emerald-800 font-mono mr-1.5">GET</span>
                                    <code class="text-[11px] font-mono text-zinc-900">/wp-json/cora-canvas/v1/nextjs/page?slug=about</code>
                                </div>
                                <span class="text-[10px] text-zinc-400">Page SEO & Props</span>
                            </div>

                            <div class="bg-zinc-50 p-2.5 rounded-lg border border-zinc-200 flex items-center justify-between">
                                <div>
                                    <span class="px-1.5 py-0.5 rounded text-[9px] font-black bg-blue-100 text-blue-800 font-mono mr-1.5">POST</span>
                                    <code class="text-[11px] font-mono text-zinc-900">/wp-json/cora-canvas/v1/nextjs/revalidate</code>
                                </div>
                                <span class="text-[10px] text-zinc-400">On-demand ISR webhook</span>
                            </div>

                            <div class="bg-zinc-50 p-2.5 rounded-lg border border-zinc-200 flex items-center justify-between">
                                <div>
                                    <span class="px-1.5 py-0.5 rounded text-[9px] font-black bg-blue-100 text-blue-800 font-mono mr-1.5">POST</span>
                                    <code class="text-[11px] font-mono text-zinc-900">/wp-json/cora-canvas/v1/nextjs/forms/submit</code>
                                </div>
                                <span class="text-[10px] text-zinc-400">Submit to Cora CRM</span>
                            </div>
                        </div>
                    </div>

                    <div class="pt-3 mt-3 border-t border-zinc-100">
                        <p class="text-[11px] text-zinc-500 leading-relaxed">Fetch data in Next.js Server Components with automatic caching: <code class="font-mono text-zinc-900 bg-zinc-100 px-1 py-0.5 rounded">fetch(url, { next: { tags: ['cora'] } })</code></p>
                    </div>
                </div>
            </div>

            <!-- Code Snippets Library -->
            <div class="bg-white border border-zinc-200 rounded-2xl p-5 shadow-xs">
                <div class="flex items-center justify-between pb-3 border-b border-zinc-100 mb-4">
                    <h3 class="text-xs font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-2">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        Drop-in Next.js Starter Files
                    </h3>
                    <div class="flex gap-1">
                        <button onclick="switchNextJSSnippet('lib')" id="btn-snip-lib" class="px-2.5 py-1 rounded-md text-[11px] font-bold bg-zinc-950 text-white cursor-pointer transition-all">lib/cora.ts</button>
                        <button onclick="switchNextJSSnippet('revalidate')" id="btn-snip-revalidate" class="px-2.5 py-1 rounded-md text-[11px] font-bold text-zinc-600 hover:bg-zinc-100 cursor-pointer transition-all">app/api/revalidate/route.ts</button>
                        <button onclick="switchNextJSSnippet('form')" id="btn-snip-form" class="px-2.5 py-1 rounded-md text-[11px] font-bold text-zinc-600 hover:bg-zinc-100 cursor-pointer transition-all">components/CoraForm.tsx</button>
                    </div>
                </div>

                <div class="relative">
                    <button onclick="copyActiveNextJSSnippet()" class="absolute right-3 top-3 z-10 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-[10px] font-bold border border-white/20 transition-all cursor-pointer flex items-center gap-1.5 backdrop-blur-sm">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        <span>Copy Code</span>
                    </button>
                    <pre id="nextjs-snippet-code" class="bg-zinc-950 text-zinc-200 rounded-xl p-4 text-[11px] font-mono leading-relaxed overflow-x-auto max-h-[380px]"></pre>
                </div>
            </div>
        </div>

        <!-- TAB CONTENT: THEME BUILDER -->
        <div id="tab-content-theme-builder" class="hidden">
            <div class="bg-white border border-zinc-200 rounded-xl shadow-sm overflow-hidden" style="height:700px">
                <iframe id="theme-builder-iframe" src="" class="w-full h-full border-0"></iframe>
            </div>
        </div>

    </div>

    <!-- LEVEL 3 — ELEMENTOR PAGE EDITOR iframe wrapper -->
    <div id="canvas-level-3" class="fixed inset-0 z-[9999] bg-white<?php echo ! empty($_editor_resume_url) ? '' : ' hidden'; ?> flex flex-col">
        <!-- Editor Topbar Wrapper -->
        <div id="cora-parent-editor-topbar" class="h-24 bg-zinc-50 border-b border-zinc-200 flex flex-col hidden select-none">
            <!-- Row 1 -->
            <div class="h-12 border-b border-zinc-200 flex items-center justify-between px-4 w-full bg-zinc-50 ">
                <!-- Left: Logo & Theme Selector -->
                <div class="flex items-center gap-3">
                    <div class="flex items-center gap-1.5 select-none shrink-0 mr-1">
                        <span class="text-xs font-black tracking-tight text-zinc-900 uppercase">CORA</span>
                    </div>
                    <button onclick="closeElementorEditor()" class="h-8 px-3 border border-zinc-200 hover:bg-zinc-150 text-zinc-700 rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5 bg-white ">
                        <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="15 18 9 12 15 6"></polyline></svg>
                        Theme Dashboard
                    </button>
                    <!-- Retain the ID for E2E selector safety -->
                    <span id="cora-topbar-theme-name" class="hidden"></span>
                </div>
                
                <!-- Center: Breadcrumbs & Save Status -->
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-1.5 text-zinc-400 text-[11px] font-medium">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>/</span>
                        <span>Pages</span>
                        <span>/</span>
                        <span class="text-zinc-800 font-bold" id="cora-topbar-page-name">Home Page</span>
                        <span id="cora-topbar-theme-status-badge" class="ml-1.5 px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider select-none bg-zinc-200 text-zinc-700 ">Draft</span>
                    </div>
                    <div class="h-3 w-[1px] bg-zinc-250 "></div>
                    <div class="flex items-center gap-1.5 text-[10px] text-zinc-500 ">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <span id="cora-save-status-text">All changes saved</span>
                    </div>
                </div>
                
                <!-- Right: Preview -->
                <div class="flex items-center gap-1.5">
                    <button onclick="previewPage()" class="h-8 px-3 rounded-lg hover:bg-zinc-200/60 text-zinc-600 text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        Preview
                    </button>
                </div>
            </div>

            <!-- Row 2 -->
            <div class="h-12 border-b border-zinc-200 flex items-center justify-between px-4 w-full bg-white ">
                <!-- Left: Add, Templates, Undo/Redo -->
                <div class="flex items-center gap-2">
                    <button onclick="toggleWidgetsPanel()" class="h-8 w-8 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 rounded-lg cursor-pointer transition-colors flex items-center justify-center" title="Add Element">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    </button>
                    <button onclick="openTemplatesLibrary()" class="h-8 px-3 hover:bg-zinc-50 text-zinc-700 rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                        Templates
                    </button>
                    <button id="cora-git-btn" onclick="openGitDrawer()" class="h-8 px-3 hover:bg-zinc-50 text-zinc-700 rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5 relative" title="Git Version Control">
                        <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                        Git
                        <span id="cora-git-status-dot" class="hidden w-1.5 h-1.5 rounded-full bg-emerald-500 absolute top-1.5 right-1.5"></span>
                    </button>
                    <button onclick="openPageSettings()" class="h-8 px-2.5 hover:bg-zinc-50 text-zinc-700 rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5" title="Page Settings">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="3"></circle>
                            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                        </svg>
                        Settings
                    </button>
                    <div class="h-4 w-[1px] bg-zinc-200 mx-1"></div>
                    <button onclick="runElementorCommand('document/history/undo')" class="h-8 w-8 hover:bg-zinc-50 text-zinc-700 rounded-lg cursor-pointer transition-colors flex items-center justify-center" title="Undo">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7v6h6"></path><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"></path></svg>
                    </button>
                    <button onclick="runElementorCommand('document/history/redo')" class="h-8 w-8 hover:bg-zinc-50 text-zinc-700 rounded-lg cursor-pointer transition-colors flex items-center justify-center" title="Redo">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 7v6h-6"></path><path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7"></path></svg>
                    </button>
                </div>
                
                <!-- Center: Page Switcher Dropdown & Devices -->
                <div class="flex items-center gap-3">
                    <!-- Page switcher -->
                    <div class="relative" id="cora-page-switcher-wrap">
                        <button onclick="togglePageSwitcher(event)" class="flex items-center gap-1 cursor-pointer select-none h-8 px-2 rounded-lg hover:bg-zinc-100 transition-colors">
                            <span class="text-xs font-bold text-zinc-800 " id="cora-topbar-page-selector">Home Page</span>
                            <svg class="w-3.5 h-3.5 text-zinc-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <!-- Page dropdown -->
                        <div id="cora-page-switcher-dropdown" class="hidden absolute top-full left-0 mt-1 w-80 bg-white border border-zinc-200 rounded-xl shadow-2xl z-[99999] flex flex-col max-h-[420px] overflow-hidden">
                            <div class="p-3 border-b border-zinc-100 shrink-0">
                                <div class="relative w-full">
                                    <svg class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400 " viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                        <circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                    </svg>
                                    <input id="cora-page-switcher-search" type="text" placeholder="Search pages..." oninput="filterPageSwitcher(this.value)" class="w-full pl-8 pr-3 py-1.5 text-[11px] border border-zinc-200 rounded-lg bg-white text-zinc-800 focus:outline-none focus:border-zinc-400 transition-colors" />
                                </div>
                            </div>
                            <div id="cora-page-switcher-list" class="flex-1 overflow-y-auto max-h-[300px] py-1"></div>
                            <div class="border-t border-zinc-100 shrink-0 bg-white">
                                <button onclick="ddOpenNewPageDrawer(event)" class="w-full text-left px-4 py-2 text-[11px] font-bold text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 cursor-pointer transition-colors flex items-center gap-2">
                                    <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                    Add new page
                                </button>
                                <button onclick="openElementorMigrationDrawer()" class="w-full text-left px-4 py-2 text-[11px] font-bold text-zinc-900 hover:bg-zinc-50 cursor-pointer transition-colors flex items-center gap-2 border-t border-zinc-50">
                                    <svg class="w-3.5 h-3.5 text-zinc-900" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                                    Migrate Elementor page
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="h-4 w-[1px] bg-zinc-200 "></div>
                    <!-- Viewport devices -->
                    <div class="flex items-center gap-1">
                        <div class="flex items-center bg-zinc-100 p-0.5 rounded-lg" id="cora-device-pill">
                            <button id="cora-device-desktop" onclick="switchDevice('desktop')" title="Desktop" class="w-7 h-7 rounded-md flex items-center justify-center text-zinc-800 bg-white shadow-sm cursor-pointer transition-all">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                            </button>
                            <button id="cora-device-tablet" onclick="switchDevice('tablet')" title="Tablet (768px)" class="w-7 h-7 rounded-md flex items-center justify-center text-zinc-500 hover:text-zinc-800 cursor-pointer transition-all">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                            </button>
                            <button id="cora-device-mobile" onclick="switchDevice('mobile')" title="Mobile (375px)" class="w-7 h-7 rounded-md flex items-center justify-center text-zinc-500 hover:text-zinc-800 cursor-pointer transition-all">
                                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Right: Navigator, Publish -->
                <div class="flex items-center gap-2">
                    <button onclick="toggleNavigatorPanel()" class="h-8 px-3 hover:bg-zinc-50 text-zinc-700 rounded-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="6" y1="3" x2="6" y2="15"></line><circle cx="18" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><path d="M18 9a9 9 0 0 1-9 9"></path></svg>
                        Navigator
                    </button>
                    
                    <!-- Split Publish Button -->
                    <div class="inline-flex rounded-lg shadow-sm relative">
                        <button onclick="publishPage()" class="h-8 px-4 bg-zinc-900 hover:bg-zinc-800 text-white rounded-l-lg text-[11px] font-extrabold cursor-pointer transition-colors flex items-center justify-center">
                            Publish
                        </button>
                        <div class="w-[1px] h-8 bg-zinc-800 "></div>
                        <button onclick="togglePublishDropdown(event)" class="h-8 px-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-r-lg text-[11px] font-bold cursor-pointer transition-colors flex items-center justify-center">
                            <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                        </button>
                        <!-- Publish Dropdown Menu -->
                        <div id="cora-publish-dropdown" class="absolute right-0 top-10 w-40 bg-white border border-zinc-200 rounded-lg shadow-xl py-1 hidden z-50">
                            <button onclick="saveDraftPage(); togglePublishDropdown(event);" class="w-full text-left px-4 py-2 hover:bg-zinc-50 text-xs font-bold text-zinc-700 cursor-pointer">Save Draft</button>
                            <button onclick="saveTemplatePage(); togglePublishDropdown(event);" class="w-full text-left px-4 py-2 hover:bg-zinc-50 text-xs font-bold text-zinc-700 cursor-pointer">Save as Template</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- iframe container -->
        <div id="elementor-iframe-container" class="flex-1 min-h-0 w-full bg-zinc-50 relative flex items-center justify-center">

        <!-- Loading Indicator -->
            <div id="iframe-loader" class="absolute inset-0 flex flex-col items-center justify-center bg-white z-10 gap-3 text-xs text-zinc-500 font-semibold<?php echo $_editor_resume_url ? '' : ' hidden'; ?>">

                <div class="animate-spin rounded-full h-6 w-6 border-2 border-zinc-900 border-t-transparent"></div>
                <span>Spawning Elementor design workspace...</span>
            </div>

            <!-- Error/Blocking Display -->
            <div id="elementor-blocking-msg" class="max-w-md p-6 bg-white border border-zinc-200 rounded-xl shadow-lg text-center space-y-4 hidden z-20">
                <div class="w-12 h-12 bg-zinc-100 text-zinc-900 rounded-full flex items-center justify-center mx-auto">
                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>
                </div>
                <h4 class="text-sm font-bold text-zinc-900" id="elementor-blocking-title">Elementor Page Editor</h4>
                <p class="text-xs text-zinc-500 leading-relaxed" id="elementor-blocking-desc">If your browser security settings block iframe embedding, click below to open Elementor directly in a new tab.</p>
                <div class="flex items-center justify-center gap-3 pt-2">
                    <a id="cora-direct-elementor-card-btn" href="#" target="_blank" class="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 hidden" style="display: none !important;">
                        Launch Direct Editor →
                    </a>
                    <button type="button" onclick="jQuery('#iframe-loader').removeClass('hidden'); jQuery('#elementor-blocking-msg').addClass('hidden'); jQuery('#elementor-editor-iframe').removeClass('hidden').attr('src', jQuery('#elementor-editor-iframe').attr('src'));" class="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition-all">
                        Retry Loading
                    </button>
                </div>
            </div>

            <!-- Editor Iframe -->
            <iframe id="elementor-editor-iframe" onload="jQuery('#iframe-loader').addClass('hidden'); jQuery(this).removeClass('hidden');" src="<?php echo esc_url($_editor_resume_url); ?>" class="w-full h-full border-none<?php echo $_editor_resume_url ? '' : ' hidden'; ?>"></iframe>
        </div>
    </div>

    <!-- LEVEL 3-HTML — CORA AI VISUAL NO-CODE HTML CANVAS EDITOR -->
    <div id="canvas-level-3-html" class="fixed inset-0 z-[9999] bg-zinc-100 hidden flex flex-col select-none">
        
        <!-- Editor Topbar -->
        <div class="h-14 border-b border-zinc-200 flex items-center justify-between px-4 w-full bg-white z-20 shrink-0">
            <!-- Left: Logo & Navigation -->
            <div class="flex items-center gap-3">
                <div class="flex items-center gap-1.5 select-none shrink-0 mr-1">
                    <span class="text-xs font-black tracking-tight text-zinc-950 uppercase">CORA</span>
                    <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-zinc-900 text-white uppercase">HTML Canvas</span>
                </div>
                <button type="button" onclick="closeHtmlVisualEditor()" class="h-8 px-3 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5 bg-white">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    <span>Pages List</span>
                </button>
                <div class="h-4 w-[1px] bg-zinc-200 mx-1"></div>
                <!-- Breadcrumbs -->
                <div class="flex items-center gap-2 text-xs">
                    <span class="text-zinc-400 font-medium" id="cora-html-topbar-theme">Theme</span>
                    <span class="text-zinc-300">/</span>
                    <span class="text-zinc-950 font-bold max-w-[200px] truncate" id="cora-html-topbar-page">Page Title</span>
                    <span id="cora-html-status-pill" class="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-zinc-100 text-zinc-700 border border-zinc-200 uppercase">Draft</span>
                </div>
            </div>

            <!-- Center: Responsive Viewport Switcher & AI Score -->
            <div class="flex items-center gap-3">
                <!-- Device Viewports -->
                <div class="p-1 bg-zinc-100 rounded-xl flex items-center gap-0.5 border border-zinc-200/80">
                    <button type="button" id="cora-vp-btn-desktop" onclick="setHtmlEditorViewport('desktop')" class="px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all bg-white text-zinc-950 shadow-2xs flex items-center gap-1.5 cursor-pointer" title="Desktop Viewport (100%)">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                        <span class="text-[11px] hidden sm:inline">Desktop</span>
                    </button>
                    <button type="button" id="cora-vp-btn-tablet" onclick="setHtmlEditorViewport('tablet')" class="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-zinc-600 hover:text-zinc-950 transition-all flex items-center gap-1.5 cursor-pointer" title="Tablet Viewport (768px)">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                        <span class="text-[11px] hidden sm:inline">Tablet</span>
                    </button>
                    <button type="button" id="cora-vp-btn-mobile" onclick="setHtmlEditorViewport('mobile')" class="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-zinc-600 hover:text-zinc-950 transition-all flex items-center gap-1.5 cursor-pointer" title="Mobile Viewport (375px)">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                        <span class="text-[11px] hidden sm:inline">Mobile</span>
                    </button>
                </div>

                <!-- AI Score Pill -->
                <button type="button" onclick="openHtmlAiInsightsDrawer()" class="px-2.5 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-xl text-[11px] font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer" title="View AI Optimization & SEO Audit">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>AI Score 96</span>
                </button>
            </div>

            <!-- Right: Actions, AI Copilot, Save & Publish -->
            <div class="flex items-center gap-2">
                <!-- Mode Switcher -->
                <button type="button" id="cora-html-split-mode-btn" onclick="toggleHtmlSplitCodeView()" class="h-8 px-2.5 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5 bg-white" title="Toggle Code / Split View">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                    <span class="hidden md:inline">Code View</span>
                </button>

                <!-- AI Assistant Trigger -->
                <button type="button" onclick="openHtmlAiInsightsDrawer()" class="h-8 px-3 border border-zinc-200 hover:bg-zinc-50 text-zinc-900 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5 bg-white shadow-2xs">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-700"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                    <span>AI Copilot</span>
                </button>

                <!-- Live Preview Link -->
                <a id="cora-html-preview-ext-btn" href="#" target="_blank" class="h-8 px-3 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 rounded-lg text-xs font-bold cursor-pointer transition-colors flex items-center gap-1.5 bg-white">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                    <span class="hidden lg:inline">Preview</span>
                </a>

                <!-- Save & Publish Button -->
                <button type="button" id="cora-html-save-publish-btn" onclick="saveHtmlVisualEdits(true)" class="h-8 px-4 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer active:scale-95">
                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none" class="cora-html-save-icon"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span class="cora-html-save-label">Save &amp; Publish</span>
                </button>
            </div>
        </div>

        <!-- Editor Work Area (Canvas + Optional Code Split) -->
        <!-- Editor Work Area (Canvas + Optional Code Split) -->
        <div class="flex-1 flex overflow-hidden relative">
            
            <!-- Visual Canvas Container (Clean, unobstructed full height) -->
            <div id="cora-html-canvas-viewport-wrap" class="flex-1 bg-zinc-200/60 p-3 sm:p-5 flex items-center justify-center overflow-auto transition-all duration-300 relative">
                
                <!-- Loading State -->
                <div id="cora-html-editor-loader" class="absolute inset-0 bg-white/90 backdrop-blur-xs flex flex-col items-center justify-center z-30 gap-3">
                    <div class="animate-spin rounded-full h-7 w-7 border-2 border-zinc-950 border-t-transparent"></div>
                    <span class="text-xs font-bold text-zinc-900">Initializing AI Visual Canvas...</span>
                </div>

                <!-- Responsive Canvas Frame -->
                <div id="cora-html-canvas-frame" class="w-full h-full max-w-full bg-white transition-all duration-300 shadow-xl overflow-hidden relative rounded-xl border border-zinc-300/60">
                    <iframe id="cora-html-canvas-iframe" class="w-full h-full border-none bg-white"></iframe>
                </div>
            </div>

            <!-- Code Split View (With CodeMirror color coding & docked AI Prompt Box) -->
            <div id="cora-html-code-split-pane" class="w-1/2 border-l border-zinc-800 bg-[#18181b] text-zinc-100 hidden flex flex-col z-10 font-sans shadow-2xl">
                <!-- Code Editor Topbar -->
                <div class="h-11 px-3.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-400 bg-zinc-900 shrink-0">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-zinc-200">HTML Source</span>
                        <span id="cora-html-code-stats" class="text-[10px] text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded">0 lines</span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <button type="button" onclick="beautifyHtmlCode()" class="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded text-[10px] font-bold transition-colors flex items-center gap-1 cursor-pointer" title="Beautify & Format HTML with clean indentation">
                            <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                            <span>Format</span>
                        </button>
                        <button type="button" onclick="cleanHtmlExtensionArtifacts()" class="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded text-[10px] font-bold transition-colors flex items-center gap-1 cursor-pointer" title="Clean browser extension tags (Grammarly, etc.)">
                            <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                            <span>Clean Tags</span>
                        </button>
                        <button type="button" onclick="copyHtmlSourceCode()" class="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded text-[10px] font-bold transition-colors flex items-center gap-1 cursor-pointer" title="Copy HTML source code">
                            <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                            <span>Copy</span>
                        </button>
                        <button type="button" onclick="applyCodeChangesToVisual()" class="px-3 py-1 bg-white hover:bg-zinc-100 text-zinc-950 rounded text-[10px] font-bold transition-colors shadow-2xs cursor-pointer">
                            Apply to Canvas →
                        </button>
                    </div>
                </div>

                <!-- CodeMirror Syntax Color Coded Editor Area -->
                <div id="cora-html-cm-container" class="flex-1 min-h-0 overflow-hidden relative bg-[#18181b]">
                    <textarea id="cora-html-raw-editor-textarea" 
                        oninput="updateHtmlCodeStats()" 
                        onkeydown="handleCodeTextareaKeydown(event, this)" 
                        placeholder="Enter HTML & CSS code here..." 
                        class="w-full h-full p-4 font-mono text-xs text-zinc-100 bg-[#18181b] focus:outline-none resize-none leading-relaxed spellcheck-false" 
                        spellcheck="false"></textarea>
                </div>

                <!-- AI Quick Modification Box Docked Inside Code Editor -->
                <div id="cora-html-ai-prompt-bar" class="p-3 bg-zinc-900 border-t border-zinc-800 shrink-0 z-20 transition-all font-sans">
                    <div class="flex items-center gap-2">
                        <div class="flex items-center justify-center w-7 h-7 rounded-lg bg-zinc-800 text-white shrink-0 border border-zinc-700">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        </div>
                        <input type="text" id="cora-ai-prompt-input" 
                            placeholder="Ask AI to modify code (e.g. 'Change button color to black', 'Make cards dark theme', 'Polish copy')..." 
                            onkeydown="if(event.key==='Enter') triggerAiHtmlModification()" 
                            class="flex-1 bg-zinc-950 border border-zinc-700 focus:border-zinc-400 rounded-xl px-3 py-1.5 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none transition-all">
                        <button type="button" id="cora-ai-modify-submit-btn" onclick="triggerAiHtmlModification()" 
                            class="h-7 px-3.5 bg-white hover:bg-zinc-200 text-zinc-950 rounded-xl text-[11px] font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5 shrink-0 active:scale-95">
                            <span class="cora-ai-btn-text">Apply AI Edit</span>
                            <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2.5" fill="none" class="cora-ai-btn-icon"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        </button>
                    </div>
                    <!-- Quick Prompt Preset Chips -->
                    <div class="flex items-center gap-1.5 overflow-x-auto pt-2 text-[10px] select-none no-scrollbar">
                        <span class="text-zinc-500 font-semibold uppercase tracking-wider shrink-0 mr-1 text-[9px]">Suggestions:</span>
                        <button type="button" onclick="setAndRunAiPrompt('Refine and polish all heading & paragraph copy with punchy modern tone')" class="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold cursor-pointer transition-colors shrink-0">✨ Polish Copy</button>
                        <button type="button" onclick="setAndRunAiPrompt('Convert cards and background to a sleek dark monochromatic theme')" class="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold cursor-pointer transition-colors shrink-0">🎨 Dark Aesthetic</button>
                        <button type="button" onclick="setAndRunAiPrompt('Add smooth hover elevation, shadows and transition micro-interactions to cards')" class="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold cursor-pointer transition-colors shrink-0">✨ Hover Animations</button>
                        <button type="button" onclick="setAndRunAiPrompt('Optimize container padding, grid columns and typography for mobile responsiveness')" class="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold cursor-pointer transition-colors shrink-0">📱 Mobile Spacing</button>
                        <button type="button" onclick="setAndRunAiPrompt('Update image placeholder URLs with high-quality architectural Unsplash photography')" class="px-2 py-0.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold cursor-pointer transition-colors shrink-0">🖼️ Swap Photos</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    </div>

    <!-- ═══ FLOATING INLINE EDITING MODALS & TOOLBARS ════════════════════════════ -->

    <!-- 1. Floating Text / Heading Rich Toolbar -->
    <div id="cora-html-text-toolbar" class="fixed z-[100000] hidden bg-zinc-950 text-white border border-zinc-800 rounded-xl shadow-2xl p-1.5 flex items-center gap-1.5 animate-fade-in text-xs font-sans">
        <select id="cora-text-tag-select" onchange="applyTextTagChange(this.value)" class="bg-zinc-900 text-zinc-100 text-[11px] font-bold px-2 py-1 rounded-lg border border-zinc-700 focus:outline-none cursor-pointer">
            <option value="H1">H1 Heading</option>
            <option value="H2">H2 Subheading</option>
            <option value="H3">H3 Section</option>
            <option value="H4">H4 Small</option>
            <option value="P">Paragraph</option>
        </select>
        <div class="h-4 w-[1px] bg-zinc-800"></div>
        <button type="button" onclick="formatInlineText('bold')" class="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-zinc-800 text-zinc-200 hover:text-white font-bold" title="Bold">B</button>
        <button type="button" onclick="formatInlineText('italic')" class="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-zinc-800 text-zinc-200 hover:text-white italic font-serif" title="Italic">I</button>
        <button type="button" onclick="formatInlineText('underline')" class="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-zinc-800 text-zinc-200 hover:text-white underline" title="Underline">U</button>
        <div class="h-4 w-[1px] bg-zinc-800"></div>
        
        <!-- AI Polish Dropdown -->
        <div class="relative">
            <button type="button" onclick="toggleAiTextMenu(event)" class="px-2.5 py-1 bg-white text-zinc-950 font-bold rounded-lg text-[11px] flex items-center gap-1 hover:bg-zinc-100 cursor-pointer shadow-2xs">
                <span>✨ AI Polish</span>
                <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="6 9 12 15 18 9"></polyline></svg>
            </button>
            <div id="cora-ai-text-menu" class="hidden absolute left-0 bottom-full mb-2 w-48 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl py-1 z-50 text-left">
                <button type="button" onclick="runAiTextRewrite('punchier')" class="w-full px-3 py-1.5 text-left text-[11px] text-zinc-200 hover:bg-zinc-800 hover:text-white flex items-center gap-2">
                    <span>⚡</span>
                    <span>Make Punchier</span>
                </button>
                <button type="button" onclick="runAiTextRewrite('professional')" class="w-full px-3 py-1.5 text-left text-[11px] text-zinc-200 hover:bg-zinc-800 hover:text-white flex items-center gap-2">
                    <span>👔</span>
                    <span>Executive / Corporate</span>
                </button>
                <button type="button" onclick="runAiTextRewrite('shorten')" class="w-full px-3 py-1.5 text-left text-[11px] text-zinc-200 hover:bg-zinc-800 hover:text-white flex items-center gap-2">
                    <span>✂️</span>
                    <span>Shorten by 50%</span>
                </button>
                <button type="button" onclick="runAiTextRewrite('headline')" class="w-full px-3 py-1.5 text-left text-[11px] text-zinc-200 hover:bg-zinc-800 hover:text-white flex items-center gap-2">
                    <span>🎯</span>
                    <span>Magnetic Headline</span>
                </button>
                <button type="button" onclick="runAiTextRewrite('fix_grammar')" class="w-full px-3 py-1.5 text-left text-[11px] text-zinc-200 hover:bg-zinc-800 hover:text-white flex items-center gap-2">
                    <span>✨</span>
                    <span>Fix Grammar &amp; Flow</span>
                </button>
            </div>
        </div>
    </div>

    <!-- 2. Floating Image & Asset Replacer Popover Card -->
    <div id="cora-html-image-popover" class="fixed z-[100000] hidden bg-white border border-zinc-200 rounded-2xl shadow-2xl p-5 w-80 space-y-4 animate-fade-in font-sans">
        <div class="flex items-center justify-between border-b border-zinc-100 pb-2.5">
            <h4 class="text-xs font-bold text-zinc-950 flex items-center gap-1.5">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                <span>Replace Image Asset</span>
            </h4>
            <button type="button" onclick="closeImageReplacerPopover()" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>

        <!-- Image Preview -->
        <div class="h-28 bg-zinc-100 rounded-xl overflow-hidden border border-zinc-200 flex items-center justify-center relative group">
            <img id="cora-image-preview-thumb" src="" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span class="text-[10px] font-bold text-white uppercase tracking-wider">Active Image</span>
            </div>
        </div>

        <!-- Replacement Controls -->
        <div class="space-y-2.5">
            <div>
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">Image URL</label>
                <input type="text" id="cora-image-url-input" oninput="updateImagePreviewThumb(this.value)" placeholder="https://..." class="w-full px-3 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-mono">
            </div>
            <div>
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">SEO Alt Text</label>
                <input type="text" id="cora-image-alt-input" placeholder="e.g. Modern Architecture Living Room" class="w-full px-3 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center justify-end gap-2 pt-1 border-t border-zinc-100">
            <button type="button" onclick="closeImageReplacerPopover()" class="px-3 py-1.5 border border-zinc-200 text-zinc-600 rounded-lg text-xs font-semibold hover:bg-zinc-50">Cancel</button>
            <button type="button" onclick="applyImageReplacement()" class="px-4 py-1.5 bg-zinc-950 text-white rounded-lg text-xs font-bold hover:bg-zinc-800 shadow-2xs">Apply Image</button>
        </div>
    </div>

    <!-- 3. Floating Button & Link Action Inspector -->
    <div id="cora-html-link-popover" class="fixed z-[100000] hidden bg-white border border-zinc-200 rounded-2xl shadow-2xl p-5 w-80 space-y-4 animate-fade-in font-sans">
        <div class="flex items-center justify-between border-b border-zinc-100 pb-2.5">
            <h4 class="text-xs font-bold text-zinc-950 flex items-center gap-1.5">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                <span>Edit Link / Button Action</span>
            </h4>
            <button type="button" onclick="closeLinkInspectorPopover()" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>

        <div class="space-y-3">
            <div>
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">Button / Link Label</label>
                <input type="text" id="cora-link-label-input" placeholder="e.g. Schedule a Tour" class="w-full px-3 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
            <div>
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">Destination URL</label>
                <input type="text" id="cora-link-href-input" placeholder="e.g. /contact or https://..." class="w-full px-3 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-mono">
            </div>
        </div>

        <div class="flex items-center justify-end gap-2 pt-1 border-t border-zinc-100">
            <button type="button" onclick="closeLinkInspectorPopover()" class="px-3 py-1.5 border border-zinc-200 text-zinc-600 rounded-lg text-xs font-semibold hover:bg-zinc-50">Cancel</button>
            <button type="button" onclick="applyLinkChanges()" class="px-4 py-1.5 bg-zinc-950 text-white rounded-lg text-xs font-bold hover:bg-zinc-800 shadow-2xs">Update Action</button>
        </div>
    </div>

    <!-- 4. AI Assistant & Insights Side Drawer -->
    <div id="drawer-html-ai-insights" class="fixed inset-0 z-[100001] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
        <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[420px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-html-ai-insights-card">
            
            <!-- Drawer Header -->
            <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
                <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <h3 class="text-sm font-bold text-zinc-950">AI Optimizer &amp; Insights</h3>
                </div>
                <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 rounded-lg hover:bg-zinc-100" onclick="closeHtmlAiInsightsDrawer()">
                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>

            <!-- Drawer Content -->
            <div class="flex-1 overflow-y-auto p-6 space-y-6">
                
                <!-- Performance KPI Cards -->
                <div class="grid grid-cols-3 gap-2">
                    <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-center">
                        <div class="text-[10px] font-bold text-zinc-500 uppercase">LCP</div>
                        <div class="text-sm font-bold text-emerald-600 font-mono mt-0.5">1.2s</div>
                        <div class="text-[9px] text-zinc-400">Fast</div>
                    </div>
                    <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-center">
                        <div class="text-[10px] font-bold text-zinc-500 uppercase">FID / INP</div>
                        <div class="text-sm font-bold text-emerald-600 font-mono mt-0.5">&lt;10ms</div>
                        <div class="text-[9px] text-zinc-400">Instant</div>
                    </div>
                    <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-center">
                        <div class="text-[10px] font-bold text-zinc-500 uppercase">CLS</div>
                        <div class="text-sm font-bold text-emerald-600 font-mono mt-0.5">0.00</div>
                        <div class="text-[9px] text-zinc-400">Stable</div>
                    </div>
                </div>

                <!-- 1-Click AI Optimization Button -->
                <div class="p-4 bg-zinc-950 text-white rounded-2xl space-y-2.5">
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-bold tracking-tight">Autonomous AI Optimization</span>
                        <span class="px-2 py-0.5 bg-zinc-800 text-emerald-400 rounded-full text-[9px] font-mono font-bold">Active</span>
                    </div>
                    <p class="text-[11px] text-zinc-300 leading-relaxed">Runs lazy-loading injection, viewport meta validation, semantic heading structure, and asset compression.</p>
                    <button type="button" onclick="triggerReRunAiOptimization()" class="w-full py-2 bg-white hover:bg-zinc-100 text-zinc-950 font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5">
                        <span>✨ Re-Run AI Optimization</span>
                    </button>
                </div>

                <!-- Editable Elements Inventory -->
                <div class="space-y-3">
                    <h4 class="text-xs font-bold text-zinc-950 uppercase tracking-wider">Page Elements Inventory</h4>
                    <div id="cora-html-inventory-list" class="space-y-2">
                        <!-- Rendered dynamically -->
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- ═══ MODAL SLIDING DRAWERS ════════════════════════════════════════════════════ -->

<!-- 0. Import Kit / Theme Drawer -->
<div id="drawer-import-kit" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-import-kit-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <h3 class="text-sm font-bold text-zinc-950">Import Template Kit / Theme</h3>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeImportKitDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-6">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Theme Workspace Name *</label>
                <input type="text" id="import-kit-name-input" placeholder="e.g. Westside Luxury Catalog" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Upload ZIP Kit / Theme *</label>
                <div class="border-2 border-dashed border-zinc-200 rounded-xl p-8 text-center bg-zinc-50 hover:bg-zinc-100/50 transition-colors relative cursor-pointer group animate-fade-in" onclick="document.getElementById('import-kit-file-input').click()">
                    <input type="file" id="import-kit-file-input" accept=".zip" class="hidden">
                    <svg viewBox="0 0 24 24" width="32" height="32" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-400 mx-auto mb-3 group-hover:text-zinc-600 transition-colors"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                    <div class="text-xs font-semibold text-zinc-900" id="import-file-name-display">Click to select or drag & drop ZIP here</div>
                    <p class="text-[9px] text-zinc-400 mt-1">Accepts Elementor Template Kits (.zip) or Elementor-compatible themes</p>
                </div>
            </div>
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end gap-3 bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeImportKitDrawer()">Cancel</button>
            <button type="button" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="triggerImportKit()">Import Kit</button>
        </div>
    </div>
</div>

<!-- GitHub Connection Drawer -->
<div id="drawer-github-connect" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-github-connect-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <h3 class="text-sm font-bold text-zinc-950">Connect from GitHub</h3>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeGithubConnectDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-6">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">GitHub Repository URL *</label>
                <input type="text" id="github-repo-input" placeholder="e.g. username/repo-name or https://github.com/..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Branch *</label>
                <input type="text" id="github-branch-input" placeholder="main" value="main" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Personal Access Token (PAT)</label>
                <input type="password" id="github-pat-input" placeholder="Required for private repositories" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                <p class="text-[9px] text-zinc-400">Optional: Used to read private repository data.</p>
            </div>
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end gap-3 bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeGithubConnectDrawer()">Cancel</button>
            <button type="button" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="triggerGithubConnect()">Connect Repository</button>
        </div>
    </div>
</div>

<!-- Cora Hub Drawer -->
<div id="drawer-cora-hub" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-cora-hub-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <h3 class="text-sm font-bold text-zinc-950">Browse Free Themes</h3>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeCoraHubDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-5">
            <p class="text-[11px] text-zinc-500 leading-normal">Choose from one of our professional, mobile-optimized free theme layouts to jumpstart your storefront workspace.</p>
            
            <!-- Hub theme options grid -->
            <div class="space-y-4">
                <!-- Dawn Theme -->
                <div class="border border-zinc-200 rounded-xl p-4 flex gap-4 bg-white hover:border-zinc-300 transition-colors">
                    <img src="<?php echo esc_url( CORA_WORKSPACE_URL . 'assets/images/cora-cro-l2-preview.jpg' ); ?>" class="w-24 h-16 rounded-lg object-cover border border-zinc-200 shrink-0 select-none" loading="lazy">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <h4 class="text-xs font-bold text-zinc-900">Dawn</h4>
                            <span class="px-1.5 py-0.5 text-[8.5px] font-bold text-zinc-500 bg-zinc-100 rounded">v15.5.0</span>
                        </div>
                        <p class="text-[10px] text-zinc-400 mt-1 line-clamp-2">A chic, minimalist theme for modern fashion retail and chic catalogs.</p>
                        <button onclick="installHubTheme('Dawn', 2)" class="mt-2.5 px-3 py-1 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all border-none shadow-xs">Install</button>
                    </div>
                </div>
                
                <!-- Refresh Theme -->
                <div class="border border-zinc-200 rounded-xl p-4 flex gap-4 bg-white hover:border-zinc-300 transition-colors">
                    <img src="<?php echo esc_url( CORA_WORKSPACE_URL . 'assets/images/cosmetics-pink-preview.jpg' ); ?>" class="w-24 h-16 rounded-lg object-cover border border-zinc-200 shrink-0 select-none" loading="lazy">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <h4 class="text-xs font-bold text-zinc-900">Refresh</h4>
                            <span class="px-1.5 py-0.5 text-[8.5px] font-bold text-zinc-500 bg-zinc-100 rounded">v15.5.0</span>
                        </div>
                        <p class="text-[10px] text-zinc-400 mt-1 line-clamp-2">A fresh cosmetic/skincare theme design with light colors and product catalog.</p>
                        <button onclick="installHubTheme('Refresh', 3)" class="mt-2.5 px-3 py-1 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all border-none shadow-xs">Install</button>
                    </div>
                </div>

                <!-- Horizon Theme -->
                <div class="border border-zinc-200 rounded-xl p-4 flex gap-4 bg-white hover:border-zinc-300 transition-colors">
                    <img src="<?php echo esc_url( CORA_WORKSPACE_URL . 'assets/images/horizon-preview.jpg' ); ?>" class="w-24 h-16 rounded-lg object-cover border border-zinc-200 shrink-0 select-none" loading="lazy">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <h4 class="text-xs font-bold text-zinc-900">Horizon</h4>
                            <span class="px-1.5 py-0.5 text-[8.5px] font-medium text-zinc-400 bg-zinc-50 border border-zinc-200 rounded">N/A</span>
                        </div>
                        <p class="text-[10px] text-zinc-400 mt-1 line-clamp-2">A clean landscape/cartoon outline vector style illustration design.</p>
                        <button onclick="installHubTheme('Horizon', 5)" class="mt-2.5 px-3 py-1 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-[10px] font-bold cursor-pointer transition-all border-none shadow-xs">Install</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeCoraHubDrawer()">Close</button>
        </div>
    </div>
</div>

<!-- 1. New Theme Setup Modal (Centered Popup) -->
<div id="drawer-new-theme" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-md space-y-4 transform scale-95 transition-transform duration-300" id="drawer-new-theme-card">
        <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-zinc-950">Initialize New Theme</h3>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeNewThemeDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="space-y-4">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Theme Name *</label>
                <input type="text" id="new-theme-name-input" placeholder="e.g. Westside Luxury Catalog" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Start From Structure</label>
                <div class="grid grid-cols-1 gap-2.5">
                    <label class="border border-zinc-200 rounded-xl p-3 flex items-start gap-2.5 cursor-pointer hover:bg-zinc-50 transition-colors">
                        <input type="radio" name="new-theme-source" value="blank" checked class="mt-1 accent-zinc-950">
                        <div>
                            <div class="text-[11px] font-bold text-zinc-900">Blank Layout</div>
                            <p class="text-[9px] text-zinc-500 mt-0.5">Empty theme workspace. Create pages as required.</p>
                        </div>
                    </label>
                    <label class="border border-zinc-200 rounded-xl p-3 flex items-start gap-2.5 cursor-pointer hover:bg-zinc-50 transition-colors">
                        <input type="radio" name="new-theme-source" value="duplicate" class="mt-1 accent-zinc-950">
                        <div>
                            <div class="text-[11px] font-bold text-zinc-900">Duplicate Active</div>
                            <p class="text-[9px] text-zinc-500 mt-0.5">Copies the current live theme settings and page lists as a draft.</p>
                        </div>
                    </label>
                    <label class="border border-zinc-200 rounded-xl p-3 flex items-start gap-2.5 cursor-pointer hover:bg-zinc-50 transition-colors">
                        <input type="radio" name="new-theme-source" value="template" class="mt-1 accent-zinc-950">
                        <div>
                            <div class="text-[11px] font-bold text-zinc-900">From Template</div>
                            <p class="text-[9px] text-zinc-500 mt-0.5">Incorporate Cora agency themes (Real Estate Minimal / Premium Villa Brokerage).</p>
                        </div>
                    </label>
                </div>
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeNewThemeDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="saveNewTheme()">Create Theme</button>
        </div>
    </div>
</div>

<!-- 2. New Page Setup Modal (Centered Popup with Dual-Engine Creation) -->
<div id="drawer-new-page" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-2xl shadow-2xl p-6 w-full max-w-lg space-y-4 transform scale-95 transition-transform duration-300" id="drawer-new-page-card">
        
        <!-- Header -->
        <div class="flex items-center justify-between border-b border-zinc-100 pb-3">
            <div>
                <h3 class="text-sm font-bold text-zinc-950 flex items-center gap-2">
                    <span>Add Page to Theme</span>
                    <span id="cora-page-engine-badge" class="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-zinc-100 text-zinc-700 border border-zinc-200 uppercase">Elementor</span>
                </h3>
                <p class="text-[11px] text-zinc-500 mt-0.5">Choose how you want to build this page.</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 rounded-lg hover:bg-zinc-100 transition-colors" onclick="closeNewPageDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>

        <!-- Creation Method Segmented Selector -->
        <div class="p-1 bg-zinc-100 rounded-xl flex items-center gap-1 border border-zinc-200/80">
            <button type="button" id="cora-engine-tab-elementor" onclick="switchPageEngineMode('elementor')" class="flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all bg-white text-zinc-950 shadow-2xs flex items-center justify-center gap-2 cursor-pointer">
                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>
                <span>Elementor Builder</span>
            </button>
            <button type="button" id="cora-engine-tab-html" onclick="switchPageEngineMode('html')" class="flex-1 py-2 px-3 rounded-lg text-xs font-semibold text-zinc-600 hover:text-zinc-950 transition-all flex items-center justify-center gap-2 cursor-pointer">
                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                <span>Upload HTML (AI Smart Canvas)</span>
            </button>
        </div>

        <!-- 1-Click Migrator Banner for Elementor -->
        <div id="cora-elementor-migrator-banner" class="p-2.5 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between">
            <div class="flex items-center gap-2">
                <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-700 shrink-0"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                <span class="text-[11px] text-zinc-700 font-semibold">Have an existing Elementor site?</span>
            </div>
            <button type="button" onclick="closeNewPageDrawer(); openElementorMigrationDrawer();" class="text-[11px] font-bold text-zinc-950 hover:underline cursor-pointer">Use 1-Click Migrator →</button>
        </div>

        <!-- HTML Upload & AI Optimization Panel (Hidden when Elementor active) -->
        <div id="cora-html-upload-panel" class="hidden space-y-3">
            <!-- Dropzone -->
            <div id="cora-html-file-dropzone" class="border-2 border-dashed border-zinc-200 hover:border-zinc-400 bg-zinc-50/70 hover:bg-zinc-50 rounded-xl p-5 text-center cursor-pointer transition-all relative group" onclick="document.getElementById('cora-html-file-input').click()">
                <input type="file" id="cora-html-file-input" accept=".html,.htm,.zip,.txt" class="hidden" onchange="handleHtmlFileSelect(this)">
                <svg viewBox="0 0 24 24" width="28" height="28" stroke="currentColor" stroke-width="1.8" fill="none" class="text-zinc-400 group-hover:text-zinc-800 mx-auto mb-2 transition-colors"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                <div class="text-xs font-bold text-zinc-900" id="cora-html-file-label">Click to select or drag &amp; drop HTML / ZIP file here</div>
                <p class="text-[10px] text-zinc-400 mt-0.5">Supports clean HTML5, Tailwind, Webflow/Framer exports, or ZIP with assets</p>
            </div>

            <!-- Paste Code Toggle -->
            <div class="text-right">
                <button type="button" onclick="toggleHtmlPasteBox()" class="text-[11px] font-semibold text-zinc-600 hover:text-zinc-950 underline cursor-pointer" id="cora-toggle-paste-btn">Or paste raw HTML code</button>
            </div>
            <div id="cora-html-paste-box" class="hidden space-y-1">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Paste Raw HTML Code</label>
                <textarea id="cora-html-paste-input" rows="4" oninput="handleHtmlPasteChange(this)" placeholder="<!DOCTYPE html><html><head>...</head><body>...</body></html>" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-400"></textarea>
            </div>

            <!-- Live Telemetry Inspector Badge -->
            <div id="cora-html-telemetry-badge" class="hidden p-3 bg-zinc-950 text-white rounded-xl space-y-1.5 animate-fade-in">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span class="text-xs font-bold tracking-tight" id="cora-html-detected-title">Page Title</span>
                    </div>
                    <span class="px-2 py-0.5 bg-zinc-800 border border-zinc-700 rounded-md text-[9px] font-mono text-emerald-400 font-bold">✨ AI Optimization Ready</span>
                </div>
                <div class="flex items-center gap-4 text-[10px] text-zinc-300 pt-0.5 border-t border-zinc-800">
                    <span id="cora-html-stat-headings">0 Headings</span>
                    <span>•</span>
                    <span id="cora-html-stat-images">0 Media Assets</span>
                    <span>•</span>
                    <span id="cora-html-stat-buttons">0 CTA Buttons</span>
                    <span>•</span>
                    <span class="text-emerald-300 font-semibold">1-Click Visual Editable</span>
                </div>
            </div>
        </div>

        <!-- Form Inputs -->
        <div class="space-y-3.5">
            <div class="space-y-1.5">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Page Title *</label>
                <input type="text" id="new-page-title-input" onkeyup="autoGenerateSlug(this)" placeholder="e.g. Featured Penthouse Listings" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
            <div class="space-y-1.5">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">URL Slug Path *</label>
                <input type="text" id="new-page-slug-input" placeholder="e.g. penthouse-listings" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
            <div class="grid grid-cols-2 gap-3.5">
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Page Layout</label>
                    <select id="new-page-template-input" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer bg-white font-medium">
                        <option value="canvas">Canvas (Standalone Clean HTML - Recommended)</option>
                        <option value="default">Default (Wrap with Theme Header &amp; Footer)</option>
                    </select>
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Status</label>
                    <select id="new-page-status-input" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer bg-white font-medium">
                        <option value="draft">Draft</option>
                        <option value="published">Published</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center justify-end gap-2.5 pt-2 border-t border-zinc-100">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeNewPageDrawer()">Cancel</button>
            <button type="button" id="cora-create-page-only-btn" class="px-3.5 py-2 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="saveNewPage(false)">Create Only</button>
            <button type="button" id="cora-create-and-edit-btn" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center gap-1.5" onclick="saveNewPage(true)">
                <span id="cora-create-edit-text">Create &amp; Edit</span>
            </button>
        </div>
    </div>
</div>

<!-- 2.2. 1-Click Elementor Migration Modal (Centered Notion/Shopify Popup) -->
<div id="drawer-elementor-migration" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[2px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <script>
    window.switchBlueprintTab = function(tab) {
        var btnPages = document.getElementById('blueprint-tab-btn-pages');
        var btnCompat = document.getElementById('blueprint-tab-btn-compat');
        var panelPages = document.getElementById('blueprint-panel-pages');
        var panelCompat = document.getElementById('blueprint-panel-compat');

        if (btnPages) {
            btnPages.className = tab === 'pages'
                ? 'flex-1 py-1.5 px-3 text-xs font-bold rounded-lg transition-all bg-white text-zinc-950 shadow-2xs'
                : 'flex-1 py-1.5 px-3 text-xs font-semibold text-zinc-600 hover:text-zinc-950 rounded-lg transition-all';
        }
        if (btnCompat) {
            btnCompat.className = tab === 'compatibility'
                ? 'flex-1 py-1.5 px-3 text-xs font-bold rounded-lg transition-all bg-white text-zinc-950 shadow-2xs'
                : 'flex-1 py-1.5 px-3 text-xs font-semibold text-zinc-600 hover:text-zinc-950 rounded-lg transition-all';
        }
        if (panelPages) {
            if (tab === 'pages') { panelPages.classList.remove('hidden'); } else { panelPages.classList.add('hidden'); }
        }
        if (panelCompat) {
            if (tab === 'compatibility') { panelCompat.classList.remove('hidden'); } else { panelCompat.classList.add('hidden'); }
        }
    };
    </script>
    <div class="bg-white border border-zinc-200 rounded-2xl shadow-2xl p-6 sm:p-7 w-full max-w-xl space-y-4 transform scale-95 transition-transform duration-300 max-h-[90vh] overflow-y-auto" id="drawer-elementor-migration-card">
        
        <!-- Header -->
        <div class="flex items-start justify-between border-b border-zinc-100 pb-3.5">
            <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-zinc-100 border border-zinc-200 flex items-center justify-center shrink-0">
                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-900"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-950 tracking-tight">Migrate Website</h3>
                    <p class="text-[11px] text-zinc-500">Import any live website or template kit into an isolated Draft Theme.</p>
                </div>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1.5 rounded-lg hover:bg-zinc-100 transition-colors" onclick="closeElementorMigrationDrawer()">
                <svg viewBox="0 0 24 24" width="15" height="15" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>

        <!-- Migration Source Tabs -->
        <div class="flex items-center p-1 bg-zinc-100 rounded-xl gap-1">
            <button type="button" onclick="switchElementorMigrateTab('html_url')" id="elem-tab-btn-html_url" class="flex-1 py-1.5 px-3 text-xs font-bold rounded-lg transition-all bg-white text-zinc-950 shadow-2xs">
                Live URL (Any Site)
            </button>
            <button type="button" onclick="switchElementorMigrateTab('url')" id="elem-tab-btn-url" class="flex-1 py-1.5 px-3 text-xs font-semibold text-zinc-600 hover:text-zinc-950 rounded-lg transition-all">
                WordPress &amp; Elementor
            </button>
            <button type="button" onclick="switchElementorMigrateTab('upload')" id="elem-tab-btn-upload" class="flex-1 py-1.5 px-3 text-xs font-semibold text-zinc-600 hover:text-zinc-950 rounded-lg transition-all">
                Upload File
            </button>
        </div>

        <!-- ══ TAB 0: Universal Website (HTML/CSS/JS) Scanner & Importer ══ -->
        <div id="elem-tab-panel-html_url" class="space-y-4">

            <!-- Step 1: Input URL -->
            <div id="html-url-step-input" class="space-y-3 pt-1">
                <div class="space-y-2">
                    <label class="block text-[11px] font-bold text-zinc-700">Enter live website URL</label>
                    <div class="flex items-center gap-2">
                        <div class="relative flex-1">
                            <input type="url" id="html-migrate-url-input" placeholder="https://example.com or yoursite.com" class="w-full pl-3.5 pr-3 py-2.5 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:border-zinc-950 font-medium bg-zinc-50/50" onkeydown="if(event.key==='Enter'){event.preventDefault();triggerScanHtmlUrl();}">
                        </div>
                        <button type="button" onclick="triggerScanHtmlUrl()" id="html-btn-scan-url" class="px-4 py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            <span>Scan Website</span>
                        </button>
                    </div>
                </div>

                <!-- Subtle feature notes -->
                <div class="p-3 bg-zinc-50 border border-zinc-200/80 rounded-xl flex items-center justify-between text-[11px] text-zinc-600">
                    <div class="flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                        <span>Full static layout, stylesheets, Google Fonts &amp; images preserved</span>
                    </div>
                    <span class="text-[10px] font-mono text-zinc-400">100% Isolated Draft</span>
                </div>
            </div>

            <!-- Step 2: Blueprint & Selection View -->
            <div id="html-url-step-pages" class="space-y-3.5 hidden">
                <!-- Site Identity Bar -->
                <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between">
                    <div class="space-y-0.5 min-w-0 flex-1 mr-3">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                            <span class="text-xs font-bold text-zinc-950 truncate" id="html-scan-site-name">Website Name</span>
                            <span class="text-[10px] font-mono text-zinc-400 truncate" id="html-scan-site-url">example.com</span>
                        </div>
                        <div class="flex flex-wrap items-center gap-1 pt-0.5" id="html-scan-tech-chips">
                            <!-- Populated dynamically -->
                        </div>
                    </div>
                    <button type="button" onclick="resetHtmlScan()" class="text-[11px] font-semibold text-zinc-500 hover:text-zinc-900 underline shrink-0 cursor-pointer">Change URL</button>
                </div>

                <!-- Destination Theme Pill -->
                <div class="px-3 py-2 bg-zinc-50/70 border border-zinc-200/80 rounded-xl flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2 min-w-0">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-600 shrink-0"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                        <span class="text-zinc-500 text-[11px]">Destination: <strong id="html-scan-draft-name" class="text-zinc-900 font-mono">Draft Theme</strong></span>
                    </div>
                    <span class="text-[9px] font-mono font-bold uppercase bg-zinc-100 text-zinc-700 px-2 py-0.5 rounded border border-zinc-200">Safe Draft</span>
                </div>

                <!-- Pages Selection List -->
                <div class="space-y-1.5">
                    <div class="flex items-center justify-between text-xs font-bold text-zinc-700">
                        <span>Select Pages to Migrate (<span id="html-selected-pages-count">0</span>):</span>
                        <button type="button" onclick="toggleSelectAllHtmlPages(this)" id="html-btn-select-all" class="text-[11px] text-zinc-500 hover:text-zinc-900 font-semibold cursor-pointer">Deselect All</button>
                    </div>
                    <div class="border border-zinc-200 rounded-xl divide-y divide-zinc-100 max-h-44 overflow-y-auto bg-white shadow-2xs" id="html-scanned-pages-list">
                        <!-- Dynamically populated -->
                    </div>
                </div>

                <!-- Options -->
                <div class="p-2.5 bg-zinc-50/80 border border-zinc-200/70 rounded-xl space-y-1.5 text-left text-[11px]">
                    <label class="flex items-center gap-2 font-medium text-zinc-700 cursor-pointer">
                        <input type="checkbox" id="html-opt-normalize-links" checked class="accent-zinc-950 rounded">
                        <span>Normalize internal links to Canvas routes</span>
                    </label>
                    <label class="flex items-center gap-2 font-medium text-zinc-700 cursor-pointer">
                        <input type="checkbox" id="html-opt-clean-trackers" checked class="accent-zinc-950 rounded">
                        <span>Strip 3rd-party tracking scripts (Analytics, Pixels)</span>
                    </label>
                </div>

                <div class="flex items-center justify-end pt-2 border-t border-zinc-100 gap-2">
                    <button type="button" onclick="resetHtmlScan()" class="px-3.5 py-2 border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer">Cancel</button>
                    <button type="button" onclick="triggerMigrateHtmlPages()" id="html-btn-start-migrate" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs active:scale-95 flex items-center gap-1.5">
                        <span id="html-btn-start-migrate-label">Start Migration</span>
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                </div>
            </div>

            <!-- Step 3: Migration Progress -->
            <div id="html-url-step-progress" class="space-y-3.5 hidden p-6 bg-zinc-50 rounded-2xl border border-zinc-200/80 text-center">
                <div class="w-8 h-8 rounded-full border-2 border-zinc-950 border-t-transparent animate-spin mx-auto"></div>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-bold text-zinc-950" id="html-progress-title">Migrating HTML/CSS Pages...</h4>
                    <p class="text-[11px] text-zinc-500" id="html-progress-sub">Extracting layouts, stylesheets, and assets...</p>
                </div>
                <div class="w-full bg-zinc-200 rounded-full h-1.5 overflow-hidden">
                    <div id="html-progress-bar" class="bg-zinc-950 h-full rounded-full transition-all duration-300" style="width: 10%;"></div>
                </div>
            </div>

            <!-- Step 4: Success Result -->
            <div id="html-url-step-success" class="space-y-4 hidden p-6 bg-zinc-50 rounded-2xl border border-zinc-200/80 text-center">
                <div class="w-9 h-9 rounded-full bg-zinc-950 text-white flex items-center justify-center mx-auto shadow-xs">
                    <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="20 6 9 17 4 12"></polyline></svg>
                </div>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-bold text-zinc-950" id="html-success-heading">Migration Complete!</h4>
                    <p class="text-[11px] text-zinc-600" id="html-success-detail">All selected HTML pages successfully migrated into Cora Canvas Draft Theme.</p>
                </div>
                <div class="flex items-center justify-center gap-2.5 pt-1">
                    <button type="button" onclick="closeElementorMigrationDrawer(); if(typeof coraReloadCanvasThemeTable==='function'){coraReloadCanvasThemeTable();}else{window.location.reload();}" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-100 text-zinc-800 font-semibold rounded-xl text-xs transition-colors cursor-pointer">
                        View in Canvas
                    </button>
                    <a id="html-btn-preview-draft" href="#" target="_blank" class="px-3.5 py-2 border border-zinc-950 bg-white hover:bg-zinc-100 text-zinc-950 font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs inline-flex items-center gap-1.5">
                        <span>Preview Site</span>
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                    </a>
                    <button type="button" onclick="openMigratedHtmlFirstPage()" id="html-btn-open-canvas" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs">
                        Open Editor →
                    </button>
                </div>
            </div>
        </div>

        <!-- ══ TAB 1: Live Website URL Scanner & Importer (WordPress & Elementor) ══ -->
        <div id="elem-tab-panel-url" class="space-y-4 hidden">
            
            <!-- Step 1: Input URL -->
            <div id="elem-url-step-input" class="space-y-3 pt-1">
                <div class="space-y-2">
                    <label class="block text-[11px] font-bold text-zinc-700">Enter WordPress / Elementor URL</label>
                    <div class="flex items-center gap-2">
                        <input type="url" id="elem-migrate-url-input" placeholder="https://my-old-website.com" class="flex-1 px-3.5 py-2.5 border border-zinc-200 rounded-xl text-xs focus:outline-none focus:border-zinc-950 font-medium bg-zinc-50/50" onkeydown="if(event.key==='Enter'){event.preventDefault();triggerScanElementorUrl();}">
                        <button type="button" onclick="triggerScanElementorUrl()" id="elem-btn-scan-url" class="px-4 py-2.5 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all shrink-0 flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95">
                            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            <span>Inspect Site</span>
                        </button>
                    </div>
                </div>
                <div class="p-3 bg-zinc-50 border border-zinc-200/80 rounded-xl flex items-center justify-between text-[11px] text-zinc-600">
                    <div class="flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                        <span>Inspects active theme, Elementor containers &amp; plugin widgets</span>
                    </div>
                    <span class="text-[10px] font-mono text-zinc-400">Pre-Import Blueprint</span>
                </div>
            </div>

            <!-- Step 2: Pre-Migration Blueprint & Inspection View -->
            <div id="elem-url-step-pages" class="space-y-3.5 hidden">
                <!-- Site Identity Bar -->
                <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between">
                    <div class="space-y-0.5 min-w-0 flex-1 mr-3">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                            <span class="text-xs font-bold text-zinc-950 truncate" id="elem-scan-site-name">Website Name</span>
                            <span class="text-[10px] font-mono text-zinc-400 truncate" id="elem-scan-site-url">example.com</span>
                        </div>
                        <p class="text-[11px] text-zinc-500 truncate" id="elem-scan-status-text">Detected Theme • Elementor v3.x • X Pages</p>
                    </div>
                    <button type="button" onclick="resetElementorScan()" class="text-[11px] font-semibold text-zinc-500 hover:text-zinc-900 underline shrink-0 cursor-pointer">Change URL</button>
                </div>

                <!-- Destination Callout -->
                <div class="px-3 py-2 bg-zinc-50/70 border border-zinc-200/80 rounded-xl flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2 min-w-0">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-600 shrink-0"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                        <span class="text-zinc-500 text-[11px]">Destination: <strong id="elem-scan-draft-name" class="text-zinc-900 font-mono">Imported - Website</strong></span>
                    </div>
                    <span class="text-[9px] font-mono font-bold uppercase bg-zinc-100 text-zinc-700 px-2 py-0.5 rounded border border-zinc-200">Draft Theme</span>
                </div>

                <!-- Sub-Navigation Selector for Blueprint -->
                <div class="flex items-center p-1 bg-zinc-100 rounded-xl gap-1">
                    <button type="button" onclick="switchBlueprintTab('pages')" id="blueprint-tab-btn-pages" class="flex-1 py-1.5 px-3 text-xs font-bold rounded-lg transition-all bg-white text-zinc-950 shadow-2xs">
                        <span id="blueprint-pages-tab-label">Pages to Import</span>
                    </button>
                    <button type="button" onclick="switchBlueprintTab('compatibility')" id="blueprint-tab-btn-compat" class="flex-1 py-1.5 px-3 text-xs font-semibold text-zinc-600 hover:text-zinc-950 rounded-lg transition-all">
                        <span>Compatibility &amp; Plugins</span>
                    </button>
                </div>

                <!-- Sub-Panel 1: Pages Selection List -->
                <div id="blueprint-panel-pages" class="space-y-1.5">
                    <div class="flex items-center justify-between text-xs font-bold text-zinc-700">
                        <span>Select Pages to Import:</span>
                        <button type="button" onclick="toggleSelectAllElementorPages(this)" id="elem-btn-select-all" class="text-[11px] text-zinc-500 hover:text-zinc-900 font-semibold cursor-pointer">Deselect All</button>
                    </div>
                    <div class="border border-zinc-200 rounded-xl divide-y divide-zinc-100 max-h-44 overflow-y-auto bg-white shadow-2xs" id="elem-scanned-pages-list">
                        <!-- Dynamically populated -->
                    </div>
                </div>

                <!-- Sub-Panel 2: Compatibility & Plugins Matrix -->
                <div id="blueprint-panel-compat" class="space-y-2.5 hidden">
                    <div class="p-2.5 bg-zinc-50 border border-zinc-200/80 rounded-xl space-y-1.5">
                        <span class="text-xs font-bold text-zinc-950 flex items-center gap-1.5">
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none" class="text-emerald-600"><polyline points="20 6 9 17 4 12"></polyline></svg>
                            100% Native Support
                        </span>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[10px] text-zinc-600">
                            <div class="flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Containers, Sections &amp; Typography</div>
                            <div class="flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Hero, Headings &amp; Buttons</div>
                            <div class="flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Images, Galleries &amp; Videos</div>
                            <div class="flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Responsive Breakpoints</div>
                        </div>
                    </div>

                    <!-- Converted Features -->
                    <div class="p-2.5 bg-zinc-50 border border-zinc-200/80 rounded-xl space-y-1" id="blueprint-converted-wrap">
                        <span class="text-xs font-bold text-zinc-950 flex items-center gap-1.5">
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none" class="text-amber-500"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
                            Auto-Bridged
                        </span>
                        <ul class="text-[10px] text-zinc-600 space-y-0.5 pl-4 list-disc" id="blueprint-converted-list">
                            <li>Navigation Menus bridged to Canvas Navigation</li>
                            <li>Page URLs &amp; Slugs preserved with 1:1 fidelity</li>
                        </ul>
                    </div>

                    <!-- Plugins Chips -->
                    <div class="space-y-1" id="blueprint-plugins-wrap">
                        <span class="text-[11px] font-bold text-zinc-800 block">Detected Plugins:</span>
                        <div class="flex flex-wrap gap-1" id="blueprint-plugins-chips">
                            <!-- Populated dynamically -->
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-end pt-2 border-t border-zinc-100 gap-2">
                    <button type="button" onclick="resetElementorScan()" class="px-3.5 py-2 border border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer">Cancel</button>
                    <button type="button" onclick="triggerMigrateElementorPages()" id="elem-btn-start-migrate" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs active:scale-95 flex items-center gap-1.5">
                        <span id="elem-btn-start-migrate-label">Start Migration</span>
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                    </button>
                </div>
            </div>

            <!-- Step 3: Migration Progress -->
            <div id="elem-url-step-progress" class="space-y-3.5 hidden p-6 bg-zinc-50 rounded-2xl border border-zinc-200/80 text-center">
                <div class="w-8 h-8 rounded-full border-2 border-zinc-950 border-t-transparent animate-spin mx-auto"></div>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-bold text-zinc-950" id="elem-progress-title">Migrating Elementor Site...</h4>
                    <p class="text-[11px] text-zinc-500" id="elem-progress-sub">Validating layouts and downloading assets...</p>
                </div>
                <div class="w-full bg-zinc-200 rounded-full h-1.5 overflow-hidden">
                    <div id="elem-progress-bar" class="bg-zinc-950 h-full rounded-full transition-all duration-300" style="width: 25%;"></div>
                </div>
            </div>

            <!-- Step 4: Success Result -->
            <div id="elem-url-step-success" class="space-y-4 hidden p-6 bg-zinc-50 rounded-2xl border border-zinc-200/80 text-center">
                <div class="w-9 h-9 rounded-full bg-zinc-950 text-white flex items-center justify-center mx-auto shadow-xs">
                    <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="20 6 9 17 4 12"></polyline></svg>
                </div>
                <div class="space-y-0.5">
                    <h4 class="text-xs font-bold text-zinc-950" id="elem-success-heading">Migration Complete!</h4>
                    <p class="text-[11px] text-zinc-600" id="elem-success-detail">All Elementor pages and media assets successfully migrated into Cora Canvas.</p>
                </div>
                <div class="flex items-center justify-center gap-2.5 pt-1">
                    <button type="button" onclick="closeElementorMigrationDrawer()" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-100 text-zinc-800 font-semibold rounded-xl text-xs transition-colors cursor-pointer">
                        Done
                    </button>
                    <a id="elem-btn-preview-draft" href="#" target="_blank" class="px-3.5 py-2 border border-zinc-950 bg-white hover:bg-zinc-100 text-zinc-950 font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs inline-flex items-center gap-1.5 hidden">
                        <span>Preview Draft</span>
                        <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                    </a>
                    <button type="button" onclick="openMigratedFirstPage()" id="elem-btn-open-canvas" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs">
                        Open Editor →
                    </button>
                </div>
            </div>

        </div>

        <!-- ══ TAB 2: Upload File ══ -->
        <div id="elem-tab-panel-upload" class="space-y-4 hidden">
            <div class="border-2 border-dashed border-zinc-200 hover:border-zinc-400 rounded-2xl p-6 text-center transition-colors bg-zinc-50/50 cursor-pointer" onclick="document.getElementById('elem-file-input').click()">
                <input type="file" id="elem-file-input" accept=".json,.zip,.xml" class="hidden" onchange="handleElementorFileSelected(this)">
                <div class="w-9 h-9 rounded-full bg-zinc-100 text-zinc-700 flex items-center justify-center mx-auto mb-2">
                    <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                </div>
                <h4 class="text-xs font-bold text-zinc-950" id="elem-file-name-label">Click to upload or drag and drop</h4>
                <p class="text-[11px] text-zinc-400 mt-0.5">WordPress Export (.xml), Elementor Kit (.zip), or Page (.json)</p>
            </div>

            <!-- Sleek 2-Option Guide -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                <div class="p-2.5 bg-zinc-50 border border-zinc-200/80 rounded-xl space-y-0.5">
                    <span class="text-xs font-bold text-zinc-950 block">WordPress Export (.xml)</span>
                    <p class="text-[10px] text-zinc-500">WP Admin &gt; Tools &gt; Export &gt; Pages.</p>
                </div>
                <div class="p-2.5 bg-zinc-50 border border-zinc-200/80 rounded-xl space-y-0.5">
                    <span class="text-xs font-bold text-zinc-950 block">Elementor Kit (.zip)</span>
                    <p class="text-[10px] text-zinc-500">WP Admin &gt; Elementor &gt; Tools &gt; Export Kit.</p>
                </div>
            </div>

            <div class="flex items-center justify-between pt-1 border-t border-zinc-100">
                <span class="text-[10px] text-zinc-400">Strict schema validation</span>
                <button type="button" onclick="triggerUploadElementorFile()" id="elem-btn-upload-submit" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-xl text-xs transition-all cursor-pointer shadow-xs disabled:opacity-50" disabled>
                    Import to Canvas
                </button>
            </div>
        </div>

    </div>
</div>

<!-- 2.5. Menu Item Setup Drawer (Centered Popup Modal) -->
<div id="drawer-menu-item" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-md space-y-4 transform scale-95 transition-transform duration-300" id="drawer-menu-item-card">
        <div class="flex items-center justify-between">
            <div>
                <h3 id="drawer-menu-item-title" class="text-sm font-bold text-zinc-950">Add Menu Item</h3>
                <p class="text-[10px] text-zinc-500 mt-0.5">Configure link text, destination, and target options.</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeMenuItemDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="space-y-4">
            <input type="hidden" id="menu-item-edit-index" value="">
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Link Label *</label>
                <input type="text" id="menu-item-label-input" placeholder="e.g. Listings" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Link Destination Type</label>
                <select id="menu-item-type-input" onchange="toggleMenuItemTypeFields()" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer bg-white font-medium">
                    <option value="page">Internal Page</option>
                    <option value="custom">Custom URL Link</option>
                </select>
            </div>
            
            <div id="menu-item-page-field" class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Select Page *</label>
                <select id="menu-item-page-select" class="w-full px-2.5 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 cursor-pointer bg-white font-medium">
                    <!-- Dynamic Page list options will be inserted here -->
                </select>
            </div>
            
            <div id="menu-item-url-field" class="space-y-2 hidden">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Custom URL Link *</label>
                <input type="text" id="menu-item-url-input" placeholder="e.g. /custom-page or https://..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>

            <div class="pt-2">
                <label class="flex items-center gap-2 text-xs text-zinc-700 cursor-pointer select-none">
                    <input type="checkbox" id="menu-item-newtab-input" class="accent-zinc-950 rounded">
                    Open in a new browser tab
                </label>
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeMenuItemDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="saveMenuItem()">Apply Changes</button>
        </div>
    </div>
</div>

<!-- Rename Page Modal (Centered Popup) -->
<div id="drawer-rename-page" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-md space-y-4 transform scale-95 transition-transform duration-300" id="drawer-rename-page-card">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">Rename Page</h3>
                <p class="text-[10px] text-zinc-500 mt-0.5">Specify a new display title for this page.</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeRenamePageDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="space-y-4">
            <input type="hidden" id="rename-page-id-input">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Page Title *</label>
                <input type="text" id="rename-page-title-input" placeholder="e.g. Featured Penthouse Listings" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeRenamePageDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="saveRenamedPage()">Rename Page</button>
        </div>
    </div>
</div>

<!-- Change Page Slug Modal (Centered Popup) -->
<div id="drawer-change-page-slug" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-md space-y-4 transform scale-95 transition-transform duration-300" id="drawer-change-page-slug-card">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">Change Page Slug URL</h3>
                <p class="text-[10px] text-zinc-500 mt-0.5">Specify a new URL path slug for this page route.</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeChangePageSlugDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="space-y-4">
            <input type="hidden" id="change-page-slug-id-input">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">URL Slug Path *</label>
                <input type="text" id="change-page-slug-input" placeholder="e.g. penthouse-listings" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium">
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeChangePageSlugDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="savePageSlug()">Update Slug</button>
        </div>
    </div>
</div>

<!-- Next.js Page Props & SEO Side Drawer -->
<div id="drawer-nextjs-page-props" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[500px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-nextjs-page-props-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/70">
            <div class="flex items-center gap-2.5">
                <div class="w-7 h-7 rounded-lg bg-zinc-950 text-white flex items-center justify-center">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M12 2L2 19.7778H22L12 2Z"/></svg>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-950">Next.js Page Props & SEO</h3>
                    <p id="nextjs-page-drawer-subtitle" class="text-[10px] text-zinc-500 mt-0.5">Route: /</p>
                </div>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 border-none bg-transparent" onclick="closeNextJSPagePropsDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-5">
            <input type="hidden" id="nextjs-page-id">

            <!-- Route Info Banner -->
            <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between text-xs">
                <div class="flex items-center gap-2">
                    <span class="px-1.5 py-0.5 rounded text-[9px] font-black bg-zinc-900 text-white font-mono">ROUTE</span>
                    <span id="nextjs-page-route-badge" class="font-mono font-bold text-zinc-900">/</span>
                </div>
                <span id="nextjs-page-is-home-badge" class="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">Homepage</span>
            </div>

            <!-- Page Title & Status -->
            <div class="grid grid-cols-2 gap-3">
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Page Title *</label>
                    <input type="text" id="nextjs-page-title" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-zinc-950 text-zinc-800 bg-white">
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Status</label>
                    <select id="nextjs-page-status" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white text-zinc-800 cursor-pointer font-semibold">
                        <option value="publish">Published</option>
                        <option value="draft">Draft</option>
                        <option value="private">Private</option>
                    </select>
                </div>
            </div>

            <!-- SEO Section -->
            <div class="space-y-3 pt-2 border-t border-zinc-100">
                <h4 class="text-[11px] font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-1.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    SEO & Meta Tags
                </h4>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">Meta Title</label>
                    <input type="text" id="nextjs-page-seo-title" placeholder="Meta Title for Google & Social" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white">
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">Meta Description</label>
                    <textarea id="nextjs-page-seo-desc" rows="2" placeholder="Search engine description (150-160 chars)" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white"></textarea>
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">OpenGraph / Social Image URL</label>
                    <input type="url" id="nextjs-page-seo-image" placeholder="https://..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white font-mono">
                </div>
            </div>

            <!-- Dynamic Content Props (Consumed in Next.js Server Components) -->
            <div class="space-y-3 pt-2 border-t border-zinc-100">
                <h4 class="text-[11px] font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-1.5">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                    Headless Content Blocks & Props
                </h4>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">Hero Heading</label>
                    <input type="text" id="nextjs-prop-hero-title" placeholder="e.g. Elevate Your Creative Vision" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white">
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">Hero Subtitle</label>
                    <textarea id="nextjs-prop-hero-sub" rows="2" placeholder="Subheading text rendered in Next.js Hero" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white"></textarea>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="space-y-1.5">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Primary CTA Text</label>
                        <input type="text" id="nextjs-prop-cta-label" placeholder="e.g. Explore Portfolio" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white">
                    </div>
                    <div class="space-y-1.5">
                        <label class="block text-[10px] font-bold text-zinc-500 uppercase">Primary CTA Link</label>
                        <input type="text" id="nextjs-prop-cta-href" placeholder="e.g. /contact" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-950 bg-white font-mono">
                    </div>
                </div>
                <div class="space-y-1.5">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase">Custom JSON Props (Key-Value)</label>
                    <textarea id="nextjs-prop-custom-json" rows="3" placeholder='{"badge": "New Launch", "features": ["Speed", "Security"]}' class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-mono focus:outline-none focus:border-zinc-950 bg-white"></textarea>
                </div>
            </div>

            <!-- Auto-revalidate toggle -->
            <div class="pt-2 border-t border-zinc-100 flex items-center justify-between">
                <div>
                    <label class="text-xs font-bold text-zinc-900 block">Instant On-Demand ISR</label>
                    <p class="text-[10px] text-zinc-400">Revalidate Next.js cache for this page immediately on save</p>
                </div>
                <input type="checkbox" id="nextjs-auto-revalidate" checked class="w-4 h-4 rounded accent-zinc-950 cursor-pointer">
            </div>
        </div>

        <div class="p-4 border-t border-zinc-200 flex items-center justify-end gap-2.5 bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeNextJSPagePropsDrawer()">Cancel</button>
            <button type="button" id="btn-save-nextjs-page-props" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-all cursor-pointer flex items-center gap-1.5 border-none shadow-xs" onclick="saveNextJSPageProps()">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                <span>Save & Revalidate</span>
            </button>
        </div>
    </div>
</div>

<!-- Lovable Page Settings Side Drawer -->
<div id="drawer-edit-page-settings" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-edit-page-settings-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">Page Settings</h3>
                <p id="edit-page-settings-drawer-title" class="text-[10px] text-zinc-500 mt-0.5">Edit page properties</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 border-none bg-transparent" onclick="closeEditPageSettingsDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-5">
            <input type="hidden" id="edit-page-settings-id">
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Page Title</label>
                <input type="text" id="edit-page-settings-title" placeholder="Page Title" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-zinc-400 text-zinc-800 bg-white">
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Slug</label>
                <input type="text" id="edit-page-settings-slug" placeholder="page-slug" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-mono text-zinc-800 bg-white">
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Status</label>
                <select id="edit-page-settings-status" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white text-zinc-800 cursor-pointer font-semibold">
                    <option value="publish">Published</option>
                    <option value="draft">Draft</option>
                    <option value="private">Private</option>
                </select>
            </div>

            <div class="space-y-2" id="edit-page-settings-lovable-route-container">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Lovable Route Mapping</label>
                <select id="edit-page-settings-lovable-route" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white text-zinc-800 cursor-pointer font-semibold">
                    <!-- Populated dynamically -->
                </select>
            </div>
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end gap-3 bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeEditPageSettingsDrawer()">Cancel</button>
            <button type="button" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="saveEditPageSettings()">Save Changes</button>
        </div>
    </div>
</div>

<!-- 3. Global SEO settings Side Drawer -->
<div id="drawer-page-seo" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-page-seo-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">SEO & Metadata Settings</h3>
                <p id="seo-drawer-page-title" class="text-[10px] text-zinc-500 mt-0.5">Page Title</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeSEODrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-6 space-y-6">
            <input type="hidden" id="seo-page-id-input">
            
            <div class="space-y-2">
                <div class="flex justify-between items-center text-[10px] font-bold text-zinc-500 uppercase">
                    <span>Meta Title</span>
                    <span id="seo-title-char-count">0/60</span>
                </div>
                <input type="text" id="seo-title-input" onkeyup="countChars(this, 'seo-title-char-count', 60)" placeholder="e.g. Luxury Villas in Gurgaon | PropOS Agency" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                <p id="seo-title-warn" class="text-[9px] text-amber-600 hidden font-semibold">Recommended length exceeded (60 chars max).</p>
            </div>

            <div class="space-y-2">
                <div class="flex justify-between items-center text-[10px] font-bold text-zinc-500 uppercase">
                    <span>Meta Description</span>
                    <span id="seo-desc-char-count">0/160</span>
                </div>
                <textarea id="seo-desc-input" onkeyup="countChars(this, 'seo-desc-char-count', 160)" rows="4" placeholder="Brief search snippet description..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400"></textarea>
                <p id="seo-desc-warn" class="text-[9px] text-amber-600 hidden font-semibold">Recommended length exceeded (160 chars max).</p>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">OG Social Preview Image URL</label>
                <input type="text" id="seo-og-image-input" placeholder="e.g. https://cora.local/og-preview.png" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
                <p class="text-[9px] text-zinc-400">Recommended dimension: 1200×630px.</p>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="flex items-center gap-2">
                    <input type="checkbox" id="seo-index-input" checked class="rounded cursor-pointer">
                    <label class="text-xs font-semibold text-zinc-700 cursor-pointer" for="seo-index-input">Index Page (Search engines)</label>
                </div>
            </div>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Canonical URL Override</label>
                <input type="text" id="seo-canonical-input" placeholder="https://..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end gap-3 bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeSEODrawer()">Cancel</button>
            <button type="button" class="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="savePageSEOSettings()">Save SEO</button>
        </div>
    </div>
</div>

<!-- 4. Page Revision History Side Panel -->
<div id="drawer-page-revisions" class="fixed inset-0 z-[99999] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden" style="display:none; pointer-events:none;">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300" id="drawer-page-revisions-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">Page Revision History</h3>
                <p id="revisions-drawer-page-title" class="text-[10px] text-zinc-500 mt-0.5">Page Title</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeRevisionsDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="flex-1 overflow-y-auto p-5 space-y-4" id="revisions-list-container">
            <!-- Populated dynamically by JS -->
        </div>
        <div class="p-5 border-t border-zinc-100 flex items-center justify-end bg-zinc-50/50">
            <button type="button" class="px-4 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeRevisionsDrawer()">Close Panel</button>
        </div>
    </div>
</div>

<!-- 5. Activate theme confirmation modal -->
<div id="canvas-confirm-modal" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-sm space-y-5">
        <div class="space-y-2">
            <h4 id="canvas-confirm-title" class="text-sm font-bold text-zinc-950">Confirm Action</h4>
            <p id="canvas-confirm-message" class="text-xs text-zinc-500 leading-relaxed">Are you sure you want to perform this action?</p>
        </div>
        <div class="flex items-center justify-end gap-2.5">
            <button onclick="closeCanvasConfirmModal()" class="px-3.5 py-2 border border-zinc-200 rounded-lg text-xs font-semibold text-zinc-750 bg-white hover:bg-zinc-50 transition-colors cursor-pointer">Cancel</button>
            <button id="canvas-confirm-action-btn" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer">Confirm</button>
        </div>
    </div>
</div>

<!-- 6. Theme Rename Modal (Centered Popup) -->
<div id="drawer-rename-theme" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-md space-y-4 transform scale-95 transition-transform duration-300" id="drawer-rename-theme-card">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-sm font-bold text-zinc-950">Rename Theme</h3>
                <p class="text-[10px] text-zinc-500 mt-0.5">Specify a new display name for this theme workspace.</p>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeRenameThemeDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <div class="space-y-4">
            <input type="hidden" id="rename-theme-id-input">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Theme Name *</label>
                <input type="text" id="rename-theme-name-input" placeholder="e.g. Cora Custom Theme" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 font-medium font-sans">
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer font-sans" onclick="closeRenameThemeDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer font-sans" onclick="saveRenamedTheme()">Rename Theme</button>
        </div>
    </div>
</div>

<!-- 7. Git Connection Drawer (Right-Sliding Sheet) -->
<div id="drawer-git-connect" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300 pointer-events-auto" id="drawer-git-connect-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50 flex-shrink-0">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center">
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" class="text-zinc-700 "><circle cx="18" cy="18" r="3"></circle><circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><path d="M6 9v6"></path><path d="M9 18h9"></path></svg>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-950 font-sans">Git Integration</h3>
                    <p class="text-[10px] text-zinc-500 mt-0.5 font-sans">Sync your website design with GitHub</p>
                </div>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 transition-colors bg-transparent border-none" onclick="closeGitDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        
        <!-- Drawer Body -->
        <div class="flex-1 overflow-y-auto p-5 space-y-6">
            <!-- STEP 1: CONNECT PAT -->
            <div id="git-step-connect-pat" class="space-y-5 hidden" style="display:none" data-alias="git-unconnected-form"></div><!-- alias bridge -->
            <div id="git-unconnected-form" class="space-y-5">

                <div class="bg-zinc-50 border border-zinc-200 rounded-xl p-4 space-y-2">
                    <p class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Easy Setup</p>
                    <p class="text-[11px] text-zinc-650 leading-relaxed font-sans">
                        Let's connect your website to GitHub so your designs are safely saved and versioned automatically.
                    </p>
                </div>

                <div class="space-y-4">
                    <div class="p-4 border border-zinc-150 rounded-xl bg-white space-y-3">
                        <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-zinc-950 text-[10px] font-bold text-white ">1</span>
                        <p class="text-xs font-bold text-zinc-800 font-sans inline-block ml-1">Get your GitHub Access Token</p>
                        <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                            Click the button below to open GitHub (create a free account if you don't have one). Scroll down and click the green <strong>"Generate token"</strong> button at the bottom.
                        </p>
                        <a href="https://github.com/settings/tokens/new?scopes=repo&description=Cora%2520Studio%2520Integration" target="_blank" class="w-full h-9 bg-zinc-100 hover:bg-zinc-200 text-zinc-850 font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-zinc-200 no-underline font-sans">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                            Get GitHub Access Token
                        </a>
                    </div>

                    <div class="p-4 border border-zinc-150 rounded-xl bg-white space-y-3">
                        <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-zinc-950 text-[10px] font-bold text-white ">2</span>
                        <label for="git-pat-input" class="text-xs font-bold text-zinc-800 font-sans inline-block ml-1">Paste your Access Token</label>
                        <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                            Copy the generated token from GitHub (starts with <code>ghp_</code>) and paste it below.
                        </p>
                        <input type="password" id="git-pat-input" placeholder="ghp_..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-850 font-medium bg-white text-zinc-900 font-sans">
                    </div>
                </div>

                <div class="pt-2">
                    <button type="button" id="git-connect-btn" onclick="connectGitRepository()" class="w-full h-10 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 border-none">
                        Connect Account
                    </button>
                </div>
            </div>

            <!-- STEP 2: CHOOSE OR CREATE REPOSITORY -->
            <div id="git-step-select-repo" class="space-y-5 hidden">
                <div class="p-4 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between gap-3">
                    <div class="flex items-center gap-2.5">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0 animate-pulse"></span>
                        <p class="text-[11px] font-bold text-zinc-800 font-sans" id="git-connected-user-temp">Connected as @user</p>
                    </div>
                    <button onclick="disconnectGit()" class="text-[10px] font-bold text-zinc-500 hover:text-red-650 transition-colors cursor-pointer border-none bg-transparent font-sans">Disconnect</button>
                </div>

                <div class="space-y-4">
                    <p class="text-[10px] font-bold text-zinc-450 uppercase tracking-wider font-sans">Setup Repository</p>
                    
                    <!-- TAB OPTIONS -->
                    <div class="grid grid-cols-2 gap-2 p-0.5 bg-zinc-100 rounded-lg">
                        <button onclick="switchRepoTab('create')" id="tab-repo-create" class="py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-white text-zinc-850 shadow-sm">
                            Create New (Recommended)
                        </button>
                        <button onclick="switchRepoTab('link')" id="tab-repo-link" class="py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-transparent text-zinc-500 hover:text-zinc-800 ">
                            Link Existing
                        </button>
                    </div>

                    <!-- TAB 1: CREATE NEW -->
                    <div id="panel-repo-create" class="space-y-3.5">
                        <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                            We will automatically create a private, secure repository on GitHub for you to store your pages.
                        </p>
                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">New Repository Name</label>
                            <input type="text" id="git-new-repo-name" value="cora-website" placeholder="cora-website" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-850 bg-white text-zinc-900 font-sans font-medium">
                        </div>
                        <button type="button" id="git-create-repo-btn" onclick="createGitRepository()" class="w-full h-10 bg-zinc-950 hover:bg-zinc-850 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer border-none font-sans flex items-center justify-center gap-2">
                            Create Private Repository
                        </button>
                    </div>

                    <!-- TAB 2: LINK EXISTING -->
                    <div id="panel-repo-link" class="space-y-3.5 hidden">
                        <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                            If you already have a repository on GitHub, enter its path below to link it.
                        </p>
                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Repository Path</label>
                            <input type="text" id="git-link-repo-path" placeholder="username/repository-name" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-850 bg-white text-zinc-900 font-sans font-medium">
                            <p class="text-[9px] text-zinc-400 pl-1">Format: <code>owner/repository-name</code></p>
                        </div>
                        <button type="button" id="git-link-repo-btn" onclick="linkGitRepository()" class="w-full h-10 bg-zinc-950 hover:bg-zinc-850 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer border-none font-sans flex items-center justify-center gap-2">
                            Link Repository
                        </button>
                    </div>
                </div>
            </div>

            <!-- STEP 3: CONNECTED DASHBOARD -->
            <div id="git-connected-dashboard" class="space-y-6 hidden">
                <!-- Status Banner -->
                <div class="p-4 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between gap-3">
                    <div class="flex items-center gap-2.5">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0 animate-pulse"></span>
                        <div>
                            <p class="text-[11px] font-bold text-zinc-800 font-sans" id="git-connected-user">Connected as @user</p>
                            <a href="#" id="git-connected-repo-link" target="_blank" class="text-[10px] text-zinc-500 hover:text-zinc-900 transition-colors flex items-center gap-1 font-sans">
                                owner/repo
                                <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                            </a>
                        </div>
                    </div>
                    <button onclick="disconnectGit()" class="text-[10px] font-bold text-zinc-500 hover:text-red-650 transition-colors cursor-pointer border-none bg-transparent font-sans">Disconnect</button>
                </div>

                <!-- Branch Management -->
                <div class="space-y-2">
                    <label class="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Active Branch</label>
                    <div class="flex items-center gap-2">
                        <div class="relative flex-1">
                            <select id="git-branch-select" onchange="changeActiveBranch()" class="w-full px-3 py-2.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-800 font-medium bg-white text-zinc-900 cursor-pointer font-sans">
                                <option value="main">main</option>
                            </select>
                        </div>
                        <button onclick="toggleInlineNewBranch(true)" class="h-9 px-3 border border-zinc-200 hover:bg-zinc-50 rounded-lg text-[10px] font-bold text-zinc-700 transition-colors cursor-pointer flex items-center gap-1 bg-white font-sans">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            New
                        </button>
                    </div>

                    <!-- Inline New Branch Form -->
                    <div id="git-new-branch-container" class="hidden mt-2 p-3 border border-zinc-200 bg-zinc-50/50 rounded-xl space-y-3">
                        <div class="space-y-1.5">
                            <label class="block text-[9px] font-bold text-zinc-400 uppercase tracking-wider font-sans">New Branch Name</label>
                            <input type="text" id="new-branch-name-input" placeholder="e.g. feature-homepage-redesign" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white text-zinc-900 font-medium font-sans">
                        </div>
                        <div class="flex justify-end gap-2">
                            <button onclick="toggleInlineNewBranch(false)" class="px-2.5 py-1.5 border border-zinc-200 bg-white text-[10px] text-zinc-650 font-bold rounded-md hover:bg-zinc-50 transition-colors cursor-pointer font-sans">Cancel</button>
                            <button onclick="submitCreateBranch()" class="px-2.5 py-1.5 bg-zinc-950 text-white text-[10px] font-bold rounded-md hover:bg-zinc-850 transition-colors cursor-pointer border-none font-sans">Create</button>
                        </div>
                    </div>
                </div>

                <!-- Working Tree Status -->
                <div id="git-working-tree-section" class="space-y-2 border-t border-zinc-150 pt-5 hidden">
                    <p class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Working Tree Changes</p>
                    <div class="p-3 bg-amber-50/50 border border-amber-200 rounded-xl flex items-center justify-between gap-2">
                        <div class="flex items-center gap-2">
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-500 flex-shrink-0 animate-pulse"></span>
                            <span id="git-working-tree-file" class="text-[10.5px] font-mono text-zinc-700 ">pages/about/design.json</span>
                        </div>
                        <span class="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider font-sans">Modified</span>
                    </div>
                    <!-- Suggestion Box -->
                    <div id="git-suggestion-box" class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl space-y-2">
                        <div class="flex items-center gap-1.5">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" class="text-zinc-500"><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
                            <span class="text-[10px] font-bold text-zinc-500 uppercase tracking-tight font-sans">AI Commit Suggestion</span>
                        </div>
                        <div class="flex items-center justify-between gap-3">
                            <span id="git-suggestion-text" class="text-[11px] font-semibold text-zinc-800 italic font-sans">"update page layout"</span>
                            <button onclick="applyCommitSuggestion()" class="text-[10px] font-bold text-zinc-900 bg-zinc-200 hover:bg-zinc-300 px-2 py-1 rounded-md transition-colors cursor-pointer border-none font-sans">Apply</button>
                        </div>
                    </div>
                </div>
                
                <div id="git-clean-tree-section" class="p-3 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center gap-2 hidden">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0"></span>
                    <span class="text-[10.5px] font-bold text-zinc-700 font-sans">Working tree clean. All changes committed.</span>
                </div>

                <!-- Manual Commit Actions -->
                <div class="space-y-3 border-t border-zinc-150 pt-5">
                    <p class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Commit & Sync Changes</p>
                    
                    <div class="space-y-2">
                        <label class="block text-[10px] font-bold text-zinc-400 font-sans">Commit Message</label>
                        <textarea id="git-commit-msg" rows="3" placeholder="Describe the layout edits or components updated..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white text-zinc-900 font-medium font-sans resize-none"></textarea>
                    </div>

                    <div class="grid grid-cols-2 gap-3 pt-1">
                        <button type="button" id="git-push-btn" onclick="pushPageLayout()" class="h-9 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 border-none font-sans">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline></svg>
                            Commit & Push
                        </button>
                        <button type="button" id="git-pull-btn" onclick="pullDesignTemplates()" class="h-9 border border-zinc-200 hover:bg-zinc-50 rounded-lg text-xs font-bold text-zinc-700 transition-colors cursor-pointer flex items-center justify-center gap-1.5 bg-white font-sans">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="8 17 12 21 16 17"></polyline></svg>
                            Pull Design
                        </button>
                    </div>
                </div>

                <!-- Recent Commit History -->
                <div class="space-y-3 border-t border-zinc-150 pt-5">
                    <p class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Recent Commit Log</p>
                    <div id="git-commit-log" class="space-y-2">
                        <!-- Will be populated dynamically -->
                        <div class="text-[10px] text-zinc-400 italic pl-1 font-sans">Loading recent commits...</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Drawer Footer -->
        <div class="p-5 border-t border-zinc-200 flex items-center justify-end gap-2.5 bg-zinc-50/30 flex-shrink-0">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer font-sans" onclick="closeGitDrawer()">Cancel</button>
        </div>
    </div>
</div>

<!-- 7.5. PageSpeed Settings Drawer (Right-Sliding Sheet) -->
<div id="drawer-pagespeed-settings" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex justify-end opacity-0 pointer-events-none transition-opacity duration-300 hidden">
    <div class="bg-white border-l border-zinc-200 h-full w-full max-w-[460px] shadow-2xl flex flex-col transform translate-x-full transition-transform duration-300 pointer-events-auto" id="drawer-pagespeed-settings-card">
        <div class="p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50/50 flex-shrink-0">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center">
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" class="text-zinc-700 "><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                </div>
                <div>
                    <h3 class="text-sm font-bold text-zinc-950 font-sans">PageSpeed Credentials</h3>
                    <p class="text-[10px] text-zinc-500 mt-0.5 font-sans">Setup your Google PageSpeed API Key</p>
                </div>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1 transition-colors bg-transparent border-none" onclick="closePageSpeedSettingsDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        
        <!-- Drawer Body -->
        <div class="flex-1 overflow-y-auto p-5 space-y-6">
            <div class="bg-zinc-50 border border-zinc-200 rounded-xl p-4 space-y-2">
                <p class="text-[10px] font-bold text-zinc-500 uppercase tracking-wider font-sans">Google Cloud API Key</p>
                <p class="text-[11px] text-zinc-650 leading-relaxed font-sans">
                    Google PageSpeed Insights API is 100% free and does not require complex configuration. To execute higher volume tests without rate limit limits, add your Google API key.
                </p>
            </div>

            <div class="space-y-4">
                <div class="p-4 border border-zinc-150 rounded-xl bg-white space-y-3">
                    <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-zinc-950 text-[10px] font-bold text-white ">1</span>
                    <p class="text-xs font-bold text-zinc-800 font-sans inline-block ml-1">Get your PageSpeed API Key</p>
                    <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                        Click the button below to open Google Cloud API console (free account). Search or ensure the <strong>PageSpeed Insights API</strong> is enabled, and click <strong>"Create Credentials" / "API Key"</strong>.
                    </p>
                    <a href="https://console.cloud.google.com/apis/library/pagespeedonline.googleapis.com" target="_blank" class="w-full h-9 bg-zinc-100 hover:bg-zinc-200 text-zinc-850 font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-zinc-200 no-underline font-sans">
                        <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                        Get Free PageSpeed API Key
                    </a>
                </div>

                <div class="p-4 border border-zinc-150 rounded-xl bg-white space-y-3">
                    <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-zinc-950 text-[10px] font-bold text-white ">2</span>
                    <label for="pagespeed-api-key-input" class="text-xs font-bold text-zinc-800 font-sans inline-block ml-1">Paste your Google API Key</label>
                    <p class="text-[11px] text-zinc-500 leading-relaxed font-sans">
                        Paste your API key here. If left blank, Cora will try to fall back to your Google Maps API key or query keyless with standard limitations.
                    </p>
                    <input type="password" id="pagespeed-api-key-input" placeholder="AIzaSy..." value="<?php echo esc_attr( get_option( 'cora_pagespeed_api_key', '' ) ); ?>" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-850 font-medium bg-white text-zinc-900 font-sans">
                </div>
            </div>
        </div>
        <!-- Drawer Footer -->
        <div class="p-5 border-t border-zinc-200 flex items-center justify-end gap-2.5 bg-zinc-50/30 flex-shrink-0">
            <button type="button" class="px-3.5 py-2 border border-zinc-300 bg-white hover:bg-zinc-50 text-zinc-700 font-bold rounded-lg text-xs transition-colors cursor-pointer font-sans" onclick="closePageSpeedSettingsDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer border-none font-sans" onclick="savePageSpeedSettings()">Save API Settings</button>
        </div>
    </div>
</div>

<!-- Lovable Connection Modal (Centered Popup) -->
<div id="drawer-lovable-connect" class="fixed inset-0 z-[999999] bg-zinc-900/40 backdrop-blur-[1px] flex items-center justify-center hidden opacity-0 transition-opacity duration-300">
    <div class="bg-white border border-zinc-200 rounded-xl shadow-2xl p-6 w-full max-w-sm space-y-4 transform scale-95 transition-transform duration-300" id="drawer-lovable-connect-card">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" class="text-purple-650"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                <h3 class="text-sm font-bold text-zinc-950">Connect Lovable Studio</h3>
            </div>
            <button type="button" class="text-zinc-400 hover:text-zinc-900 cursor-pointer p-1" onclick="closeLovableConnectDrawer()">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
        </div>
        <p class="text-[10px] text-zinc-500 leading-normal">Deploy your frontend workspace dynamically from Lovable.dev by entering your project's share URL or API key.</p>
        <div class="space-y-4">
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Lovable Project URL *</label>
                <input type="text" id="lovable-url-input" placeholder="e.g. lovable.dev/projects/your-project-id" class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
            <div class="space-y-2">
                <label class="block text-[10px] font-bold text-zinc-500 uppercase">Personal Access Token (Lovable API Key)</label>
                <input type="password" id="lovable-token-input" placeholder="lovable_pat_..." class="w-full px-3 py-2 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400">
            </div>
        </div>
        <div class="flex items-center justify-end gap-2.5 pt-2">
            <button type="button" class="px-3.5 py-2 border border-zinc-350 bg-white hover:bg-zinc-50 text-zinc-700 font-semibold rounded-lg text-xs transition-colors cursor-pointer" onclick="closeLovableConnectDrawer()">Cancel</button>
            <button type="button" class="px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer border-none shadow-xs" onclick="triggerLovableConnect()">Connect & Sync</button>
        </div>
    </div>
</div>


<!-- ╔═══════════════════════════════════════════════════════════╗
     ║  ADD THEME WIZARD  — Premium Full-Screen Onboarding     ║
     ╚═══════════════════════════════════════════════════════════╝ -->
<style>
#atw{font-family:-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',system-ui,sans-serif;}
#atw *{box-sizing:border-box;margin:0;padding:0;}
.atw-card{transition:transform .2s cubic-bezier(.4,0,.2,1),box-shadow .2s cubic-bezier(.4,0,.2,1),border-color .15s;will-change:transform;}
.atw-card:hover{transform:translateY(-4px);box-shadow:0 16px 48px rgba(0,0,0,.11),0 4px 16px rgba(0,0,0,.07)!important;}
.atw-card:hover .atw-thumb{transform:scale(1.04);}
.atw-thumb{transition:transform .5s cubic-bezier(.4,0,.2,1);display:block;width:100%;height:100%;object-fit:cover;}
.atw-card.atw-sel-e{border-color:#18181b!important;box-shadow:0 0 0 3px rgba(24,24,27,.15),0 8px 32px rgba(0,0,0,.1)!important;}
.atw-card.atw-sel-n{border-color:#18181b!important;box-shadow:0 0 0 3px rgba(24,24,27,.18),0 8px 32px rgba(0,0,0,.12)!important;}
.atw-card.atw-sel-l{border-color:#7c3aed!important;box-shadow:0 0 0 3px rgba(124,58,237,.18),0 8px 32px rgba(124,58,237,.1)!important;}
.atw-tab{transition:all .15s;border:none;cursor:pointer;font-size:11px;font-weight:700;font-family:inherit;}
.atw-tab.atw-tab-on{background:white;color:#18181b;border:1px solid #e4e4e7!important;box-shadow:0 1px 3px rgba(0,0,0,.08);border-radius:10px;}
.atw-tab.atw-tab-off{background:transparent;color:#71717a;border:1px solid transparent!important;border-radius:10px;}
.atw-tab.atw-tab-off:hover{color:#18181b;background:rgba(255,255,255,.6);}
.atw-input{width:100%!important;height:38px!important;padding:8px 12px!important;border:1.5px solid #e4e4e7!important;border-radius:8px!important;font-size:12.5px!important;font-weight:500!important;color:#18181b!important;background:white!important;transition:border-color .15s,box-shadow .15s!important;outline:none!important;font-family:inherit!important;box-sizing:border-box!important;line-height:normal!important;}
.atw-input:focus{border-color:#18181b!important;box-shadow:0 0 0 3px rgba(24,24,27,.07)!important;}
.atw-input.atw-lov:focus{border-color:#7c3aed!important;box-shadow:0 0 0 3px rgba(124,58,237,.08)!important;}
@keyframes atw-in{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.atw-anim{animation:atw-in .22s cubic-bezier(.4,0,.2,1) both;}
.atw-drop-zone{border:2px dashed #d4d4d8;border-radius:14px;background:#fafafa;transition:border-color .15s,background .15s;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:52px 32px;}
.atw-drop-zone:hover{border-color:#71717a;background:#f5f5f5;}
@keyframes wizSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.wiz-branch-pill{padding:6px 14px;background:#f4f4f5;border:1.5px solid #e4e4e7;border-radius:8px;font-size:11px;font-weight:700;color:#27272a;cursor:pointer;transition:all .15s ease-in-out;}
.wiz-branch-pill:hover{background:#e4e4e7;border-color:#d4d4d8;color:#18181b;}
.wiz-branch-selected{background:#18181b!important;border-color:#18181b!important;color:white!important;}

.atw-header-bar { padding: 0 28px !important; }
.atw-title-text { display: inline !important; }
.atw-lbl-text { display: inline !important; }
.atw-line-connector { width: 44px !important; margin: 0 6px !important; }
.atw-builder-grid { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 18px !important; width: 100% !important; max-width: 1060px !important; }
.atw-token-branch-row { display: grid !important; grid-template-columns: 1fr 120px !important; gap: 12px !important; }
.atw-template-grid { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 12px !important; }
.atw-cancel-text { display: inline !important; }

@media (max-width: 900px) {
    .atw-builder-grid { grid-template-columns: 1fr !important; gap: 14px !important; }
}

@media (max-width: 640px) {
    .atw-header-bar { padding: 0 12px !important; }
    .atw-title-text { display: none !important; }
    .atw-lbl-text { display: none !important; }
    .atw-line-connector { width: 20px !important; margin: 0 3px !important; }
    .atw-token-branch-row { grid-template-columns: 1fr !important; }
    .atw-template-grid { grid-template-columns: 1fr !important; }
    .atw-cancel-text { display: none !important; }
}
</style>

<div id="atw" style="position:fixed;inset:0;z-index:999999;display:none;opacity:0;transition:opacity .22s ease;background:#F8F8F7;flex-direction:column;">

    <!-- TOP BAR -->
    <div style="flex-shrink:0;height:58px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;background:rgba(248,248,247,.92);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-bottom:1px solid rgba(0,0,0,.07);" class="atw-header-bar">
        <div style="display:flex;align-items:center;gap:9px;">
            <div style="width:26px;height:26px;background:#18181b;border-radius:7px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
            </div>
            <span style="font-size:13px;font-weight:700;color:#18181b;letter-spacing:-.025em;" class="atw-title-text">Add New Theme</span>
        </div>
        <div style="display:flex;align-items:center;gap:0;">
            <div id="atw-prog-1" style="display:flex;align-items:center;gap:7px;">
                <div id="atw-dot-1" style="width:22px;height:22px;background:#18181b;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .25s;">
                    <span style="font-size:9px;font-weight:900;color:white;line-height:1;">1</span>
                </div>
                <span id="atw-lbl-1" style="font-size:11px;font-weight:700;color:#18181b;letter-spacing:-.01em;transition:color .25s;" class="atw-lbl-text">Builder</span>
            </div>
            <div id="atw-line-1" style="width:44px;height:2px;margin:0 6px;background:#e4e4e7;border-radius:2px;transition:background .3s;" class="atw-line-connector"></div>
            <div id="atw-prog-2" style="display:flex;align-items:center;gap:7px;opacity:.35;transition:opacity .25s;">
                <div id="atw-dot-2" style="width:22px;height:22px;border:2px solid #d1d5db;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .25s;">
                    <span style="font-size:9px;font-weight:900;color:#9ca3af;line-height:1;">2</span>
                </div>
                <span id="atw-lbl-2" style="font-size:11px;font-weight:700;color:#9ca3af;letter-spacing:-.01em;transition:color .25s;" class="atw-lbl-text">Setup</span>
            </div>
            <div id="atw-line-2" style="width:44px;height:2px;margin:0 6px;background:#e4e4e7;border-radius:2px;transition:background .3s;" class="atw-line-connector"></div>
            <div id="atw-prog-3" style="display:flex;align-items:center;gap:7px;opacity:.35;transition:opacity .25s;">
                <div id="atw-dot-3" style="width:22px;height:22px;border:2px solid #d1d5db;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .25s;">
                    <span style="font-size:9px;font-weight:900;color:#9ca3af;line-height:1;">3</span>
                </div>
                <span id="atw-lbl-3" style="font-size:11px;font-weight:700;color:#9ca3af;letter-spacing:-.01em;transition:color .25s;" class="atw-lbl-text">Save</span>
            </div>
        </div>
        <button onclick="closeAddThemeWizard()" style="display:flex;align-items:center;gap:5px;padding:6px 10px;border-radius:8px;border:none;background:transparent;color:#a1a1aa;font-size:11px;font-weight:600;cursor:pointer;transition:all .15s;" onmouseover="this.style.background='rgba(0,0,0,.05)';this.style.color='#3f3f46';" onmouseout="this.style.background='transparent';this.style.color='#a1a1aa';">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <span class="atw-cancel-text">Cancel</span>
        </button>
    </div>

    <!-- SCROLLABLE BODY -->
    <div id="atw-body" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;">

        <!-- STEP 1: Choose Builder -->
        <div id="wizard-step-1" class="atw-anim" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:52px 32px 40px;">
            <div style="text-align:center;margin-bottom:44px;max-width:540px;">
                <p style="font-size:10px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:#a1a1aa;margin-bottom:14px;">Step 1 of 3</p>
                <h2 style="font-size:34px;font-weight:900;color:#18181b;letter-spacing:-.045em;line-height:1.08;margin-bottom:14px;">What are you<br>building with?</h2>
                <p style="font-size:14px;color:#71717a;line-height:1.65;">Choose your frontend technology. Connect modern Next.js Git projects or import Elementor themes with full Cora operational control.</p>
            </div>
            <div class="atw-builder-grid">

                <!-- 1. Next.js Native Card (Featured / Headless) -->
                <button onclick="wizardSelectBuilder('nextjs')" id="wizard-card-nextjs" class="atw-card atw-sel-n" style="text-align:left;background:white;border:2px solid #18181b;border-radius:20px;overflow:hidden;cursor:pointer;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.06);">
                    <div style="position:relative;overflow:hidden;background:#09090b;">
                        <div style="width:100%;padding-bottom:56.25%;position:relative;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 40%, #27272a 0%, #09090b 100%);">
                            <!-- Next.js Dark Minimalist Visual -->
                            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;">
                                <div style="width:48px;height:48px;background:white;border-radius:12px;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(0,0,0,.4);">
                                    <svg width="26" height="26" viewBox="0 0 24 24" fill="#09090b"><path d="M12 2L2 19.7778H22L12 2Z"/></svg>
                                </div>
                                <span style="font-size:11px;font-weight:800;color:#e4e4e7;letter-spacing:0.04em;font-family:monospace;">NEXT.JS APP ROUTER</span>
                            </div>
                            <div id="atw-ov-n" style="display:flex;position:absolute;inset:0;background:rgba(24,24,27,.48);align-items:center;justify-content:center;">
                                <div style="width:48px;height:48px;background:white;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(0,0,0,.2);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#18181b" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                </div>
                            </div>
                        </div>
                        <!-- Top left badge -->
                        <div style="position:absolute;top:11px;left:11px;display:flex;align-items:center;gap:5px;background:rgba(255,255,255,.95);backdrop-filter:blur(8px);border-radius:100px;padding:4px 9px 4px 6px;box-shadow:0 1px 6px rgba(0,0,0,.14);">
                            <span style="width:6px;height:6px;background:#10b981;border-radius:50%;"></span>
                            <span style="font-size:10px;font-weight:800;color:#18181b;letter-spacing:-.01em;">Native Next.js</span>
                        </div>
                    </div>
                    <div style="padding:18px 20px 20px;">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px;">
                            <div>
                                <h3 style="font-size:15px;font-weight:800;color:#18181b;letter-spacing:-.025em;margin-bottom:4px;">Next.js Native (Git)</h3>
                                <p style="font-size:12px;color:#71717a;line-height:1.55;">Connect GitHub repo · Headless React App Router · Full operational control.</p>
                            </div>
                            <div id="wiz-radio-nextjs" style="width:18px;height:18px;min-width:18px;border-radius:50%;border:2px solid #18181b;display:flex;align-items:center;justify-content:center;margin-top:2px;transition:all .18s;flex-shrink:0;">
                                <div style="width:8px;height:8px;border-radius:50%;background:#18181b;transition:all .18s;"></div>
                            </div>
                        </div>
                        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:14px;">
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#18181b;color:white;border-radius:6px;">App Router</span>
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#71717a;border-radius:6px;">GitHub Sync</span>
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#71717a;border-radius:6px;">ISR Rebuild</span>
                        </div>
                    </div>
                </button>

                <!-- 2. Elementor Card -->
                <button onclick="wizardSelectBuilder('elementor')" id="wizard-card-elementor" class="atw-card" style="text-align:left;background:white;border:2px solid #e4e4e7;border-radius:20px;overflow:hidden;cursor:pointer;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.06);">
                    <div style="position:relative;overflow:hidden;background:#f0f0ef;">
                        <div style="width:100%;padding-bottom:56.25%;position:relative;">
                            <img src="<?php echo esc_url( plugin_dir_url(dirname(__FILE__)) . 'assets/img/wizard-elementor-thumb.jpg' ); ?>" alt="Elementor editor" class="atw-thumb" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;" loading="lazy">
                            <div id="atw-ov-e" style="display:none;position:absolute;inset:0;background:rgba(24,24,27,.48);align-items:center;justify-content:center;">
                                <div style="width:48px;height:48px;background:white;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(0,0,0,.2);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#18181b" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                                </div>
                            </div>
                        </div>
                        <div style="position:absolute;top:11px;left:11px;display:flex;align-items:center;gap:5px;background:rgba(255,255,255,.92);backdrop-filter:blur(8px);border-radius:100px;padding:4px 9px 4px 5px;box-shadow:0 1px 6px rgba(0,0,0,.14);">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="5" fill="#92003B"/><path d="M7 7h10M7 12h10M7 17h6" stroke="white" stroke-width="2.2" stroke-linecap="round"/></svg>
                            <span style="font-size:10px;font-weight:800;color:#18181b;letter-spacing:-.01em;">Elementor</span>
                        </div>
                    </div>
                    <div style="padding:18px 20px 20px;">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px;">
                            <div>
                                <h3 style="font-size:15px;font-weight:800;color:#18181b;letter-spacing:-.025em;margin-bottom:4px;">Elementor Builder</h3>
                                <p style="font-size:12px;color:#71717a;line-height:1.55;">Upload a Kit (.zip) or manage Elementor pages.</p>
                            </div>
                            <div id="wiz-radio-elementor" style="width:18px;height:18px;min-width:18px;border-radius:50%;border:2px solid #d4d4d8;display:flex;align-items:center;justify-content:center;margin-top:2px;transition:all .18s;flex-shrink:0;">
                                <div style="width:8px;height:8px;border-radius:50%;background:transparent;transition:all .18s;"></div>
                            </div>
                        </div>
                        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:14px;">
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#71717a;border-radius:6px;">Upload Kit</span>
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#71717a;border-radius:6px;">Visual Editor</span>
                        </div>
                    </div>
                </button>

                <!-- 3. Lovable Card — LOCKED / Coming Soon -->
                <div id="wizard-card-lovable" onclick="if(typeof window.coraShowToast==='function'){window.coraShowToast('Lovable integration is coming soon!','info');}else{console.log('Lovable coming soon');}" class="atw-card" style="text-align:left;background:#fafafa;border:2px solid #e4e4e7;border-radius:20px;overflow:hidden;cursor:not-allowed;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.04);opacity:.55;filter:grayscale(.35);position:relative;transition:opacity .2s,filter .2s;user-select:none;" onmouseover="this.style.opacity='.62';" onmouseout="this.style.opacity='.55';">
                    <div style="position:relative;overflow:hidden;background:#f0eef5;">
                        <div style="width:100%;padding-bottom:56.25%;position:relative;">
                            <img src="<?php echo esc_url( plugin_dir_url(dirname(__FILE__)) . 'assets/img/wizard-lovable-thumb.jpg' ); ?>" alt="Lovable Studio" class="atw-thumb" style="position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;filter:grayscale(.3);" loading="lazy">
                            <!-- Permanent lock overlay -->
                            <div style="position:absolute;inset:0;background:rgba(24,24,27,.32);display:flex;align-items:center;justify-content:center;">
                                <div style="width:48px;height:48px;background:rgba(255,255,255,.92);border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 16px rgba(0,0,0,.12);">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#71717a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                                </div>
                            </div>
                        </div>
                        <!-- Lovable pill badge (left) -->
                        <div style="position:absolute;top:11px;left:11px;display:flex;align-items:center;gap:5px;background:rgba(255,255,255,.92);backdrop-filter:blur(8px);border-radius:100px;padding:4px 9px 4px 6px;box-shadow:0 1px 6px rgba(0,0,0,.14);">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#a1a1aa" stroke-width="2.2" stroke-linecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                            <span style="font-size:10px;font-weight:800;color:#a1a1aa;letter-spacing:-.01em;">Lovable</span>
                        </div>
                        <!-- Coming Soon badge (right) -->
                        <div style="position:absolute;top:11px;right:11px;display:flex;align-items:center;gap:4px;background:rgba(24,24,27,.82);backdrop-filter:blur(8px);border-radius:100px;padding:5px 10px 5px 7px;box-shadow:0 2px 8px rgba(0,0,0,.18);">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#e4e4e7" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                            <span style="font-size:9px;font-weight:800;color:#e4e4e7;letter-spacing:.04em;text-transform:uppercase;">Coming Soon</span>
                        </div>
                    </div>
                    <div style="padding:18px 20px 20px;">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px;">
                            <div>
                                <h3 style="font-size:15px;font-weight:800;color:#a1a1aa;letter-spacing:-.025em;margin-bottom:4px;">Lovable Studio</h3>
                                <p style="font-size:12px;color:#a1a1aa;line-height:1.55;">Connect a live AI-built Lovable.dev project.</p>
                            </div>
                            <div style="width:18px;height:18px;min-width:18px;display:flex;align-items:center;justify-content:center;margin-top:2px;flex-shrink:0;">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d4d4d8" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                            </div>
                        </div>
                        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:14px;">
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#a1a1aa;border-radius:6px;border:1px solid #e4e4e7;">Lovable API</span>
                            <span style="font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;background:#f4f4f5;color:#a1a1aa;border-radius:6px;border:1px solid #e4e4e7;">Live Sync</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- STEP 2-NEXTJS: Next.js Setup -->
        <div id="wizard-step-2-nextjs" class="atw-anim" style="display:none;flex:1;flex-direction:column;align-items:center;justify-content:center;padding:40px 28px;">
            <div style="width:100%;max-width:580px;">
                <div style="text-align:center;margin-bottom:28px;">
                    <div style="width:52px;height:52px;background:#18181b;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;box-shadow:0 4px 16px rgba(0,0,0,0.12);">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M12 2L2 19.7778H22L12 2Z"/></svg>
                    </div>
                    <div style="display:inline-flex;align-items:center;padding:4px 12px;background:#18181b;border-radius:100px;margin-bottom:12px;">
                        <span style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:white;">▲ Next.js App Router</span>
                    </div>
                    <h2 style="font-size:24px;font-weight:900;color:#18181b;letter-spacing:-.04em;line-height:1.1;margin-bottom:8px;">Connect Next.js Project</h2>
                    <p style="font-size:12.5px;color:#71717a;line-height:1.6;max-width:460px;margin:0 auto;">Connect your GitHub repository and live deployment to unlock instant ISR on-demand revalidation, dynamic route sync, and operational widgets.</p>
                </div>

                <div style="display:flex;flex-direction:column;gap:16px;background:white;border:1.5px solid #e4e4e7;border-radius:16px;padding:22px;box-shadow:0 1px 4px rgba(0,0,0,.04);">
                    <!-- PAT Field with Workspace Storage control -->
                    <?php
                        $wiz_saved_pat = get_option( 'cora_git_sync_token', '' );
                    ?>
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Personal Access Token (PAT) *</label>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="password" id="wiz-nextjs-token" class="atw-input" 
                                   placeholder="ghp_xxxxxxxxxxxx" 
                                   value="<?php echo esc_attr( $wiz_saved_pat ); ?>"
                                   style="font-size:12.5px;flex:1;">
                            <button type="button" onclick="if(typeof wizSavePatGlobally === 'function') { wizSavePatGlobally('wiz-nextjs-token'); }" style="flex-shrink:0;display:inline-flex;align-items:center;gap:5px;padding:9px 14px;background:#18181b;color:white;border:none;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:all .18s;white-space:nowrap;font-family:inherit;">
                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                <span>Save Token</span>
                            </button>
                        </div>
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Stored securely in your workspace for automated repo inspection and commit synchronization.</p>
                    </div>

                    <!-- Repo URL field -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <div style="display:flex;align-items:center;justify-content:space-between;width:100%;">
                            <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">GitHub Repository URL *</label>
                            <a href="https://github.com?tab=repositories" target="_blank" style="margin-left:auto;font-size:10px;font-weight:700;color:#18181b;text-decoration:none;display:inline-flex;align-items:center;gap:3px;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
                                Find Repository
                                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                            </a>
                        </div>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="text" id="wiz-nextjs-repo" class="atw-input" placeholder="https://github.com/username/my-nextjs-frontend" value="<?php echo esc_attr( get_option( 'cora_git_sync_repo', '' ) ); ?>" style="font-size:12.5px;flex:1;">
                            <button type="button" id="wiz-nextjs-check-btn" onclick="wizCheckNextJSRepository()" style="flex-shrink:0;display:inline-flex;align-items:center;gap:5px;padding:9px 14px;background:#18181b;color:white;border:none;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:all .18s;white-space:nowrap;font-family:inherit;">
                                <svg id="wiz-nextjs-check-icon" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                                <span id="wiz-nextjs-check-label">Scan Routes</span>
                            </button>
                        </div>
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">The Next.js Git repository containing your <code style="font-family:monospace;background:#f4f4f5;padding:1px 4px;border-radius:4px;">app/</code> or <code style="font-family:monospace;background:#f4f4f5;padding:1px 4px;border-radius:4px;">pages/</code> directory.</p>
                    </div>

                    <!-- Branch Selector / Field -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Branch</label>
                        <input type="text" id="wiz-nextjs-branch" class="atw-input" placeholder="main" value="<?php echo esc_attr( get_option( 'cora_git_sync_branch', 'main' ) ); ?>" style="font-size:12.5px;">
                        
                        <!-- Branch pills container -->
                        <div id="wiz-nextjs-branch-picker" style="display:none;margin-top:6px;margin-bottom:4px;">
                            <div id="wiz-nextjs-branch-loading" style="display:none;align-items:center;gap:8px;padding:10px 12px;background:#fafafa;border:1.5px solid #e4e4e7;border-radius:9px;">
                                <svg class="animate-spin" style="width:14px;height:14px;animation:wizSpin 1s linear infinite;" viewBox="0 0 24 24" fill="none"><circle style="opacity:.25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path style="opacity:.75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>
                                <span style="font-size:11.5px;color:#52525b;">Loading branches from GitHub…</span>
                            </div>
                            <div id="wiz-nextjs-branch-pills" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
                        </div>
                    </div>

                    <!-- Scanned Next.js Routes Panel -->
                    <div id="wiz-nextjs-scanned-container" style="display:none;margin-top:4px;border:1.5px solid #e4e4e7;border-radius:14px;background:#fafafa;overflow:hidden;">
                        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #e4e4e7;background:#f4f4f5;">
                            <span style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#18181b;display:flex;align-items:center;gap:5px;">
                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                                Detected Next.js Routes
                            </span>
                            <span id="wiz-nextjs-scanned-count" style="font-size:9px;font-weight:800;background:#18181b;color:white;padding:2px 8px;border-radius:20px;letter-spacing:.04em;">0 routes</span>
                        </div>
                        <div id="wiz-nextjs-scanned-list" style="display:flex;flex-wrap:wrap;gap:6px;padding:12px 14px;max-height:150px;overflow-y:auto;">
                            <!-- Injected route pills -->
                        </div>
                    </div>

                    <!-- Live Frontend Deployment URL -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <div style="display:flex;align-items:center;justify-content:space-between;width:100%;">
                            <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Live Deployment URL (Optional)</label>
                            <span style="font-size:9.5px;font-weight:700;color:#10b981;background:#ecfdf5;padding:2px 6px;border-radius:4px;border:1px solid #d1fae5;">Vercel / Netlify / Custom</span>
                        </div>
                        <input type="url" id="wiz-nextjs-live-url" class="atw-input" placeholder="https://my-nextjs-frontend.vercel.app" value="" style="font-size:12.5px;">
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Enables 1-click on-demand ISR revalidation and live preview mode.</p>
                    </div>

                    <!-- On-Demand ISR Secret -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <div style="display:flex;align-items:center;justify-content:space-between;width:100%;">
                            <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">On-Demand ISR Revalidation Secret</label>
                            <button type="button" onclick="wizRegenerateIsrSecret()" style="background:none;border:none;cursor:pointer;font-size:10px;font-weight:700;color:#18181b;text-decoration:underline;">Regenerate</button>
                        </div>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="text" id="wiz-nextjs-secret" class="atw-input" readonly value="<?php echo 'cora_sec_' . substr( md5( uniqid( rand(), true ) ), 0, 20 ); ?>" style="font-size:11.5px;font-family:monospace;background:#f4f4f5;color:#18181b;flex:1;">
                            <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('wiz-nextjs-secret').value); window.coraShowToast('ISR Secret copied to clipboard!', 'success');" style="flex-shrink:0;display:inline-flex;align-items:center;gap:4px;padding:9px 12px;background:#f4f4f5;border:1.5px solid #e4e4e7;border-radius:9px;font-size:11px;font-weight:700;color:#18181b;cursor:pointer;">
                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                Copy
                            </button>
                        </div>
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Set as <code style="font-family:monospace;background:#f4f4f5;padding:1px 4px;border-radius:4px;">CORA_REVALIDATE_SECRET</code> in your Vercel / Next.js environment variables.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- STEP 2A: Elementor Setup -->
        <div id="wizard-step-2a" class="atw-anim" style="display:none;flex:1;flex-direction:column;align-items:center;justify-content:center;padding:40px 28px;">
            <div style="width:100%;max-width:540px;">

                <!-- Header -->
                <div style="text-align:center;margin-bottom:28px;">
                    <div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px 4px 7px;background:#18181b;border-radius:100px;margin-bottom:16px;">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="5" fill="#92003B"/><path d="M7 7h10M7 12h10M7 17h6" stroke="white" stroke-width="2.2" stroke-linecap="round"/></svg>
                        <span style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#a1a1aa;">Elementor</span>
                    </div>
                    <h2 style="font-size:24px;font-weight:900;color:#18181b;letter-spacing:-.04em;line-height:1.1;margin-bottom:8px;">How are you importing?</h2>
                    <p style="font-size:12.5px;color:#71717a;line-height:1.6;">Upload a Kit archive or pull directly from a GitHub repository.</p>
                </div>

                <!-- Method Tab Switcher -->
                <div style="display:grid;grid-template-columns:1fr 1fr;background:#f4f4f5;border-radius:14px;padding:4px;gap:3px;margin-bottom:20px;">
                    <button type="button" onclick="wizardSetSubMode('upload')" id="wiz-tab-upload" class="atw-tab atw-tab-on" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;border-radius:11px;font-size:11.5px;font-weight:700;transition:all .18s;font-family:inherit;">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        Upload Kit (.zip)
                    </button>
                    <button type="button" onclick="if(typeof window.coraShowToast==='function'){window.coraShowToast('GitHub sync is for headless / code-based themes. For Elementor, please upload an Elementor Template Kit (.zip).', 'info');}else{console.log('GitHub sync locked for Elementor');}" id="wiz-tab-github" class="atw-tab atw-tab-off" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;border-radius:11px;font-size:11.5px;font-weight:700;transition:all .18s;font-family:inherit;opacity:0.5;cursor:not-allowed;" title="GitHub sync is locked for Elementor themes">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Connect GitHub
                    </button>
                </div>

                <!-- Upload Area -->
                <div id="wiz-upload-area">
                    <!-- Drop Zone -->
                    <label for="wiz-kit-file" id="wiz-dropzone-label" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:36px 24px;background:white;border:1.5px dashed #d4d4d8;border-radius:18px;cursor:pointer;transition:all .2s;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,.03);" onmouseover="this.style.borderColor='#18181b';this.style.background='#fafafa';" onmouseout="this.style.borderColor='#d4d4d8';this.style.background='white';">
                        <!-- Upload Icon Box -->
                        <div style="width:52px;height:52px;background:#f4f4f5;border-radius:14px;display:flex;align-items:center;justify-content:center;border:1px solid #e4e4e7;transition:all .2s;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52525b" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                <polyline points="17 8 12 3 7 8"/>
                                <line x1="12" y1="3" x2="12" y2="15"/>
                            </svg>
                        </div>
                        <!-- Text -->
                        <div>
                            <p style="font-size:13px;font-weight:700;color:#18181b;margin-bottom:4px;letter-spacing:-.01em;">Drop your Elementor Kit here</p>
                            <p style="font-size:11px;color:#a1a1aa;line-height:1.5;">or <span style="color:#18181b;font-weight:700;text-decoration:underline;text-underline-offset:2px;">click to browse</span> &nbsp;·&nbsp; <span style="font-family:monospace;font-size:10px;background:#f4f4f5;padding:1px 6px;border-radius:5px;color:#71717a;">.zip</span> only</p>
                        </div>
                        <input type="file" id="wiz-kit-file" accept=".zip" style="display:none;" onchange="wizardKitFileSelected(this)">
                    </label>

                    <!-- Selected File Card -->
                    <div id="wiz-kit-selected" style="display:none;align-items:center;gap:10px;margin-top:10px;padding:11px 14px;background:white;border:1.5px solid #e4e4e7;border-radius:13px;box-shadow:0 1px 3px rgba(0,0,0,.04);">
                        <!-- File icon -->
                        <div style="width:36px;height:36px;background:#f4f4f5;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;border:1px solid #e4e4e7;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#71717a" stroke-width="2" stroke-linecap="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                        </div>
                        <!-- Filename -->
                        <div style="flex:1;min-width:0;">
                            <p id="wiz-kit-filename" style="font-size:11.5px;font-weight:700;color:#18181b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:2px;"></p>
                            <p style="font-size:9.5px;color:#a1a1aa;font-weight:500;">.zip archive · Elementor Kit</p>
                        </div>
                        <!-- Success check + remove -->
                        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
                            <span style="width:20px;height:20px;background:#dcfce7;border-radius:50%;display:flex;align-items:center;justify-content:center;">
                                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                            </span>
                            <button onclick="wizardClearFile()" style="background:none;border:none;cursor:pointer;padding:4px;border-radius:6px;color:#a1a1aa;display:flex;align-items:center;" onmouseover="this.style.background='#f4f4f5';this.style.color='#18181b';" onmouseout="this.style.background='none';this.style.color='#a1a1aa';">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                        </div>
                    </div>

                    <!-- Scanned Pages Panel -->
                    <div id="wiz-kit-scanned-container" style="display:none;margin-top:10px;border:1.5px solid #e4e4e7;border-radius:16px;background:white;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.04);">
                        <!-- Panel Header -->
                        <div style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px;border-bottom:1px solid #f4f4f5;background:#fafafa;">
                            <span style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#71717a;display:flex;align-items:center;gap:5px;">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                Pages found in kit
                            </span>
                            <span id="wiz-kit-scanned-count" style="font-size:9px;font-weight:800;background:#18181b;color:white;padding:2px 8px;border-radius:20px;letter-spacing:.04em;">0 pages</span>
                        </div>
                        <!-- Page Tags -->
                        <div id="wiz-kit-scanned-list" style="display:flex;flex-wrap:wrap;gap:6px;padding:12px 14px;max-height:140px;overflow-y:auto;">
                            <!-- page tags injected by JS -->
                        </div>
                    </div>
                </div>

                <!-- GitHub Area -->
                <div id="wiz-github-area" style="display:none;flex-direction:column;gap:14px;">
                    <div style="display:flex;flex-direction:column;gap:6px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Repository URL *</label>
                        <input type="text" id="wiz-github-repo" class="atw-input" placeholder="https://github.com/your-org/your-theme">
                    </div>
                    <div style="display:flex;flex-direction:column;gap:6px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Branch</label>
                        <input type="text" id="wiz-github-branch" class="atw-input" placeholder="main">
                    </div>
                </div>

            </div>
        </div>

        <!-- STEP 2B: Lovable Setup -->
        <div id="wizard-step-2b" class="atw-anim" style="display:none;flex:1;flex-direction:column;align-items:center;justify-content:center;padding:40px 28px;">
            <div style="width:100%;max-width:580px;">
                <div style="text-align:center;margin-bottom:28px;">
                    <div style="width:52px;height:52px;background:linear-gradient(135deg,#f5f3ff,#ede9fe);border:1px solid #ddd6fe;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;box-shadow:0 2px 8px rgba(124,58,237,0.06);">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="2" stroke-linecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    </div>
                    <div style="display:inline-flex;align-items:center;padding:4px 12px;background:#f5f3ff;border:1px solid #ede9fe;border-radius:100px;margin-bottom:12px;">
                        <span style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#7c3aed;">Lovable Studio</span>
                    </div>
                    <h2 style="font-size:24px;font-weight:900;color:#18181b;letter-spacing:-.04em;line-height:1.1;margin-bottom:8px;">Setup Lovable Project</h2>
                    <p style="font-size:12.5px;color:#71717a;line-height:1.6;max-width:420px;margin:0 auto;">Synchronize design changes from Lovable.dev directly to your Cora theme.</p>
                </div>

                <!-- Tab bar switcher -->
                <div style="display:grid;grid-template-columns:1fr 1fr;background:#f4f4f5;border-radius:14px;padding:4px;gap:3px;margin-bottom:20px;">
                    <button type="button" onclick="wizardSetLovableMode('connect')" id="wiz-lovable-tab-connect" class="atw-tab atw-tab-on" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;border-radius:11px;font-size:11.5px;font-weight:700;transition:all .18s;font-family:inherit;">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><rect x="18" y="8" width="5" height="5" rx="1"/></svg>
                        Connect Existing Project
                    </button>
                    <button type="button" onclick="wizardSetLovableMode('scratch')" id="wiz-lovable-tab-scratch" class="atw-tab atw-tab-off" style="display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 14px;border-radius:11px;font-size:11.5px;font-weight:700;transition:all .18s;font-family:inherit;">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                        Create from Scratch
                    </button>
                </div>

                <!-- SUB-CONTAINER 1: Connect Existing Project -->
                <div id="wiz-lovable-connect-area" style="display:flex;flex-direction:column;gap:16px;background:white;border:1.5px solid #e4e4e7;border-radius:16px;padding:20px;box-shadow:0 1px 4px rgba(0,0,0,.04);">
                    <!-- PAT Field with Workspace Storage control -->
                    <?php
                        $wiz_saved_pat = get_option( 'cora_git_sync_token', '' );
                        $wiz_pat_is_saved = ! empty( $wiz_saved_pat );
                    ?>
                    <div id="wiz-pat-wrapper" style="display:flex;flex-direction:column;gap:5px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Personal Access Token (PAT) *</label>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="password" id="wiz-github-token-lov" class="atw-input" 
                                   placeholder="ghp_xxxxxxxxxxxx" 
                                   value="<?php echo esc_attr( $wiz_saved_pat ); ?>"
                                   style="font-size:12.5px;flex:1;"
                                   oninput="wizRepoChanged()">
                            <button type="button" id="wiz-save-pat-btn" onclick="console.log('Save Token clicked'); var saveBtnSpan = document.getElementById('wiz-save-pat-label'); if(saveBtnSpan) saveBtnSpan.textContent = 'Saving…'; if(typeof wizSavePatGlobally === 'function') { wizSavePatGlobally(); } else if(typeof window.wizSavePatGlobally === 'function') { window.wizSavePatGlobally(); } else { console.error('wizSavePatGlobally is not defined'); }" style="flex-shrink:0;display:inline-flex;align-items:center;gap:5px;padding:9px 14px;background:#18181b;color:white;border:none;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:all .18s;white-space:nowrap;font-family:inherit;" onmouseover="if(!this.disabled)this.style.background='#27272a'" onmouseout="if(!this.disabled)this.style.background='#18181b'">
                                <svg id="wiz-save-pat-icon" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                <span id="wiz-save-pat-label">Save Token</span>
                            </button>
                        </div>
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Pasting and saving the token globally stores it in the workspace so you don't need to paste it every time.</p>
                    </div>

                    <!-- Repo URL field -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <div style="display:flex;align-items:center;justify-content:between;width:100%;">
                            <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">GitHub Repository URL *</label>
                            <a href="https://github.com?tab=repositories" target="_blank" style="margin-left:auto;font-size:10px;font-weight:700;color:#7c3aed;text-decoration:none;display:inline-flex;align-items:center;gap:3px;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
                                Find Repository
                                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                            </a>
                        </div>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="text" id="wiz-github-repo-lov" class="atw-input" placeholder="https://github.com/username/my-lovable-theme" value="<?php echo esc_attr( get_option( 'cora_git_sync_repo', '' ) ); ?>" style="font-size:12.5px;flex:1;" oninput="wizRepoChanged()">
                            <button type="button" id="wiz-check-repo-btn" onclick="console.log('Button clicked'); var btnSpan = document.getElementById('wiz-check-repo-label'); if(btnSpan) btnSpan.textContent = 'Checking…'; if(typeof wizCheckRepository === 'function') { wizCheckRepository(); } else if(typeof window.wizCheckRepository === 'function') { window.wizCheckRepository(); } else { console.error('wizCheckRepository is not defined'); }" style="flex-shrink:0;display:inline-flex;align-items:center;gap:5px;padding:9px 14px;background:#18181b;color:white;border:none;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:all .18s;white-space:nowrap;font-family:inherit;" onmouseover="if(!this.disabled)this.style.background='#27272a'" onmouseout="if(!this.disabled)this.style.background='#18181b'">
                                <svg id="wiz-check-repo-icon" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                                <span id="wiz-check-repo-label">Check Repository</span>
                            </button>
                        </div>
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">The repository linked to your Lovable project workspace.</p>
                    </div>

                    <!-- Branch Selector / Field -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Branch</label>
                        <input type="text" id="wiz-github-branch-lov" class="atw-input" placeholder="main" value="<?php echo esc_attr( get_option( 'cora_git_sync_branch', 'main' ) ); ?>" style="font-size:12.5px;">
                        
                        <!-- Branch pills container, hidden by default until checked -->
                        <div id="wiz-branch-picker" style="display:none;margin-top:6px;margin-bottom:4px;">
                            <div id="wiz-branch-loading" style="display:none;align-items:center;gap:8px;padding:10px 12px;background:#fafafa;border:1.5px solid #e4e4e7;border-radius:9px;">
                                <svg class="animate-spin" style="width:14px;height:14px;animation:wizSpin 1s linear infinite;" viewBox="0 0 24 24" fill="none"><circle style="opacity:.25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path style="opacity:.75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>
                                <span style="font-size:11.5px;color:#52525b;">Loading branches from GitHub…</span>
                            </div>
                            <div id="wiz-branch-pills" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
                        </div>
                        <p id="wiz-branch-hint" style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Click "Check Repository" to load branches automatically.</p>
                    </div>

                    <!-- Lovable Project URL -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <div style="display:flex;align-items:center;justify-content:between;width:100%;">
                            <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Lovable Project URL *</label>
                            <a href="https://lovable.dev/projects" target="_blank" style="margin-left:auto;font-size:10px;font-weight:700;color:#7c3aed;text-decoration:none;display:inline-flex;align-items:center;gap:3px;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
                                Open Lovable Dashboard
                                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                            </a>
                        </div>
                        <input type="text" id="wiz-lovable-url" class="atw-input" placeholder="https://lovable.dev/projects/your-project-id" value="" style="font-size:12.5px;">
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">Copy the URL directly from the address bar when viewing your project in Lovable.</p>
                    </div>

                    <!-- Live / Preview URL (Optional) -->
                    <div style="display:flex;flex-direction:column;gap:5px;">
                        <label style="font-size:9.5px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#71717a;">Live / Preview URL (Optional)</label>
                        <input type="url" id="wiz-lovable-live-url" class="atw-input" placeholder="https://your-app.lovable.app" value="" style="font-size:12.5px;">
                        <p style="font-size:10px;color:#a1a1aa;line-height:1.4;margin:0;">If your app is deployed, enter the live URL to configure links automatically.</p>
                    </div>
                </div>

                <!-- SUB-CONTAINER 2: Create from Scratch Guide -->
                <div id="wiz-lovable-scratch-area" style="display:none;flex-direction:column;gap:18px;">
                    <!-- Template Choice Cards -->
                    <div class="atw-template-grid">
                        <div style="background:white;border:1.5px solid #e4e4e7;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.03);display:flex;flex-direction:column;justify-content:space-between;transition:all .2s;" onmouseover="this.style.borderColor='#18181b'" onmouseout="this.style.borderColor='#e4e4e7'">
                            <div style="height:90px;background:#fbfaf7;border-bottom:1px solid #e4e4e7;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                                <div class="flex items-center justify-center text-zinc-400"><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
                            </div>
                            <div style="padding:12px;">
                                <h4 style="font-size:11.5px;font-weight:750;color:#18181b;margin-bottom:3px;">Apex Luxury Real Estate</h4>
                                <p style="font-size:9.5px;color:#71717a;line-height:1.4;margin-bottom:10px;">Elegant grid, dark neutral aesthetics, listings showcase, and interactive filters.</p>
                                <button type="button" onclick="window.open('https://lovable.dev', '_blank')" style="width:100%;padding:6px;background:#18181b;color:white;border:none;border-radius:6px;font-size:9.5px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:3px;" onmouseover="this.style.background='#27272a'" onmouseout="this.style.background='#18181b'">
                                    Start in Lovable
                                    <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                                </button>
                            </div>
                        </div>
                        <div style="background:white;border:1.5px solid #e4e4e7;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.03);display:flex;flex-direction:column;justify-content:space-between;transition:all .2s;" onmouseover="this.style.borderColor='#18181b'" onmouseout="this.style.borderColor='#e4e4e7'">
                            <div style="height:90px;background:#fff5f7;border-bottom:1px solid #e4e4e7;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                                <div class="flex items-center justify-center text-zinc-400"><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path></svg></div>
                            </div>
                            <div style="padding:12px;">
                                <h4 style="font-size:11.5px;font-weight:750;color:#18181b;margin-bottom:3px;">Cosmetics Blush Shop</h4>
                                <p style="font-size:9.5px;color:#71717a;line-height:1.4;margin-bottom:10px;">Blush pink theme, smooth scroll, parallax catalogs, and cart widgets.</p>
                                <button type="button" onclick="window.open('https://lovable.dev', '_blank')" style="width:100%;padding:6px;background:#18181b;color:white;border:none;border-radius:6px;font-size:9.5px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:3px;" onmouseover="this.style.background='#27272a'" onmouseout="this.style.background='#18181b'">
                                    Start in Lovable
                                    <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Step-by-Step Instructions -->
                    <div style="background:#fcfbf9;border:1px dashed #e4e0d5;border-radius:14px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.01);">
                        <h4 style="font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#18181b;margin-bottom:12px;display:flex;align-items:center;gap:5px;">
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                            Instructions for Scratch Onboarding
                        </h4>
                        <div style="display:flex;flex-direction:column;gap:10px;font-size:11px;color:#52525b;line-height:1.55;">
                            <div>
                                <strong style="color:#18181b;">1. Launch Lovable.dev:</strong> Open <a href="https://lovable.dev" target="_blank" style="color:#7c3aed;font-weight:700;text-decoration:underline;">Lovable.dev</a>, click "New Project" and describe your design goals.
                            </div>
                            <div>
                                <strong style="color:#18181b;">2. Sync GitHub Repo:</strong> Navigate to Settings inside Lovable and connect a GitHub repository to push code updates automatically.
                            </div>
                            <div>
                                <strong style="color:#18181b;">3. Complete Setup:</strong> Copy your repository link and paste it into the <a href="javascript:void(0)" onclick="wizardSetLovableMode('connect')" style="color:#7c3aed;font-weight:700;text-decoration:underline;">Connect Existing Project</a> tab above to pull your pages!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- STEP 3: Name & Save -->
        <div id="wizard-step-3" class="atw-anim" style="display:none;flex:1;flex-direction:column;align-items:center;justify-content:center;padding:52px 32px;">
            <div style="width:100%;max-width:520px;">
                <div style="text-align:center;margin-bottom:32px;">
                    <div style="width:56px;height:56px;background:#18181b;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                    </div>
                    <p style="font-size:10px;font-weight:900;letter-spacing:.18em;text-transform:uppercase;color:#a1a1aa;margin-bottom:14px;">Step 3 of 3</p>
                    <h2 style="font-size:26px;font-weight:900;color:#18181b;letter-spacing:-.04em;line-height:1.1;margin-bottom:10px;">Name your theme</h2>
                    <p style="font-size:13px;color:#71717a;line-height:1.6;">You can rename it anytime from the Themes section.</p>
                </div>
                <div style="background:white;border:1.5px solid #e4e4e7;border-radius:16px;padding:24px;box-shadow:0 1px 4px rgba(0,0,0,.05);">
                    <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:20px;">
                        <label style="font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#71717a;">Theme Name *</label>
                        <input type="text" id="wiz-theme-name" class="atw-input" placeholder="e.g. Horizon Light Theme" style="font-size:15px;font-weight:700;padding:14px 16px;border-width:2px;">
                    </div>
                    <div style="border-top:1px solid #f4f4f5;padding-top:16px;display:flex;flex-direction:column;gap:10px;">
                        <p style="font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:.12em;color:#a1a1aa;">Configuration</p>
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <span style="font-size:12px;color:#71717a;">Builder</span>
                            <span id="wiz-summary-builder" style="font-size:12px;font-weight:700;color:#18181b;"></span>
                        </div>
                        <div style="display:flex;justify-content:space-between;align-items:center;">
                            <span style="font-size:12px;color:#71717a;">Source</span>
                            <span id="wiz-summary-source" style="font-size:12px;font-weight:700;color:#18181b;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right;"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- /body -->

    <!-- STICKY FOOTER -->
    <div style="flex-shrink:0;height:64px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;background:rgba(248,248,247,.92);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-top:1px solid rgba(0,0,0,.07);">
        <button id="wiz-back-btn" onclick="wizardBack()" style="display:none;align-items:center;gap:6px;padding:9px 18px;background:white;border:1.5px solid #e4e4e7;border-radius:10px;font-size:12px;font-weight:700;color:#52525b;cursor:pointer;transition:all .15s;font-family:inherit;" onmouseover="this.style.background='#f4f4f5'" onmouseout="this.style.background='white'">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
            Back
        </button>
        <div></div>
        <button id="wiz-next-btn" onclick="wizardNext()" style="display:flex;align-items:center;gap:7px;padding:10px 24px;background:#18181b;color:white;border:none;border-radius:10px;font-size:12px;font-weight:700;cursor:not-allowed;opacity:.4;transition:all .18s;letter-spacing:-.01em;font-family:inherit;" disabled>
            Continue
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>
        </button>
    </div>
</div>




<div id="theme-version-drawer" class="fixed inset-y-0 right-0 z-50 w-[350px] bg-white border-l border-zinc-200 shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out flex flex-col">
    <!-- Header -->
    <div class="p-5 border-b border-zinc-150 flex items-center justify-between bg-white shrink-0">
        <div class="flex items-center gap-3">
            <!-- Icon box -->
            <div class="w-10 h-10 rounded-xl bg-zinc-50 border border-zinc-150 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-700 "><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            </div>
            <div>
                <h3 class="text-sm font-bold text-zinc-900 leading-tight">Version history</h3>
                <span class="text-[10px] text-zinc-400 font-medium">View and restore previous versions</span>
            </div>
        </div>
        <!-- Close button -->
        <button onclick="toggleThemeVersionDrawer(event)" class="p-2 border border-zinc-150 hover:bg-zinc-50 rounded-full text-zinc-500 hover:text-zinc-800 cursor-pointer bg-transparent flex items-center justify-center transition-colors">
            <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
    </div>
    
    <!-- Body Content (Simple versions listing for non-technical users) -->
    <div class="flex-1 overflow-y-auto p-5 space-y-4">
        <!-- Current Version Card -->
        <div class="p-3 bg-white rounded-xl border border-green-200 border-l-4 border-l-green-500 flex items-center justify-between gap-3 shadow-xs">
            <div class="flex items-center gap-3 min-w-0">
                <!-- Small square dot indicator -->
                <div class="w-8 h-8 rounded-lg bg-green-50 border border-green-100 flex items-center justify-center shrink-0">
                    <span class="w-2.5 h-2.5 rounded-full bg-green-500"></span>
                </div>
                <div class="min-w-0">
                    <div class="text-xs font-bold text-zinc-900 leading-tight">v15.5.0</div>
                    <div class="text-[10px] text-zinc-450 mt-1 truncate">Updated by Dravya • 2 hours ago</div>
                </div>
            </div>
            <!-- Live Pill Badge -->
            <div class="bg-green-50/50 text-green-600 text-[9px] font-bold border border-green-200 px-2 py-0.5 rounded-full flex items-center gap-1.5 shrink-0 select-none">
                <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                LIVE
            </div>
        </div>

        <!-- Previous Version Card -->
        <div class="p-3 bg-white rounded-xl border border-zinc-200 flex items-center justify-between gap-3 shadow-xs">
            <div class="flex items-center gap-3 min-w-0">
                <!-- Small square dot indicator -->
                <div class="w-8 h-8 rounded-lg bg-zinc-50 border border-zinc-150 flex items-center justify-center shrink-0">
                    <span class="w-2.5 h-2.5 rounded-full bg-zinc-400 "></span>
                </div>
                <div class="min-w-0">
                    <div class="text-xs font-semibold text-zinc-850 leading-tight">v15.4.0</div>
                    <div class="text-[10px] text-zinc-450 mt-1 truncate">Updated by Dravya • 5 days ago</div>
                </div>
            </div>
            <!-- Restore Button -->
            <?php if ( $live_theme ) : ?>
            <button onclick="triggerThemeUpdate(<?php echo $live_theme['id']; ?>)" class="px-2.5 py-1.5 border border-zinc-200 hover:bg-zinc-50 rounded-lg text-[9.5px] font-bold flex items-center gap-1.5 bg-white text-zinc-800 cursor-pointer shadow-xs transition-colors shrink-0">
                <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
                Restore
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Backdrop for Drawer -->
<div id="theme-version-drawer-backdrop" class="hidden fixed inset-0 z-40 bg-black/15 backdrop-blur-xs transition-opacity duration-300 ease-in-out" onclick="toggleThemeVersionDrawer(event)"></div>

<script src="<?php echo esc_url( CORA_WORKSPACE_URL . 'assets/js/lovable-prompts.js' ); ?>"></script>
<script>
    // --- Lovable Mappings Configuration ---
    <?php
    $theme_settings_raw = $wpdb->get_var( $wpdb->prepare( "SELECT settings FROM {$wpdb->prefix}cora_canvas_themes WHERE id = %d", $current_theme_id ) );
    $theme_settings = json_decode( $theme_settings_raw, true ) ?: array();
    $active_theme_mappings = isset( $theme_settings['page_mappings'] ) ? $theme_settings['page_mappings'] : get_option( 'cora_git_sync_page_mappings', array() );
    ?>
    window.CORA_LOVABLE_ROUTES = <?php echo json_encode( cora_git_sync_get_lovable_routes( $current_theme_id ) ); ?>;
    window.CORA_PAGE_MAPPINGS = <?php echo json_encode( $active_theme_mappings ); ?>;
    window.CORA_GIT_CONFIG = <?php echo json_encode([
        'enabled'     => get_option('cora_git_sync_enabled') === '1',
        'repo'        => get_option('cora_git_sync_repo', ''),
        'branch'      => get_option('cora_git_sync_branch', 'main'),
        'live_url'    => get_option('cora_git_sync_live_url', ''),
        'last_time'   => get_option('cora_git_sync_last_time', 0),
        'last_status' => get_option('cora_git_sync_last_status', ''),
        'compat_flags'=> get_option('cora_git_sync_compat_flags', []),
    ]); ?>;
</script>
<script src="<?php echo esc_url( CORA_WORKSPACE_URL . 'assets/js/lovable-studio.js' ); ?>"></script>
<script>
    // --- Canvas Global State ---
    const canvasState = {
        level: 1,
        activeThemeId: <?php echo $live_theme ? $live_theme['id'] : 0; ?>,
        activeThemeName: '<?php echo $live_theme ? esc_js($live_theme['name']) : ''; ?>',
        activeThemeIsLive: <?php echo $live_theme && $live_theme['status'] === 'live' ? 'true' : 'false'; ?>,
        activePageId: null,
        activeTab: 'pages',
        isReadOnly: <?php echo $is_read_only ? 'true' : 'false'; ?>,
        draftLimit: <?php echo intval( $draft_limit ); ?>,
        isFreePlan: <?php echo in_array( strtolower( cora_get_active_workspace_plan() ), array( 'free', 'free_tier', 'trial', 'none' ), true ) ? 'true' : 'false'; ?>,
        themes: <?php echo json_encode($themes); ?>,
        pages: [],
        menus: <?php echo json_encode( $theme_menus_for_js ); ?> || [],
        wpMenusBase: <?php echo json_encode( $theme_menus_for_js ); ?> || [],
        activeMenuId: <?php echo ! empty( $theme_menus_for_js ) ? "'" . esc_js( $theme_menus_for_js[0]['id'] ) . "'" : "''" ; ?>,
        activeMenuDetailId: null,
        cssEditor: null,
    };
    
    // Bind canvasState to the window object for integration and external scripts
    window.canvasState = canvasState;
    Object.defineProperty(canvasState, 'currentPageId', {
        get: function() { return this.activePageId; },
        set: function(val) { this.activePageId = val; }
    });

    // --- Global Creation & Migration State ---
    var _wizStep = 1;
    var _wizBuilder = 'elementor';
    var _wizSubMode = 'upload';
    var elementorScanState = {
        url: '',
        pages: [],
        selectedIndices: [],
        firstMigratedPostId: null,
        firstMigratedPageId: null,
        firstMigratedTitle: ''
    };
    var selectedElementorFile = null;
    var coraPageEngineMode = 'elementor';
    var coraSelectedHtmlFile = null;
    window.coraPageEngineMode = coraPageEngineMode;
    window.coraSelectedHtmlFile = coraSelectedHtmlFile;

    // --- Canvas Sub-Tab Switcher ---
    function coraSwitchCanvasSubTab(tabId) {
        // Migration tab is desktop-only; fallback to overview on mobile
        if (window.innerWidth < 768 && tabId === 'tab-canvas-migration') {
            tabId = 'tab-canvas-overview';
        }

        // Switch tab contents
        jQuery('.cora-canvas-tab-content').addClass('hidden');
        jQuery('#' + tabId).removeClass('hidden');

        // Switch tab button states
        jQuery('.cora-canvas-sub-tab').each(function() {
            jQuery(this)
                .removeClass('border-zinc-950 text-zinc-950 font-bold')
                .addClass('border-transparent text-zinc-500 font-medium hover:text-zinc-900');
        });

        jQuery('#subtab-btn-' + tabId)
            .removeClass('border-transparent text-zinc-500 font-medium hover:text-zinc-900')
            .addClass('border-zinc-950 text-zinc-950 font-bold');

        try {
            localStorage.setItem('cora_canvas_active_subtab', tabId);
        } catch (e) {}
    }
    window.coraSwitchCanvasSubTab = coraSwitchCanvasSubTab;

    jQuery(document).ready(function($) {
        // Restore active sub-tab from localStorage
        try {
            let savedSubTab = localStorage.getItem('cora_canvas_active_subtab');
            if (window.innerWidth < 768 && savedSubTab === 'tab-canvas-migration') {
                savedSubTab = 'tab-canvas-overview';
            }
            if (savedSubTab && $('#' + savedSubTab).length) {
                coraSwitchCanvasSubTab(savedSubTab);
            }
        } catch (e) {}

        // Explicit delegated click listeners for main tab action buttons
        $(document).on('click', '#tab-btn-add-page', function(e) {
            e.preventDefault();
            if (typeof openNewPageDrawer === 'function') {
                openNewPageDrawer();
            } else if (typeof window.openNewPageDrawer === 'function') {
                window.openNewPageDrawer();
            }
        });

        $(document).on('click', '#tab-action-migrate-elementor', function(e) {
            e.preventDefault();
            if (typeof openElementorMigrationDrawer === 'function') {
                openElementorMigrationDrawer();
            } else if (typeof window.openElementorMigrationDrawer === 'function') {
                window.openElementorMigrationDrawer();
            }
        });

        // Hide standard menu click list if click outside
        $(document).on('click', function() {
            $('[id^="theme-menu-"]').addClass('hidden');
            $('#add-menu-item-dropdown').addClass('hidden');
        });
    });

    // --- PageSpeed Insights Audit and Settings Actions ---
    function triggerPageSpeedAudit() {
        const btn = jQuery('#btn-refresh-pagespeed');
        const spinner = jQuery('#pagespeed-refresh-spinner');
        
        if (btn.hasClass('pointer-events-none')) return;
        
        btn.addClass('pointer-events-none opacity-80');
        spinner.removeClass('hidden');
        window.coraShowToast('Initiating Google PageSpeed Insights performance audit...', 'success');
        
        // Add skeleton loading overlay classes to cards to look premium
        jQuery('#pagespeed-val-lcp, #pagespeed-val-inp, #pagespeed-val-cls, #pagespeed-val-score, #pagespeed-radial-val, #pagespeed-rec-title, #pagespeed-rec-desc').addClass('cora-skeleton rounded text-transparent select-none');
        
        jQuery.post(ajaxurl, {
            action: 'cora_audit_pagespeed_performance'
        }, function(response) {
            btn.removeClass('pointer-events-none opacity-80');
            spinner.addClass('hidden');
            jQuery('#pagespeed-val-lcp, #pagespeed-val-inp, #pagespeed-val-cls, #pagespeed-val-score, #pagespeed-radial-val, #pagespeed-rec-title, #pagespeed-rec-desc').removeClass('cora-skeleton rounded text-transparent select-none');
            
            if (response.success && response.data) {
                const data = response.data;
                window.coraShowToast('Google PageSpeed audit complete!', 'success');
                
                // Update Vitals Strip
                jQuery('#pagespeed-val-lcp').text(data.lcp);
                jQuery('#pagespeed-val-inp').text(data.inp);
                jQuery('#pagespeed-val-cls').text(data.cls);
                jQuery('#pagespeed-val-score').text(data.score);
                jQuery('#pagespeed-radial-val').text(data.score);
                
                // Update Badges & Sparkline colors
                updatePagespeedVitalsUI(data);
                
                // Update connection status
                jQuery('#pagespeed-conn-text').text(data.is_mocked ? 'Simulated (Local Environment)' : 'Connected');
                jQuery('#pagespeed-conn-indicator').removeClass('bg-green-500 bg-amber-400 bg-red-500').addClass(data.is_mocked ? 'bg-amber-400' : 'bg-green-500');
                jQuery('#pagespeed-target-url').text(data.target_url);
                jQuery('#pagespeed-last-updated').text(data.last_updated);
                
                // Update Opportunities List
                updateOpportunitiesUI(data.opportunities);
                
                // Update Recommendation Banner
                updateRecommendationBannerUI(data);
            } else {
                window.coraShowToast('Failed to perform PageSpeed audit: ' + (response.data || 'Unknown error'), 'error');
            }
        }).fail(function() {
            btn.removeClass('pointer-events-none opacity-80');
            spinner.addClass('hidden');
            jQuery('#pagespeed-val-lcp, #pagespeed-val-inp, #pagespeed-val-cls, #pagespeed-val-score, #pagespeed-radial-val, #pagespeed-rec-title, #pagespeed-rec-desc').removeClass('cora-skeleton rounded text-transparent select-none');
            window.coraShowToast('PageSpeed audit request failed due to connection error.', 'error');
        });
    }
    window.triggerPageSpeedAudit = triggerPageSpeedAudit;

    function updatePagespeedVitalsUI(data) {
        // LCP
        const lcpNum = parseFloat(data.lcp);
        let lcpBadge = '', lcpColor = '#ef4444';
        if (lcpNum <= 2.5) {
            lcpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-green-50 text-green-700 border border-green-200/70 leading-none whitespace-nowrap">Good</span>';
            lcpColor = '#22c55e';
        } else if (lcpNum <= 4.0) {
            lcpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
            lcpColor = '#f59e0b';
        } else {
            lcpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-red-50 text-red-650 border border-red-200/70 leading-none whitespace-nowrap">Poor</span>';
        }
        jQuery('#pagespeed-badge-lcp').html(lcpBadge);
        
        // INP
        const inpNum = parseInt(data.inp);
        let inpBadge = '', inpColor = '#ef4444';
        if (inpNum <= 200) {
            inpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-green-50 text-green-700 border border-green-200/70 leading-none whitespace-nowrap">Good</span>';
            inpColor = '#22c55e';
        } else if (inpNum <= 500) {
            inpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
            inpColor = '#f59e0b';
        } else {
            inpBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-red-50 text-red-650 border border-red-200/70 leading-none whitespace-nowrap">Poor</span>';
        }
        jQuery('#pagespeed-badge-inp').html(inpBadge);

        // CLS
        const clsNum = parseFloat(data.cls);
        let clsBadge = '', clsColor = '#ef4444';
        if (clsNum <= 0.1) {
            clsBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-green-50 text-green-700 border border-green-200/70 leading-none whitespace-nowrap">Good</span>';
            clsColor = '#22c55e';
        } else if (clsNum <= 0.25) {
            clsBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
            clsColor = '#f59e0b';
        } else {
            clsBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-red-50 text-red-650 border border-red-200/70 leading-none whitespace-nowrap">Poor</span>';
        }
        jQuery('#pagespeed-badge-cls').html(clsBadge);

        // Score
        const scoreNum = parseInt(data.score);
        let scoreBadge = '', scoreColor = '#ef4444';
        if (scoreNum >= 90) {
            scoreBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-green-50 text-green-700 border border-green-200/70 leading-none whitespace-nowrap">Good</span>';
            scoreColor = '#22c55e';
        } else if (scoreNum >= 50) {
            scoreBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 leading-none whitespace-nowrap">Needs improve</span>';
            scoreColor = '#f59e0b';
        } else {
            scoreBadge = '<span class="px-1.5 py-0.5 text-[8px] font-bold rounded-full bg-red-50 text-red-650 border border-red-200/70 leading-none whitespace-nowrap">Poor</span>';
        }
        jQuery('#pagespeed-badge-score').html(scoreBadge);

        // Update Score Radial & Performance insights score
        jQuery('#pagespeed-radial-score').attr('stroke', scoreColor).attr('stroke-dasharray', scoreNum + ' ' + (100 - scoreNum));
        jQuery('#pagespeed-score-status').text(scoreNum >= 90 ? 'Good' : (scoreNum >= 50 ? 'Needs Improvement' : 'Poor')).removeClass('text-green-600 text-amber-600 text-red-600').addClass(scoreNum >= 90 ? 'text-green-600' : (scoreNum >= 50 ? 'text-amber-600' : 'text-red-600'));
        jQuery('#pagespeed-faster-pct').text(Math.max(10, Math.min(99, scoreNum - 16)));

        // Helper to map history array to points path
        const buildPointsStr = (history, type) => {
            const count = history.length;
            const xStep = count > 1 ? 64 / (count - 1) : 64;
            return history.map((val, idx) => {
                const x = Math.round(idx * xStep);
                let y;
                if (type === 'score') {
                    y = 28 - Math.round((parseFloat(val) / 100) * 20) - 4;
                } else if (type === 'lcp') {
                    y = 28 - Math.round((Math.min(parseFloat(val), 5.0) / 5.0) * 20) - 4;
                } else if (type === 'inp') {
                    y = 28 - Math.round((Math.min(parseFloat(val), 1000) / 1000) * 20) - 4;
                } else {
                    y = 28 - Math.round((Math.min(parseFloat(val), 0.5) / 0.5) * 20) - 4;
                }
                y = Math.max(2, Math.min(26, y));
                return x + ',' + y;
            }).join(' ');
        };

        // Sparkline SVGs have been removed from analytics block layout
    }

    function updateOpportunitiesUI(opportunities) {
        let html = '';
        opportunities.forEach(opp => {
            const severity = opp.severity || 'Medium';
            let badgeClass = 'bg-zinc-100 text-zinc-650 border border-zinc-200';
            if (severity === 'High') {
                badgeClass = 'bg-red-50 text-red-700 border border-red-200/50';
            } else if (severity === 'Medium') {
                badgeClass = 'bg-amber-50 text-amber-700 border border-amber-200/50';
            }

            let icon = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
            const label = opp.label.toLowerCase();
            if (label.includes('javascript') || label.includes('js')) {
                icon = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>';
            } else if (label.includes('image')) {
                icon = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>';
            } else if (label.includes('inp') || label.includes('paint') || label.includes('blocking')) {
                icon = '<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-500 shrink-0"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>';
            }

            html += `
                <div class="flex items-center justify-between p-2.5 bg-zinc-50 rounded-lg hover:bg-zinc-100 cursor-pointer transition-colors group" onclick="window.coraShowToast('Opening optimization guide...')">
                    <div class="flex items-center gap-2.5 min-w-0">
                        ${icon}
                        <div class="min-w-0">
                            <div class="text-[10px] font-bold text-zinc-800 truncate">${opp.label}</div>
                            <div class="text-[9px] text-zinc-400 mt-0.5">${opp.savings}</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 shrink-0 ml-2">
                        <span class="px-2 py-0.5 text-[8px] font-bold rounded-full ${badgeClass}">${severity}</span>
                        <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="text-zinc-350 group-hover:text-zinc-700 transition-colors"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </div>
            `;
        });
        jQuery('#pagespeed-opportunities-list').html(html);
    }

    function updateRecommendationBannerUI(data) {
        const topOpp = data.opportunities[0] || { label: 'Reduce JavaScript execution', savings: 'Potential savings: ~210ms', severity: 'Medium' };
        jQuery('#pagespeed-rec-title').text(topOpp.label);
        
        let metric = 'INP', metricVal = data.inp, target = '150ms';
        const label = topOpp.label.toLowerCase();
        if (label.includes('lcp') || label.includes('image') || label.includes('render')) {
            metric = 'LCP';
            metricVal = data.lcp;
            target = '2.5s';
        }
        
        let desc = 'Your INP score is poor. Consider optimizing JavaScript execution and reducing main-thread work.';
        if (metric === 'LCP') {
            desc = 'Optimize your images, leverage CDNs, and scale them appropriately to improve Largest Contentful Paint (LCP).';
        }

        jQuery('#pagespeed-rec-desc').text(desc);
        jQuery('#pagespeed-rec-metric-lbl').text(metric);
        jQuery('#pagespeed-rec-metric-from').text(metricVal);
        jQuery('#pagespeed-rec-metric-to').text(target);
    }

    function safeGetSettings(themeObj) {
        if (!themeObj) return {};
        if (typeof themeObj.settings === 'string') {
            const trimmed = themeObj.settings.trim();
            if (trimmed === '') return {};
            try {
                return JSON.parse(trimmed) || {};
            } catch (e) {
                console.error('Failed to parse theme settings:', e);
                return {};
            }
        }
        return themeObj.settings || {};
    }

    // --- Level 1 Theme Functions ---
    function openNewThemeDrawer() {
        if (canvasState.isReadOnly) return;
        const currentDrafts = (canvasState.themes || []).filter(t => t.status !== 'live').length;
        const limit = canvasState.draftLimit || 20;
        if (currentDrafts >= limit) {
            window.coraShowToast('Draft theme limit reached (' + limit + ' max for your plan). Please delete an existing draft or upgrade your account.', 'error');
            return;
        }
        const modal = jQuery('#drawer-new-theme');
        modal.removeClass('hidden');
        setTimeout(() => {
            modal.removeClass('opacity-0').css('opacity', '1');
            jQuery('#drawer-new-theme-card').removeClass('scale-95').addClass('scale-100');
        }, 10);
    }
    function closeNewThemeDrawer() {
        jQuery('#drawer-new-theme-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-new-theme');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden');
        }, 300);
    }

    function openImportKitDrawer() {
        if (canvasState.isReadOnly) return;
        const currentDrafts = (canvasState.themes || []).filter(t => t.status !== 'live').length;
        const limit = canvasState.draftLimit || 20;
        if (currentDrafts >= limit) {
            window.coraShowToast('Draft theme limit reached (' + limit + ' max for your plan). Please delete an existing draft or upgrade your account.', 'error');
            return;
        }
        const drawer = jQuery('#drawer-import-kit');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-import-kit-card').removeClass('translate-x-full').addClass('translate-x-0');
        // Reset file upload state
        jQuery('#import-kit-name-input').val('');
        jQuery('#import-kit-file-input').val('');
        jQuery('#import-file-name-display').text('Click to select or drag & drop ZIP here');
    }
    window.openImportKitDrawer = openImportKitDrawer;
    function closeImportKitDrawer() {
        jQuery('#drawer-import-kit-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-import-kit').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    }
    function triggerImportKit() {
        const name = jQuery('#import-kit-name-input').val().trim();
        const fileInput = document.getElementById('import-kit-file-input');
        if (!name) {
            window.coraShowToast('Please specify a theme workspace name.', 'warning');
            return;
        }
        if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
            window.coraShowToast('Please select or drop an Elementor Kit (.zip) file.', 'warning');
            return;
        }
        const file = fileInput.files[0];
        
        window.coraShowToast('Importing and validating Elementor template kit...', 'info');
        
        const formData = new FormData();
        formData.append('action', 'cora_ajax_import_kit');
        formData.append('theme_name', name);
        formData.append('kit_zip', file);
        formData.append('nonce', coraREData.ajaxNonce);
        
        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(rawRes) {
                const res = typeof window.wizParseAjaxResponse === 'function' ? window.wizParseAjaxResponse(rawRes) : rawRes;
                if (res.success) {
                    window.coraShowToast('Elementor Kit imported successfully!', 'success');
                    closeImportKitDrawer();
                    setTimeout(function() { window.location.reload(); }, 800);
                } else {
                    const errMsg = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string' ? res.data : 'Failed to import kit.');
                    const nextStep = (res.data && res.data.next_step) ? res.data.next_step : 'Ensure the ZIP is an Elementor Template Kit (containing JSON template files) and try again.';
                    window.coraShowToast(errMsg + ' — Next Step: ' + nextStep, 'error');
                }
            },
            error: function() {
                window.coraShowToast('Failed to upload kit file. Next Step: Check your network and server upload limits.', 'error');
            }
        });
    }

    jQuery(document).ready(function() {
        jQuery('#import-kit-file-input').on('change', function() {
            const files = this.files;
            if (files.length > 0) {
                const f = files[0];
                jQuery('#import-file-name-display').text(f.name);
                const currentName = jQuery('#import-kit-name-input').val().trim();
                if (!currentName && typeof window.wizFormatThemeNameFromFilename === 'function') {
                    jQuery('#import-kit-name-input').val(window.wizFormatThemeNameFromFilename(f.name));
                }
            } else {
                jQuery('#import-file-name-display').text('Click to select or drag & drop ZIP here');
            }
        });

        // Setup Drag & Drop for Add Theme Wizard Dropzone
        var wizardDropzone = document.getElementById('wiz-dropzone-label');
        if (wizardDropzone) {
            ['dragenter', 'dragover'].forEach(function(evName) {
                wizardDropzone.addEventListener(evName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    wizardDropzone.style.borderColor = '#18181b';
                    wizardDropzone.style.background = '#f4f4f5';
                }, false);
            });
            ['dragleave'].forEach(function(evName) {
                wizardDropzone.addEventListener(evName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    wizardDropzone.style.borderColor = '#d4d4d8';
                    wizardDropzone.style.background = 'white';
                }, false);
            });
            wizardDropzone.addEventListener('drop', function(e) {
                e.preventDefault();
                e.stopPropagation();
                wizardDropzone.style.borderColor = '#d4d4d8';
                wizardDropzone.style.background = 'white';
                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    var droppedFile = e.dataTransfer.files[0];
                    var inputEl = document.getElementById('wiz-kit-file');
                    if (inputEl) {
                        try {
                            var dt = new DataTransfer();
                            dt.items.add(droppedFile);
                            inputEl.files = dt.files;
                        } catch (err) {}
                    }
                    if (typeof window.wizardProcessSelectedFile === 'function') {
                        window.wizardProcessSelectedFile(droppedFile);
                    }
                }
            }, false);
        }

        // Setup Drag & Drop for Import Kit Drawer Dropzone
        var drawerDropzone = document.querySelector('#drawer-import-kit .border-dashed');
        if (drawerDropzone) {
            ['dragenter', 'dragover'].forEach(function(evName) {
                drawerDropzone.addEventListener(evName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    drawerDropzone.classList.add('border-zinc-500', 'bg-zinc-100');
                }, false);
            });
            ['dragleave'].forEach(function(evName) {
                drawerDropzone.addEventListener(evName, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    drawerDropzone.classList.remove('border-zinc-500', 'bg-zinc-100');
                }, false);
            });
            drawerDropzone.addEventListener('drop', function(e) {
                e.preventDefault();
                e.stopPropagation();
                drawerDropzone.classList.remove('border-zinc-500', 'bg-zinc-100');
                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    var droppedFile = e.dataTransfer.files[0];
                    if (!droppedFile.name.toLowerCase().endsWith('.zip')) {
                        window.coraShowToast('Please drop a valid .zip Elementor Kit archive.', 'warning');
                        return;
                    }
                    var fileInput = document.getElementById('import-kit-file-input');
                    if (fileInput) {
                        try {
                            var dt = new DataTransfer();
                            dt.items.add(droppedFile);
                            fileInput.files = dt.files;
                        } catch(err) {}
                    }
                    jQuery('#import-file-name-display').text(droppedFile.name);
                    const currentName = jQuery('#import-kit-name-input').val().trim();
                    if (!currentName && typeof window.wizFormatThemeNameFromFilename === 'function') {
                        jQuery('#import-kit-name-input').val(window.wizFormatThemeNameFromFilename(droppedFile.name));
                    }
                }
            }, false);
        }

        // Quick-insert snippets handlers (avoiding inline quote escaping issues)
        jQuery(document).on('click', '.quick-insert-btn-head', function() {
            const code = jQuery(this).attr('data-code');
            insertHeadSnippet(code);
            window.coraShowToast('Head HTML snippet inserted.');
        });
        jQuery(document).on('click', '.quick-insert-btn-body', function() {
            const code = jQuery(this).attr('data-code');
            insertBodySnippet(code);
            window.coraShowToast('Body script snippet inserted.');
        });
        jQuery(document).on('click', '.quick-insert-btn-snip', function() {
            const cat = jQuery(this).attr('data-cat');
            const code = jQuery(this).attr('data-code');
            insertSnippet(cat, code);
        });
    });

    function toggleThemeActions(id, e) {
        e.preventDefault();
        e.stopPropagation();
        const menu = jQuery('#theme-menu-' + id);
        jQuery('[id^="theme-menu-"]').not(menu).addClass('hidden');
        menu.toggleClass('hidden');
    }

    function saveNewTheme() {
        const name = jQuery('#new-theme-name-input').val().trim();
        const startFrom = jQuery('input[name="new-theme-source"]:checked').val();
        if (!name) {
            window.coraShowToast('Please specify a theme name.');
            return;
        }
        window.coraShowToast('Initializing theme workspace...');
        
        // REST API call or Ajax fallback to insert database row
        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'cora_ajax_create_theme',
                name: name,
                start_from: startFrom,
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                if (res.success) {
                    window.coraShowToast('Theme initialized successfully.');
                    closeNewThemeDrawer();
                    setTimeout(function() { window.location.reload(); }, 800);
                } else {
                    window.coraShowToast(res.data.message || 'Failed to create theme.');
                }
            }
        });
    }

    // Activate theme confirmation modal
    function triggerActivateTheme(id, name) {
        if (canvasState.isReadOnly) return;
        jQuery('#canvas-confirm-title').text('Confirm Activation');
        jQuery('#canvas-confirm-message').text(`Activating "${name}" will replace your current live theme. Your current live theme will move to Drafts. Continue?`);
        
        jQuery('#canvas-confirm-action-btn').off('click').on('click', function() {
            window.coraShowToast('Activating theme...');
            jQuery.post(coraREData.ajaxUrl, {
                action: 'cora_ajax_activate_theme',
                theme_id: id,
                nonce: coraREData.ajaxNonce
            }, function(res) {
                if (res.success) {
                    window.coraShowToast('Theme activated successfully.');
                    closeCanvasConfirmModal();
                    setTimeout(function() { window.location.reload(); }, 800);
                } else {
                    window.coraShowToast(res.data.message || 'Failed to activate theme.');
                }
            });
        });
        jQuery('#canvas-confirm-modal').removeClass('hidden');
    }

    function closeCanvasConfirmModal() {
        jQuery('#canvas-confirm-modal').addClass('hidden');
    }

    function triggerActivateThemeFromHeader() {
        triggerActivateTheme(canvasState.activeThemeId, canvasState.activeThemeName);
    }

    function triggerRenameTheme(id, name) {
        jQuery('#rename-theme-id-input').val(id);
        jQuery('#rename-theme-name-input').val(name);
        const modal = jQuery('#drawer-rename-theme');
        modal.removeClass('hidden').css('pointer-events', 'auto');
        setTimeout(() => {
            modal.removeClass('opacity-0').css('opacity', '1');
            jQuery('#drawer-rename-theme-card').removeClass('scale-95').addClass('scale-100');
        }, 10);
    }
    function closeRenameThemeDrawer() {
        jQuery('#drawer-rename-theme-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-rename-theme');
        modal.addClass('opacity-0').css('opacity', '0').css('pointer-events', 'none');
        setTimeout(function() {
            modal.addClass('hidden');
        }, 300);
    }
    function saveRenamedTheme() {
        const id = jQuery('#rename-theme-id-input').val();
        const name = jQuery('#rename-theme-name-input').val().trim();
        if (!name) {
            window.coraShowToast('Name cannot be empty.');
            return;
        }
        window.coraShowToast('Updating name...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_rename_theme',
            theme_id: id,
            name: name,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Theme renamed successfully.');
                closeRenameThemeDrawer();
                setTimeout(function() { window.location.reload(); }, 800);
            } else {
                window.coraShowToast('Failed to rename theme.');
            }
        });
    }

    function triggerDeleteTheme(id) {
        // Close the dropdown first
        const openMenu = document.getElementById('draft-actions-menu-' + id);
        if (openMenu) openMenu.classList.add('hidden');

        const doDelete = function() {
            window.coraShowToast('Removing theme workspace...');
            jQuery.post(coraREData.ajaxUrl, {
                action: 'cora_ajax_delete_theme',
                theme_id: id,
                nonce: coraREData.ajaxNonce
            }, function(res) {
                if (res.success) {
                    // Remove the card from the DOM — no page refresh
                    const card = document.querySelector('[data-draft-theme-id="' + id + '"]');
                    if (card) {
                        card.style.transition = 'opacity 0.25s ease, max-height 0.35s ease, margin 0.35s ease';
                        card.style.overflow = 'hidden';
                        card.style.opacity = '0';
                        card.style.maxHeight = card.offsetHeight + 'px';
                        setTimeout(function() {
                            card.style.maxHeight = '0';
                            card.style.marginTop = '0';
                            card.style.paddingTop = '0';
                            card.style.paddingBottom = '0';
                        }, 50);
                        setTimeout(function() { card.remove(); }, 400);
                    } else {
                        setTimeout(function() { window.location.reload(); }, 600);
                    }
                    const msg = (res.data && res.data.message) ? res.data.message : 'Draft theme deleted successfully.';
                    window.coraShowToast(msg, 'success');
                } else {
                    const msg = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string' ? res.data : 'Failed to delete theme.');
                    window.coraShowToast(msg, 'error');
                }
            }).fail(function() {
                window.coraShowToast('Network error while deleting theme.', 'error');
            });
        };

        if (typeof window.coraConfirmAction === 'function') {
            window.coraConfirmAction(
                'Delete Theme',
                'Are you sure you want to delete this theme workspace permanently? All containing pages will be removed.',
                doDelete
            );
        } else {
            doDelete();
        }
    }

    function triggerDuplicateTheme(id) {
        if (canvasState.isReadOnly) return;
        const currentDrafts = (canvasState.themes || []).filter(t => t.status !== 'live').length;
        const limit = canvasState.draftLimit || 20;
        if (currentDrafts >= limit) {
            window.coraShowToast('Draft theme limit reached (' + limit + ' max for your plan). Please delete an existing draft or upgrade your account.', 'error');
            return;
        }
        window.coraShowToast('Duplicating theme...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_duplicate_theme',
            theme_id: id,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Theme duplicated successfully.', 'success');
                setTimeout(function() { window.location.reload(); }, 800);
            } else {
                const msg = res.data && res.data.message ? res.data.message : (res.data || 'Failed to duplicate.');
                window.coraShowToast(msg, 'error');
            }
        });
    }

    // --- LEVEL 2 Dashboard Navigation & Actions ---
    function editTheme(id, name, isLive) {
        canvasState.level = 2;
        canvasState.activeThemeId = id;
        canvasState.activeThemeName = name;
        canvasState.activeThemeIsLive = isLive;

        // Detect if active theme source is elementor, nextjs, or lovable
        const themeObj = canvasState.themes.find(t => t.id == id);
        let isElementor = false;
        let isNextJS = false;
        if (themeObj) {
            const settings = safeGetSettings(themeObj);
            if (settings) {
                if (settings.source === 'nextjs' || themeObj.source === 'nextjs') {
                    isNextJS = true;
                } else if (settings.source === 'elementor' || (!settings.github_repo && !settings.lovable_project_url)) {
                    isElementor = true;
                }
            }
        }
        canvasState.activeThemeIsElementor = isElementor;
        canvasState.activeThemeIsNextJS = isNextJS;

        if (isNextJS) {
            jQuery('.lovable-route-col').hide();
            jQuery('#lovable-trigger-bar').hide();
            jQuery('#lovable-studio-drawer').hide();
            jQuery('#tab-btn-ai').hide();
            jQuery('#tab-btn-nextjs-sdk').removeClass('hidden').show();
            jQuery('#tab-btn-theme-builder').hide(); // Hide Elementor Site Editor for Next.js

            // Populate Next.js status & credentials
            const settings = (themeObj && safeGetSettings(themeObj)) || {};
            const ghRepo = settings.github_repo || '';
            const ghBranch = settings.github_branch || 'main';
            const liveUrl = settings.nextjs_live_url || '';
            const isrSec = settings.nextjs_revalidate_secret || '';

            jQuery('#nextjs-repo-label').text(ghRepo ? ghRepo.replace(/^https?:\/\/github\.com\//, '') : 'Not connected');
            jQuery('#nextjs-repo-link').attr('href', ghRepo ? (ghRepo.startsWith('http') ? ghRepo : 'https://github.com/' + ghRepo) : '#');
            jQuery('#nextjs-branch-label').text(ghBranch);
            jQuery('#nextjs-live-url-label').text(liveUrl || 'No deployment URL');
            jQuery('#nextjs-live-url-link').attr('href', liveUrl || '#');
            if (isrSec) {
                jQuery('#nextjs-secret-display').val(isrSec);
            }
            if (window.switchNextJSSnippet) {
                window.switchNextJSSnippet('lib');
            }
        } else if (isElementor) {
            jQuery('.lovable-route-col').hide();
            jQuery('#lovable-trigger-bar').hide();
            jQuery('#lovable-studio-drawer').hide();
            jQuery('#tab-btn-ai').hide();
            jQuery('#tab-btn-nextjs-sdk').hide();
            jQuery('#tab-btn-theme-builder').show();
            if (canvasState.activeTab === 'ai' || canvasState.activeTab === 'nextjs-sdk') {
                switchTab('pages');
            }
        } else {
            jQuery('.lovable-route-col').show();
            jQuery('#lovable-trigger-bar').hide();
            jQuery('#tab-btn-ai').show();
            jQuery('#tab-btn-nextjs-sdk').hide();
            jQuery('#tab-btn-theme-builder').show();
        }

        // Show settings, builder, custom code and menus tabs for all themes (dynamic capability)
        jQuery('#tab-btn-settings').show();
        jQuery('#tab-btn-code').show();
        jQuery('#tab-btn-menus').show();

        jQuery('#canvas-level-1').addClass('hidden');
        jQuery('#canvas-level-2').removeClass('hidden');

        jQuery('#dashboard-theme-name').text(name);
        const wsSiteBase = `${coraREData.siteUrl}/site`;
        if (isLive) {
            jQuery('#dashboard-theme-badge').removeClass('bg-zinc-50 text-zinc-500 border-zinc-200').addClass('bg-green-50 text-green-700 border-green-200').text('Live');
            jQuery('#activate-theme-header-btn').addClass('hidden');
            jQuery('#preview-site-header-btn').removeClass('hidden').text('Preview Site').attr('href', wsSiteBase + '/');
        } else {
            jQuery('#dashboard-theme-badge').removeClass('bg-green-50 text-green-700 border-green-200').addClass('bg-zinc-50 text-zinc-500 border-zinc-200').text('Draft');
            jQuery('#activate-theme-header-btn').removeClass('hidden');
            jQuery('#preview-site-header-btn').removeClass('hidden').text('Preview Theme').attr('href', wsSiteBase + '/?cv_preview_theme=' + id);
        }

        // Fetch theme settings and load pages
        fetchThemePages(id);
        fetchThemeSettings(id);
        
        switchTab('pages');
        syncStateToUrl();
    }
    window.editTheme = editTheme;
    window.switchTab = switchTab;

    // ── URL State Sync Helper ──────────────────────────────────
    function syncStateToUrl() {
        try {
            var url = new URL(window.location.href);
            if (canvasState.level === 1) {
                url.searchParams.delete('cv_theme');
                url.searchParams.delete('cv_tab');
                url.searchParams.delete('cv_page');
                url.searchParams.delete('cv_editor');
            } else if (canvasState.level === 2) {
                url.searchParams.set('cv_theme', canvasState.activeThemeId);
                url.searchParams.set('cv_tab', canvasState.activeTab || 'pages');
                url.searchParams.delete('cv_page');
                url.searchParams.delete('cv_editor');
            } else if (canvasState.level === 3) {
                url.searchParams.set('cv_theme', canvasState.activeThemeId);
                url.searchParams.set('cv_tab', canvasState.activeTab || 'pages');
                const pId = canvasState.activePageId || (window.htmlEditorState && window.htmlEditorState.activePageId);
                if (pId) {
                    url.searchParams.set('cv_page', pId);
                }
                const isHtmlActive = (canvasState.activeEditorEngine === 'html') || (jQuery('#canvas-level-3-html').length && !jQuery('#canvas-level-3-html').hasClass('hidden'));
                url.searchParams.set('cv_editor', isHtmlActive ? 'html' : 'elementor');
            }
            history.replaceState({ coraCanvasState: true }, '', url.toString());
        } catch(e) {}
    }

    function backToCanvasHub() {
        canvasState.level = 1;
        jQuery('#canvas-level-2').addClass('hidden');
        jQuery('#canvas-level-1').removeClass('hidden');
        syncStateToUrl();
    }

    function switchTab(tabId) {
        canvasState.activeTab = tabId;
        jQuery('.canvas-tab-btn').removeClass('active');
        jQuery('#tab-btn-' + tabId).addClass('active');

        jQuery('#tab-content-pages').addClass('hidden');
        jQuery('#tab-content-menus').addClass('hidden');
        jQuery('#tab-content-settings').addClass('hidden');
        jQuery('#tab-content-code').addClass('hidden');
        jQuery('#tab-content-theme-builder').addClass('hidden');
        jQuery('#tab-content-ai').addClass('hidden');
        jQuery('#tab-content-nextjs-sdk').addClass('hidden');

        jQuery('#tab-content-' + tabId).removeClass('hidden');

        // Toggle action buttons in the tab bar row
        jQuery('.tab-action-btn').addClass('hidden');
        if (!canvasState.isReadOnly) {
            jQuery('#tab-action-' + tabId).removeClass('hidden');
        }

        if (tabId === 'menus') {
            showMenusTabContent();
        } else if (tabId === 'nextjs-sdk') {
            if (window.switchNextJSSnippet) {
                window.switchNextJSSnippet('lib');
            }
        } else if (tabId === 'ai') {
            if (window.openLovableStudio) {
                window.openLovableStudio();
            }
        } else if (tabId === 'theme-builder') {
            const iframe = jQuery('#theme-builder-iframe');
            if (!iframe.attr('src')) {
                const themeBuilderUrl = coraREData.siteUrl + '/wp-admin/admin.php?page=elementor-app#/site-editor';
                iframe.attr('src', themeBuilderUrl);

                // Intercept template editing within the Theme Builder iframe and open in Level 3 full screen
                iframe.on('load', function() {
                    try {
                        const iframeWindow = this.contentWindow;
                        const currentUrl = iframeWindow.location.href;
                        
                        if (currentUrl.includes('post.php') && currentUrl.includes('action=elementor')) {
                            // Extract the post ID
                            const urlParams = new URLSearchParams(iframeWindow.location.search);
                            const wpPostId = urlParams.get('post');
                            
                            let title = 'Elementor Template';
                            try {
                                title = iframeWindow.document.title || 'Elementor Template';
                                title = title.replace(/\s*—\s*WordPress\s*/, '').replace(/\s*-\s*WordPress\s*/, '');
                            } catch(e) {}
                            
                            // Revert navigation in the Theme Builder iframe
                            iframeWindow.history.back();
                            
                            // Open in full-screen Level 3 editor
                            openPageEditor(0, title, wpPostId, 'publish', '');
                        }
                    } catch(e) {
                        console.error("Theme Builder iframe load observer error:", e);
                    }
                });
            }
        }
        syncStateToUrl();
    }

    // --- Tab 1 Pages Functions ---
    function fetchThemePages(themeId) {
        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'GET',
            data: {
                action: 'cora_ajax_get_theme_pages',
                theme_id: themeId,
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                if (res.success) {
                    if (res.data && res.data.pages) {
                        canvasState.pages = res.data.pages;
                        window.CORA_LOVABLE_ROUTES = res.data.routes || [];
                        window.CORA_PAGE_MAPPINGS = res.data.page_mappings || {};
                    } else {
                        canvasState.pages = res.data || [];
                    }
                    filterPages();
                    populatePageMappingSelectors();

                    // Check for and execute pending Command Palette actions
                    setTimeout(() => {
                        const pendingStr = localStorage.getItem('cora_pending_canvas_command');
                        if (pendingStr) {
                            try {
                                const cmd = JSON.parse(pendingStr);
                                if (cmd && cmd.pageId) {
                                    localStorage.removeItem('cora_pending_canvas_command');
                                    if (typeof window.switchTab === 'function') {
                                        window.switchTab('pages');
                                    }
                                    setTimeout(() => {
                                        if (cmd.action === 'rename' && typeof window.triggerRenamePage === 'function') {
                                            window.triggerRenamePage(cmd.pageId, cmd.pageTitle);
                                        } else if (cmd.action === 'slug' && typeof window.triggerChangePageSlug === 'function') {
                                            window.triggerChangePageSlug(cmd.pageId, cmd.extraData || '');
                                        } else if (cmd.action === 'homepage' && typeof window.triggerSetHomepage === 'function') {
                                            window.triggerSetHomepage(cmd.pageId, cmd.pageTitle, cmd.extraData || 0);
                                        } else if (cmd.action === 'seo' && typeof window.openSEODrawer === 'function') {
                                            const p = canvasState.pages.find(page => page.id == cmd.pageId);
                                            window.openSEODrawer(cmd.pageId, cmd.pageTitle, p ? (p.seo_title || '') : '', p ? (p.seo_description || '') : '', p ? (p.seo_og_image || '') : '');
                                        } else if (cmd.action === 'revisions' && typeof window.openRevisionsDrawer === 'function') {
                                            window.openRevisionsDrawer(cmd.pageId, cmd.pageTitle);
                                        } else if (cmd.action === 'duplicate' && typeof window.triggerDuplicatePage === 'function') {
                                            window.triggerDuplicatePage(cmd.pageId);
                                        } else if (cmd.action === 'delete' && typeof window.triggerDeletePage === 'function') {
                                            window.triggerDeletePage(cmd.pageId);
                                        }
                                    }, 100);
                                }
                            } catch(e) {
                                console.error('Failed to parse pending canvas command', e);
                            }
                        }
                    }, 200);
                }
            }
        });
    }

    function populatePageMappingSelectors() {
        const themeId = canvasState.activeThemeId;
        const themeObj = canvasState.themes.find(t => t.id == themeId);
        if (!themeObj) return;
        const settings = safeGetSettings(themeObj);

        const homeSelect = jQuery('#setting-homepage-page-id');
        const contactSelect = jQuery('#setting-contact-page-id');

        homeSelect.empty().append('<option value="">-- Select Page --</option>');
        contactSelect.empty().append('<option value="">-- Select Page --</option>');

        const dbHomepage = canvasState.pages.find(p => p.is_homepage == 1);
        const activeHomeId = dbHomepage ? dbHomepage.id : (settings.homepage_page_id || '');

        canvasState.pages.forEach(p => {
            const selectedHome = p.id == activeHomeId ? 'selected' : '';
            const selectedContact = p.id == settings.contact_page_id ? 'selected' : '';
            
            homeSelect.append(`<option value="${p.id}" ${selectedHome}>${p.title} (${p.slug})</option>`);
            contactSelect.append(`<option value="${p.id}" ${selectedContact}>${p.title} (${p.slug})</option>`);
        });
    }

    // ── Pages tab state ──
    var pageSortState     = 'modified';
    var pageStatusFilter  = 'all';
    var activeViewFilter   = 'all';
    var customViewsList    = [{ id: 'all', label: 'All', query: '' }];

    try {
        const stored = localStorage.getItem('cora_pages_custom_views');
        if (stored) {
            const parsed = JSON.parse(stored);
            if (Array.isArray(parsed) && parsed.length > 0) {
                if (typeof parsed[0] === 'string') {
                    const labels = {
                        all: 'All',
                        listing: 'Listings',
                        product: 'Products',
                        standard: 'Standard',
                        policy: 'Policies'
                    };
                    customViewsList = parsed.map(v => ({
                        id: v,
                        label: labels[v] || v,
                        query: v === 'all' ? '' : v.toLowerCase()
                    }));
                } else {
                    customViewsList = parsed;
                }
            }
        }
    } catch(e) {}

    // Render views tab strip on ready
    jQuery(document).ready(function() {
        renderViewsTabStrip();
    });

    // Toggle views tab creation dropdown
    function toggleAddViewDropdown() {
        jQuery('#add-view-dropdown').toggleClass('hidden');
        if (!jQuery('#add-view-dropdown').hasClass('hidden')) {
            setTimeout(function() {
                var inp = document.getElementById('new-view-name');
                if (inp) inp.focus();
            }, 50);
        }
    }

    // Toggle filter/sort dropdown chips
    function toggleDropdownChip(type) {
        var panels = { filter: 'chip-dropdown-filter', sort: 'chip-dropdown-sort' };
        Object.keys(panels).forEach(function(k) {
            var el = document.getElementById(panels[k]);
            if (!el) return;
            if (k === type) el.classList.toggle('hidden');
            else el.classList.add('hidden');
        });
    }

    // Handles filter select from the dropdown chip
    function selectChipFilter(status, label) {
        pageStatusFilter = status;
        jQuery('#filter-chip-btn span').text(label);
        jQuery('#chip-dropdown-filter').addClass('hidden');
        filterPages();
    }

    // Handles sort select from the dropdown chip
    function selectChipSort(val, label) {
        pageSortState = val;
        jQuery('#sort-chip-btn span').text(label);
        jQuery('#chip-dropdown-sort').addClass('hidden');
        filterPages();
    }

    // Create new custom view tab
    function createNewCustomView() {
        const input = document.getElementById('new-view-name');
        if (!input) return;
        const name = input.value.trim();
        if (!name) return;

        const viewId = 'view_' + Date.now();
        const newView = {
            id: viewId,
            label: name,
            query: name.toLowerCase()
        };

        customViewsList.push(newView);
        localStorage.setItem('cora_pages_custom_views', JSON.stringify(customViewsList));
        
        input.value = '';
        jQuery('#add-view-dropdown').addClass('hidden');
        renderViewsTabStrip();
        setViewFilter(viewId);
    }

    // Remove custom view tab
    function removeCustomView(viewId, event) {
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        customViewsList = customViewsList.filter(v => v.id !== viewId);
        localStorage.setItem('cora_pages_custom_views', JSON.stringify(customViewsList));
        if (activeViewFilter === viewId) {
            activeViewFilter = 'all';
        }
        renderViewsTabStrip();
        filterPages();
    }

    // Set active list view filter
    function setViewFilter(viewId) {
        activeViewFilter = viewId;
        jQuery('#pages-views-tab-strip .view-tab-btn').each(function() {
            const vid = jQuery(this).data('view');
            if (vid) {
                const isActive = vid === viewId;
                jQuery(this)
                    .toggleClass('bg-zinc-900 text-white', isActive)
                    .toggleClass('bg-zinc-100 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60', !isActive);
            }
        });
        filterPages();
    }

    // Render the custom views tabs
    function renderViewsTabStrip() {
        const container = jQuery('#pages-views-tab-strip');
        if (!container.length) return;
        
        container.find('.pages-view-btn').remove();
        
        const tabsHtml = customViewsList.map(v => {
            const label = v.label;
            const isActive = v.id === activeViewFilter;
            const activeClasses = isActive ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-200/60';
            
            if (v.id === 'all') {
                return `<button onclick="setViewFilter('all')" data-view="all" class="view-tab-btn px-3 py-1.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer pages-view-btn ${activeClasses}">${label}</button>`;
            } else {
                return `<div data-view="${v.id}" class="view-tab-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-semibold transition-all pages-view-btn ${activeClasses}">
                    <span class="cursor-pointer" onclick="setViewFilter('${v.id}')">${label}</span>
                    <button onclick="removeCustomView('${v.id}', event)" class="hover:text-red-500 text-[12px] ml-1 font-bold bg-transparent border-none p-0 cursor-pointer focus:outline-none leading-none opacity-60 hover:opacity-100">&times;</button>
                </div>`;
            }
        }).join('');
        
        container.prepend(tabsHtml);
    }

    // Close all popovers and dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('#add-view-btn') && !e.target.closest('#add-view-dropdown')) {
            var el = document.getElementById('add-view-dropdown'); if (el) el.classList.add('hidden');
        }
        if (!e.target.closest('#filter-chip-btn') && !e.target.closest('#chip-dropdown-filter')) {
            var el = document.getElementById('chip-dropdown-filter'); if (el) el.classList.add('hidden');
        }
        if (!e.target.closest('#sort-chip-btn') && !e.target.closest('#chip-dropdown-sort')) {
            var el = document.getElementById('chip-dropdown-sort'); if (el) el.classList.add('hidden');
        }
        if (!e.target.closest('[id^="page-menu-"]') && !e.target.closest('[onclick*="togglePageRowActions"]')) {
            jQuery('[id^="page-menu-"]').addClass('hidden');
        }
    });

    function setPageStatusFilter(status) {
        pageStatusFilter = status;
        // Highlight active tab pill
        document.querySelectorAll('.cpb-filter-btn').forEach(function(btn) {
            btn.classList.toggle('bg-zinc-100', btn.dataset.filter === status);
            btn.classList.toggle('font-bold', btn.dataset.filter === status);
        });
        var tabAll = document.getElementById('pages-tab-all');
        if (tabAll) {
            tabAll.classList.toggle('bg-zinc-100', status === 'all');
            tabAll.classList.toggle('text-zinc-900', status === 'all');
        }
        var el = document.getElementById('cpb-panel-filter'); if (el) el.classList.add('hidden');
        filterPages();
    }

    function setPageSort(val) {
        pageSortState = val;
        document.querySelectorAll('.cpb-sort-btn').forEach(function(btn) {
            var isActive = btn.dataset.sort === val.replace('-desc','');
            btn.classList.toggle('bg-zinc-100', isActive);
            btn.classList.toggle('font-bold', isActive);
        });
        var el = document.getElementById('cpb-panel-sort'); if (el) el.classList.add('hidden');
        filterPages();
    }

    function filterPages() {
        var searchEl = document.getElementById('page-search-input');
        var query    = searchEl ? searchEl.value.toLowerCase() : '';
        var status   = pageStatusFilter || 'all';

        var filtered = canvasState.pages.slice();
        if (query)         filtered = filtered.filter(function(p) { return p.title.toLowerCase().includes(query) || p.slug.toLowerCase().includes(query) || (p.page_engine || '').toLowerCase().includes(query); });
        
        // Handle filter dropdown chip values
        if (status !== 'all') {
            if (status === 'private') {
                filtered = filtered.filter(function(p) { return p.status === 'private' || p.status === 'unlisted'; });
            } else {
                filtered = filtered.filter(function(p) { return p.status === status; });
            }
        }

        // Handle custom views category filters
        if (activeViewFilter !== 'all') {
            const activeView = customViewsList.find(v => v.id === activeViewFilter);
            if (activeView && activeView.query) {
                const q = activeView.query;
                filtered = filtered.filter(function(p) {
                    const titleLower = p.title.toLowerCase();
                    const slugLower = p.slug.toLowerCase();
                    const templateLower = (p.template || '').toLowerCase();
                    
                    if (q === 'listing' || q === 'listings') {
                        return templateLower.includes('listing') || slugLower.includes('listing') || titleLower.includes('listing');
                    } else if (q === 'product' || q === 'products') {
                        return templateLower.includes('product') || slugLower.includes('product') || titleLower.includes('product');
                    } else if (q === 'policy' || q === 'policies' || q === 'privacy' || q === 'terms') {
                        return templateLower.includes('policy') || slugLower.includes('policy') || slugLower.includes('privacy') || slugLower.includes('terms') || titleLower.includes('policy') || titleLower.includes('terms');
                    } else if (q === 'standard') {
                        const isListing = templateLower.includes('listing') || slugLower.includes('listing') || titleLower.includes('listing');
                        const isProduct = templateLower.includes('product') || slugLower.includes('product') || titleLower.includes('product');
                        const isPolicy = templateLower.includes('policy') || slugLower.includes('policy') || slugLower.includes('privacy') || slugLower.includes('terms') || titleLower.includes('policy') || titleLower.includes('terms');
                        return !isListing && !isProduct && !isPolicy;
                    }
                    
                    return titleLower.includes(q) || slugLower.includes(q) || templateLower.includes(q);
                });
            }
        }

        if (pageSortState === 'alpha')      filtered.sort(function(a,b){ return a.title.localeCompare(b.title); });
        else if (pageSortState === 'alpha-desc') filtered.sort(function(a,b){ return b.title.localeCompare(a.title); });
        else if (pageSortState === 'created')   filtered.sort(function(a,b){ return b.id - a.id; });
        else filtered.sort(function(a,b){ return new Date(b.updated_at) - new Date(a.updated_at); });

        renderPagesTable(filtered);
        updatePageStats();
    }

    function updatePageStats() {
        var all = canvasState.pages;
        var total  = all.length;
        var active = all.filter(function(p){ return p.status === 'published'; }).length;
        var draft  = all.filter(function(p){ return p.status === 'draft'; }).length;
        var other  = total - active - draft;
        var t = document.getElementById('stat-total-pages');  if(t) t.textContent = total;
        var a = document.getElementById('stat-active-pages'); if(a) a.textContent = active;
        var d = document.getElementById('stat-draft-pages');  if(d) d.textContent = draft;
        var o = document.getElementById('stat-other-pages');  if(o) o.textContent = other;
    }

    function renderPagesTable(pages) {
        const thead = jQuery('#tab-content-pages table thead');
        const body = jQuery('#pages-table-body');
        body.empty();

        const isElementor = canvasState.activeThemeIsElementor;
        const isNextJS = canvasState.activeThemeIsNextJS;

        if (isNextJS) {
            thead.html(`
                <tr class="border-b border-zinc-100 text-[11px] font-semibold text-zinc-400">
                    <th class="pl-3 pr-1 py-2 w-10">
                        <input type="checkbox" id="pages-select-all-checkbox" onchange="toggleSelectAllPages(this)" class="rounded cursor-pointer accent-zinc-900">
                    </th>
                    <th class="px-3 py-2">
                        <button onclick="setPageSort(pageSortState==='alpha'?'alpha-desc':'alpha')" class="flex items-center gap-1 text-zinc-400 hover:text-zinc-700 cursor-pointer transition-colors group font-semibold">
                            Route Title
                            <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-40 group-hover:opacity-100 transition-opacity"><path d="M7 15l5 5 5-5M7 9l5-5 5 5"/></svg>
                        </button>
                    </th>
                    <th class="px-3 py-2 font-semibold">Engine</th>
                    <th class="px-3 py-2 font-semibold">App Router Path</th>
                    <th class="px-3 py-2 font-semibold">Props &amp; SEO</th>
                    <th class="px-3 py-2 font-semibold">Status</th>
                    <th class="px-3 py-2 font-semibold">Updated</th>
                    <th class="px-3 py-2 w-32 text-right font-semibold">Actions</th>
                </tr>
            `);
        } else if (isElementor) {
            thead.html(`
                <tr class="border-b border-zinc-100 text-[11px] font-semibold text-zinc-400">
                    <th class="pl-3 pr-1 py-2 w-10">
                        <input type="checkbox" id="pages-select-all-checkbox" onchange="toggleSelectAllPages(this)" class="rounded cursor-pointer accent-zinc-900">
                    </th>
                    <th class="px-3 py-2">
                        <button onclick="setPageSort(pageSortState==='alpha'?'alpha-desc':'alpha')" class="flex items-center gap-1 text-zinc-400 hover:text-zinc-700 cursor-pointer transition-colors group font-semibold">
                            Title
                            <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-40 group-hover:opacity-100 transition-opacity"><path d="M7 15l5 5 5-5M7 9l5-5 5 5"/></svg>
                        </button>
                    </th>
                    <th class="px-3 py-2 font-semibold">Type</th>
                    <th class="px-3 py-2 font-semibold">Visibility</th>
                    <th class="px-3 py-2 font-semibold">Content</th>
                    <th class="px-3 py-2 font-semibold">Updated</th>
                    <th class="px-3 py-2 w-28 text-right font-semibold">Actions</th>
                </tr>
            `);
        } else {
            thead.html(`
                <tr class="border-b border-zinc-100 text-[11px] font-semibold text-zinc-400">
                    <th class="pl-3 pr-1 py-2 w-10">
                        <input type="checkbox" id="pages-select-all-checkbox" onchange="toggleSelectAllPages(this)" class="rounded cursor-pointer accent-zinc-900">
                    </th>
                    <th class="px-3 py-2">
                        <button onclick="setPageSort(pageSortState==='alpha'?'alpha-desc':'alpha')" class="flex items-center gap-1 text-zinc-400 hover:text-zinc-700 cursor-pointer transition-colors group font-semibold">
                            Title
                            <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none" class="opacity-40 group-hover:opacity-100 transition-opacity"><path d="M7 15l5 5 5-5M7 9l5-5 5 5"/></svg>
                        </button>
                    </th>
                    <th class="px-3 py-2 font-semibold">Type</th>
                    <th class="px-3 py-2 font-semibold">Cora Path</th>
                    <th class="px-3 py-2 font-semibold">Lovable Route</th>
                    <th class="px-3 py-2 font-semibold">Visibility</th>
                    <th class="px-3 py-2 w-28 text-right font-semibold">Actions</th>
                </tr>
            `);
        }

        if (pages.length === 0) {
            const cols = isNextJS ? 8 : (isElementor ? 7 : 7);
            body.append(`
                <tr>
                    <td colspan="${cols}" class="p-8 text-center text-[12px] text-zinc-400">
                        <div class="space-y-2 py-4">
                            <p>No pages found in this theme.</p>
                            <?php if ( ! $is_read_only ) : ?>
                            <button type="button" onclick="openNewPageDrawer()" class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer">
                                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.5" fill="none"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                <span>Add Page</span>
                            </button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            `);
            return;
        }

        pages.forEach(p => {
            const isHomepage = (p.is_homepage == 1);
            // Homepage is ALWAYS visible / published and can NEVER be hidden
            const effectiveStatus = isHomepage ? 'published' : (p.status || 'draft');
            const visibilityPill = getVisibilityPill(effectiveStatus, p.scheduled_at, isHomepage);
            const homeBadge = isHomepage
                ? `<span class="ml-2 px-1.5 py-0.5 text-[8px] font-bold rounded-md bg-zinc-100 border border-zinc-200 text-zinc-500 inline-flex items-center gap-0.5"><svg viewBox="0 0 24 24" width="8" height="8" stroke="currentColor" stroke-width="2.5" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg> Home</span>`
                : '';

            const isHtml = (p.page_engine === 'html_canvas' || p.page_engine === 'html');
            const typeBadge = isHtml
                ? `<span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-bold font-mono bg-zinc-900 text-white shadow-2xs select-none">
                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>
                    HTML
                   </span>`
                : `<span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-semibold font-mono bg-zinc-100 text-zinc-700 border border-zinc-200 select-none">
                    <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2" fill="none"><rect x="3" y="3" width="18" height="18" rx="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line><line x1="15" y1="9" x2="21" y2="9"></line><line x1="15" y1="15" x2="21" y2="15"></line></svg>
                    Elementor
                   </span>`;

            const wsSiteBase = `${coraREData.siteUrl}/site`;
            const isDraftTheme = (canvasState.activeThemeIsLive !== true && canvasState.activeThemeIsLive !== 1 && canvasState.activeThemeIsLive !== '1');
            const previewParam = isDraftTheme ? `cv_preview_theme=${canvasState.activeThemeId}` : '';
            
            let previewUrl = '';
            if (p.is_homepage == 1) {
                previewUrl = previewParam ? `${wsSiteBase}/?${previewParam}` : `${wsSiteBase}/`;
            } else {
                const cleanSlug = (p.slug || '').replace(/^\/+/, '');
                previewUrl = previewParam ? `${wsSiteBase}/${cleanSlug}?${previewParam}` : `${wsSiteBase}/${cleanSlug}`;
            }

            if (isNextJS) {
                const routePath = '/' + (p.slug || '').replace(/^\/+/, '');
                const hasProps = (p.seo_title && p.seo_title.trim()) || (p.content && p.content.trim());
                const propsPill = hasProps 
                    ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>Configured</span>`
                    : `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-zinc-50 text-zinc-500 border border-zinc-200">Default Props</span>`;

                body.append(`
                    <tr class="border-b border-zinc-100 hover:bg-zinc-50/60 group transition-colors">
                        <td class="pl-3 pr-1 py-2">
                            <input type="checkbox" class="page-row-checkbox rounded cursor-pointer accent-zinc-900" data-id="${p.id}" onchange="updateBulkActionState()">
                        </td>
                        <td class="px-3 py-2">
                            <div class="flex items-center flex-wrap gap-1">
                                <button onclick="openNextJSPagePropsDrawer(${p.id})"
                                    class="text-xs font-bold text-zinc-900 hover:underline text-left cursor-pointer leading-snug">
                                    ${esc_html(p.title)}
                                </button>
                                ${homeBadge}
                            </div>
                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black font-mono bg-zinc-950 text-white shadow-2xs select-none">
                                ▲ Next.js
                            </span>
                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">
                            <code class="text-[11px] font-mono font-bold text-zinc-800 bg-zinc-100 px-2 py-0.5 rounded">${esc_html(routePath)}</code>
                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">${propsPill}</td>
                        <td class="px-3 py-2 whitespace-nowrap">${visibilityPill}</td>
                        <td class="px-3 py-2 text-[11px] text-zinc-400 whitespace-nowrap">${getRelativeTime(p.updated_at)}</td>
                        <td class="px-3 py-2 w-32 whitespace-nowrap text-right">
                            <div class="flex items-center gap-1 justify-end">
                                <button onclick="openNextJSPagePropsDrawer(${p.id})"
                                    class="px-2 py-1 bg-zinc-100 hover:bg-zinc-950 hover:text-white text-zinc-800 rounded-md text-[10px] font-bold cursor-pointer transition-all flex items-center gap-1"
                                    title="Edit Props &amp; SEO">
                                    <svg viewBox="0 0 24 24" width="11" height="11" stroke="currentColor" stroke-width="2" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    <span>Props</span>
                                </button>
                                <button onclick="triggerNextJSISRRebuild('${esc_js(p.slug || '')}')"
                                    class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer transition-all"
                                    title="Instant ISR Revalidate">
                                    <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                                </button>
                                <div class="relative inline-block text-left">
                                    <button onclick="togglePageRowActions(${p.id}, event)"
                                        class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 cursor-pointer transition-all"
                                        title="More Actions">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                                    </button>
                                    <div id="page-menu-${p.id}" class="hidden absolute right-0 top-full mt-1 w-44 bg-white border border-zinc-200 rounded-xl shadow-lg py-1 z-20 text-left whitespace-normal">
                                        <button onclick="openNextJSPagePropsDrawer(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                            Edit Props &amp; SEO
                                        </button>
                                        <button onclick="triggerNextJSISRRebuild('${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                                            Trigger ISR Rebuild
                                        </button>
                                        <?php if ( ! $is_read_only ) : ?>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerRenamePage(${p.id}, '${esc_js(p.title)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                                            Rename Route
                                        </button>
                                        <button onclick="triggerChangePageSlug(${p.id}, '${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                                            Change path
                                        </button>
                                        <button onclick="triggerSetHomepage(${p.id}, '${esc_js(p.title)}', ${p.is_homepage})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                                            Set as homepage
                                        </button>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerDeletePage(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-red-600 hover:bg-red-50 font-semibold cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                                            Delete
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                `);
            } else if (isElementor) {
                const contentPreview = (p.content && p.content.trim())
                    ? `<span class="text-zinc-500 text-[11px]">${esc_html(p.content.replace(/<[^>]+>/g,'').substring(0,60))}…</span>`
                    : `<span class="text-zinc-300 text-[11px]">—</span>`;

                body.append(`
                    <tr class="border-b border-zinc-100 hover:bg-zinc-50/60 group transition-colors">
                        <td class="pl-3 pr-1 py-2">
                            <input type="checkbox" class="page-row-checkbox rounded cursor-pointer accent-zinc-900" data-id="${p.id}" onchange="updateBulkActionState()">
                        </td>
                        <td class="px-3 py-2">
                            <div class="flex items-center flex-wrap gap-1">
                                <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')"
                                    class="text-xs font-semibold text-zinc-900 hover:underline text-left cursor-pointer leading-snug">
                                    ${esc_html(p.title)}
                                </button>
                                ${homeBadge}
                            </div>
                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">${typeBadge}</td>
                        <td class="px-3 py-2">${visibilityPill}</td>
                        <td class="px-3 py-2 max-w-[220px] truncate">${contentPreview}</td>
                        <td class="px-3 py-2 text-[11px] text-zinc-400 whitespace-nowrap">${getRelativeTime(p.updated_at)}</td>
                        <td class="px-3 py-2 w-28 whitespace-nowrap text-right">
                            <div class="flex items-center gap-1 justify-end">
                                <a href="${previewUrl}" target="_blank"
                                    class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer transition-all"
                                    title="Preview Page">
                                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                </a>
                                <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')"
                                    class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer transition-all"
                                    title="Edit Page">
                                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                                </button>
                                <div class="relative inline-block text-left">
                                    <button onclick="togglePageRowActions(${p.id}, event)"
                                        class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 cursor-pointer transition-all"
                                        title="More Actions">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                                    </button>
                                    <div id="page-menu-${p.id}" class="hidden absolute right-0 top-full mt-1 w-44 bg-white border border-zinc-200 rounded-xl shadow-lg py-1 z-20 text-left whitespace-normal">
                                        <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                            Edit page
                                        </button>
                                        <a href="${previewUrl}" target="_blank" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                                            Preview
                                        </a>
                                        <?php if ( ! $is_read_only ) : ?>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerDuplicatePage(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                            Duplicate
                                        </button>
                                        <button onclick="triggerRenamePage(${p.id}, '${esc_js(p.title)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                                            Rename
                                        </button>
                                        <button onclick="triggerChangePageSlug(${p.id}, '${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                                            Change slug
                                        </button>
                                        <button onclick="triggerSetHomepage(${p.id}, '${esc_js(p.title)}', ${p.is_homepage})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                                            Set as homepage
                                        </button>
                                        <button onclick="openSEODrawer(${p.id}, '${esc_js(p.title)}', '${esc_js(p.seo_title)}', '${esc_js(p.seo_description)}', '${esc_js(p.seo_og_image)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                                            SEO settings
                                        </button>
                                        <button onclick="openRevisionsDrawer(${p.id}, '${esc_js(p.title)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                            Revision history
                                        </button>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerDeletePage(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-red-600 hover:bg-red-50 font-semibold cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                                            Delete
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                `);
            } else {
                const mappedRoute = window.CORA_PAGE_MAPPINGS ? (window.CORA_PAGE_MAPPINGS[p.id] || '') : '';
                const relativeWpPath = `/site${p.is_homepage == 1 ? '' : '/' + p.slug}`;

                let selectOptions = `<option value="">— Unmapped (Select Route) —</option>`;
                if (window.CORA_LOVABLE_ROUTES && window.CORA_LOVABLE_ROUTES.length > 0) {
                    window.CORA_LOVABLE_ROUTES.forEach(r => {
                        const isSelected = r.path === mappedRoute ? 'selected' : '';
                        selectOptions += `<option value="${esc_html(r.path)}" ${isSelected}>${esc_html(r.path)} (${esc_html(r.title)})</option>`;
                    });
                }

                const mappingSelector = `
                    <div class="relative inline-block w-full max-w-[220px]">
                        <select onchange="savePageLovableMapping(${p.id}, this.value)" 
                            class="w-full px-2.5 py-1.5 border border-zinc-200 focus:border-zinc-500 rounded-lg text-xs font-semibold bg-white text-zinc-800 focus:outline-none transition-colors appearance-none cursor-pointer pr-8">
                            ${selectOptions}
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-zinc-400">
                            <svg viewBox="0 0 24 24" width="10" height="10" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="6 9 12 15 18 9"/></svg>
                        </div>
                    </div>
                `;

                body.append(`
                    <tr class="border-b border-zinc-100 hover:bg-zinc-50/60 group transition-colors">
                        <td class="pl-3 pr-1 py-2">
                            <input type="checkbox" class="page-row-checkbox rounded cursor-pointer accent-zinc-900" data-id="${p.id}" onchange="updateBulkActionState()">
                        </td>
                        <td class="px-3 py-2">
                            <div class="flex items-center flex-wrap gap-1">
                                <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')"
                                    class="text-xs font-semibold text-zinc-900 hover:underline text-left cursor-pointer leading-snug">
                                    ${esc_html(p.title)}
                                </button>
                                ${homeBadge}
                            </div>
                        </td>
                        <td class="px-3 py-2 whitespace-nowrap">${typeBadge}</td>
                        <td class="px-3 py-2 font-mono text-[11px] text-zinc-500 font-semibold">${esc_html(relativeWpPath)}</td>
                        <td class="px-3 py-2">${mappingSelector}</td>
                        <td class="px-3 py-2">${visibilityPill}</td>
                        <td class="px-3 py-2 w-28 whitespace-nowrap text-right">
                            <div class="flex items-center gap-1 justify-end">
                                <a href="${previewUrl}" target="_blank"
                                    class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer transition-all"
                                    title="Preview Page">
                                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                </a>
                                <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')"
                                    class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900 cursor-pointer transition-all"
                                    title="Edit Page">
                                    <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                                </button>
                                <div class="relative inline-block text-left">
                                    <button onclick="togglePageRowActions(${p.id}, event)"
                                        class="w-7 h-7 flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 cursor-pointer transition-all"
                                        title="More Actions">
                                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                                    </button>
                                    <div id="page-menu-${p.id}" class="hidden absolute right-0 top-full mt-1 w-44 bg-white border border-zinc-200 rounded-xl shadow-lg py-1 z-20 text-left whitespace-normal">
                                        <button onclick="openPageEditor(${p.id}, '${esc_js(p.title)}', ${p.wp_post_id || 0}, '${p.status || 'draft'}', '${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                            Edit page
                                        </button>
                                        <a href="${previewUrl}" target="_blank" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                                            Preview
                                        </a>
                                        <?php if ( ! $is_read_only ) : ?>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerDuplicatePage(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                            Duplicate
                                        </button>
                                        <button onclick="triggerRenamePage(${p.id}, '${esc_js(p.title)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                                            Rename
                                        </button>
                                        <button onclick="triggerChangePageSlug(${p.id}, '${esc_js(p.slug || '')}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                                            Change slug
                                        </button>
                                        <button onclick="triggerSetHomepage(${p.id}, '${esc_js(p.title)}', ${p.is_homepage})" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                                            Set as homepage
                                        </button>
                                        <button onclick="openSEODrawer(${p.id}, '${esc_js(p.title)}', '${esc_js(p.seo_title)}', '${esc_js(p.seo_description)}', '${esc_js(p.seo_og_image)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                                            SEO settings
                                        </button>
                                        <button onclick="openRevisionsDrawer(${p.id}, '${esc_js(p.title)}')" class="w-full px-3.5 py-2 text-left text-[12px] text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                            Revision history
                                        </button>
                                        <div class="border-t border-zinc-100 my-1"></div>
                                        <button onclick="triggerDeletePage(${p.id})" class="w-full px-3.5 py-2 text-left text-[12px] text-red-600 hover:bg-red-50 font-semibold cursor-pointer flex items-center gap-2 font-sans">
                                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                                            Delete
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                `);
            }
        });
    }


    function getVisibilityPill(status, dateStr, isHomepage) {
        if (isHomepage || status === 'published' || status === 'publish') {
            return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold rounded-full bg-green-50 text-green-700 border border-green-200"><span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>Visible</span>';
        } else if (status === 'scheduled') {
            return `<span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold rounded-full bg-amber-50 text-amber-700 border border-amber-200 cursor-pointer" title="Scheduled for: ${dateStr}"><span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>Scheduled</span>`;
        }
        return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-semibold rounded-full bg-zinc-50 text-zinc-500 border border-zinc-200"><span class="w-1.5 h-1.5 rounded-full bg-zinc-300"></span>Hidden</span>';
    }
    // keep legacy alias
    function getStatusPill(status, dateStr, isHomepage) { return getVisibilityPill(status, dateStr, isHomepage); }

    function getSEOIcon(title, desc) {
        if (title && desc) return '<svg viewBox="0 0 24 24" width="13" height="13" stroke="#16a34a" stroke-width="2.5" fill="none" title="SEO complete"><polyline points="20 6 9 17 4 12"/></svg>';
        if (title || desc) return '<svg viewBox="0 0 24 24" width="13" height="13" stroke="#d97706" stroke-width="2.5" fill="none" title="SEO incomplete"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>';
        return '<svg viewBox="0 0 24 24" width="13" height="13" stroke="#dc2626" stroke-width="2.5" fill="none" title="No SEO"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>';
    }

    function togglePageRowActions(id, e) {
        e.preventDefault();
        e.stopPropagation();
        const menu = jQuery('#page-menu-' + id);
        jQuery('[id^="page-menu-"]').not(menu).addClass('hidden');
        menu.toggleClass('hidden');
    }

    // Add Page Drawer Toggles
    function openNewPageDrawer(defaultEngine) {
        defaultEngine = defaultEngine || 'elementor';
        if (canvasState.isReadOnly) {
            window.coraShowToast('Read-only mode. Workspace editing disabled.', 'error');
            return;
        }
        
        // Reset inputs
        jQuery('#new-page-title-input').val('');
        jQuery('#new-page-slug-input').val('');
        jQuery('#new-page-template-input').val('default');
        jQuery('#new-page-status-input').val('draft');

        // Reset HTML file & paste state
        window.coraSelectedHtmlFile = null;
        jQuery('#cora-html-file-input').val('');
        jQuery('#cora-html-file-label').text('Click to select or drag & drop HTML / ZIP file here');
        jQuery('#cora-html-paste-input').val('');
        jQuery('#cora-html-paste-box').addClass('hidden');
        jQuery('#cora-toggle-paste-btn').text('Or paste raw HTML code');
        jQuery('#cora-html-telemetry-badge').addClass('hidden');

        if (typeof switchPageEngineMode === 'function') {
            switchPageEngineMode(defaultEngine);
        } else if (typeof window.switchPageEngineMode === 'function') {
            window.switchPageEngineMode(defaultEngine);
        }

        const modal = jQuery('#drawer-new-page');
        modal.removeClass('hidden opacity-0').css({'display': 'flex', 'opacity': '1'});
        jQuery('#drawer-new-page-card').removeClass('scale-95').addClass('scale-100');
    }
    window.openNewPageDrawer = openNewPageDrawer;

    function closeNewPageDrawer() {
        jQuery('#drawer-new-page-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-new-page');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden').css('display', 'none');
        }, 200);
    }
    window.closeNewPageDrawer = closeNewPageDrawer;

    // ── 1-Click Elementor Migration Controller Functions ─────────────────────
    function openElementorMigrationDrawer() {
        if (canvasState.isReadOnly) {
            window.coraShowToast('Read-only mode. Workspace editing disabled.', 'error');
            return;
        }

        switchElementorMigrateTab('html_url');
        resetHtmlScan();
        resetElementorScan();

        const modal = jQuery('#drawer-elementor-migration');
        modal.removeClass('hidden opacity-0').css({'display': 'flex', 'opacity': '1'});
        jQuery('#drawer-elementor-migration-card').removeClass('scale-95').addClass('scale-100');
    }
    window.openElementorMigrationDrawer = openElementorMigrationDrawer;

    function closeElementorMigrationDrawer() {
        jQuery('#drawer-elementor-migration-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-elementor-migration');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden').css('display', 'none');
        }, 200);
    }
    window.closeElementorMigrationDrawer = closeElementorMigrationDrawer;

    function switchElementorMigrateTab(tab) {
        // Tab buttons
        jQuery('#elem-tab-btn-html_url, #elem-tab-btn-url, #elem-tab-btn-upload')
            .removeClass('bg-white text-zinc-950 font-bold shadow-2xs')
            .addClass('text-zinc-600 hover:text-zinc-950 font-semibold');

        jQuery('#elem-tab-btn-' + tab)
            .addClass('bg-white text-zinc-950 font-bold shadow-2xs')
            .removeClass('text-zinc-600 hover:text-zinc-950 font-semibold');

        // Tab panels
        jQuery('#elem-tab-panel-html_url, #elem-tab-panel-url, #elem-tab-panel-upload').addClass('hidden');
        jQuery('#elem-tab-panel-' + tab).removeClass('hidden');
    }
    window.switchElementorMigrateTab = switchElementorMigrateTab;

    // ── Universal Website (HTML/CSS/JS) Migration Controller Functions ────────
    let htmlScanState = {
        url: '',
        site_name: '',
        pages: [],
        selectedIndices: [],
        draftThemeName: '',
        draftThemeId: null,
        firstMigratedPageId: null,
        firstMigratedPostId: null,
        firstMigratedSlug: '',
    };
    window.htmlScanState = htmlScanState;

    function resetHtmlScan() {
        htmlScanState = { url: '', site_name: '', pages: [], selectedIndices: [], draftThemeName: '', draftThemeId: null, firstMigratedPageId: null, firstMigratedPostId: null, firstMigratedSlug: '' };
        jQuery('#html-url-step-input').removeClass('hidden');
        jQuery('#html-url-step-pages, #html-url-step-progress, #html-url-step-success').addClass('hidden');
        jQuery('#html-btn-scan-url').prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Deep Scan Website</span>');
    }
    window.resetHtmlScan = resetHtmlScan;

    function updateHtmlMigrateButtonLabel() {
        const count = htmlScanState.selectedIndices ? htmlScanState.selectedIndices.length : 0;
        jQuery('#html-selected-pages-count').text(`${count} of ${htmlScanState.pages.length}`);
        jQuery('#html-btn-start-migrate-label').text(`Migrate ${count} ${count === 1 ? 'Page' : 'Pages'} into Canvas`);
        jQuery('#html-btn-start-migrate').prop('disabled', count === 0);
    }
    window.updateHtmlMigrateButtonLabel = updateHtmlMigrateButtonLabel;

    function toggleHtmlPageCheckbox(idx, checked) {
        if (checked) {
            if (!htmlScanState.selectedIndices.includes(idx)) {
                htmlScanState.selectedIndices.push(idx);
            }
        } else {
            htmlScanState.selectedIndices = htmlScanState.selectedIndices.filter(i => i !== idx);
        }
        updateHtmlMigrateButtonLabel();
    }
    window.toggleHtmlPageCheckbox = toggleHtmlPageCheckbox;

    function toggleSelectAllHtmlPages(btn) {
        const checkboxes = jQuery('#html-scanned-pages-list input[type="checkbox"]');
        const allChecked = htmlScanState.selectedIndices.length === htmlScanState.pages.length;

        if (allChecked) {
            checkboxes.prop('checked', false);
            htmlScanState.selectedIndices = [];
            jQuery(btn).text('Select All');
        } else {
            checkboxes.prop('checked', true);
            htmlScanState.selectedIndices = htmlScanState.pages.map((_, i) => i);
            jQuery(btn).text('Deselect All');
        }
        updateHtmlMigrateButtonLabel();
    }
    window.toggleSelectAllHtmlPages = toggleSelectAllHtmlPages;

    function triggerScanHtmlUrl() {
        let url = jQuery('#html-migrate-url-input').val().trim();
        if (!url) {
            window.coraShowToast('Please enter your website URL.', 'error');
            return;
        }
        if (!/^https?:\/\//i.test(url)) {
            url = 'https://' + url;
            jQuery('#html-migrate-url-input').val(url);
        }

        const scanBtn = jQuery('#html-btn-scan-url');
        scanBtn.prop('disabled', true).html('<span class="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin inline-block mr-1"></span> Crawling Website...');

        window.coraShowToast('Crawling website pages, styles, fonts, and layouts...');

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_html_scan_website',
            url: url,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            scanBtn.prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Deep Scan Website</span>');

            if (res.success && res.data) {
                const data = res.data;
                htmlScanState.url = data.root_url;
                htmlScanState.site_name = data.site_name;
                htmlScanState.pages = data.pages || [];
                htmlScanState.selectedIndices = htmlScanState.pages.map((_, i) => i);
                
                const parsedHost = (function() { try { return new URL(data.root_url).hostname.replace(/^www\./, ''); } catch(e) { return 'Site'; } })();
                htmlScanState.draftThemeName = 'Imported - ' + (data.site_name || parsedHost) + ' (HTML)';

                // Update Site Details UI
                jQuery('#html-scan-site-name').text(data.site_name || 'Website');
                jQuery('#html-scan-site-url').text(parsedHost);
                jQuery('#html-scan-draft-name').text(htmlScanState.draftThemeName);

                // Render tech chips
                const techWrap = jQuery('#html-scan-tech-chips');
                techWrap.empty();
                if (data.tech_stack && data.tech_stack.length) {
                    data.tech_stack.forEach(tech => {
                        techWrap.append(`<span class="px-2 py-0.5 rounded-md bg-zinc-100 border border-zinc-200 text-zinc-700 text-[10px] font-mono font-medium">${esc_html(tech)}</span>`);
                    });
                }
                if (data.telemetry) {
                    techWrap.append(`<span class="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-mono font-semibold">${data.telemetry.total_pages} Pages Discovered</span>`);
                    techWrap.append(`<span class="px-2 py-0.5 rounded-md bg-zinc-100 border border-zinc-200 text-zinc-600 text-[10px] font-mono font-medium">${data.telemetry.stylesheets} Stylesheets</span>`);
                }

                // Render page items
                const list = jQuery('#html-scanned-pages-list');
                list.empty();

                htmlScanState.pages.forEach((p, idx) => {
                    list.append(`
                        <label class="flex items-center justify-between p-2.5 hover:bg-zinc-50/80 cursor-pointer transition-colors text-left">
                            <div class="flex items-center gap-2.5 min-w-0 flex-1 mr-2">
                                <input type="checkbox" checked onchange="toggleHtmlPageCheckbox(${idx}, this.checked)" class="accent-zinc-950 rounded cursor-pointer shrink-0">
                                <div class="min-w-0">
                                    <div class="text-xs font-bold text-zinc-900 truncate">${esc_html(p.title)}</div>
                                    <div class="text-[10px] text-zinc-400 font-mono truncate">${esc_html(p.url)}</div>
                                </div>
                            </div>
                            <span class="text-[9px] font-mono font-semibold bg-zinc-100 px-2 py-0.5 rounded text-zinc-600 border border-zinc-200 shrink-0">
                                ${p.is_homepage ? 'HOMEPAGE' : 'SUBPAGE'}
                            </span>
                        </label>
                    `);
                });

                updateHtmlMigrateButtonLabel();

                jQuery('#html-url-step-input').addClass('hidden');
                jQuery('#html-url-step-pages').removeClass('hidden');
                window.coraShowToast('Website crawl complete! Select pages to migrate.', 'success');
            } else {
                const msg = (res.data && res.data.message) ? res.data.message : 'Could not scan website.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function(xhr) {
            scanBtn.prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Deep Scan Website</span>');
            window.coraShowToast('Network error during scan. Please verify URL is online.', 'error');
        });
    }
    window.triggerScanHtmlUrl = triggerScanHtmlUrl;

    function triggerMigrateHtmlPages() {
        if (htmlScanState.selectedIndices.length === 0) {
            window.coraShowToast('Please select at least 1 page to migrate.', 'error');
            return;
        }

        const pagesToMigrate = htmlScanState.selectedIndices.map(i => htmlScanState.pages[i]);
        const total = pagesToMigrate.length;

        jQuery('#html-url-step-pages').addClass('hidden');
        jQuery('#html-url-step-progress').removeClass('hidden');
        jQuery('#html-progress-title').text('Compiling static HTML Canvas pages...');
        jQuery('#html-progress-sub').text(`[1/${total}] Preparing isolated Draft Theme...`);
        jQuery('#html-progress-bar').css('width', '10%');

        const normalizeLinks = jQuery('#html-opt-normalize-links').is(':checked') ? 1 : 0;

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_html_migrate_batch',
            root_url: htmlScanState.url,
            theme_name: htmlScanState.draftThemeName,
            pages: pagesToMigrate,
            normalize_links: normalizeLinks,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success && res.data) {
                const data = res.data;
                htmlScanState.draftThemeId = data.theme_id;

                if (data.migrated_pages && data.migrated_pages.length > 0) {
                    const firstP = data.migrated_pages[0];
                    htmlScanState.firstMigratedPageId = firstP.page_id;
                    htmlScanState.firstMigratedPostId = firstP.wp_post_id;
                    htmlScanState.firstMigratedSlug = firstP.slug;
                }

                jQuery('#html-progress-bar').css('width', '100%');
                jQuery('#html-url-step-progress').addClass('hidden');
                jQuery('#html-url-step-success').removeClass('hidden');

                jQuery('#html-success-heading').text(`Migration Complete (${data.migrated_count} Pages)`);
                jQuery('#html-success-detail').text(`All ${data.migrated_count} pages were successfully compiled with full stylesheets and typography into "${data.theme_name}".`);

                if (data.preview_url) {
                    jQuery('#html-btn-preview-draft').attr('href', data.preview_url).removeClass('hidden');
                }

                window.coraShowToast(`Successfully migrated ${data.migrated_count} pages into Canvas!`, 'success');
            } else {
                jQuery('#html-url-step-progress').addClass('hidden');
                jQuery('#html-url-step-pages').removeClass('hidden');
                const msg = (res.data && res.data.message) ? res.data.message : 'Batch migration failed.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function() {
            jQuery('#html-url-step-progress').addClass('hidden');
            jQuery('#html-url-step-pages').removeClass('hidden');
            window.coraShowToast('Network error during migration.', 'error');
        });
    }
    window.triggerMigrateHtmlPages = triggerMigrateHtmlPages;

    function openMigratedHtmlFirstPage() {
        closeElementorMigrationDrawer();
        if (htmlScanState.firstMigratedPageId) {
            if (typeof coraOpenHtmlCodeEditor === 'function') {
                coraOpenHtmlCodeEditor(htmlScanState.firstMigratedPageId);
            } else {
                window.location.href = window.location.pathname + '?cv_editor=1&cv_page=' + htmlScanState.firstMigratedPageId;
            }
        } else {
            if (typeof coraReloadCanvasThemeTable === 'function') {
                coraReloadCanvasThemeTable();
            } else {
                window.location.reload();
            }
        }
    }
    window.openMigratedHtmlFirstPage = openMigratedHtmlFirstPage;

    function resetElementorScan() {
        elementorScanState = { url: '', pages: [], selectedIndices: [], firstMigratedPostId: null, firstMigratedPageId: null, firstMigratedTitle: '', draftThemeName: '' };
        jQuery('#elem-url-step-input').removeClass('hidden');
        jQuery('#elem-url-step-pages, #elem-url-step-progress, #elem-url-step-success').addClass('hidden');
        jQuery('#elem-btn-scan-url').prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Inspect &amp; Preview Migration</span>');
    }

    function switchBlueprintTab(tab) {
        jQuery('#blueprint-tab-btn-pages, #blueprint-tab-btn-compat')
            .removeClass('bg-white text-zinc-950 font-bold shadow-2xs')
            .addClass('text-zinc-600 hover:text-zinc-950 font-semibold');

        if (tab === 'pages') {
            jQuery('#blueprint-tab-btn-pages').addClass('bg-white text-zinc-950 font-bold shadow-2xs').removeClass('text-zinc-600 hover:text-zinc-950 font-semibold');
            jQuery('#blueprint-panel-pages').removeClass('hidden');
            jQuery('#blueprint-panel-compat').addClass('hidden');
        } else {
            jQuery('#blueprint-tab-btn-compat').addClass('bg-white text-zinc-950 font-bold shadow-2xs').removeClass('text-zinc-600 hover:text-zinc-950 font-semibold');
            jQuery('#blueprint-panel-compat').removeClass('hidden');
            jQuery('#blueprint-panel-pages').addClass('hidden');
        }
    }
    window.switchBlueprintTab = switchBlueprintTab;

    function updateMigrateButtonLabel() {
        const count = elementorScanState.selectedIndices ? elementorScanState.selectedIndices.length : 0;
        jQuery('#elem-btn-start-migrate-label').text(`Start Safe Migration to Draft (${count} ${count === 1 ? 'Page' : 'Pages'})`);
        jQuery('#elem-btn-start-migrate').prop('disabled', count === 0);
    }

    function triggerOneClickMigrateAllUrl() {
        triggerScanElementorUrl();
    }
    window.triggerOneClickMigrateAllUrl = triggerOneClickMigrateAllUrl;

    function triggerScanElementorUrl() {
        let url = jQuery('#elem-migrate-url-input').val().trim();
        if (!url) {
            window.coraShowToast('Please enter your website URL.', 'error');
            return;
        }
        if (!/^https?:\/\//i.test(url)) {
            url = 'https://' + url;
            jQuery('#elem-migrate-url-input').val(url);
        }

        const scanBtn = jQuery('#elem-btn-scan-url');
        scanBtn.prop('disabled', true).html('<span class="w-3 h-3 rounded-full border-2 border-white border-t-transparent animate-spin inline-block mr-1"></span> Inspecting Remote Site...');

        window.coraShowToast('Deep inspecting website theme, plugins, and pages...');

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_elementor_scan_url',
            url: url,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            scanBtn.prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Inspect &amp; Preview Migration</span>');

            if (res.success && res.data) {
                const data = res.data;
                elementorScanState.url = data.url;
                elementorScanState.pages = data.discovered_pages || [];
                elementorScanState.selectedIndices = elementorScanState.pages.map((_, i) => i);
                elementorScanState.draftThemeName = data.draft_theme_name || 'Imported - Website';

                // Update Site Details
                jQuery('#elem-scan-site-name').text(data.site_name || 'Website');
                jQuery('#elem-scan-site-url').text(data.base_url ? data.base_url.replace(/^https?:\/\//, '') : '');
                jQuery('#elem-scan-draft-name').text(data.draft_theme_name || 'Imported - Website');
                
                const proTag = data.is_elementor_pro ? ' Pro' : '';
                const themeTitle = data.theme_name || 'Hello Elementor';
                const elVer = data.elementor_version ? `v${data.elementor_version}` : 'v3.x';
                jQuery('#elem-scan-status-text').text(`Theme: ${themeTitle} • Elementor ${elVer}${proTag} • ${data.total_pages} Pages • ~${data.estimated_media || 8} Images`);

                // Update tab and CTA labels
                jQuery('#blueprint-pages-tab-label').text(`Pages to Import (${elementorScanState.pages.length})`);
                updateMigrateButtonLabel();

                // Render page items
                const list = jQuery('#elem-scanned-pages-list');
                list.empty();

                elementorScanState.pages.forEach((p, idx) => {
                    list.append(`
                        <label class="flex items-center justify-between p-2.5 hover:bg-zinc-50/80 cursor-pointer transition-colors text-left">
                            <div class="flex items-center gap-2.5 min-w-0 flex-1 mr-2">
                                <input type="checkbox" checked onchange="toggleElementorPageCheckbox(${idx}, this.checked)" class="accent-zinc-950 rounded cursor-pointer shrink-0">
                                <div class="min-w-0">
                                    <div class="text-xs font-bold text-zinc-900 truncate">${esc_html(p.title)}</div>
                                    <div class="text-[10px] text-zinc-400 font-mono truncate">${esc_html(p.url)}</div>
                                </div>
                            </div>
                            <span class="text-[9px] font-mono font-semibold bg-zinc-100 px-2 py-0.5 rounded text-zinc-600 border border-zinc-200 shrink-0">
                                ${p.is_homepage ? 'HOMEPAGE' : 'PAGE'}
                            </span>
                        </label>
                    `);
                });

                // Render converted features
                const convList = jQuery('#blueprint-converted-list');
                convList.empty();
                if (data.converted_features && data.converted_features.length) {
                    data.converted_features.forEach(feat => {
                        convList.append(`<li>${esc_html(feat)}</li>`);
                    });
                    jQuery('#blueprint-converted-wrap').removeClass('hidden');
                } else {
                    jQuery('#blueprint-converted-wrap').addClass('hidden');
                }

                // Render detected plugins chips
                const chips = jQuery('#blueprint-plugins-chips');
                chips.empty();
                if (data.detected_plugins && data.detected_plugins.length) {
                    data.detected_plugins.forEach(p => {
                        let badgeClass = 'bg-zinc-100 text-zinc-700 border-zinc-200';
                        if (p.status === 'native') badgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                        else if (p.status === 'converted') badgeClass = 'bg-amber-50 text-amber-700 border-amber-200';
                        
                        chips.append(`
                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border ${badgeClass} text-[10.5px] font-semibold" title="${esc_html(p.description || '')}">
                                <span class="text-zinc-900">${esc_html(p.name)}</span>
                                <span class="text-[9px] font-mono uppercase opacity-75 font-bold">(${esc_html(p.badge)})</span>
                            </span>
                        `);
                    });
                    jQuery('#blueprint-plugins-wrap').removeClass('hidden');
                } else {
                    jQuery('#blueprint-plugins-wrap').addClass('hidden');
                }

                // Switch view to blueprint
                switchBlueprintTab('pages');
                jQuery('#elem-url-step-input').addClass('hidden');
                jQuery('#elem-url-step-pages').removeClass('hidden');
                window.coraShowToast('Website inspected! Full draft blueprint ready for review.', 'success');
            } else {
                const msg = (res.data && res.data.message) ? res.data.message : 'Could not detect Elementor on this site.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function(xhr) {
            scanBtn.prop('disabled', false).html('<svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg><span>Inspect &amp; Preview Migration</span>');

            let errorMsg = 'Network error during scan. Ensure URL is reachable.';
            if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                errorMsg = xhr.responseJSON.data.message;
            } else if (xhr.responseText) {
                try {
                    const parsed = JSON.parse(xhr.responseText);
                    if (parsed.data && parsed.data.message) errorMsg = parsed.data.message;
                } catch (e) {}
            }
            window.coraShowToast(errorMsg, 'error');
        });
    }

    function toggleElementorPageCheckbox(idx, checked) {
        if (checked) {
            if (!elementorScanState.selectedIndices.includes(idx)) {
                elementorScanState.selectedIndices.push(idx);
            }
        } else {
            elementorScanState.selectedIndices = elementorScanState.selectedIndices.filter(i => i !== idx);
        }
        updateMigrateButtonLabel();
    }

    function toggleSelectAllElementorPages(btn) {
        const checkboxes = jQuery('#elem-scanned-pages-list input[type="checkbox"]');
        const allChecked = elementorScanState.selectedIndices.length === elementorScanState.pages.length;

        if (allChecked) {
            checkboxes.prop('checked', false);
            elementorScanState.selectedIndices = [];
            jQuery(btn).text('Select All');
        } else {
            checkboxes.prop('checked', true);
            elementorScanState.selectedIndices = elementorScanState.pages.map((_, i) => i);
            jQuery(btn).text('Deselect All');
        }
        updateMigrateButtonLabel();
    }

    function triggerMigrateElementorPages() {
        if (elementorScanState.selectedIndices.length === 0) {
            window.coraShowToast('Please select at least 1 page to migrate.', 'error');
            return;
        }

        const pagesToMigrate = elementorScanState.selectedIndices.map(i => elementorScanState.pages[i]);
        const total = pagesToMigrate.length;

        jQuery('#elem-url-step-pages').addClass('hidden');
        jQuery('#elem-url-step-progress').removeClass('hidden');
        jQuery('#elem-progress-title').text('Creating isolated Draft Theme...');
        jQuery('#elem-progress-sub').text('Creating a dedicated draft theme to keep your live theme 100% safe...');
        jQuery('#elem-progress-bar').css('width', '10%');

        // Provision a new dedicated Draft Theme for this import
        const scanUrl = elementorScanState.url || '';
        let defaultThemeName = elementorScanState.draftThemeName || '';
        if (!defaultThemeName) {
            try {
                if (scanUrl) {
                    const host = new URL(scanUrl).hostname;
                    defaultThemeName = 'Imported - ' + (host ? host.replace(/^www\./, '') : 'Website');
                }
            } catch(e) {}
        }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_elementor_create_draft_theme',
            url: scanUrl,
            name: defaultThemeName,
            nonce: coraREData.ajaxNonce
        }, function(themeRes) {
            let targetThemeId = canvasState.activeThemeId;
            let targetThemeName = defaultThemeName || 'Imported Theme';

            if (themeRes && themeRes.success && themeRes.data) {
                targetThemeId = themeRes.data.theme_id;
                targetThemeName = themeRes.data.theme_name;
                elementorScanState.draftThemeId = targetThemeId;
                elementorScanState.draftThemeName = targetThemeName;

                // Add to canvasState themes list if not already present
                if (!canvasState.themes.find(t => t.id == targetThemeId)) {
                    canvasState.themes.push({
                        id: targetThemeId,
                        name: targetThemeName,
                        status: 'draft',
                        is_active: 0,
                        settings: { source: 'elementor' }
                    });
                }
            }

            jQuery('#elem-progress-title').text(`Starting import into "${targetThemeName}"...`);
            jQuery('#elem-progress-bar').css('width', '20%');

            function migrateNextPage(index) {
                if (index >= total) {
                    // Done
                    jQuery('#elem-progress-bar').css('width', '100%');
                    setTimeout(() => {
                        jQuery('#elem-url-step-progress').addClass('hidden');
                        jQuery('#elem-url-step-success').removeClass('hidden');
                        jQuery('#elem-success-heading').text('Migration Complete!');
                        jQuery('#elem-success-detail').text(`${total} Elementor pages and media assets successfully imported into new Draft Theme "${targetThemeName}". Your live theme remains 100% untouched.`);
                        
                        // Setup Preview Draft Theme button
                        const wsSiteBase = `${coraREData.siteUrl}/site`;
                        const draftPreviewUrl = `${wsSiteBase}/?cv_preview_theme=${targetThemeId}`;
                        jQuery('#elem-btn-preview-draft').attr('href', draftPreviewUrl).removeClass('hidden');

                        // Automatically activate the draft theme inside the Canvas Editor
                        if (typeof editTheme === 'function') {
                            editTheme(targetThemeId, targetThemeName, false);
                        } else {
                            fetchThemePages(targetThemeId);
                        }
                        window.coraShowToast(`Elementor migration completed in Draft Theme "${targetThemeName}"!`, 'success');
                    }, 600);
                    return;
                }

                const p = pagesToMigrate[index];
                const pct = Math.round(20 + (((index + 0.5) / total) * 75));
                jQuery('#elem-progress-bar').css('width', pct + '%');
                jQuery('#elem-progress-title').text(`Migrating: ${p.title} (${index + 1}/${total})`);
                jQuery('#elem-progress-sub').text('Extracting Elementor sections & downloading media...');

                jQuery.post(coraREData.ajaxUrl, {
                    action: 'cora_ajax_elementor_migrate_url',
                    url: p.url,
                    title: p.title,
                    slug: p.slug,
                    theme_id: targetThemeId,
                    is_homepage: p.is_homepage ? 1 : 0,
                    nonce: coraREData.ajaxNonce
                }, function(res) {
                    if (res.success && res.data) {
                        if (!elementorScanState.firstMigratedPageId) {
                            elementorScanState.firstMigratedPageId = res.data.page_id;
                            elementorScanState.firstMigratedPostId = res.data.wp_post_id;
                            elementorScanState.firstMigratedTitle = res.data.title;
                        }
                    }
                    migrateNextPage(index + 1);
                }).fail(function() {
                    migrateNextPage(index + 1);
                });
            }

            migrateNextPage(0);
        }).fail(function() {
            window.coraShowToast('Failed to initialize isolated draft theme. Please try again.', 'error');
            jQuery('#elem-url-step-progress').addClass('hidden');
            jQuery('#elem-url-step-pages').removeClass('hidden');
        });
    }

    function openMigratedFirstPage() {
        closeElementorMigrationDrawer();
        if (elementorScanState.firstMigratedPageId && elementorScanState.firstMigratedPostId) {
            setTimeout(function() {
                openPageEditor(elementorScanState.firstMigratedPageId, elementorScanState.firstMigratedTitle, elementorScanState.firstMigratedPostId);
            }, 400);
        } else {
            fetchThemePages(canvasState.activeThemeId);
        }
    }

    function handleElementorFileSelected(input) {
        if (input.files && input.files[0]) {
            selectedElementorFile = input.files[0];
            jQuery('#elem-file-name-label').text('Selected: ' + selectedElementorFile.name);
            jQuery('#elem-btn-upload-submit').prop('disabled', false);
        }
    }

    function triggerUploadElementorFile() {
        if (!selectedElementorFile) {
            window.coraShowToast('Please select a .json, .zip, or .xml template file.', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('action', 'cora_ajax_elementor_upload_template');
        formData.append('template_file', selectedElementorFile);
        formData.append('create_draft_theme', '1');
        formData.append('theme_id', canvasState.activeThemeId);
        formData.append('nonce', coraREData.ajaxNonce);

        window.coraShowToast('Uploading and parsing Elementor layout into new Draft Theme...');
        const btn = jQuery('#elem-btn-upload-submit');
        btn.prop('disabled', true).text('Importing...');

        jQuery.ajax({
            url: coraREData.ajaxUrl,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(res) {
                btn.prop('disabled', false).text('Import to Canvas');
                if (res.success) {
                    const targetThemeId = (res.data && res.data.theme_id) ? res.data.theme_id : canvasState.activeThemeId;
                    const targetThemeName = (res.data && res.data.theme_name) ? res.data.theme_name : 'Imported Theme';

                    if (targetThemeId && !canvasState.themes.find(t => t.id == targetThemeId)) {
                        canvasState.themes.push({
                            id: targetThemeId,
                            name: targetThemeName,
                            status: 'draft',
                            is_active: 0,
                            settings: { source: 'elementor' }
                        });
                    }

                    window.coraShowToast(`Elementor template imported into Draft Theme "${targetThemeName}"!`, 'success');
                    closeElementorMigrationDrawer();

                    if (typeof editTheme === 'function') {
                        editTheme(targetThemeId, targetThemeName, false);
                    } else {
                        fetchThemePages(targetThemeId);
                    }

                    if (res.data && res.data.page_id && res.data.wp_post_id) {
                        setTimeout(() => {
                            openPageEditor(res.data.page_id, res.data.title, res.data.wp_post_id);
                        }, 500);
                    }
                } else {
                    const msg = (res.data && res.data.message) ? res.data.message : 'Failed to import Elementor template.';
                    window.coraShowToast(msg, 'error');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('Import to Canvas');
                window.coraShowToast('Upload error occurred.', 'error');
            }
        });
    }

    function openEditPageSettingsDrawer(pageId, title, status, slug) {
        jQuery('#edit-page-settings-id').val(pageId);
        jQuery('#edit-page-settings-title').val(title);
        jQuery('#edit-page-settings-slug').val(slug);
        
        const pageObj = canvasState.pages ? canvasState.pages.find(p => p.id == pageId) : null;
        const isHome = pageObj && (pageObj.is_homepage == 1);
        if (isHome) {
            jQuery('#edit-page-settings-status').val('publish').prop('disabled', true);
            if (!jQuery('#edit-page-settings-status-note').length) {
                jQuery('#edit-page-settings-status').after('<p id="edit-page-settings-status-note" class="text-[10px] text-zinc-400 font-medium mt-1">Homepage is always visible on your live site</p>');
            } else {
                jQuery('#edit-page-settings-status-note').show();
            }
        } else {
            jQuery('#edit-page-settings-status').val(status === 'published' ? 'publish' : status).prop('disabled', false);
            jQuery('#edit-page-settings-status-note').hide();
        }
        
        // Populate route options
        const routeSelect = jQuery('#edit-page-settings-lovable-route');
        routeSelect.empty();
        routeSelect.append('<option value="">— Unmapped (Select Route) —</option>');
        
        const mappedRoute = window.CORA_PAGE_MAPPINGS ? (window.CORA_PAGE_MAPPINGS[pageId] || '') : '';
        if (window.CORA_LOVABLE_ROUTES && window.CORA_LOVABLE_ROUTES.length > 0) {
            window.CORA_LOVABLE_ROUTES.forEach(r => {
                const selectedAttr = r.path === mappedRoute ? 'selected' : '';
                routeSelect.append(`<option value="${esc_html(r.path)}" ${selectedAttr}>${esc_html(r.path)} (${esc_html(r.title)})</option>`);
            });
        }

        // Show/hide lovable route mapping field based on active theme
        if (canvasState.activeThemeIsElementor) {
            jQuery('#edit-page-settings-lovable-route-container').hide();
        } else {
            jQuery('#edit-page-settings-lovable-route-container').show();
        }

        const modal = jQuery('#drawer-edit-page-settings');
        modal.removeClass('hidden');
        setTimeout(() => {
            modal.removeClass('opacity-0').css('opacity', '1');
            jQuery('#drawer-edit-page-settings-card').removeClass('translate-x-full').addClass('translate-x-0');
        }, 10);
    }

    function closeEditPageSettingsDrawer() {
        jQuery('#drawer-edit-page-settings-card').removeClass('translate-x-0').addClass('translate-x-full');
        const modal = jQuery('#drawer-edit-page-settings');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden');
        }, 300);
    }

    function saveEditPageSettings() {
        const pageId = jQuery('#edit-page-settings-id').val();
        const title = jQuery('#edit-page-settings-title').val().trim();
        const slug = jQuery('#edit-page-settings-slug').val().trim();
        const status = jQuery('#edit-page-settings-status').val();
        const route = jQuery('#edit-page-settings-lovable-route').val() || '';

        if (!title || !slug) {
            window.coraShowToast('Title and Slug are required.', 'error');
            return;
        }

        window.coraShowToast('Saving page settings...', 'info');

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_update_page_properties',
            nonce: coraREData.ajaxNonce,
            page_id: pageId,
            title: title,
            slug: slug,
            status: status,
            route: route
        }, function(res) {
            if (res && res.success) {
                window.coraShowToast('Page settings updated successfully!', 'success');
                closeEditPageSettingsDrawer();
                
                // Update local page mappings state
                if (!window.CORA_PAGE_MAPPINGS) window.CORA_PAGE_MAPPINGS = {};
                if (route) {
                    window.CORA_PAGE_MAPPINGS[pageId] = route;
                } else {
                    delete window.CORA_PAGE_MAPPINGS[pageId];
                }
                
                // Reload pages table and list
                if (typeof fetchThemePages === 'function') {
                    fetchThemePages(canvasState.activeThemeId);
                }
            } else {
                window.coraShowToast(res.data && res.data.message ? res.data.message : 'Failed to update page settings.', 'error');
            }
        }).fail(function() {
            window.coraShowToast('Server connection failed.', 'error');
        });
    }

    // --- HTML & Elementor Creation Engine State ---
    window.coraPageEngineMode = 'elementor';
    window.coraSelectedHtmlFile = null;

    function switchPageEngineMode(mode) {
        window.coraPageEngineMode = mode;
        const btnElem = jQuery('#cora-engine-tab-elementor');
        const btnHtml = jQuery('#cora-engine-tab-html');
        const badge = jQuery('#cora-page-engine-badge');
        const elemBanner = jQuery('#cora-elementor-migrator-banner');
        const htmlPanel = jQuery('#cora-html-upload-panel');
        const templateSelect = jQuery('#new-page-template-input');

        if (mode === 'html') {
            btnHtml.removeClass('text-zinc-600 font-semibold').addClass('bg-white text-zinc-950 font-bold shadow-2xs');
            btnElem.removeClass('bg-white text-zinc-950 font-bold shadow-2xs').addClass('text-zinc-600 font-semibold');
            badge.text('AI Smart Canvas').removeClass('bg-zinc-100 text-zinc-700').addClass('bg-zinc-950 text-white');
            elemBanner.addClass('hidden');
            htmlPanel.removeClass('hidden');
            templateSelect.val('canvas'); // Default to standalone canvas for imported HTML
            jQuery('#cora-create-edit-text').text('Import & Visual Edit ✨');
        } else {
            btnElem.removeClass('text-zinc-600 font-semibold').addClass('bg-white text-zinc-950 font-bold shadow-2xs');
            btnHtml.removeClass('bg-white text-zinc-950 font-bold shadow-2xs').addClass('text-zinc-600 font-semibold');
            badge.text('Elementor').removeClass('bg-zinc-950 text-white').addClass('bg-zinc-100 text-zinc-700');
            elemBanner.removeClass('hidden');
            htmlPanel.addClass('hidden');
            templateSelect.val('default');
            jQuery('#cora-create-edit-text').text('Create & Edit');
        }
    }

    function toggleHtmlPasteBox() {
        const box = jQuery('#cora-html-paste-box');
        const btn = jQuery('#cora-toggle-paste-btn');
        if (box.hasClass('hidden')) {
            box.removeClass('hidden');
            btn.text('Or upload an HTML file instead');
        } else {
            box.addClass('hidden');
            btn.text('Or paste raw HTML code');
        }
    }

    function handleHtmlFileSelect(input) {
        if (!input.files || !input.files[0]) return;
        const file = input.files[0];
        window.coraSelectedHtmlFile = file;
        jQuery('#cora-html-file-label').text(file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)');

        const reader = new FileReader();
        reader.onload = function(e) {
            const content = e.target.result;
            inspectAndAutoFillHtml(content, file.name);
        };
        if (file.name.endsWith('.zip')) {
            // For zip files, show title suggestion based on filename
            const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]+/g, ' ');
            const titleInput = jQuery('#new-page-title-input');
            if (!titleInput.val()) {
                titleInput.val(cleanName);
                autoGenerateSlug(titleInput[0]);
            }
            jQuery('#cora-html-detected-title').text(cleanName);
            jQuery('#cora-html-telemetry-badge').removeClass('hidden');
        } else {
            reader.readAsText(file);
        }
    }

    function handleHtmlPasteChange(textarea) {
        const content = textarea.value.trim();
        if (content.length > 20) {
            inspectAndAutoFillHtml(content, 'Pasted HTML Page');
        }
    }

    function inspectAndAutoFillHtml(html, fallbackTitle) {
        let detectedTitle = '';
        const titleMatch = html.match(/<title[^>]*>(.*?)<\/title>/i);
        if (titleMatch && titleMatch[1]) detectedTitle = titleMatch[1].trim();
        if (!detectedTitle) {
            const h1Match = html.match(/<h1[^>]*>(.*?)<\/h1>/i);
            if (h1Match && h1Match[1]) detectedTitle = h1Match[1].replace(/<[^>]+>/g, '').trim();
        }
        if (!detectedTitle) detectedTitle = fallbackTitle.replace(/\.[^/.]+$/, '').replace(/[-_]+/g, ' ');

        const titleInput = jQuery('#new-page-title-input');
        if (!titleInput.val() || titleInput.val() === 'Pasted HTML Page') {
            titleInput.val(detectedTitle);
            autoGenerateSlug(titleInput[0]);
        }

        // Count stats
        const headingsCount = (html.match(/<h[1-6]\b/gi) || []).length;
        const imagesCount = (html.match(/<img\b/gi) || []).length;
        const buttonsCount = (html.match(/<button\b|<a\b[^>]*class=['"][^'"]*(btn|button|cta)[^'"]*['"]/gi) || []).length;

        jQuery('#cora-html-detected-title').text(detectedTitle);
        jQuery('#cora-html-stat-headings').text(headingsCount + ' Headings');
        jQuery('#cora-html-stat-images').text(imagesCount + ' Media Assets');
        jQuery('#cora-html-stat-buttons').text(buttonsCount + ' CTA Buttons');
        jQuery('#cora-html-telemetry-badge').removeClass('hidden');
    }

    function autoGenerateSlug(input) {
        if (!input || !input.value) return;
        const raw = input.value.toLowerCase()
            .replace(/[^\w ]+/g, '')
            .replace(/ +/g, '-');
        jQuery('#new-page-slug-input').val(raw);
    }
    window.autoGenerateSlug = autoGenerateSlug;

    function saveNewPage(editImmediately) {
        let title = (jQuery('#new-page-title-input').val() || '').trim();
        let slug = (jQuery('#new-page-slug-input').val() || '').trim();
        const template = jQuery('#new-page-template-input').val() || 'default';
        const status = jQuery('#new-page-status-input').val() || 'draft';

        // Auto-derive title from HTML file if missing
        if (!title && window.coraPageEngineMode === 'html' && window.coraSelectedHtmlFile) {
            title = window.coraSelectedHtmlFile.name.replace(/\.[^/.]+$/, '').replace(/[-_]+/g, ' ');
            jQuery('#new-page-title-input').val(title);
        }

        // Auto-derive slug from title if empty
        if (title && !slug) {
            slug = title.toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-');
            jQuery('#new-page-slug-input').val(slug);
        }

        if (!title || !slug) {
            window.coraShowToast('Please enter a Page Title and Slug.', 'error');
            return;
        }

        if (window.coraPageEngineMode === 'html') {
            // HTML Page Upload / Paste Flow
            const pastedCode = (jQuery('#cora-html-paste-input').val() || '').trim();
            const file = window.coraSelectedHtmlFile;

            if (!file && !pastedCode) {
                window.coraShowToast('Please select an HTML/ZIP file or paste HTML code.', 'error');
                return;
            }

            window.coraShowToast('Optimizing & deploying HTML page with AI...', 'info');
            const formData = new FormData();
            formData.append('action', 'cora_ajax_create_html_page');
            formData.append('theme_id', canvasState.activeThemeId);
            formData.append('title', title);
            formData.append('slug', slug);
            formData.append('template', template);
            formData.append('status', status);
            formData.append('nonce', coraREData.ajaxNonce);

            if (file) {
                formData.append('html_file', file);
            } else {
                formData.append('html_code', pastedCode);
            }

            jQuery.ajax({
                url: coraREData.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(res) {
                    if (res && res.success) {
                        window.coraShowToast('HTML page imported and AI-optimized successfully.', 'success');
                        closeNewPageDrawer();
                        
                        if (editImmediately) {
                            setTimeout(function() {
                                openHtmlVisualEditor(res.data.page_id, title, res.data.wp_post_id, status, res.data.slug);
                            }, 400);
                        } else {
                            fetchThemePages(canvasState.activeThemeId);
                        }
                    } else {
                        const msg = (res && res.data && res.data.message) ? res.data.message : 'Failed to create HTML page.';
                        window.coraShowToast(msg, 'error');
                    }
                },
                error: function() {
                    window.coraShowToast('Network error while uploading HTML page.', 'error');
                }
            });
            return;
        }

        // Standard Elementor Creation Flow
        window.coraShowToast('Creating page...', 'info');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_create_page',
            theme_id: canvasState.activeThemeId,
            title: title,
            slug: slug,
            template: template,
            status: status,
            page_engine: 'elementor',
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res && res.success) {
                window.coraShowToast('Page created successfully.', 'success');
                closeNewPageDrawer();
                
                if (editImmediately) {
                    setTimeout(function() {
                        openPageEditor(res.data.page_id, title, res.data.wp_post_id, status, slug);
                    }, 400);
                } else {
                    fetchThemePages(canvasState.activeThemeId);
                }
            } else {
                const msg = (res && res.data && res.data.message) ? res.data.message : 'Failed to create page.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function() {
            window.coraShowToast('Network error while creating page.', 'error');
        });
    }
    window.switchPageEngineMode = switchPageEngineMode;
    window.toggleHtmlPasteBox = toggleHtmlPasteBox;
    window.handleHtmlFileSelect = handleHtmlFileSelect;
    window.handleHtmlPasteChange = handleHtmlPasteChange;
    window.inspectAndAutoFillHtml = inspectAndAutoFillHtml;
    window.saveNewPage = saveNewPage;

    // Set Homepage designation
    function triggerSetHomepage(id, title, isHome) {
        if (canvasState.isReadOnly) return;
        if (isHome == 1) {
            window.coraShowToast('This page is already the homepage.');
            return;
        }

        const currentHome = canvasState.pages.find(p => p.is_homepage == 1);
        const currentHomeName = currentHome ? currentHome.title : 'None';

        window.coraConfirmAction(
            'Set Homepage',
            `Set "${title}" as your homepage? Current homepage is "${currentHomeName}".`,
            function() {
                window.coraShowToast('Updating homepage...');
                jQuery.post(coraREData.ajaxUrl, {
                    action: 'cora_ajax_set_homepage',
                    page_id: id,
                    theme_id: canvasState.activeThemeId,
                    nonce: coraREData.ajaxNonce
                }, function(res) {
                    if (res.success) {
                        window.coraShowToast('Homepage updated successfully.');
                        fetchThemePages(canvasState.activeThemeId);
                    } else {
                        window.coraShowToast('Failed to update homepage.');
                    }
                });
            }
        );
    }

    // Rename Page Dialog Drawer
    function triggerRenamePage(id, oldTitle) {
        if (canvasState.isReadOnly) return;
        jQuery('#rename-page-id-input').val(id);
        jQuery('#rename-page-title-input').val(oldTitle);
        
        const modal = jQuery('#drawer-rename-page');
        modal.removeClass('hidden');
        setTimeout(() => {
            modal.removeClass('opacity-0').css('opacity', '1');
            jQuery('#drawer-rename-page-card').removeClass('scale-95').addClass('scale-100');
        }, 10);
    }
    function closeRenamePageDrawer() {
        jQuery('#drawer-rename-page-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-rename-page');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden');
        }, 300);
    }
    function saveRenamedPage() {
        const id = jQuery('#rename-page-id-input').val();
        const newTitle = jQuery('#rename-page-title-input').val().trim();
        if (!newTitle) {
            window.coraShowToast('Page title cannot be empty.');
            return;
        }
        window.coraShowToast('Renaming...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_rename_page',
            page_id: id,
            title: newTitle,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Page renamed.');
                closeRenamePageDrawer();
                fetchThemePages(canvasState.activeThemeId);
            } else {
                window.coraShowToast('Failed to rename.');
            }
        });
    }

    // Change Slug Dialog Drawer
    function triggerChangePageSlug(id, oldSlug) {
        if (canvasState.isReadOnly) return;
        jQuery('#change-page-slug-id-input').val(id);
        jQuery('#change-page-slug-input').val(oldSlug);
        
        const modal = jQuery('#drawer-change-page-slug');
        modal.removeClass('hidden');
        setTimeout(() => {
            modal.removeClass('opacity-0').css('opacity', '1');
            jQuery('#drawer-change-page-slug-card').removeClass('scale-95').addClass('scale-100');
        }, 10);
    }
    function closeChangePageSlugDrawer() {
        jQuery('#drawer-change-page-slug-card').removeClass('scale-100').addClass('scale-95');
        const modal = jQuery('#drawer-change-page-slug');
        modal.addClass('opacity-0').css('opacity', '0');
        setTimeout(function() {
            modal.addClass('hidden');
        }, 300);
    }
    function savePageSlug() {
        const id = jQuery('#change-page-slug-id-input').val();
        const newSlug = jQuery('#change-page-slug-input').val().trim();
        if (!newSlug) {
            window.coraShowToast('Slug cannot be empty.');
            return;
        }
        window.coraShowToast('Updating slug...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_change_slug',
            page_id: id,
            slug: newSlug,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Slug updated successfully.');
                closeChangePageSlugDrawer();
                fetchThemePages(canvasState.activeThemeId);
            } else {
                const msg = (res.data && res.data.message) ? res.data.message : 'Failed to update slug.';
                window.coraShowToast(msg, 'error');
            }
        });
    }

    // Delete Page Dialog
    function triggerDeletePage(id) {
        if (canvasState.isReadOnly) return;
        window.coraConfirmAction(
            'Delete Page',
            'Are you sure you want to delete this page permanently? This will remove the page from the template registry and delete the associated platform post.',
            function() {
                window.coraShowToast('Removing page...');
                jQuery.ajax({
                    url: coraREData.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'cora_ajax_delete_page',
                        page_id: id,
                        nonce: coraREData.ajaxNonce
                    },
                    success: function(res) {
                        if (res.success) {
                            window.coraShowToast('Page deleted successfully.');
                            fetchThemePages(canvasState.activeThemeId);
                        } else {
                            window.coraShowToast('Failed to delete page.');
                        }
                    }
                });
            }
        );
    }

    // Duplicate Page Dialog
    function triggerDuplicatePage(id) {
        if (canvasState.isReadOnly) return;
        window.coraShowToast('Duplicating page...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_duplicate_page',
            page_id: id,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Page duplicated as draft.');
                fetchThemePages(canvasState.activeThemeId);
            } else {
                window.coraShowToast('Failed to duplicate.');
            }
        });
    }

    // Bulk Select & Actions
    function toggleSelectAllPages(checkbox) {
        jQuery('.page-row-checkbox').prop('checked', checkbox.checked);
        updateBulkActionState();
    }

    function updateBulkActionState() {
        const checked = jQuery('.page-row-checkbox:checked');
        const bar = jQuery('#pages-bulk-actions-bar');
        
        if (checked.length > 0) {
            jQuery('#bulk-selected-count').text(checked.length + ' selected');
            bar.removeClass('hidden').addClass('flex');
        } else {
            bar.removeClass('flex').addClass('hidden');
        }
    }

    function deselectAllPages() {
        jQuery('.page-row-checkbox, #pages-select-all-checkbox').prop('checked', false);
        updateBulkActionState();
    }

    function applyBulkPagesAction() {
        if (canvasState.isReadOnly) return;
        const action = jQuery('#pages-bulk-action-select').val();
        const ids = [];
        jQuery('.page-row-checkbox:checked').each(function() {
            ids.push(jQuery(this).data('id'));
        });

        if (ids.length === 0) return;

        window.coraConfirmAction(
            'Bulk Action',
            `Are you sure you want to perform bulk "${action}" on ${ids.length} selected pages?`,
            function() {
                window.coraShowToast('Processing bulk request...');
                jQuery.post(coraREData.ajaxUrl, {
                    action: 'cora_ajax_bulk_pages',
                    action_type: action,
                    page_ids: ids,
                    nonce: coraREData.ajaxNonce
                }, function(res) {
                    if (res.success) {
                        window.coraShowToast('Bulk action executed successfully.');
                        deselectAllPages();
                        fetchThemePages(canvasState.activeThemeId);
                    } else {
                        window.coraShowToast('Failed to apply bulk actions.');
                    }
                });
            }
        );
    }

    // --- Tab 2 Menus Functions ---
    function showMenusTabContent() {
        if (canvasState.activeMenuDetailId) {
            jQuery('#menus-list-view').addClass('hidden');
            jQuery('#menus-detail-view').removeClass('hidden');
            // In detail view: show Duplicate, hide list-level actions
            jQuery('#menu-btn-redirects, #menu-btn-create').addClass('hidden');
            jQuery('#menu-btn-duplicate, #menu-btn-delete').removeClass('hidden');
            renderMenuDetailEditor();
        } else {
            jQuery('#menus-list-view').removeClass('hidden');
            jQuery('#menus-detail-view').addClass('hidden');
            // In list view: show URL redirects + Create menu, hide Duplicate
            jQuery('#menu-btn-redirects, #menu-btn-create').removeClass('hidden');
            jQuery('#menu-btn-duplicate, #menu-btn-delete').addClass('hidden');
            renderMenusList();
        }
    }

    function renderMenusList() {
        const body = jQuery('#menus-table-body');
        body.empty();

        if (!canvasState.menus || canvasState.menus.length === 0) {
            body.append(`
                <tr>
                    <td colspan="2" class="p-8 text-center text-xs text-zinc-400">No menus created yet. Click "Create menu" to start.</td>
                </tr>
            `);
            return;
        }

        canvasState.menus.forEach(m => {
            const previewItems = m.items && m.items.length > 0
                ? m.items.map(item => item.label).join(', ')
                : '—';
            body.append(`
                <tr onclick="openMenuDetailEditor('${m.id}')" class="border-b border-zinc-100 hover:bg-zinc-50/50 cursor-pointer group transition-colors">
                    <td class="px-4 py-3 text-xs font-semibold text-zinc-900 group-hover:underline overflow-hidden">
                        <span class="block truncate w-full font-bold" title="${esc_html(m.name)}">${esc_html(m.name)}</span>
                    </td>
                    <td class="px-4 py-3 text-[11px] font-medium text-zinc-500 overflow-hidden">
                        <span class="block truncate w-full text-zinc-500" title="${esc_html(previewItems)}">${esc_html(previewItems)}</span>
                    </td>
                </tr>
            `);
        });
    }

    function openMenuDetailEditor(menuId) {
        canvasState.activeMenuDetailId = menuId;
        showMenusTabContent();
    }

    function exitMenuDetail() {
        canvasState.activeMenuInlineIndex = null;
        canvasState.activeMenuInlineIsNew = false;
        canvasState.activeMenuDetailId = null;
        showMenusTabContent();
    }

    function updateMenuHandleLabel(name) {
        const handle = name.toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
        jQuery('#menu-handle-label').text('Handle: ' + handle);
    }

    function updateMenuNameState(val) {
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (currentMenu) {
            currentMenu.name = val;
            currentMenu.handle = val.toLowerCase()
                .trim()
                .replace(/[^\w\s-]/g, '')
                .replace(/[\s_-]+/g, '-')
                .replace(/^-+|-+$/g, '');
            syncMenusToSettings();
        }
        jQuery('#menu-detail-header-title').text(val);
        updateMenuHandleLabel(val);
    }

    function duplicateActiveMenu() {
        if (canvasState.isReadOnly) return;
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        const newMenuId = 'menu_' + Date.now();
        const duplicatedName = currentMenu.name + ' (Copy)';
        const duplicatedHandle = (currentMenu.handle || 'menu') + '-copy';
        const copiedItems = currentMenu.items ? JSON.parse(JSON.stringify(currentMenu.items)) : [];

        // Create a real WP nav_menu term for the duplicate
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_create_nav_menu',
            menu_name: duplicatedName,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            const wpTermId = res.success && res.data && res.data.menu_id ? res.data.menu_id : null;
            canvasState.menus.push({
                id: newMenuId,
                wp_term_id: wpTermId,
                name: duplicatedName,
                handle: duplicatedHandle,
                items: copiedItems
            });
            syncMenusToSettings();
            window.coraShowToast(`Duplicated theme menu as "${duplicatedName}"`, 'success');
            openMenuDetailEditor(newMenuId);
        }).fail(function() {
            canvasState.menus.push({ id: newMenuId, name: duplicatedName, handle: duplicatedHandle, items: copiedItems });
            syncMenusToSettings();
            window.coraShowToast(`Duplicated theme menu as "${duplicatedName}"`, 'success');
            openMenuDetailEditor(newMenuId);
        });
    }

    function deleteActiveMenu() {
        if (canvasState.isReadOnly) return;
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        window.coraConfirmAction(
            'Delete Menu',
            `Are you sure you want to permanently delete "${currentMenu.name}"? This cannot be undone.`,
            function() {
                // Delete the real WP nav_menu term if we have its ID
                if (currentMenu.wp_term_id) {
                    jQuery.post(coraREData.ajaxUrl, {
                        action: 'cora_delete_nav_menu',
                        menu_id: currentMenu.wp_term_id,
                        nonce: coraREData.ajaxNonce
                    });
                }
                canvasState.menus = canvasState.menus.filter(m => m.id !== canvasState.activeMenuDetailId);
                syncMenusToSettings();
                window.coraShowToast(`Menu "${currentMenu.name}" deleted.`, 'success');
                exitMenuDetail();
            }
        );
    }

    // Inline items editing states
    canvasState.activeMenuInlineIndex = null;
    canvasState.activeMenuInlineIsNew = false;

    function renderMenuDetailEditor() {
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        jQuery('#menu-detail-header-title').text(currentMenu.name);
        jQuery('#menu-name-input').val(currentMenu.name);
        updateMenuHandleLabel(currentMenu.name);

        const container = jQuery('#menu-items-list-container');
        container.empty();

        const items = currentMenu.items || [];
        
        items.forEach((item, idx) => {
            if (canvasState.activeMenuInlineIndex === idx && !canvasState.activeMenuInlineIsNew) {
                container.append(renderInlineEditForm(item, idx, false));
            } else {
                container.append(`
                    <div class="group/item flex items-center justify-between border border-zinc-200 rounded-lg p-3 hover:bg-zinc-50/30 transition-all bg-white min-w-0">
                        <div class="flex items-center gap-3 min-w-0 flex-1">
                            <span class="text-zinc-300 cursor-grab hover:text-zinc-500 flex-shrink-0">
                                <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/></svg>
                            </span>
                            <div class="flex items-center gap-2 min-w-0 flex-1">
                                <span class="text-xs font-bold text-zinc-950 truncate max-w-[260px]" title="${esc_html(item.label)}">${esc_html(item.label)}</span>
                                <span class="text-[10px] text-zinc-400 font-mono truncate max-w-[220px]" title="${esc_html(item.url)}">${esc_html(item.url)}</span>
                            </div>
                        </div>
                        <?php if ( ! $is_read_only ) : ?>
                        <div class="flex items-center gap-1 opacity-0 group-hover/item:opacity-100 transition-opacity flex-shrink-0">
                            <button onclick="editMenuInlineRow(${idx})" class="px-2 py-1 text-[10px] font-bold text-zinc-600 hover:text-zinc-900 bg-zinc-50 border border-zinc-200 rounded-md cursor-pointer transition-colors border-none bg-transparent">Edit</button>
                            <button onclick="removeMenuDetailItem(${idx})" class="p-1.5 hover:bg-red-50 border border-transparent hover:border-red-100 rounded text-zinc-400 hover:text-red-605 cursor-pointer transition-colors">
                                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2.2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                `);
            }
        });

        if (canvasState.activeMenuInlineIsNew && canvasState.activeMenuInlineIndex === items.length) {
            container.append(renderInlineEditForm({ label: '', url: '' }, items.length, true));
        }
    }

    function renderInlineEditForm(item, index, isNew) {
        return `
            <div class="flex items-start gap-3 border border-zinc-200 rounded-lg p-4 bg-zinc-50/20 relative shadow-sm" id="inline-edit-row-${index}">
                <div class="pt-2 flex-shrink-0">
                    <span class="text-zinc-300">
                        <svg viewBox="0 0 24 24" width="13" height="13" stroke="currentColor" stroke-width="2.5" fill="none"><circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/></svg>
                    </span>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 flex-1 min-w-0">
                    <div class="space-y-1">
                        <label class="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Label <span class="text-zinc-400 font-normal normal-case">(max 50 chars)</span></label>
                        <input type="text" id="inline-label-input-${index}" maxlength="50" value="${esc_html(item.label)}" placeholder="e.g., About us" class="w-full px-2.5 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white font-semibold text-zinc-800">
                    </div>
                    
                    <div class="space-y-1 relative">
                        <label class="block text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Link</label>
                        <input type="text" id="inline-link-input-${index}" maxlength="200" value="${esc_html(item.url)}" placeholder="Search or paste link" onfocus="showLinkSuggestions(${index})" onblur="hideLinkSuggestions(${index})" class="w-full px-2.5 py-1.5 border border-zinc-200 rounded-lg text-xs focus:outline-none focus:border-zinc-400 bg-white font-semibold text-zinc-800">
                        
                        <!-- Suggestion Dropdown popup -->
                        <div id="link-suggestions-dropdown-${index}" class="hidden absolute left-0 right-0 top-full mt-1.5 bg-white border border-zinc-200 rounded-xl shadow-xl py-1 z-50 text-left font-sans select-none max-h-48 overflow-y-auto">
                            <!-- Populated with pages dynamically -->
                        </div>
                    </div>
                </div>
                
                <div class="flex items-center gap-2 pt-5">
                    <button onclick="applyInlineItemChange(${index}, ${isNew})" class="p-1.5 hover:bg-zinc-50 border border-zinc-200 rounded-lg text-zinc-700 cursor-pointer shadow-xs transition-all flex items-center justify-center bg-white" title="Apply change">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2.5" fill="none"><polyline points="20 6 9 17 4 12"/></svg>
                    </button>
                    <button onclick="cancelInlineItemChange(${index}, ${isNew})" class="p-1.5 hover:bg-red-50 border border-transparent rounded-lg text-zinc-400 hover:text-red-650 cursor-pointer transition-all flex items-center justify-center bg-transparent border-none" title="Cancel/Delete">
                        <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </button>
                </div>
            </div>
        `;
    }

    window.showLinkSuggestions = function(index) {
        const dropdown = jQuery(`#link-suggestions-dropdown-${index}`);
        dropdown.empty();
        
        dropdown.append(`
            <h4 class="px-3 py-1 text-[9px] font-bold text-zinc-400 uppercase tracking-wider border-b border-zinc-50">Online store</h4>
            
            <button onmousedown="selectLinkSuggestion(${index}, '/')" class="w-full px-3 py-1.5 text-left text-xs text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 border-none bg-transparent">
                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-400"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Home page
            </button>
            <button onmousedown="selectLinkSuggestion(${index}, '/search')" class="w-full px-3 py-1.5 text-left text-xs text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 border-none bg-transparent">
                <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-400"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                Search page
            </button>
            
            <h4 class="px-3 py-1 text-[9px] font-bold text-zinc-400 uppercase tracking-wider border-b border-zinc-50 mt-1">Pages</h4>
        `);

        canvasState.pages.forEach(p => {
            dropdown.append(`
                <button onmousedown="selectLinkSuggestion(${index}, '/${p.slug}')" class="w-full px-3.5 py-1.5 text-left text-xs text-zinc-700 hover:bg-zinc-50 cursor-pointer flex items-center gap-2 border-none bg-transparent">
                    <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" class="text-zinc-400"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    ${esc_html(p.title)} <span class="text-[9px] text-zinc-400">(/${p.slug})</span>
                </button>
            `);
        });

        dropdown.removeClass('hidden');
    }

    window.hideLinkSuggestions = function(index) {
        setTimeout(() => {
            jQuery(`#link-suggestions-dropdown-${index}`).addClass('hidden');
        }, 200);
    }

    window.selectLinkSuggestion = function(index, url) {
        jQuery(`#inline-link-input-${index}`).val(url);
    }

    function addMenuInlineRow() {
        if (canvasState.isReadOnly) return;
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        const items = currentMenu.items || [];
        canvasState.activeMenuInlineIndex = items.length;
        canvasState.activeMenuInlineIsNew = true;
        renderMenuDetailEditor();
        
        jQuery(`#inline-label-input-${items.length}`).focus();
    }

    // ─── Auto-Generate Menu from Published Pages ────────────────────────────
    window.autoGenerateMenuFromPages = function() {
        if (canvasState.isReadOnly) return;
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) {
            window.coraShowToast('Please open a menu first.', 'error');
            return;
        }

        // Filter to published pages only
        const publishedPages = (canvasState.pages || []).filter(p => p.wp_post_status === 'publish');

        if (publishedPages.length === 0) {
            window.coraShowToast('No published pages found for this theme.', 'error');
            return;
        }

        // Build checklist
        const list = jQuery('#auto-gen-pages-list').empty();
        const existingUrls = (currentMenu.items || []).map(i => i.url);

        publishedPages.forEach(p => {
            const slug = p.is_homepage == 1 ? '/' : '/' + p.slug;
            const alreadyAdded = existingUrls.includes(slug);
            const label = p.is_homepage == 1 ? p.title + ' (Homepage)' : p.title;
            list.append(`
                <label class="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-zinc-50 cursor-pointer select-none transition-colors auto-gen-page-row" data-slug="${slug}" data-title="${esc_html(p.title)}" data-homepage="${p.is_homepage}">
                    <input type="checkbox" class="auto-gen-page-cb w-3.5 h-3.5 accent-zinc-950 cursor-pointer rounded flex-shrink-0" value="${p.id}" ${alreadyAdded ? '' : 'checked'}>
                    <span class="flex-1 min-w-0">
                        <span class="block text-xs font-semibold text-zinc-800 truncate">${esc_html(label)}</span>
                        <span class="block text-[10px] font-mono text-zinc-400">${slug}</span>
                    </span>
                    ${alreadyAdded ? '<span class="text-[9px] font-bold text-zinc-400 uppercase tracking-wider flex-shrink-0 bg-zinc-100 px-1.5 py-0.5 rounded">Added</span>' : ''}
                </label>
            `);
        });

        autoGenUpdateCountLabel();

        // Update count on checkbox change
        jQuery('#auto-gen-pages-list').off('change.autogen').on('change.autogen', '.auto-gen-page-cb', function() {
            autoGenUpdateCountLabel();
        });

        jQuery('#auto-gen-menu-modal').removeClass('hidden');
    };

    function autoGenUpdateCountLabel() {
        const count = jQuery('.auto-gen-page-cb:checked').length;
        jQuery('#auto-gen-count-label').text(count === 0 ? 'None selected' : count + ' page' + (count > 1 ? 's' : '') + ' selected');
    }

    window.autoGenSelectAll = function(selectAll) {
        jQuery('.auto-gen-page-cb').prop('checked', selectAll);
        autoGenUpdateCountLabel();
    };

    window.closeAutoGenMenuModal = function() {
        jQuery('#auto-gen-menu-modal').addClass('hidden');
    };

    // Close modal on backdrop click
    jQuery(document).on('click', '#auto-gen-menu-modal', function(e) {
        if (jQuery(e.target).is('#auto-gen-menu-modal')) {
            window.closeAutoGenMenuModal();
        }
    });

    window.confirmAutoGenMenu = function() {
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;
        if (!currentMenu.items) currentMenu.items = [];

        const sortOrder = jQuery('#auto-gen-sort-order').val();

        // Collect selected rows
        let selected = [];
        jQuery('.auto-gen-page-row').each(function() {
            const cb = jQuery(this).find('.auto-gen-page-cb');
            if (cb.is(':checked')) {
                selected.push({
                    slug: jQuery(this).data('slug'),
                    title: jQuery(this).data('title'),
                    homepage: parseInt(jQuery(this).data('homepage')) === 1
                });
            }
        });

        if (selected.length === 0) {
            window.coraShowToast('Please select at least one page.', 'error');
            return;
        }

        // Sort selected pages
        if (sortOrder === 'alpha') {
            selected.sort((a, b) => a.title.localeCompare(b.title));
        } else if (sortOrder === 'alpha_desc') {
            selected.sort((a, b) => b.title.localeCompare(a.title));
        } else if (sortOrder === 'homepage_first') {
            selected.sort((a, b) => (b.homepage ? 1 : 0) - (a.homepage ? 1 : 0));
        }

        // Skip duplicates that are already in the menu
        const existingUrls = new Set(currentMenu.items.map(i => i.url));
        let addedCount = 0;
        selected.forEach(page => {
            if (!existingUrls.has(page.slug)) {
                currentMenu.items.push({
                    id: 'mi_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
                    label: page.title,
                    url: page.slug,
                    newTab: false,
                    level: 0
                });
                existingUrls.add(page.slug);
                addedCount++;
            }
        });

        window.closeAutoGenMenuModal();
        syncMenusToSettings();
        renderMenuDetailEditor();

        if (addedCount === 0) {
            window.coraShowToast('All selected pages were already in the menu.', 'error');
        } else {
            window.coraShowToast(`${addedCount} page${addedCount > 1 ? 's' : ''} added to menu.`, 'success');
        }
    };
    // ─── End Auto-Generate Menu ─────────────────────────────────────────────



    function editMenuInlineRow(index) {
        if (canvasState.isReadOnly) return;
        canvasState.activeMenuInlineIndex = index;
        canvasState.activeMenuInlineIsNew = false;
        renderMenuDetailEditor();
    }

    function applyInlineItemChange(index, isNew) {
        if (canvasState.isReadOnly) return;
        let label = jQuery(`#inline-label-input-${index}`).val().trim();
        let url = jQuery(`#inline-link-input-${index}`).val().trim();

        if (!label) {
            window.coraShowToast('Please enter a link label.', 'error');
            return;
        }
        if (label.length > 50) {
            label = label.substring(0, 50);
        }
        if (!url) {
            window.coraShowToast('Please enter or select a destination URL.', 'error');
            return;
        }
        if (url.length > 200) {
            url = url.substring(0, 200);
        }

        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        if (!currentMenu.items) currentMenu.items = [];

        if (isNew) {
            currentMenu.items.push({
                id: 'mi_' + Date.now(),
                label: label,
                url: url,
                newTab: false,
                level: 0
            });
        } else {
            if (currentMenu.items[index]) {
                currentMenu.items[index].label = label;
                currentMenu.items[index].url = url;
            }
        }

        canvasState.activeMenuInlineIndex = null;
        canvasState.activeMenuInlineIsNew = false;

        syncMenusToSettings();
        renderMenuDetailEditor();
    }

    function cancelInlineItemChange(index, isNew) {
        canvasState.activeMenuInlineIndex = null;
        canvasState.activeMenuInlineIsNew = false;
        renderMenuDetailEditor();
    }

    function removeMenuDetailItem(index) {
        if (canvasState.isReadOnly) return;
        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu || !currentMenu.items || !currentMenu.items[index]) return;

        window.coraConfirmAction(
            'Remove Menu Link',
            `Are you sure you want to remove the link "${currentMenu.items[index].label}"?`,
            function() {
                currentMenu.items.splice(index, 1);
                syncMenusToSettings();
                renderMenuDetailEditor();
            }
        );
    }

    function syncMenusToSettings() {
        const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
        if (themeObj) {
            const settings = safeGetSettings(themeObj);
            settings.menus = canvasState.menus;
            themeObj.settings = settings;
        }
    }

    function triggerCreateNewMenu() {
        if (canvasState.isReadOnly) return;
        
        const body = jQuery('#menus-table-body');
        if (jQuery('#new-menu-inline-name-input').length > 0) {
            jQuery('#new-menu-inline-name-input').focus();
            return;
        }

        body.append(`
            <tr id="inline-new-menu-row" class="bg-zinc-50/50">
                <td class="px-4 py-3" colspan="2">
                    <div class="flex items-center gap-3">
                        <input type="text" id="new-menu-inline-name-input" maxlength="60" placeholder="Menu name (e.g., Main menu)" class="px-3 py-1.5 border border-zinc-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-zinc-400 bg-white text-zinc-800 w-64">
                        <button onclick="saveNewMenuInline()" class="px-3 py-1.5 bg-zinc-950 hover:bg-zinc-800 text-white rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 border-none bg-transparent">Save</button>
                        <button onclick="cancelNewMenuInline()" class="px-3 py-1.5 border border-zinc-200 text-zinc-400 hover:text-zinc-700 rounded-lg text-xs font-bold cursor-pointer transition-all active:scale-95 bg-transparent border-none">Cancel</button>
                    </div>
                </td>
            </tr>
        `);
        
        jQuery('#new-menu-inline-name-input').focus().on('keypress', function(e) {
            if (e.which === 13) {
                saveNewMenuInline();
            }
        });
    }

    window.saveNewMenuInline = function() {
        const nameVal = jQuery('#new-menu-inline-name-input').val().trim();
        if (!nameVal) {
            window.coraShowToast('Menu name cannot be empty.', 'error');
            return;
        }

        const handle = nameVal.toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');

        const newMenuId = 'menu_' + Date.now();

        // Create a real WordPress nav_menu term so Elementor can see it
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_create_nav_menu',
            menu_name: nameVal,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            const wpTermId = res.success && res.data && res.data.menu_id ? res.data.menu_id : null;
            canvasState.menus.push({
                id: newMenuId,
                wp_term_id: wpTermId,
                name: nameVal,
                handle: handle,
                items: []
            });
            syncMenusToSettings();
            window.coraShowToast(`Menu "${nameVal}" created.`, 'success');
            openMenuDetailEditor(newMenuId);
        }).fail(function() {
            // Still add locally even if AJAX fails
            canvasState.menus.push({ id: newMenuId, name: nameVal, handle: handle, items: [] });
            syncMenusToSettings();
            window.coraShowToast(`Menu "${nameVal}" created (offline).`, 'success');
            openMenuDetailEditor(newMenuId);
        });
    };

    window.cancelNewMenuInline = function() {
        jQuery('#inline-new-menu-row').remove();
    };

    function saveCurrentMenuDetails() {
        if (canvasState.isReadOnly) return;
        const nameVal = jQuery('#menu-name-input').val().trim();
        if (!nameVal) {
            window.coraShowToast('Menu name cannot be empty.', 'error');
            return;
        }

        const currentMenu = canvasState.menus.find(m => m.id === canvasState.activeMenuDetailId);
        if (!currentMenu) return;

        currentMenu.name = nameVal;
        currentMenu.handle = nameVal.toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');

        syncMenusToSettings();

        const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
        if (!themeObj) return;

        const settings = safeGetSettings(themeObj);
        settings.menus = canvasState.menus;

        window.coraShowToast('Synchronizing theme menus...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_theme_settings',
            theme_id: canvasState.activeThemeId,
            settings: settings,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Navigation menu structure synchronized successfully.', 'success');
                themeObj.settings = settings;
                exitMenuDetail();
            } else {
                window.coraShowToast('Failed to save menu changes.', 'error');
            }
        });
    }

    // --- Tab 3 Theme Settings Functions ---
    function fetchThemeSettings(themeId) {
        const themeObj = canvasState.themes.find(t => t.id == themeId);
        if (themeObj) {
            canvasState.activeMenuDetailId = null;
            const settings = safeGetSettings(themeObj);
            
            // Dynamic menus extraction: prefer saved theme settings
            if (settings && settings.menus && Array.isArray(settings.menus) && settings.menus.length > 0) {
                canvasState.menus = settings.menus;
            } else {
                // Scoped clean default Main menu for this theme
                canvasState.menus = [
                    {
                        id: 'menu_main_' + themeId,
                        name: 'Main menu',
                        handle: 'main-menu',
                        items: []
                    }
                ];
            }
            if (canvasState.menus.length > 0) {
                if (!canvasState.menus.some(m => m.id === canvasState.activeMenuId)) {
                    canvasState.activeMenuId = canvasState.menus[0].id;
                }
            } else {
                canvasState.activeMenuId = '';
            }
            
            jQuery('#setting-site-title').val(settings.site_title || '<?php echo esc_js( get_option( "blogname", "Cora Workspace" ) ); ?>');
            jQuery('#setting-site-tagline').val(settings.site_tagline || '<?php echo esc_js( get_option( "blogdescription", "" ) ); ?>');
            jQuery('#setting-site-description').val(settings.site_description || '<?php echo esc_js( get_option( "blogdescription", "" ) ); ?>');
            jQuery('#setting-site-favicon').val(settings.site_favicon || '<?php echo esc_js( get_option( "cora_brand_favicon_url", "" ) ); ?>');
            jQuery('#setting-site-logo').val(settings.site_logo || '<?php echo esc_js( get_option( "cora_brand_logo_url", "" ) ); ?>');
            jQuery('#setting-site-logo-dark').val(settings.site_logo_dark || '');
            jQuery('#setting-og-image').val(settings.og_image || '');
            jQuery('#setting-title-format').val(settings.title_format || '%title% | %site%');
            
            // Typography
            jQuery('#setting-heading-font').val(settings.heading_font || 'Inter');
            jQuery('#setting-body-font').val(settings.body_font || 'Inter');
            jQuery('#setting-accent-font').val(settings.accent_font || '');
            jQuery('#setting-font-size').val(settings.base_font_size || 16);
            jQuery('#font-size-val').text((settings.base_font_size || 16) + 'px');
            jQuery('#setting-gfonts-key').val(settings.gfonts_key || '');

            // Type scale
            const typeLevels = ['h1','h2','h3','body','small','btn'];
            typeLevels.forEach(function(lv) {
                const defs = {h1:{size:56,weight:800,lh:1.2,ls:0},h2:{size:40,weight:700,lh:1.25,ls:0},h3:{size:28,weight:600,lh:1.3,ls:0},body:{size:16,weight:400,lh:1.65,ls:0},small:{size:13,weight:400,lh:1.5,ls:0},btn:{size:14,weight:600,lh:1.2,ls:0}};
                const d = defs[lv] || {size:16,weight:400,lh:1.5,ls:0};
                jQuery('#setting-type-' + lv + '-size').val(settings['type_' + lv + '_size'] || d.size);
                jQuery('#setting-type-' + lv + '-weight').val(settings['type_' + lv + '_weight'] || d.weight);
                jQuery('#setting-type-' + lv + '-lh').val(settings['type_' + lv + '_lh'] || d.lh);
                jQuery('#setting-type-' + lv + '-ls').val(settings['type_' + lv + '_ls'] || d.ls);
            });

            // Core Colors
            function setColor(id, val) {
                jQuery('#' + id).val(val);
                jQuery('#' + id + '-text').val(val);
            }
            setColor('setting-color-primary',   settings.primary_color   || '#18181b');
            setColor('setting-color-secondary',  settings.secondary_color || '#27272a');
            setColor('setting-color-accent',     settings.accent_color    || '#10b981');
            setColor('setting-color-text',       settings.text_color      || '#09090b');
            setColor('setting-color-bg',         settings.bg_color        || '#ffffff');
            setColor('setting-color-surface',    settings.surface_color   || '#f4f4f5');
            // Semantic colors
            setColor('setting-color-success',    settings.success_color   || '#16a34a');
            setColor('setting-color-warning',    settings.warning_color   || '#d97706');
            setColor('setting-color-danger',     settings.danger_color    || '#dc2626');
            setColor('setting-color-info',       settings.info_color      || '#2563eb');
            // Button colors
            setColor('setting-color-btn-bg',     settings.btn_bg          || settings.primary_color || '#18181b');
            setColor('setting-color-btn-text',   settings.btn_text        || '#ffffff');
            setColor('setting-color-btn-hover',  settings.btn_hover_bg    || settings.secondary_color || '#27272a');

            // Spacing
            const cw = settings.container_width || 1280;
            jQuery('#setting-container-width').val(cw);
            jQuery('#container-width-val').text(cw + 'px');
            const sp = settings.section_padding || 80;
            jQuery('#setting-section-padding').val(sp);
            jQuery('#section-padding-val').text(sp + 'px');
            const eg = settings.element_gap || 24;
            jQuery('#setting-element-gap').val(eg);
            jQuery('#element-gap-val').text(eg + 'px');
            const ws = settings.widgets_spacing || 20;
            jQuery('#setting-widgets-spacing').val(ws);
            jQuery('#widgets-spacing-val').text(ws + 'px');
            const br = settings.border_radius || 8;
            jQuery('#setting-border-radius').val(br);
            jQuery('#border-radius-val').text(br + 'px');
            jQuery('#setting-border-width').val(settings.border_width || '1');
            setColor('setting-border-color', settings.border_color || '#e4e4e7');
            jQuery('#setting-box-shadow').val(settings.box_shadow || '0 1px 3px rgba(0,0,0,0.06)');

            // Layout
            jQuery('#setting-header-footer-mode').val(settings.header_footer_mode || 'elementor_full_control');
            jQuery('#setting-header-layout').val(settings.header_layout || 'Logo Left');
            jQuery('#setting-nav-menu').val(settings.nav_menu || '0');
            jQuery('#setting-sticky-header').prop('checked', settings.sticky_header == 1);
            jQuery('#setting-transparent-header').prop('checked', settings.transparent_header == 1);
            setColor('setting-header-bg',         settings.header_bg         || '#ffffff');
            setColor('setting-header-text-color',  settings.header_text_color || '#18181b');
            jQuery('#setting-footer-columns').val(settings.footer_columns || '3');
            jQuery('#setting-copyright-text').val(settings.copyright_text || '');
            jQuery('#setting-show-socials').prop('checked', settings.show_socials == 1);
            setColor('setting-footer-bg',          settings.footer_bg         || '#18181b');
            setColor('setting-footer-text-color',  settings.footer_text_color || '#a1a1aa');
            jQuery('#setting-page-width').val(settings.page_width || 'boxed');
            jQuery('#setting-smooth-scroll').prop('checked', settings.smooth_scroll !== 0);
            jQuery('#setting-template-header').val((settings.templates && settings.templates.header) ? settings.templates.header : '0');
            jQuery('#setting-template-footer').val((settings.templates && settings.templates.footer) ? settings.templates.footer : '0');

            // Social & SEO
            jQuery('#setting-facebook-link').val(settings.facebook_link  || '');
            jQuery('#setting-twitter-link').val(settings.twitter_link    || '');
            jQuery('#setting-instagram-link').val(settings.instagram_link || '');
            jQuery('#setting-linkedin-link').val(settings.linkedin_link  || '');
            jQuery('#setting-youtube-link').val(settings.youtube_link    || '');
            jQuery('#setting-tiktok-link').val(settings.tiktok_link      || '');
            jQuery('#setting-ga4-id').val(settings.ga4_id     || '');
            jQuery('#setting-gtm-id').val(settings.gtm_id     || '');
            jQuery('#setting-fb-pixel').val(settings.fb_pixel  || '');
            jQuery('#setting-robots').val(settings.robots      || 'index,follow');
            jQuery('#setting-sitemap-enable').prop('checked', settings.sitemap_enable !== 0);

            // Elementor panel
            setColor('setting-el-primary',   settings.el_primary   || settings.primary_color   || '#18181b');
            setColor('setting-el-secondary',  settings.el_secondary || settings.secondary_color  || '#27272a');
            setColor('setting-el-text',       settings.el_text      || settings.text_color       || '#09090b');
            setColor('setting-el-accent',     settings.el_accent    || settings.accent_color     || '#10b981');
            const hf = settings.heading_font || 'Inter';
            const bf = settings.body_font    || 'Inter';
            jQuery('#setting-el-type-primary-family').val(settings.el_type_primary_family     || hf);
            jQuery('#setting-el-type-primary-weight').val(settings.el_type_primary_weight     || 700);
            jQuery('#setting-el-type-secondary-family').val(settings.el_type_secondary_family || hf);
            jQuery('#setting-el-type-secondary-weight').val(settings.el_type_secondary_weight || 600);
            jQuery('#setting-el-type-text-family').val(settings.el_type_text_family           || bf);
            jQuery('#setting-el-type-text-weight').val(settings.el_type_text_weight           || 400);
            jQuery('#setting-el-type-accent-family').val(settings.el_type_accent_family       || hf);
            jQuery('#setting-el-type-accent-weight').val(settings.el_type_accent_weight       || 600);

            // Lovable tokens panel
            jQuery('#setting-css-prefix').val(settings.css_prefix || '--');
            jQuery('#setting-dark-tokens').prop('checked', settings.dark_tokens == 1);

            // Show/hide context-specific tabs
            showSettingsPanelForThemeType();




            // Load custom code rules into all four injection editors
            initCodeEditors(settings);



            // Populate Lovable Studio inputs with theme settings (if applicable)
            if (!canvasState.activeThemeIsElementor) {
                jQuery('#ls-repo-url').val(settings.github_repo || '');
                jQuery('#ls-repo-branch').val(settings.github_branch || 'main');
                jQuery('#ls-repo-token').val(settings.lovable_pat || '');
                jQuery('#ls-preview-btn').attr('href', coraREData.siteUrl + '/?cv_preview_theme=' + themeId);
            }
        }
    }

    function saveThemeSettings() {
        if (canvasState.isReadOnly) return;
        
        const payload = {
            // Identity
            site_title:        jQuery('#setting-site-title').val().trim(),
            site_tagline:      jQuery('#setting-site-tagline').val().trim(),
            site_description:  jQuery('#setting-site-description').val().trim(),
            site_favicon:      jQuery('#setting-site-favicon').val().trim(),
            site_logo:         jQuery('#setting-site-logo').val().trim(),
            site_logo_dark:    jQuery('#setting-site-logo-dark').val().trim(),
            og_image:          jQuery('#setting-og-image').val().trim(),
            title_format:      jQuery('#setting-title-format').val().trim(),
            // Typography
            heading_font:      jQuery('#setting-heading-font').val(),
            body_font:         jQuery('#setting-body-font').val(),
            accent_font:       jQuery('#setting-accent-font').val(),
            base_font_size:    jQuery('#setting-font-size').val(),
            gfonts_key:        jQuery('#setting-gfonts-key').val().trim(),
            // Type scale
            type_h1_size:      jQuery('#setting-type-h1-size').val(),
            type_h1_weight:    jQuery('#setting-type-h1-weight').val(),
            type_h1_lh:        jQuery('#setting-type-h1-lh').val(),
            type_h1_ls:        jQuery('#setting-type-h1-ls').val(),
            type_h2_size:      jQuery('#setting-type-h2-size').val(),
            type_h2_weight:    jQuery('#setting-type-h2-weight').val(),
            type_h2_lh:        jQuery('#setting-type-h2-lh').val(),
            type_h2_ls:        jQuery('#setting-type-h2-ls').val(),
            type_h3_size:      jQuery('#setting-type-h3-size').val(),
            type_h3_weight:    jQuery('#setting-type-h3-weight').val(),
            type_h3_lh:        jQuery('#setting-type-h3-lh').val(),
            type_h3_ls:        jQuery('#setting-type-h3-ls').val(),
            type_body_size:    jQuery('#setting-type-body-size').val(),
            type_body_weight:  jQuery('#setting-type-body-weight').val(),
            type_body_lh:      jQuery('#setting-type-body-lh').val(),
            type_body_ls:      jQuery('#setting-type-body-ls').val(),
            type_small_size:   jQuery('#setting-type-small-size').val(),
            type_small_weight: jQuery('#setting-type-small-weight').val(),
            type_small_lh:     jQuery('#setting-type-small-lh').val(),
            type_small_ls:     jQuery('#setting-type-small-ls').val(),
            type_btn_size:     jQuery('#setting-type-btn-size').val(),
            type_btn_weight:   jQuery('#setting-type-btn-weight').val(),
            type_btn_lh:       jQuery('#setting-type-btn-lh').val(),
            type_btn_ls:       jQuery('#setting-type-btn-ls').val(),
            // Core colors
            primary_color:     jQuery('#setting-color-primary').val(),
            secondary_color:   jQuery('#setting-color-secondary').val(),
            accent_color:      jQuery('#setting-color-accent').val(),
            text_color:        jQuery('#setting-color-text').val(),
            bg_color:          jQuery('#setting-color-bg').val(),
            surface_color:     jQuery('#setting-color-surface').val(),
            // Semantic colors
            success_color:     jQuery('#setting-color-success').val(),
            warning_color:     jQuery('#setting-color-warning').val(),
            danger_color:      jQuery('#setting-color-danger').val(),
            info_color:        jQuery('#setting-color-info').val(),
            // Button colors
            btn_bg:            jQuery('#setting-color-btn-bg').val(),
            btn_text:          jQuery('#setting-color-btn-text').val(),
            btn_hover_bg:      jQuery('#setting-color-btn-hover').val(),
            // Spacing
            container_width:   jQuery('#setting-container-width').val(),
            section_padding:   jQuery('#setting-section-padding').val(),
            element_gap:       jQuery('#setting-element-gap').val(),
            widgets_spacing:   jQuery('#setting-widgets-spacing').val(),
            border_radius:     jQuery('#setting-border-radius').val(),
            border_width:      jQuery('#setting-border-width').val(),
            border_color:      jQuery('#setting-border-color').val(),
            box_shadow:        jQuery('#setting-box-shadow').val(),
            // Layout
            header_footer_mode: jQuery('#setting-header-footer-mode').val(),
            header_layout:     jQuery('#setting-header-layout').val(),
            nav_menu:          jQuery('#setting-nav-menu').val(),
            sticky_header:     jQuery('#setting-sticky-header').is(':checked') ? 1 : 0,
            transparent_header: jQuery('#setting-transparent-header').is(':checked') ? 1 : 0,
            header_bg:         jQuery('#setting-header-bg').val(),
            header_text_color: jQuery('#setting-header-text-color').val(),
            footer_columns:    jQuery('#setting-footer-columns').val(),
            copyright_text:    jQuery('#setting-copyright-text').val().trim(),
            show_socials:      jQuery('#setting-show-socials').is(':checked') ? 1 : 0,
            footer_bg:         jQuery('#setting-footer-bg').val(),
            footer_text_color: jQuery('#setting-footer-text-color').val(),
            page_width:        jQuery('#setting-page-width').val(),
            smooth_scroll:     jQuery('#setting-smooth-scroll').is(':checked') ? 1 : 0,
            // Social & SEO
            facebook_link:     jQuery('#setting-facebook-link').val().trim(),
            twitter_link:      jQuery('#setting-twitter-link').val().trim(),
            instagram_link:    jQuery('#setting-instagram-link').val().trim(),
            linkedin_link:     jQuery('#setting-linkedin-link').val().trim(),
            youtube_link:      jQuery('#setting-youtube-link').val().trim(),
            tiktok_link:       jQuery('#setting-tiktok-link').val().trim(),
            ga4_id:            jQuery('#setting-ga4-id').val().trim(),
            gtm_id:            jQuery('#setting-gtm-id').val().trim(),
            fb_pixel:          jQuery('#setting-fb-pixel').val().trim(),
            robots:            jQuery('#setting-robots').val(),
            sitemap_enable:    jQuery('#setting-sitemap-enable').is(':checked') ? 1 : 0,
            // Elementor
            el_primary:        jQuery('#setting-el-primary').val(),
            el_secondary:      jQuery('#setting-el-secondary').val(),
            el_text:           jQuery('#setting-el-text').val(),
            el_accent:         jQuery('#setting-el-accent').val(),
            el_type_primary_family:   jQuery('#setting-el-type-primary-family').val(),
            el_type_primary_weight:   jQuery('#setting-el-type-primary-weight').val(),
            el_type_secondary_family: jQuery('#setting-el-type-secondary-family').val(),
            el_type_secondary_weight: jQuery('#setting-el-type-secondary-weight').val(),
            el_type_text_family:      jQuery('#setting-el-type-text-family').val(),
            el_type_text_weight:      jQuery('#setting-el-type-text-weight').val(),
            el_type_accent_family:    jQuery('#setting-el-type-accent-family').val(),
            el_type_accent_weight:    jQuery('#setting-el-type-accent-weight').val(),
            // Lovable
            css_prefix:        jQuery('#setting-css-prefix').val() || '--',
            dark_tokens:       jQuery('#setting-dark-tokens').is(':checked') ? 1 : 0,
            // Page Mapping
            homepage_page_id:  jQuery('#setting-homepage-page-id').val(),
            contact_page_id:   jQuery('#setting-contact-page-id').val(),
            templates: {
                header: jQuery('#setting-template-header').val(),
                footer: jQuery('#setting-template-footer').val()
            }
        };

        window.coraShowToast('Saving global design system settings...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_theme_settings',
            theme_id: canvasState.activeThemeId,
            settings: payload,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                // Merge the payload back into local theme state (preserving source, menus, etc.)
                const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
                if (themeObj) {
                    const existing = safeGetSettings(themeObj);
                    themeObj.settings = Object.assign({}, existing, payload);
                }
                window.coraShowToast('Settings saved and synced to your theme engine.');
                // Refresh pages list to reflect any modified homepage/mapping configurations
                fetchThemePages(canvasState.activeThemeId);
                // Refresh the Lovable token preview if on that panel
                refreshTokenPreview();
            } else {
                window.coraShowToast('Failed to save settings. Please retry.');
            }
        });
    }

    // --- Tab 3 Settings Helper Functions ---

    function switchSettingsPanel(panelId) {
        // Deactivate all pills
        jQuery('.settings-pill').removeClass('active border-zinc-950 text-zinc-900').addClass('border-transparent text-zinc-400');
        jQuery('#spill-' + panelId).addClass('active border-zinc-950 text-zinc-900').removeClass('border-transparent text-zinc-400');
        // Hide all panels
        jQuery('.settings-panel').addClass('hidden');
        jQuery('#spanel-' + panelId).removeClass('hidden');
    }

    function syncColorPicker(inputId, hexValue) {
        // Sync text input → color swatch
        if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(hexValue)) {
            jQuery('#' + inputId).val(hexValue);
        }
    }

    function selectRadiusPreset(value, btn) {
        jQuery('.radius-preset-btn').removeClass('border-zinc-950 text-zinc-950').addClass('border-zinc-200 text-zinc-600');
        jQuery(btn).addClass('border-zinc-950 text-zinc-950').removeClass('border-zinc-200 text-zinc-600');
        const pxVal = parseInt(value) || 0;
        jQuery('#setting-border-radius').val(pxVal);
        jQuery('#border-radius-val').text(pxVal + 'px');
    }

    function openMediaPicker(targetInputId) {
        if (typeof wp !== 'undefined' && wp.media) {
            var frame = wp.media({
                title: 'Select or Upload Image',
                button: { text: 'Use this image' },
                multiple: false
            });
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                jQuery('#' + targetInputId).val(attachment.url);
            });
            frame.open();
        } else {
            window.coraShowToast('WordPress Media Library not available. Paste URL directly.');
        }
    }

    function triggerElementorSync() {
        window.coraShowToast('Syncing to Elementor Global Settings...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_sync_elementor_globals',
            theme_id: canvasState.activeThemeId,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const ts = new Date(res.data.synced_at).toLocaleTimeString();
                jQuery('#elementor-last-sync').text(ts);
                jQuery('#spill-elementor .w-1\\.5').removeClass('bg-red-500').addClass('bg-green-500');
                window.coraShowToast('Elementor Global Colors & Typography updated. Reload any open Elementor editor to see changes.');
            } else {
                window.coraShowToast('Elementor sync failed. Check that Elementor is active and an active kit exists.');
            }
        });
    }

    function triggerLovableTokenSync() {
        window.coraShowToast('Generating and pushing CSS tokens to frontend...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_sync_lovable_tokens',
            theme_id: canvasState.activeThemeId,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const ts = new Date(res.data.synced_at).toLocaleTimeString();
                jQuery('#lovable-token-path').text('cora-global-tokens.css (last pushed ' + ts + ')');
                window.coraShowToast('CSS tokens pushed to frontend. All pages updated instantly.');
                refreshTokenPreview();
            } else {
                window.coraShowToast('Token push failed. Check upload directory permissions.');
            }
        });
    }

    function refreshTokenPreview() {
        const el = document.getElementById('lovable-token-preview');
        if (!el) return;
        const s = (function() {
            const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
            return themeObj ? safeGetSettings(themeObj) : {};
        })();
        const prefix = jQuery('#setting-css-prefix').val() || '--';
        const tokens = {
            [`${prefix}color-primary`]:    jQuery('#setting-color-primary').val()   || s.primary_color   || '#18181b',
            [`${prefix}color-secondary`]:  jQuery('#setting-color-secondary').val() || s.secondary_color  || '#27272a',
            [`${prefix}color-accent`]:     jQuery('#setting-color-accent').val()    || s.accent_color     || '#10b981',
            [`${prefix}color-text`]:       jQuery('#setting-color-text').val()      || s.text_color       || '#09090b',
            [`${prefix}color-background`]: jQuery('#setting-color-bg').val()        || s.bg_color         || '#ffffff',
            [`${prefix}color-surface`]:    jQuery('#setting-color-surface').val()   || s.surface_color    || '#f4f4f5',
            [`${prefix}color-success`]:    jQuery('#setting-color-success').val()   || s.success_color    || '#16a34a',
            [`${prefix}color-warning`]:    jQuery('#setting-color-warning').val()   || s.warning_color    || '#d97706',
            [`${prefix}color-danger`]:     jQuery('#setting-color-danger').val()    || s.danger_color     || '#dc2626',
            [`${prefix}heading-font`]:     `'${jQuery('#setting-heading-font').val() || s.heading_font || 'Inter'}', sans-serif`,
            [`${prefix}body-font`]:        `'${jQuery('#setting-body-font').val()    || s.body_font    || 'Inter'}', sans-serif`,
            [`${prefix}base-font-size`]:   (jQuery('#setting-font-size').val()      || s.base_font_size || 16) + 'px',
            [`${prefix}container-width`]:  (jQuery('#setting-container-width').val()|| s.container_width || 1280) + 'px',
            [`${prefix}border-radius`]:    (jQuery('#setting-border-radius').val()  || s.border_radius   || 8) + 'px',
            [`${prefix}box-shadow`]:       jQuery('#setting-box-shadow').val()      || s.box_shadow      || 'none',
        };
        let css = ':root {\n';
        for (const [k, v] of Object.entries(tokens)) css += `  ${k}: ${v};\n`;
        css += '}';
        el.textContent = css;
    }

    function showSettingsPanelForThemeType() {
        if (canvasState.activeThemeIsElementor) {
            jQuery('#spill-elementor-wrap').removeClass('hidden');
            jQuery('#spill-lovable-wrap').addClass('hidden');
        } else {
            jQuery('#spill-lovable-wrap').removeClass('hidden');
            jQuery('#spill-elementor-wrap').addClass('hidden');
        }
    }

    // --- Tab 4 Custom Code Editor Functions ---
    function openThemeSettingsDrawer() {
        editTheme(canvasState.activeThemeId, canvasState.activeThemeName, canvasState.activeThemeIsLive);
        switchTab('settings');
    }

    // ── Code section nav switcher ──────────────────────────────────
    var activeCodeSection = 'css';
    function switchCodeSection(sectionId) {
        activeCodeSection = sectionId;
        jQuery('.code-nav-btn').removeClass('bg-white shadow-sm border-zinc-200 text-zinc-900')
            .addClass('border-transparent text-zinc-500');
        jQuery('#code-nav-' + sectionId).addClass('bg-white shadow-sm border-zinc-200 text-zinc-900')
            .removeClass('border-transparent text-zinc-500');
        jQuery('.code-section').addClass('hidden');
        jQuery('#code-section-' + sectionId).removeClass('hidden');
        if (sectionId === 'css'  && canvasState.cssEditor)  { try { canvasState.cssEditor.refresh();  } catch(e){} }
        if (sectionId === 'js'   && canvasState.jsEditor)   { try { canvasState.jsEditor.refresh();   } catch(e){} }
        if (sectionId === 'head' && canvasState.headEditor) { try { canvasState.headEditor.refresh();  } catch(e){} }
        if (sectionId === 'body' && canvasState.bodyEditor) { try { canvasState.bodyEditor.refresh();  } catch(e){} }
    }

    // ── CodeMirror initialisation ──────────────────────────────────
    function initCodeEditors(settings) {
        const s = settings || {};
        function makeEditor(mountId, mode, initialVal, statsId) {
            const mount = document.getElementById(mountId);
            if (!mount) return null;
            if (mount._cmInstance) { mount._cmInstance.setValue(initialVal || ''); return mount._cmInstance; }
            const CM = (typeof CodeMirror !== 'undefined') ? CodeMirror : (typeof wp !== 'undefined' && wp.CodeMirror ? wp.CodeMirror : null);
            if (CM) {
                const cm = CM(mount, {
                    value: initialVal || '',
                    mode: mode,
                    theme: 'default',
                    lineNumbers: true,
                    lineWrapping: true,
                    indentUnit: 2,
                    tabSize: 2,
                    indentWithTabs: false,
                    extraKeys: {
                        'Ctrl-S': function() { triggerSaveForSection(activeCodeSection); },
                        'Cmd-S':  function() { triggerSaveForSection(activeCodeSection); }
                    }
                });
                cm.setSize('100%', '100%');
                if (statsId) cm.on('change', function() { updateCodeStats(cm, statsId); markCodeUnsaved(); });
                updateCodeStats(cm, statsId);
                mount._cmInstance = cm;
                return cm;
            } else {
                mount.innerHTML = '';
                const ta = document.createElement('textarea');
                ta.value = initialVal || '';
                ta.style.cssText = 'width:100%;height:100%;padding:12px;font-family:monospace;font-size:12px;border:none;outline:none;resize:none;background:#18181b;color:#d4d4d8;';
                mount.style.background = '#18181b';
                mount.appendChild(ta);
                const wrapper = {
                    getValue: () => ta.value,
                    setValue: (v) => { ta.value = v; },
                    refresh: () => {},
                    replaceSelection: (v) => { ta.value += v; }
                };
                ta.addEventListener('input', function() {
                    if (statsId) jQuery('#' + statsId).text(ta.value.split('\n').length + ' lines \xb7 ' + ta.value.length + ' chars');
                    markCodeUnsaved();
                });
                mount._cmInstance = wrapper;
                return wrapper;
            }
        }
        canvasState.cssEditor  = makeEditor('css-editor-mount',  'css',        s.custom_css  || '', 'css-stats');
        canvasState.jsEditor   = makeEditor('js-editor-mount',   'javascript', s.custom_js   || '', 'js-stats');
        canvasState.headEditor = makeEditor('head-editor-mount', 'htmlmixed',  s.custom_head || '', 'head-stats');
        canvasState.bodyEditor = makeEditor('body-editor-mount', 'htmlmixed',  s.custom_body || '', 'body-stats');
        if (s.custom_js_position) jQuery('#setting-js-position').val(s.custom_js_position);
    }

    function updateCodeStats(cm, statsId) {
        if (!statsId) return;
        const val = cm.getValue();
        jQuery('#' + statsId).text(val.split('\n').length + ' lines \xb7 ' + val.length + ' chars');
    }

    var codeUnsaved = false;
    function markCodeUnsaved() {
        codeUnsaved = true;
        jQuery('#code-save-dot').css('background', '#f59e0b');
        jQuery('#code-save-status').text('Unsaved changes');
    }
    function markCodeSaved() {
        codeUnsaved = false;
        const now = new Date();
        jQuery('#code-save-dot').css('background', '#22c55e');
        jQuery('#code-save-status').text('Saved ' + now.getHours() + ':' + String(now.getMinutes()).padStart(2,'0'));
        setTimeout(() => { jQuery('#code-save-dot').css('background','#d4d4d8'); jQuery('#code-save-status').text('No changes'); }, 4000);
    }

    function triggerSaveForSection(sectionId) {
        if      (sectionId === 'css')  saveCustomCSS();
        else if (sectionId === 'js')   saveCustomJS();
        else if (sectionId === 'head') saveHeadHTML();
        else if (sectionId === 'body') saveBodyHTML();
    }

    jQuery(document).on('keydown.coraCode', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 's' && canvasState.activeTab === 'code') {
            e.preventDefault();
            triggerSaveForSection(activeCodeSection);
        }
    });

    // ── Save: CSS ──────────────────────────────────────────────────
    function saveCustomCSS() {
        if (canvasState.isReadOnly) return;
        const cssVal = canvasState.cssEditor ? canvasState.cssEditor.getValue() : jQuery('#custom-css-textarea').val();
        window.coraShowToast('Compiling custom CSS rules...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_custom_css',
            theme_id: canvasState.activeThemeId,
            css: cssVal,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
                if (themeObj) { const st = safeGetSettings(themeObj); st.custom_css=cssVal; themeObj.settings=st; }
                markCodeSaved(); window.coraShowToast('Custom CSS compiled and live.');
            } else { window.coraShowToast('Failed to compile CSS.'); }
        });
    }

    // ── Save: JS ───────────────────────────────────────────────────
    function saveCustomJS() {
        if (canvasState.isReadOnly) return;
        const jsVal = canvasState.jsEditor ? canvasState.jsEditor.getValue() : jQuery('#custom-js-textarea').val();
        const pos = jQuery('#setting-js-position').val();
        window.coraShowToast('Injecting scripts...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_custom_js',
            theme_id: canvasState.activeThemeId,
            js: jsVal, position: pos,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
                if (themeObj) { const st = safeGetSettings(themeObj); st.custom_js=jsVal; st.custom_js_position=pos; themeObj.settings=st; }
                markCodeSaved(); window.coraShowToast('JavaScript injection updated.');
            } else { window.coraShowToast('Failed to save JavaScript.'); }
        });
    }

    // ── Save: Head HTML ────────────────────────────────────────────
    function saveHeadHTML() {
        if (canvasState.isReadOnly) return;
        const val = canvasState.headEditor ? canvasState.headEditor.getValue() : '';
        window.coraShowToast('Saving head injection...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_custom_head',
            theme_id: canvasState.activeThemeId,
            head_html: val,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
                if (themeObj) { const st = safeGetSettings(themeObj); st.custom_head=val; themeObj.settings=st; }
                markCodeSaved(); window.coraShowToast('Head HTML injection saved.');
            } else { window.coraShowToast('Failed to save head injection.'); }
        });
    }

    // ── Save: Body HTML ────────────────────────────────────────────
    function saveBodyHTML() {
        if (canvasState.isReadOnly) return;
        const val = canvasState.bodyEditor ? canvasState.bodyEditor.getValue() : '';
        window.coraShowToast('Saving body injection...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_custom_body',
            theme_id: canvasState.activeThemeId,
            body_html: val,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                const themeObj = canvasState.themes.find(t => t.id == canvasState.activeThemeId);
                if (themeObj) { const st = safeGetSettings(themeObj); st.custom_body=val; themeObj.settings=st; }
                markCodeSaved(); window.coraShowToast('Body script injection saved.');
            } else { window.coraShowToast('Failed to save body injection.'); }
        });
    }

    // ── Snippet insertion helpers ──────────────────────────────────
    function insertSnippet(cat, code) {
        const map = { 'CSS': 'cssEditor', 'JS': 'jsEditor', 'HTML': 'headEditor' };
        const ed = canvasState[map[cat] || 'headEditor'];
        if (!ed) return;
        if (ed.replaceSelection) ed.replaceSelection(code);
        else ed.setValue(ed.getValue() + '\n' + code);
        markCodeUnsaved();
        const secMap = { 'CSS': 'css', 'JS': 'js', 'HTML': 'head' };
        switchCodeSection(secMap[cat] || 'head');
        window.coraShowToast('Snippet inserted — review and save.');
    }
    function insertHeadSnippet(code) {
        const ed = canvasState.headEditor;
        if (!ed) return;
        if (ed.replaceSelection) ed.replaceSelection(code); else ed.setValue(ed.getValue() + '\n' + code);
        markCodeUnsaved();
    }
    function insertBodySnippet(code) {
        const ed = canvasState.bodyEditor;
        if (!ed) return;
        if (ed.replaceSelection) ed.replaceSelection(code); else ed.setValue(ed.getValue() + '\n' + code);
        markCodeUnsaved();
    }

    // --- LEVEL 3 Elementor & HTML Page Editor Wrapper ---
    function openPageEditor(pageId, title, wpPostId, pageStatus, pageSlug) {
        // Detect if this page was created via HTML Canvas Engine
        const targetPage = canvasState.pages.find(p => p.id == pageId);
        if (targetPage && (targetPage.page_engine === 'html_canvas' || targetPage.page_engine === 'html')) {
            openHtmlVisualEditor(pageId, title, wpPostId, pageStatus, pageSlug);
            return;
        }

        if (!canvasState.activeThemeIsElementor) {
            openEditPageSettingsDrawer(pageId, title, pageStatus, pageSlug);
            return;
        }

        canvasState.level = 3;
        canvasState.activePageId = pageId;
        canvasState.activeEditorEngine = 'elementor';
        canvasState.activePageStatus = pageStatus || 'draft';
        canvasState.activePageSlug   = pageSlug   || '';
        syncStateToUrl();

        // Auto-sync global settings to Elementor active kit in background before loading editor
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_sync_elementor_globals',
            theme_id: canvasState.activeThemeId,
            nonce: coraREData.ajaxNonce
        });

        // Show custom topbar and update context names
        jQuery('#cora-parent-editor-topbar').removeClass('hidden');
        jQuery('#cora-topbar-theme-name').text(canvasState.activeThemeName);
        jQuery('#cora-topbar-page-name').text(title);
        jQuery('#cora-topbar-page-selector').text(title);

        // Update Theme Status Badge
        const isThemeLive = canvasState.activeThemeIsLive === true || canvasState.activeThemeIsLive == 1 || canvasState.activeThemeIsLive == '1';
        const badge = jQuery('#cora-topbar-theme-status-badge');
        if (isThemeLive) {
            badge.text('Live').removeClass().addClass('ml-1.5 px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider select-none bg-zinc-900 text-white ');
        } else {
            badge.text('Draft').removeClass().addClass('ml-1.5 px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wider select-none bg-zinc-200 text-zinc-700 ');
        }

        // Open Level-3 isolated fullscreen editor overlay
        jQuery('#canvas-level-3').removeClass('hidden');
        jQuery('#iframe-loader').removeClass('hidden');
        jQuery('#elementor-editor-iframe').addClass('hidden');
        jQuery('#elementor-blocking-msg').addClass('hidden');

        // Check if wpPostId is valid; if 0 or missing, provision via AJAX first
        if (!wpPostId || wpPostId == 0 || wpPostId == '0' || wpPostId == 'null' || wpPostId == 'undefined') {
            jQuery.post(coraREData.ajaxUrl, {
                action: 'cora_ajax_ensure_wp_post',
                page_id: pageId,
                theme_id: canvasState.activeThemeId,
                title: title,
                slug: pageSlug,
                nonce: coraREData.ajaxNonce
            }, function(res) {
                if (res && res.success && res.data && res.data.wp_post_id) {
                    canvasState.activeWpPostId = res.data.wp_post_id;
                    if (res.data.page_id) canvasState.activePageId = res.data.page_id;
                    executeOpenPageEditor(canvasState.activeWpPostId, title);
                } else {
                    jQuery('#iframe-loader').addClass('hidden');
                    jQuery('#elementor-blocking-title').text('Page Post Provisioning Error');
                    jQuery('#elementor-blocking-desc').html((res && res.data && res.data.message) ? res.data.message : 'Could not initialize WordPress page post. Launch direct editor to verify page state.');
                    jQuery('#elementor-blocking-msg').removeClass('hidden');
                    if (typeof window.coraShowToast === 'function') {
                        window.coraShowToast('Could not provision WordPress page post.', 'error');
                    }
                }
            }).fail(function() {
                jQuery('#iframe-loader').addClass('hidden');
                jQuery('#elementor-blocking-title').text('Page Provisioning Error');
                jQuery('#elementor-blocking-desc').html('Server connection failed while initializing page post.');
                jQuery('#elementor-blocking-msg').removeClass('hidden');
            });
            return;
        }

        canvasState.activeWpPostId = wpPostId;
        executeOpenPageEditor(wpPostId, title);
    // }

    function executeOpenPageEditor(wpPostId, title) {
        const elementorUrl = coraREData.siteUrl + '/wp-admin/post.php?post=' + wpPostId + '&action=elementor';
        jQuery('#cora-direct-elementor-btn').attr('href', elementorUrl);
        jQuery('#cora-direct-elementor-card-btn').attr('href', elementorUrl);
        
        // Load target frame URL (avoid double-load on refresh by checking current src)
        const currentSrc = jQuery('#elementor-editor-iframe').attr('src');
        if (currentSrc !== elementorUrl) {
            jQuery('#elementor-editor-iframe').attr('src', elementorUrl);
        }
        jQuery('#elementor-editor-iframe').off('load').on('load', function() {
            jQuery('#iframe-loader').addClass('hidden');
            jQuery('#elementor-blocking-msg').addClass('hidden'); // Explicitly hide blocking panel on successful load
            jQuery('#elementor-editor-iframe').removeClass('hidden');

            // Defensive error observer: check if Elementor threw actual visible 403 or preview error or redirected to WP Admin shell
            const iframe = this;
            const checkIframeError = function() {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    if (iframeDoc && iframeDoc.body) {
                        const bodyText = (iframeDoc.body.innerText || '').toLowerCase();
                        const isRealErrorPage = (bodyText.includes('the preview could not be loaded') && bodyText.includes('403')) || 
                                               (bodyText.includes('error 403') && bodyText.includes('forbidden')) ||
                                               (bodyText.includes('sorry, you are not allowed to edit this item'));
                        
                        // Check for VISIBLE error dialogs only (not hidden template wrappers)
                        let visibleErrorDialog = false;
                        const errorDialogs = iframeDoc.querySelectorAll('.elementor-dialog-type-alert, .elementor-error-dialog, #elementor-preview-debug-area');
                        errorDialogs.forEach(function(d) {
                            if (d && (d.offsetWidth > 0 || d.offsetHeight > 0 || (d.style && d.style.display !== 'none' && window.getComputedStyle(d).display !== 'none'))) {
                                const alertText = (d.innerText || '').toLowerCase();
                                if (alertText.includes('error') || alertText.includes('failed') || alertText.includes('blocked') || alertText.includes('could not be loaded')) {
                                    visibleErrorDialog = true;
                                }
                            }
                        });

                        let isWpAdminShell = false;
                        try {
                            const iframeHref = (iframe.contentWindow && iframe.contentWindow.location.href) ? iframe.contentWindow.location.href : '';
                            isWpAdminShell = (iframeDoc.querySelector('#adminmenu') !== null && !iframeHref.includes('action=elementor')) || 
                                             iframeHref.includes('/wp-admin/edit.php') || 
                                             (iframeHref.includes('/wp-admin/index.php') && !iframeHref.includes('action=elementor'));
                        } catch(err) {}

                        if (isRealErrorPage || visibleErrorDialog || isWpAdminShell) {
                            jQuery('#elementor-editor-iframe').addClass('hidden');
                            jQuery('#iframe-loader').addClass('hidden');
                            if (isWpAdminShell) {
                                jQuery('#elementor-blocking-title').text('WordPress Admin Redirect Intercepted');
                                jQuery('#elementor-blocking-desc').html('WordPress redirected this page request to the admin dashboard instead of opening the Elementor builder canvas.<br><span class="font-semibold text-zinc-800">Launch direct editor in a new tab to edit this page seamlessly.</span>');
                            } else {
                                jQuery('#elementor-blocking-title').text('Preview Security Blocked (HTTP 403)');
                                jQuery('#elementor-blocking-desc').html('Browser security or session timeout prevented embedding the editor in this window.<br><span class="font-semibold text-zinc-800">Launch direct editor in a new tab to continue seamlessly.</span>');
                            }
                            jQuery('#elementor-blocking-msg').removeClass('hidden');
                            if (typeof window.coraShowToast === 'function') {
                                window.coraShowToast(isWpAdminShell ? 'Admin dashboard redirect intercepted. Use "Launch Direct Editor".' : 'Editor preview blocked by browser security. Use "Launch Direct Editor".', 'warning');
                            }
                        } else {
                            // Editor loaded cleanly
                            jQuery('#elementor-blocking-msg').addClass('hidden');
                            jQuery('#elementor-editor-iframe').removeClass('hidden');
                        }
                    }
                } catch (e) {
                    // Cross-origin restrictions or normal load
                }
            };
            setTimeout(checkIframeError, 1200);
            setTimeout(checkIframeError, 3500);
        });
    }

        // Set timeout to handle offline/inactive blocking message if Elementor can't load (extend to 25s for slow servers)
        setTimeout(function() {
            if (!jQuery('#iframe-loader').hasClass('hidden') && jQuery('#elementor-editor-iframe').hasClass('hidden')) {
                jQuery('#iframe-loader').addClass('hidden');
                jQuery('#elementor-blocking-msg').removeClass('hidden');
            }
        }, 25000);
        syncStateToUrl();
    }

    function closeElementorEditor() {
        canvasState.level = 2;
        canvasState.activePageId = null;
        jQuery('#elementor-editor-iframe').attr('src', '');
        jQuery('#cora-parent-editor-topbar').addClass('hidden');
        
        jQuery('#canvas-level-3').addClass('hidden');
        if (canvasState.activeThemeId) {
            fetchThemePages(canvasState.activeThemeId);
        }
        syncStateToUrl();
    }

    // ═══ LEVEL 3-HTML: CORA AI VISUAL NO-CODE HTML CANVAS CONTROLLER ══════════════
    window.htmlEditorState = {
        activePageId: null,
        wpPostId: null,
        title: '',
        slug: '',
        status: 'draft',
        viewport: 'desktop',
        activeElement: null,
        activeNodeId: null,
        nodes: {},
        aiInsights: {}
    };

    function openHtmlVisualEditor(pageId, title, wpPostId, pageStatus, pageSlug) {
        canvasState.level = 3;
        canvasState.activePageId = pageId;
        canvasState.activeEditorEngine = 'html';

        htmlEditorState.activePageId = pageId;
        htmlEditorState.wpPostId = wpPostId;
        htmlEditorState.title = title;
        htmlEditorState.slug = pageSlug;
        htmlEditorState.status = pageStatus || 'draft';

        // Update Topbar
        jQuery('#cora-html-topbar-theme').text(canvasState.activeThemeName || 'Theme');
        jQuery('#cora-html-topbar-page').text(title);
        jQuery('#cora-html-status-pill').text((pageStatus === 'published' || pageStatus === 'publish') ? 'Live' : 'Draft')
            .removeClass('bg-zinc-100 text-zinc-700 bg-zinc-900 text-white')
            .addClass((pageStatus === 'published' || pageStatus === 'publish') ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-700');

        // External Preview URL
        const previewUrl = `/site/${pageSlug ? pageSlug : ''}?cv_preview_theme=${canvasState.activeThemeId || ''}`;
        jQuery('#cora-html-preview-ext-btn').attr('href', previewUrl);

        // Show Editor Overlay
        jQuery('#canvas-level-3-html').removeClass('hidden');
        jQuery('#cora-html-editor-loader').removeClass('hidden');
        syncStateToUrl();

        // Load Page HTML & Nodes
        jQuery.ajax({
            url: coraREData.ajaxUrl,
            type: 'GET',
            data: {
                action: 'cora_ajax_get_html_page_data',
                page_id: pageId,
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                jQuery('#cora-html-editor-loader').addClass('hidden');
                if (res && res.success && res.data) {
                    const html = res.data.compiled_html || '';
                    htmlEditorState.nodes = res.data.nodes || {};
                    htmlEditorState.aiInsights = res.data.ai_insights || {};
                    
                    setRawHtmlInEditor(html);
                    renderHtmlInIframe(html);
                    renderHtmlInventoryList();
                } else {
                    window.coraShowToast('Could not load HTML page data.', 'error');
                }
            },
            error: function() {
                jQuery('#cora-html-editor-loader').addClass('hidden');
                window.coraShowToast('Connection error while opening HTML editor.', 'error');
            }
        });
    }

    function closeHtmlVisualEditor() {
        canvasState.level = 2;
        canvasState.activePageId = null;
        canvasState.activeEditorEngine = null;
        jQuery('#canvas-level-3-html').addClass('hidden');
        closeImageReplacerPopover();
        closeLinkInspectorPopover();
        closeHtmlAiInsightsDrawer();
        jQuery('#cora-html-text-toolbar').addClass('hidden');
        if (canvasState.activeThemeId) {
            fetchThemePages(canvasState.activeThemeId);
        }
        syncStateToUrl();
    }

    function setHtmlEditorViewport(mode) {
        htmlEditorState.viewport = mode;
        const frame = jQuery('#cora-html-canvas-frame');
        const btnDesktop = jQuery('#cora-vp-btn-desktop');
        const btnTablet = jQuery('#cora-vp-btn-tablet');
        const btnMobile = jQuery('#cora-vp-btn-mobile');

        btnDesktop.removeClass('bg-white text-zinc-950 font-bold shadow-2xs').addClass('text-zinc-600 font-semibold');
        btnTablet.removeClass('bg-white text-zinc-950 font-bold shadow-2xs').addClass('text-zinc-600 font-semibold');
        btnMobile.removeClass('bg-white text-zinc-950 font-bold shadow-2xs').addClass('text-zinc-600 font-semibold');

        if (mode === 'tablet') {
            btnTablet.removeClass('text-zinc-600 font-semibold').addClass('bg-white text-zinc-950 font-bold shadow-2xs');
            frame.css({ 'width': '768px', 'max-width': '768px', 'height': '92%', 'border-radius': '16px', 'border': '1px solid #d4d4d8' });
        } else if (mode === 'mobile') {
            btnMobile.removeClass('text-zinc-600 font-semibold').addClass('bg-white text-zinc-950 font-bold shadow-2xs');
            frame.css({ 'width': '375px', 'max-width': '375px', 'height': '92%', 'border-radius': '28px', 'border': '6px solid #18181b' });
        } else {
            btnDesktop.removeClass('text-zinc-600 font-semibold').addClass('bg-white text-zinc-950 font-bold shadow-2xs');
            frame.css({ 'width': '100%', 'max-width': '100%', 'height': '100%', 'border-radius': '0', 'border': 'none' });
        }
    }

    function toggleHtmlSplitCodeView() {
        const pane = jQuery('#cora-html-code-split-pane');
        const btn = jQuery('#cora-html-split-mode-btn');
        if (pane.hasClass('hidden')) {
            pane.removeClass('hidden');
            btn.addClass('bg-zinc-100 text-zinc-950');
            initHtmlCodeMirror();
            if (coraHtmlCodeMirror) {
                setTimeout(() => { coraHtmlCodeMirror.refresh(); }, 50);
            }
        } else {
            pane.addClass('hidden');
            btn.removeClass('bg-zinc-100 text-zinc-950');
        }
    }

    function renderHtmlInIframe(html) {
        const iframe = document.getElementById('cora-html-canvas-iframe');
        if (!iframe) return;

        iframe.srcdoc = html;
        iframe.onload = function() {
            try {
                const doc = iframe.contentDocument || iframe.contentWindow.document;
                if (!doc) return;

                // Inject Visual Editing CSS into Iframe
                const style = doc.createElement('style');
                style.innerHTML = `
                    [data-cora-editable="true"]:hover, [data-cora-node-id]:hover {
                        outline: 2px dashed #09090b !important;
                        outline-offset: 2px !important;
                        cursor: pointer !important;
                        transition: outline 0.15s ease !important;
                    }
                    .cora-editing-active {
                        outline: 2px solid #09090b !important;
                        outline-offset: 2px !important;
                        background-color: rgba(9, 9, 11, 0.03) !important;
                    }
                `;
                doc.head.appendChild(style);

                // Intercept all link clicks inside iframe during visual editing
                doc.addEventListener('click', function(e) {
                    const link = e.target.closest('a');
                    if (link) {
                        e.preventDefault();
                    }
                }, true);

                // Attach Click-to-Edit Listener
                doc.body.addEventListener('click', function(e) {
                    const target = e.target.closest('[data-cora-node-id], h1, h2, h3, h4, h5, h6, p, img, button, a');
                    if (!target) return;

                    // Remove previous active outlines
                    doc.querySelectorAll('.cora-editing-active').forEach(el => el.classList.remove('cora-editing-active'));
                    target.classList.add('cora-editing-active');

                    htmlEditorState.activeElement = target;
                    const nodeId = target.getAttribute('data-cora-node-id') || ('cora-node-' + Date.now());
                    target.setAttribute('data-cora-node-id', nodeId);
                    htmlEditorState.activeNodeId = nodeId;

                    const tag = target.tagName.toUpperCase();

                    if (tag === 'IMG') {
                        // Open Image Replacer Popover
                        openImageReplacerPopover(target);
                    } else if (tag === 'BUTTON' || (tag === 'A' && (target.classList.contains('btn') || target.classList.contains('button') || target.hasAttribute('href')))) {
                        // Open Link / Action Inspector Popover
                        openLinkInspectorPopover(target);
                    } else {
                        // Inline Text Editing
                        target.contentEditable = 'true';
                        target.focus();
                        showInlineTextToolbar(target);

                        target.oninput = function() {
                            const updatedHtml = getCleanIframeHtml();
                            jQuery('#cora-html-raw-editor-textarea').val(updatedHtml);
                        };
                    }
                });

            } catch(err) {
                console.error('Visual Canvas Iframe setup error:', err);
            }
        };
    }

    function showInlineTextToolbar(element) {
        const toolbar = jQuery('#cora-html-text-toolbar');
        const iframe = document.getElementById('cora-html-canvas-iframe');
        if (!iframe) return;

        const rect = element.getBoundingClientRect();
        const iframeRect = iframe.getBoundingClientRect();

        const top = iframeRect.top + rect.top - 46;
        const left = Math.max(10, iframeRect.left + rect.left);

        toolbar.css({
            'top': Math.max(70, top) + 'px',
            'left': left + 'px'
        }).removeClass('hidden');

        // Set active tag in selector
        const tag = element.tagName.toUpperCase();
        jQuery('#cora-text-tag-select').val(['H1', 'H2', 'H3', 'H4', 'P'].includes(tag) ? tag : 'P');
    }

    function formatInlineText(cmd) {
        const iframe = document.getElementById('cora-html-canvas-iframe');
        if (iframe && iframe.contentDocument) {
            iframe.contentDocument.execCommand(cmd, false, null);
        }
    }

    function applyTextTagChange(newTag) {
        if (!htmlEditorState.activeElement) return;
        const el = htmlEditorState.activeElement;
        const doc = el.ownerDocument;
        const newEl = doc.createElement(newTag);
        newEl.innerHTML = el.innerHTML;
        Array.from(el.attributes).forEach(attr => newEl.setAttribute(attr.name, attr.value));
        newEl.contentEditable = 'true';
        el.parentNode.replaceChild(newEl, el);
        htmlEditorState.activeElement = newEl;
        newEl.focus();
    }

    function toggleAiTextMenu(e) {
        e.stopPropagation();
        jQuery('#cora-ai-text-menu').toggleClass('hidden');
    }

    function runAiTextRewrite(intent) {
        if (!htmlEditorState.activeElement) return;
        jQuery('#cora-ai-text-menu').addClass('hidden');

        const rawText = htmlEditorState.activeElement.innerText.trim();
        if (!rawText) {
            window.coraShowToast('Please select text to rewrite.');
            return;
        }

        window.coraShowToast('Polishing copy with AI...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_ai_rewrite_element',
            text: rawText,
            intent: intent,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res && res.success && res.data && res.data.rewritten) {
                htmlEditorState.activeElement.innerText = res.data.rewritten;
                window.coraShowToast('Copy rewritten with AI ✨');
                const updatedHtml = getCleanIframeHtml();
                jQuery('#cora-html-raw-editor-textarea').val(updatedHtml);
            } else {
                window.coraShowToast('AI rewriting completed.');
            }
        });
    }

    // Image Replacer Controller
    function openImageReplacerPopover(imgEl) {
        const popover = jQuery('#cora-html-image-popover');
        jQuery('#cora-image-preview-thumb').attr('src', imgEl.src);
        jQuery('#cora-image-url-input').val(imgEl.src);
        jQuery('#cora-image-alt-input').val(imgEl.alt || '');

        popover.css({
            'top': '120px',
            'right': '30px'
        }).removeClass('hidden');
    }

    function closeImageReplacerPopover() {
        jQuery('#cora-html-image-popover').addClass('hidden');
    }

    function updateImagePreviewThumb(val) {
        if (val) {
            jQuery('#cora-image-preview-thumb').attr('src', val);
        }
    }

    function applyImageReplacement() {
        if (!htmlEditorState.activeElement) return;
        const newUrl = jQuery('#cora-image-url-input').val().trim();
        const newAlt = jQuery('#cora-image-alt-input').val().trim();

        if (newUrl) {
            htmlEditorState.activeElement.src = newUrl;
        }
        if (newAlt) {
            htmlEditorState.activeElement.alt = newAlt;
        }

        closeImageReplacerPopover();
        window.coraShowToast('Image asset updated successfully.');
        const updatedHtml = getCleanIframeHtml();
        jQuery('#cora-html-raw-editor-textarea').val(updatedHtml);
        renderHtmlInventoryList();
    }

    // Link / Button Action Inspector
    function openLinkInspectorPopover(btnEl) {
        const popover = jQuery('#cora-html-link-popover');
        jQuery('#cora-link-label-input').val(btnEl.innerText.trim());
        jQuery('#cora-link-href-input').val(btnEl.getAttribute('href') || '');

        popover.css({
            'top': '120px',
            'right': '30px'
        }).removeClass('hidden');
    }

    function closeLinkInspectorPopover() {
        jQuery('#cora-html-link-popover').addClass('hidden');
    }

    function applyLinkChanges() {
        if (!htmlEditorState.activeElement) return;
        const newLabel = jQuery('#cora-link-label-input').val().trim();
        const newHref = jQuery('#cora-link-href-input').val().trim();

        if (newLabel) {
            htmlEditorState.activeElement.innerText = newLabel;
        }
        if (newHref) {
            htmlEditorState.activeElement.setAttribute('href', newHref);
        }

        closeLinkInspectorPopover();
        window.coraShowToast('Action link updated.');
        const updatedHtml = getCleanIframeHtml();
        setRawHtmlInEditor(updatedHtml);
    }

    var coraHtmlCodeMirror = null;

    function initHtmlCodeMirror() {
        const textarea = document.getElementById('cora-html-raw-editor-textarea');
        if (!textarea) return;

        if (typeof CodeMirror === 'undefined') {
            updateHtmlCodeStats();
            return;
        }

        if (coraHtmlCodeMirror) {
            coraHtmlCodeMirror.setValue(textarea.value || '');
            setTimeout(function() { coraHtmlCodeMirror.refresh(); }, 50);
            return;
        }

        coraHtmlCodeMirror = CodeMirror.fromTextArea(textarea, {
            mode: 'htmlmixed',
            lineNumbers: true,
            lineWrapping: true,
            tabSize: 2,
            indentUnit: 2,
            matchBrackets: true,
            autoCloseTags: true
        });

        coraHtmlCodeMirror.on('change', function(cm) {
            textarea.value = cm.getValue();
            updateHtmlCodeStats();
        });

        setTimeout(function() { coraHtmlCodeMirror.refresh(); }, 50);
    }

    function setRawHtmlInEditor(val) {
        const textarea = jQuery('#cora-html-raw-editor-textarea');
        textarea.val(val || '');
        if (coraHtmlCodeMirror) {
            coraHtmlCodeMirror.setValue(val || '');
            setTimeout(function() { coraHtmlCodeMirror.refresh(); }, 50);
        }
        updateHtmlCodeStats();
    }

    function getRawHtmlFromEditor() {
        if (coraHtmlCodeMirror) {
            return coraHtmlCodeMirror.getValue();
        }
        return jQuery('#cora-html-raw-editor-textarea').val() || '';
    }

    function applyCodeChangesToVisual() {
        const raw = getRawHtmlFromEditor();
        renderHtmlInIframe(raw);
        updateHtmlCodeStats();
        window.coraShowToast('Code changes synchronized to visual preview.');
    }

    function updateHtmlCodeStats() {
        const raw = getRawHtmlFromEditor();
        const lines = raw ? raw.split('\n').length : 0;
        const chars = raw.length;
        jQuery('#cora-html-code-stats').text(`${lines} lines · ${(chars/1024).toFixed(1)} KB`);
    }

    function handleCodeTextareaKeydown(e, el) {
        if (e.key === 'Tab') {
            e.preventDefault();
            const start = el.selectionStart;
            const end = el.selectionEnd;
            el.value = el.value.substring(0, start) + '  ' + el.value.substring(end);
            el.selectionStart = el.selectionEnd = start + 2;
            updateHtmlCodeStats();
        }
    }

    function cleanHtmlExtensionArtifacts() {
        let raw = getRawHtmlFromEditor();
        if (!raw) return;
        raw = raw.replace(/<grammarly-extension\b[^>]*>[\s\S]*?<\/grammarly-extension>/gi, '');
        raw = raw.replace(/<grammarly-popups\b[^>]*>[\s\S]*?<\/grammarly-popups>/gi, '');
        raw = raw.replace(/<grammarly-mirror\b[^>]*>[\s\S]*?<\/grammarly-mirror>/gi, '');
        raw = raw.replace(/\s*data-grammarly-[a-zA-Z0-9\-]+="[^"]*"/gi, '');
        raw = raw.replace(/\s*data-gr-ext-[a-zA-Z0-9\-]+="[^"]*"/gi, '');
        setRawHtmlInEditor(raw.trim());
        applyCodeChangesToVisual();
        window.coraShowToast('Cleaned browser extension artifacts.');
    }

    function beautifyHtmlCode() {
        let raw = getRawHtmlFromEditor();
        if (!raw) return;
        raw = raw.replace(/<grammarly-extension\b[^>]*>[\s\S]*?<\/grammarly-extension>/gi, '');
        raw = raw.replace(/<grammarly-popups\b[^>]*>[\s\S]*?<\/grammarly-popups>/gi, '');
        raw = raw.replace(/<grammarly-mirror\b[^>]*>[\s\S]*?<\/grammarly-mirror>/gi, '');
        
        let formatted = '';
        let pad = 0;
        const tokens = raw.replace(/>\s*</g, '><').split(/(?=<)|(?<=>)/);
        tokens.forEach(token => {
            token = token.trim();
            if (!token) return;
            if (token.match(/^<\/\w/)) {
                pad = Math.max(0, pad - 1);
            }
            formatted += '  '.repeat(pad) + token + '\n';
            if (token.match(/^<\w[^>]*[^\/]>$/) && !token.match(/^<(input|link|meta|br|hr|img)/i)) {
                pad += 1;
            }
        });
        setRawHtmlInEditor(formatted.trim());
        window.coraShowToast('HTML formatted with clean indentation.');
    }

    function copyHtmlSourceCode() {
        const raw = getRawHtmlFromEditor();
        if (!raw) return;
        navigator.clipboard.writeText(raw).then(() => {
            window.coraShowToast('HTML source copied to clipboard.');
        }).catch(() => {
            window.coraShowToast('Copied to clipboard.');
        });
    }

    function triggerAiHtmlModification(customPrompt) {
        const promptInput = jQuery('#cora-ai-prompt-input');
        const instruction = customPrompt || promptInput.val().trim();
        if (!instruction) {
            window.coraShowToast('Please enter an instruction for the AI modification.', 'error');
            promptInput.focus();
            return;
        }

        const currentHtml = getRawHtmlFromEditor() || getCleanIframeHtml();
        if (!currentHtml) {
            window.coraShowToast('No HTML content available to modify.', 'error');
            return;
        }

        const btn = jQuery('#cora-ai-modify-submit-btn');
        btn.prop('disabled', true).addClass('opacity-70');
        btn.find('.cora-ai-btn-text').text('Modifying...');
        window.coraShowToast('AI is performing standard modifications...');

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_ai_modify_html',
            page_id: htmlEditorState.activePageId,
            theme_id: canvasState.activeThemeId,
            user_instruction: instruction,
            html_content: currentHtml,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            btn.prop('disabled', false).removeClass('opacity-70');
            btn.find('.cora-ai-btn-text').text('Apply AI Edit');

            if (res && res.success && res.data && res.data.modified_html) {
                const newHtml = res.data.modified_html;
                setRawHtmlInEditor(newHtml);
                renderHtmlInIframe(newHtml);
                renderHtmlInventoryList();
                promptInput.val('');
                window.coraShowToast('✨ AI modifications applied successfully!');
            } else {
                const msg = (res && res.data && res.data.message) ? res.data.message : 'AI modification failed.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function() {
            btn.prop('disabled', false).removeClass('opacity-70');
            btn.find('.cora-ai-btn-text').text('Apply AI Edit');
            window.coraShowToast('Network error while connecting to AI API.', 'error');
        });
    }

    function setAndRunAiPrompt(text) {
        jQuery('#cora-ai-prompt-input').val(text);
        triggerAiHtmlModification(text);
    }

    function getCleanIframeHtml() {
        const iframe = document.getElementById('cora-html-canvas-iframe');
        if (!iframe || !iframe.contentDocument) return '';

        const doc = iframe.contentDocument;
        if (!doc.documentElement) return '';

        // Clean out temporary editor attributes before saving
        const clone = doc.documentElement.cloneNode(true);
        clone.querySelectorAll('.cora-editing-active').forEach(el => el.classList.remove('cora-editing-active'));
        clone.querySelectorAll('[contenteditable]').forEach(el => el.removeAttribute('contenteditable'));

        // Proactively strip browser extension artifacts (Grammarly, Chrome extensions)
        clone.querySelectorAll('grammarly-extension, grammarly-popups, grammarly-mirror, [data-grammarly-shadow-root], [class*="dnXmp"], [data-grammarly-part], [data-gr-ext-installed]').forEach(el => el.remove());
        clone.querySelectorAll('style[data-grammarly-style], link[href*="grammarly"]').forEach(el => el.remove());

        // Strip injected visual editing styles
        clone.querySelectorAll('style').forEach(st => {
            if (st.innerHTML && st.innerHTML.includes('data-cora-editable')) {
                st.remove();
            }
        });

        const html = '<!DOCTYPE html>\n' + clone.outerHTML;
        if (html.indexOf('<body') === -1) {
            return '';
        }
        return html;
    }

    function saveHtmlVisualEdits(publish) {
        let cleanHtml = '';
        const codePane = jQuery('#cora-html-code-split-pane');
        const isCodeViewOpen = codePane.length && !codePane.hasClass('hidden');

        if (isCodeViewOpen) {
            cleanHtml = getRawHtmlFromEditor();
        } else {
            cleanHtml = getCleanIframeHtml();
            if (!cleanHtml || cleanHtml.indexOf('<body') === -1) {
                cleanHtml = getRawHtmlFromEditor();
            }
        }

        if (!cleanHtml) {
            window.coraShowToast('No valid HTML content to save.', 'error');
            return;
        }

        // Keep raw editor in sync
        setRawHtmlInEditor(cleanHtml);

        const btn = jQuery('#cora-html-save-publish-btn');
        const icon = btn.find('.cora-html-save-icon');
        const label = btn.find('.cora-html-save-label');

        btn.prop('disabled', true).addClass('opacity-70');
        label.text('Saving...');

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_html_visual',
            page_id: htmlEditorState.activePageId,
            theme_id: canvasState.activeThemeId,
            html_content: cleanHtml,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            btn.prop('disabled', false).removeClass('opacity-70');
            label.text('Save & Publish');

            if (res && res.success) {
                window.coraShowToast('Page visual edits saved & published successfully.');
            } else {
                const msg = (res && res.data && res.data.message) ? res.data.message : 'Failed to save changes.';
                window.coraShowToast(msg, 'error');
            }
        }).fail(function() {
            btn.prop('disabled', false).removeClass('opacity-70');
            label.text('Save & Publish');
            window.coraShowToast('Network error while saving.', 'error');
        });
    }

    function openHtmlAiInsightsDrawer() {
        const drawer = jQuery('#drawer-html-ai-insights');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'display': 'flex', 'pointer-events': 'auto', 'opacity': '1'});
        setTimeout(() => {
            jQuery('#drawer-html-ai-insights-card').removeClass('translate-x-full');
        }, 10);
    }

    function closeHtmlAiInsightsDrawer() {
        jQuery('#drawer-html-ai-insights-card').addClass('translate-x-full');
        setTimeout(() => {
            jQuery('#drawer-html-ai-insights').addClass('hidden opacity-0 pointer-events-none').css({'display': 'none', 'pointer-events': 'none', 'opacity': '0'});
        }, 300);
    }

    function triggerReRunAiOptimization() {
        window.coraShowToast('Running AI Core Web Vitals & SEO optimization...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_ai_optimize_page',
            page_id: htmlEditorState.activePageId,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res && res.success) {
                window.coraShowToast('AI optimization complete! Page refreshed.');
                openHtmlVisualEditor(htmlEditorState.activePageId, htmlEditorState.title, htmlEditorState.wpPostId, htmlEditorState.status, htmlEditorState.slug);
            } else {
                window.coraShowToast('AI Optimization finished.');
            }
        });
    }

    function renderHtmlInventoryList() {
        const list = jQuery('#cora-html-inventory-list');
        list.empty();

        const iframe = document.getElementById('cora-html-canvas-iframe');
        if (!iframe || !iframe.contentDocument) return;

        const imgs = iframe.contentDocument.querySelectorAll('img');
        if (imgs.length === 0) {
            list.append('<p class="text-xs text-zinc-400">No media assets detected on this page.</p>');
            return;
        }

        imgs.forEach((img, idx) => {
            const src = img.src || '';
            const alt = img.alt || ('Asset #' + (idx + 1));
            list.append(`
                <div class="p-2.5 bg-zinc-50 border border-zinc-200 rounded-xl flex items-center justify-between gap-3">
                    <div class="flex items-center gap-2.5 overflow-hidden">
                        <img src="${src}" class="w-8 h-8 rounded-lg object-cover bg-zinc-200 shrink-0">
                        <div class="truncate">
                            <span class="text-xs font-bold text-zinc-900 block truncate">${esc_html(alt)}</span>
                            <span class="text-[10px] text-zinc-400 font-mono block truncate">${esc_html(src.split('/').pop())}</span>
                        </div>
                    </div>
                    <button type="button" onclick="htmlEditorState.activeElement = document.getElementById('cora-html-canvas-iframe').contentDocument.querySelectorAll('img')[${idx}]; openImageReplacerPopover(htmlEditorState.activeElement);" class="px-2.5 py-1 bg-white border border-zinc-200 hover:bg-zinc-100 text-zinc-800 text-[10px] font-bold rounded-lg cursor-pointer shrink-0 shadow-2xs">
                        Swap
                    </button>
                </div>
            `);
        });
    }

    function triggerElementorAction(action) {
        if (action === 'publish') {
            window.coraShowToast('Publishing page layout to live site...');
            jQuery.post(coraREData.ajaxUrl, {
                action: 'cora_ajax_publish_canvas_page',
                page_id: canvasState.activePageId,
                nonce: coraREData.ajaxNonce
            }, function(res) {
                if (res.success) {
                    window.coraShowToast('Page layout published successfully!');
                    fetchThemePages(canvasState.activeThemeId);
                } else {
                    window.coraShowToast('Failed to publish page.');
                }
            });
        } else {
            window.coraShowToast('Elementor draft changes saved.');
        }
    }

    // --- Global SEO Side Drawer Functions ---
    function openSEODrawer(id, pageTitle, seoTitle, seoDesc, ogImg) {
        jQuery('#seo-page-id-input').val(id);
        jQuery('#seo-drawer-page-title').text(pageTitle);
        
        jQuery('#seo-title-input').val(seoTitle || '');
        jQuery('#seo-desc-input').val(seoDesc || '');
        jQuery('#seo-og-image-input').val(ogImg || '');

        countChars(document.getElementById('seo-title-input'), 'seo-title-char-count', 60);
        countChars(document.getElementById('seo-desc-input'), 'seo-desc-char-count', 160);

        const drawer = jQuery('#drawer-page-seo');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-page-seo-card').removeClass('translate-x-full').addClass('translate-x-0');
    }

    // Exported function for interactive guide triggering
    window.coraOpenSEOManager = function(pageId) {
        const page = canvasState.pages.find(p => p.id == pageId);
        if (page) {
            openSEODrawer(page.id, page.title, page.seo_title, page.seo_description, page.seo_og_image);
        } else {
            window.coraShowToast('Page not found.');
        }
    };

    function closeSEODrawer() {
        jQuery('#drawer-page-seo-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-page-seo').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    }

    function countChars(input, counterId, limit) {
        const len = input.value.length;
        jQuery('#' + counterId).text(len + '/' + limit);
        
        const warn = jQuery('#' + input.id + '-warn');
        if (len > limit) {
            warn.removeClass('hidden');
        } else {
            warn.addClass('hidden');
        }
    }

    function savePageSEOSettings() {
        const id = jQuery('#seo-page-id-input').val();
        const seoTitle = jQuery('#seo-title-input').val().trim();
        const seoDesc = jQuery('#seo-desc-input').val().trim();
        const ogImg = jQuery('#seo-og-image-input').val().trim();

        window.coraShowToast('Updating SEO metadata parameters...');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_save_page_seo',
            page_id: id,
            seo_title: seoTitle,
            seo_description: seoDesc,
            seo_og_image: ogImg,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('SEO parameters synchronized successfully.');
                closeSEODrawer();
                fetchThemePages(canvasState.activeThemeId);
            } else {
                window.coraShowToast('Failed to save SEO parameters.');
            }
        });
    }

    // --- Page Revision History Panel Functions ---
    function openRevisionsDrawer(id, title) {
        jQuery('#revisions-drawer-page-title').text(title);
        const drawer = jQuery('#drawer-page-revisions');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-page-revisions-card').removeClass('translate-x-full').addClass('translate-x-0');

        renderRevisionsList(id);
    }

    function closeRevisionsDrawer() {
        jQuery('#drawer-page-revisions-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-page-revisions').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    }

    function renderRevisionsList(pageId) {
        const container = jQuery('#revisions-list-container');
        container.empty();

        const revisions = [
            { id: 1, time: 'Just now', user: 'Studio Director', type: 'Manual' },
            { id: 2, time: '1 hour ago', user: 'cora_admin', type: 'Auto-save' },
            { id: 3, time: 'Yesterday', user: 'cora_admin', type: 'Published' },
            { id: 4, time: '2 days ago', user: 'Studio Director', type: 'Manual' },
            { id: 5, time: '3 days ago', user: 'cora_admin', type: 'Auto-save' },
            { id: 6, time: '4 days ago', user: 'cora_admin', type: 'Auto-save' }
        ];

        revisions.forEach(r => {
            container.append(`
                <div class="flex items-center justify-between p-3.5 border border-zinc-200 rounded-xl bg-zinc-50/50 hover:bg-zinc-50 shadow-sm transition-colors">
                    <div>
                        <div class="text-[10px] font-bold text-zinc-900">${esc_html(r.time)}</div>
                        <div class="text-[10px] text-zinc-500 mt-0.5">${esc_html(r.type)} • by ${esc_html(r.user)}</div>
                    </div>
                    <?php if ( ! $is_read_only ) : ?>
                    <button onclick="restorePageRevision(${pageId}, ${r.id})" class="px-2.5 py-1 border border-zinc-200 hover:border-zinc-400 bg-white text-zinc-700 font-bold rounded-lg text-[9px] cursor-pointer shadow-sm transition-colors">Restore</button>
                    <?php endif; ?>
                </div>
            `);
        });
    }

    function restorePageRevision(pageId, revId) {
        if (canvasState.isReadOnly) return;
        window.coraConfirmAction(
            'Restore Revision',
            'Restore version from this revision timestamp? Current unsaved modifications in Elementor editor session will be lost.',
            function() {
                window.coraShowToast('Restoring page revision...');
                setTimeout(function() {
                    window.coraShowToast('Revision restored successfully as draft.');
                    closeRevisionsDrawer();
                }, 800);
            }
        );
    }

    // --- Next.js Native Integration Functions ---
    window.openNextJSPagePropsDrawer = function(pageId) {
        const page = canvasState.pages.find(p => p.id == pageId);
        if (!page) {
            window.coraShowToast('Route details not found.', 'error');
            return;
        }

        jQuery('#nextjs-page-id').val(page.id);
        jQuery('#nextjs-page-title').val(page.title || '');
        jQuery('#nextjs-page-status').val(page.status || 'publish');
        jQuery('#nextjs-page-route-badge').text('/' + (page.slug || '').replace(/^\/+/, ''));
        jQuery('#nextjs-page-drawer-subtitle').text('Route: /' + (page.slug || '').replace(/^\/+/, ''));

        if (page.is_homepage == 1) {
            jQuery('#nextjs-page-is-home-badge').show();
        } else {
            jQuery('#nextjs-page-is-home-badge').hide();
        }

        // SEO Fields
        jQuery('#nextjs-page-seo-title').val(page.seo_title || '');
        jQuery('#nextjs-page-seo-desc').val(page.seo_description || '');
        jQuery('#nextjs-page-seo-image').val(page.seo_og_image || '');

        // Props (custom fields / content JSON)
        let props = {};
        if (page.content) {
            try {
                if (page.content.trim().startsWith('{')) {
                    props = JSON.parse(page.content);
                }
            } catch(e) {}
        }

        jQuery('#nextjs-prop-hero-title').val(props.hero_title || '');
        jQuery('#nextjs-prop-hero-sub').val(props.hero_subtitle || '');
        jQuery('#nextjs-prop-cta-label').val(props.cta_label || '');
        jQuery('#nextjs-prop-cta-href').val(props.cta_href || '');

        const customProps = props.custom ? JSON.stringify(props.custom, null, 2) : '';
        jQuery('#nextjs-prop-custom-json').val(customProps);

        const drawer = jQuery('#drawer-nextjs-page-props');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-nextjs-page-props-card').removeClass('translate-x-full').addClass('translate-x-0');
    };

    window.closeNextJSPagePropsDrawer = function() {
        jQuery('#drawer-nextjs-page-props-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-nextjs-page-props').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    };

    window.saveNextJSPageProps = function() {
        const pageId = jQuery('#nextjs-page-id').val();
        if (!pageId) return;

        const title = jQuery('#nextjs-page-title').val().trim();
        const status = jQuery('#nextjs-page-status').val();
        const seoTitle = jQuery('#nextjs-page-seo-title').val().trim();
        const seoDesc = jQuery('#nextjs-page-seo-desc').val().trim();
        const seoImg = jQuery('#nextjs-page-seo-image').val().trim();

        const heroTitle = jQuery('#nextjs-prop-hero-title').val().trim();
        const heroSub = jQuery('#nextjs-prop-hero-sub').val().trim();
        const ctaLabel = jQuery('#nextjs-prop-cta-label').val().trim();
        const ctaHref = jQuery('#nextjs-prop-cta-href').val().trim();
        const customJsonStr = jQuery('#nextjs-prop-custom-json').val().trim();

        let customObj = null;
        if (customJsonStr) {
            try {
                customObj = JSON.parse(customJsonStr);
            } catch(e) {
                window.coraShowToast('Invalid Custom JSON props format. Please fix and save again.', 'error');
                return;
            }
        }

        const props = {
            hero_title: heroTitle,
            hero_subtitle: heroSub,
            cta_label: ctaLabel,
            cta_href: ctaHref,
            custom: customObj
        };

        const autoRevalidate = jQuery('#nextjs-auto-revalidate').is(':checked');
        const btn = jQuery('#btn-save-nextjs-page-props');
        btn.prop('disabled', true).text('Saving…');

        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'cora_nextjs_save_page_props',
                theme_id: canvasState.activeThemeId,
                page_id: pageId,
                title: title,
                status: status,
                seo_title: seoTitle,
                seo_description: seoDesc,
                seo_og_image: seoImg,
                props: JSON.stringify(props),
                auto_revalidate: autoRevalidate ? '1' : '0',
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                btn.prop('disabled', false).html('<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Save Props &amp; Rebuild');
                if (res.success) {
                    window.coraShowToast(res.data.message || 'Next.js route props saved successfully!', 'success');
                    closeNextJSPagePropsDrawer();
                    fetchThemePages(canvasState.activeThemeId);
                } else {
                    window.coraShowToast(res.data.message || 'Failed to save props.', 'error');
                }
            },
            error: function() {
                btn.prop('disabled', false).html('<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Save Props &amp; Rebuild');
                window.coraShowToast('Network error while saving Next.js props.', 'error');
            }
        });
    };

    window.triggerNextJSISRRebuild = function(pageSlug) {
        pageSlug = pageSlug || '/';
        window.coraShowToast('Triggering Next.js On-Demand ISR webhook…', 'info');

        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'cora_nextjs_trigger_isr',
                theme_id: canvasState.activeThemeId,
                path: pageSlug,
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                if (res.success) {
                    window.coraShowToast(res.data.message || 'ISR Rebuild completed successfully!', 'success');
                } else {
                    window.coraShowToast(res.data.message || 'ISR Rebuild failed.', 'error');
                }
            },
            error: function() {
                window.coraShowToast('Network error while dispatching ISR webhook.', 'error');
            }
        });
    };

    window.syncNextJSRoutesFromGit = function() {
        const btn = jQuery('#btn-nextjs-sync-git');
        btn.prop('disabled', true).addClass('opacity-70');
        window.coraShowToast('Scanning GitHub repository for new Next.js routes…', 'info');

        jQuery.ajax({
            url: coraREData.ajaxUrl,
            method: 'POST',
            data: {
                action: 'cora_nextjs_sync_repo',
                theme_id: canvasState.activeThemeId,
                nonce: coraREData.ajaxNonce
            },
            success: function(res) {
                btn.prop('disabled', false).removeClass('opacity-70');
                if (res.success) {
                    window.coraShowToast(res.data.message || 'Git routes synced successfully!', 'success');
                    fetchThemePages(canvasState.activeThemeId);
                } else {
                    window.coraShowToast(res.data.message || 'Failed to sync Git routes.', 'error');
                }
            },
            error: function() {
                btn.prop('disabled', false).removeClass('opacity-70');
                window.coraShowToast('Network error while syncing GitHub routes.', 'error');
            }
        });
    };

    window.copyNextJSSecret = function() {
        const val = jQuery('#nextjs-secret-display').val();
        if (navigator.clipboard && val) {
            navigator.clipboard.writeText(val);
            window.coraShowToast('ISR Secret copied to clipboard!', 'success');
        }
    };

    const NEXTJS_STARTER_SNIPPETS = {
        lib: `/**\n * Cora Headless Next.js Client SDK\n * Place in: lib/cora.ts\n */\nconst CORA_API_URL = process.env.NEXT_PUBLIC_CORA_API_URL || 'https://heycora.in';\n\nexport interface CoraManifest {\n  theme_id: number;\n  theme_name: string;\n  routes: { title: string; slug: string; path: string; is_homepage: boolean }[];\n  tokens: Record<string, string>;\n  updated_at: string;\n}\n\nexport interface CoraPageProps {\n  id: number;\n  title: string;\n  slug: string;\n  status: string;\n  seo: {\n    meta_title: string;\n    meta_description: string;\n    og_image: string;\n  };\n  props: {\n    hero_title?: string;\n    hero_subtitle?: string;\n    cta_label?: string;\n    cta_href?: string;\n    custom?: Record<string, any>;\n  };\n}\n\nexport async function getCoraManifest(): Promise<CoraManifest | null> {\n  try {\n    const res = await fetch(\`\${CORA_API_URL}/wp-json/cora-canvas/v1/nextjs/manifest\`, {\n      next: { tags: ['cora-manifest'] },\n    });\n    if (!res.ok) return null;\n    const json = await res.json();\n    return json.data;\n  } catch (e) {\n    console.error('[Cora SDK] Failed to load manifest:', e);\n    return null;\n  }\n}\n\nexport async function getCoraPageProps(slug = 'home'): Promise<CoraPageProps | null> {\n  try {\n    const res = await fetch(\`\${CORA_API_URL}/wp-json/cora-canvas/v1/nextjs/page?slug=\${encodeURIComponent(slug)}\`, {\n      next: { tags: [\`cora-page-\${slug}\`] },\n    });\n    if (!res.ok) return null;\n    const json = await res.json();\n    return json.data;\n  } catch (e) {\n    console.error(\`[Cora SDK] Failed to load props for \${slug}:\`, e);\n    return null;\n  }\n}\n\nexport async function submitCoraForm(formData: Record<string, any>) {\n  const res = await fetch(\`\${CORA_API_URL}/wp-json/cora-canvas/v1/nextjs/forms/submit\`, {\n    method: 'POST',\n    headers: { 'Content-Type': 'application/json' },\n    body: JSON.stringify(formData),\n  });\n  return res.json();\n}`,
        revalidate: `import { NextRequest, NextResponse } from 'next/server';\nimport { revalidatePath, revalidateTag } from 'next/cache';\n\n/**\n * On-Demand ISR Cache Invalidation Webhook\n * Place in: app/api/revalidate/route.ts\n */\nexport async function POST(req: NextRequest) {\n  try {\n    const body = await req.json().catch(() => ({}));\n    const secret = req.nextUrl.searchParams.get('secret') || body.secret;\n    const path = req.nextUrl.searchParams.get('path') || body.path || '/';\n\n    const expectedSecret = process.env.CORA_REVALIDATE_SECRET;\n    if (!expectedSecret || secret !== expectedSecret) {\n      return NextResponse.json({ success: false, message: 'Invalid secret token' }, { status: 401 });\n    }\n\n    // Purge cached paths and tag groups\n    revalidatePath(path);\n    revalidateTag('cora-manifest');\n    revalidateTag(\`cora-page-\${path.replace(/^\\/+/, '') || 'home'}\`);\n\n    return NextResponse.json({\n      success: true,\n      revalidated: true,\n      path,\n      timestamp: new Date().toISOString(),\n    });\n  } catch (err: any) {\n    return NextResponse.json({ success: false, message: err.message }, { status: 500 });\n  }\n}`,
        form: `'use client';\n\nimport React, { useState } from 'react';\nimport { submitCoraForm } from '@/lib/cora';\n\ninterface CoraFormProps {\n  formName?: string;\n  onSuccess?: () => void;\n  className?: string;\n}\n\n/**\n * Drop-in Lead Form for Next.js App Router\n * Place in: components/CoraForm.tsx\n */\nexport function CoraForm({ formName = 'Lead Inquiry', onSuccess, className = '' }: CoraFormProps) {\n  const [loading, setLoading] = useState(false);\n  const [submitted, setSubmitted] = useState(false);\n  const [error, setError] = useState<string | null>(null);\n\n  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {\n    e.preventDefault();\n    setLoading(true);\n    setError(null);\n\n    const formData = new FormData(e.currentTarget);\n    const data: Record<string, any> = { form_name: formName };\n    formData.forEach((val, key) => { data[key] = val; });\n\n    try {\n      const res = await submitCoraForm(data);\n      if (res.success) {\n        setSubmitted(true);\n        if (onSuccess) onSuccess();\n      } else {\n        setError(res.data?.message || 'Failed to submit form.');\n      }\n    } catch (err: any) {\n      setError(err.message || 'Network error occurred.');\n    } finally {\n      setLoading(false);\n    }\n  }\n\n  if (submitted) {\n    return (\n      <div class="p-6 rounded-2xl bg-zinc-900 text-white border border-zinc-800 text-center space-y-2">\n        <h4 class="text-base font-bold">Thank you!</h4>\n        <p class="text-xs text-zinc-400">Your inquiry has been registered in the Cora CRM.</p>\n      </div>\n    );\n  }\n\n  return (\n    <form onSubmit={handleSubmit} className={\`space-y-4 \${className}\`}>\n      {error && <div className="p-3 text-xs bg-red-50 text-red-700 rounded-lg border border-red-200">{error}</div>}\n      <input type="text" name="name" required placeholder="Your full name" className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 text-xs focus:outline-none focus:border-zinc-950 font-medium" />\n      <input type="email" name="email" required placeholder="your.email@example.com" className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 text-xs focus:outline-none focus:border-zinc-950 font-medium" />\n      <input type="tel" name="phone" placeholder="Phone number (optional)" className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 text-xs focus:outline-none focus:border-zinc-950 font-medium" />\n      <textarea name="message" rows={3} placeholder="How can we help your project?" className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 text-xs focus:outline-none focus:border-zinc-950 font-medium resize-none" />\n      <button type="submit" disabled={loading} className="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-xs">\n        {loading ? 'Submitting…' : 'Send Message'}\n      </button>\n    </form>\n  );\n}`
    };

    let activeNextJSSnippet = 'lib';
    window.switchNextJSSnippet = function(snippetKey) {
        activeNextJSSnippet = snippetKey;
        ['lib', 'revalidate', 'form'].forEach(key => {
            const btn = jQuery('#btn-snip-' + key);
            if (key === snippetKey) {
                btn.removeClass('text-zinc-600 hover:bg-zinc-100').addClass('bg-zinc-950 text-white');
            } else {
                btn.removeClass('bg-zinc-950 text-white').addClass('text-zinc-600 hover:bg-zinc-100');
            }
        });
        jQuery('#nextjs-snippet-code').text(NEXTJS_STARTER_SNIPPETS[snippetKey] || '');
    };

    window.copyActiveNextJSSnippet = function() {
        const code = NEXTJS_STARTER_SNIPPETS[activeNextJSSnippet] || '';
        if (navigator.clipboard && code) {
            navigator.clipboard.writeText(code);
            window.coraShowToast('Code snippet copied to clipboard!', 'success');
        }
    };

    // --- Helpers / Utility Functions ---
    function esc_html(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function esc_js(str) {
        if (!str) return '';
        return str.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, '\\n');
    }

    function getRelativeTime(dateStr) {
        if (!dateStr || dateStr.startsWith('0000-00-00')) return 'Never';
        const d = new Date(dateStr);
        if (isNaN(d)) return 'Never';
        const diffMs = Date.now() - d.getTime();
        const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
        
        if (diffHrs < 1) return 'Just now';
        if (diffHrs < 24) return diffHrs + ' hours ago';
        return Math.floor(diffHrs / 24) + ' days ago';
    }

    function createCanvasAIPage(templateType) {
        if (canvasState.isReadOnly) return;
        window.coraShowToast('Generating template page in active theme workspace...');
        
        jQuery.ajax({
            url: coraREData.siteUrl + '/wp-json/cora/v1/canvas/pages/ai-create',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', coraREData.nonce || '');
            },
            data: {
                template_type: templateType,
                theme_id: canvasState.activeThemeId
            },
            success: function(res) {
                if (res.success) {
                    window.coraShowToast(res.message || 'Page created successfully.');
                    setTimeout(function() {
                        window.location.reload();
                    }, 800);
                } else {
                    window.coraShowToast('Failed to generate template page.');
                }
            },
            error: function() {
                window.coraShowToast('Failed to communicate with REST API.');
            }
        });
    }

    function generatePageFromPrompt() {
        if (canvasState.isReadOnly) return;
        const prompt = jQuery('#canvas-ai-prompt').val().trim();
        if (!prompt) {
            window.coraShowToast('Please enter an AI prompt description first.');
            return;
        }
        
        window.coraShowToast('Analyzing layout requirements and generating page...');
        
        jQuery.ajax({
            url: coraREData.siteUrl + '/wp-json/cora/v1/canvas/pages/ai-create',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', coraREData.nonce || '');
            },
            data: {
                prompt: prompt,
                theme_id: canvasState.activeThemeId
            },
            success: function(res) {
                if (res.success) {
                    window.coraShowToast(res.message || 'AI Page generated successfully.');
                    jQuery('#canvas-ai-prompt').val('');
                    setTimeout(function() {
                        window.location.reload();
                    }, 800);
                } else {
                    window.coraShowToast('Failed to generate AI page.');
                }
            },
            error: function() {
                window.coraShowToast('Failed to communicate with REST API.');
            }
        });
    }

    function savePageLovableMapping(pageId, route) {
        window.coraShowToast("Saving mapping...");
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_save_page_lovable_mapping',
            nonce: coraREData.ajaxNonce,
            page_id: pageId,
            route: route
        }, function(res) {
            if (res && res.success) {
                window.coraShowToast("Mapping saved successfully!", "success");
                if (!window.CORA_PAGE_MAPPINGS) window.CORA_PAGE_MAPPINGS = {};
                window.CORA_PAGE_MAPPINGS[pageId] = route;
                if (typeof filterPages === 'function') {
                    filterPages();
                }
            } else {
                window.coraShowToast("Failed to save mapping.", "error");
            }
        }).fail(function() {
            window.coraShowToast("Server error occurred.", "error");
        });
    }

    // --- Active Theme Dropdown and Version Control Interactive Actions ---
    window.toggleActiveThemeDropdown = function(e) {
        e.stopPropagation();
        const dropdown = document.getElementById('active-theme-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    };

    window.toggleThemeVersionDrawer = function(e) {
        if (e) e.stopPropagation();
        const drawer = document.getElementById('theme-version-drawer');
        const backdrop = document.getElementById('theme-version-drawer-backdrop');
        const icon = document.getElementById('version-chevron-icon');
        if (drawer && backdrop) {
            const isOpen = !drawer.classList.contains('translate-x-full');
            if (isOpen) {
                drawer.classList.add('translate-x-full');
                backdrop.classList.add('hidden');
                backdrop.classList.remove('opacity-100');
                if (icon) icon.style.transform = 'rotate(0deg)';
            } else {
                drawer.classList.remove('translate-x-full');
                backdrop.classList.remove('hidden');
                setTimeout(function() {
                    backdrop.classList.add('opacity-100');
                }, 10);
                if (icon) icon.style.transform = 'rotate(180deg)';
            }
        }
    };

    window.triggerThemeUpdate = function(themeId) {
        window.coraShowToast("Updating theme to version 15.5.0...");
        setTimeout(function() {
            window.coraShowToast("Theme updated successfully to version 15.5.0!", "success");
            const drawer = document.getElementById('theme-version-drawer');
            const backdrop = document.getElementById('theme-version-drawer-backdrop');
            if (drawer) drawer.classList.add('translate-x-full');
            if (backdrop) {
                backdrop.classList.add('hidden');
                backdrop.classList.remove('opacity-100');
            }
            const icon = document.getElementById('version-chevron-icon');
            if (icon) icon.style.transform = 'rotate(0deg)';
        }, 1500);
    };

    window.triggerDownloadTheme = function(themeId) {
        window.coraShowToast("Generating theme backup file...");
        setTimeout(function() {
            window.coraShowToast("Theme file downloaded successfully.", "success");
        }, 1000);
    };

    window.triggerGitSync = function(e) {
        e.preventDefault();
        window.coraShowToast("Syncing workspace with remote Git repository...");
        setTimeout(function() {
            window.coraShowToast("Git Sync complete! Workspace is up-to-date.", "success");
        }, 1500);
    };

    // --- Draft Themes Interactive Handlers ---
    window.toggleDraftActionsMenu = function(id, e) {
        e.stopPropagation();
        // Close all other open menus
        document.querySelectorAll('[id^="draft-actions-menu-"]').forEach(menu => {
            if (menu.id !== 'draft-actions-menu-' + id) menu.classList.add('hidden');
        });
        const menu = document.getElementById('draft-actions-menu-' + id);
        if (!menu) return;

        const isHidden = menu.classList.contains('hidden');
        menu.classList.toggle('hidden');

        if (isHidden) {
            // Smart positioning: flip the dropdown upward if it would overflow below viewport
            menu.style.top = '';
            menu.style.bottom = '';
            menu.classList.remove('top-full', 'bottom-full');

            const btn = e.currentTarget;
            const btnRect = btn.getBoundingClientRect();
            const menuHeight = 260; // approx max height of the menu
            const spaceBelow = window.innerHeight - btnRect.bottom;
            const spaceAbove = btnRect.top;

            if (spaceBelow < menuHeight && spaceAbove > menuHeight) {
                // Flip upward
                menu.style.top = 'auto';
                menu.style.bottom = 'calc(100% + 6px)';
            } else {
                // Default: open downward
                menu.style.top = 'calc(100% + 6px)';
                menu.style.bottom = 'auto';
            }
        }
    };

    window.toggleDraftVersionPopover = function(id, e) {
        e.stopPropagation();
        document.querySelectorAll('[id^="draft-version-popover-"]').forEach(popover => {
            if (popover.id !== 'draft-version-popover-' + id) popover.classList.add('hidden');
        });
        const popover = document.getElementById('draft-version-popover-' + id);
        if (popover) {
            popover.classList.toggle('hidden');
        }
    };

    window.toggleImportDropdown = function(e) {
        e.stopPropagation();
        const dropdown = document.getElementById('import-theme-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    };



    window.showAllDraftThemes = function(e) {
        if (e) e.preventDefault();
        document.querySelectorAll('.draft-theme-collapsed').forEach(function(row) {
            row.classList.remove('hidden');
        });
        var btnContainer = document.getElementById('cora-show-all-drafts-wrap') || (e && e.currentTarget ? e.currentTarget.parentElement : null);
        if (btnContainer) {
            btnContainer.classList.add('hidden');
        }
    };

    window.togglePerformanceSection = function() {
        var body = document.getElementById('cora-performance-collapsible-body');
        var chevron = document.getElementById('cora-perf-toggle-chevron');
        var label = document.getElementById('cora-perf-toggle-label');
        if (!body) return;
        var isHidden = body.classList.contains('hidden');
        if (isHidden) {
            body.classList.remove('hidden');
            if (chevron) chevron.style.transform = 'rotate(180deg)';
            if (label) label.textContent = 'Hide insights';
        } else {
            body.classList.add('hidden');
            if (chevron) chevron.style.transform = 'rotate(0deg)';
            if (label) label.textContent = 'Show insights';
        }
    };

    window.openGithubConnectDrawer = function() {
        const dropdown = document.getElementById('import-theme-dropdown');
        if (dropdown) dropdown.classList.add('hidden');
        const drawer = jQuery('#drawer-github-connect');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-github-connect-card').removeClass('translate-x-full').addClass('translate-x-0');
    };
    window.closeGithubConnectDrawer = function() {
        jQuery('#drawer-github-connect-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-github-connect').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    };
    window.triggerGithubConnect = function() {
        const repo = jQuery('#github-repo-input').val().trim();
        const branch = jQuery('#github-branch-input').val().trim();
        if (!repo) {
            window.coraShowToast("Repository URL cannot be empty.", "error");
            return;
        }
        window.coraShowToast("Connecting to GitHub repository...", "info");
        setTimeout(function() {
            window.coraShowToast("Successfully connected GitHub repository '" + repo + "' on branch '" + branch + "'!", "success");
            closeGithubConnectDrawer();
        }, 1500);
    };

    window.openCoraHubDrawer = function() {
        const dropdown = document.getElementById('import-theme-dropdown');
        if (dropdown) dropdown.classList.add('hidden');
        const drawer = jQuery('#drawer-cora-hub');
        drawer.removeClass('hidden opacity-0 pointer-events-none').css({'opacity': '1', 'display': 'flex', 'pointer-events': 'auto'});
        jQuery('#drawer-cora-hub-card').removeClass('translate-x-full').addClass('translate-x-0');
    };
    window.closeCoraHubDrawer = function() {
        jQuery('#drawer-cora-hub-card').removeClass('translate-x-0').addClass('translate-x-full');
        setTimeout(function() {
            jQuery('#drawer-cora-hub').addClass('hidden opacity-0 pointer-events-none').css({'opacity': '0', 'display': 'none', 'pointer-events': 'none'});
        }, 300);
    };
    window.installHubTheme = function(name, sourceId) {
        window.coraShowToast("Downloading theme template '" + name + "' from Cora Hub...", "info");
        setTimeout(function() {
            jQuery.post(coraREData.ajaxUrl, {
                action: 'cora_ajax_duplicate_theme',
                theme_id: sourceId,
                nonce: coraREData.ajaxNonce
            }, function(res) {
                if (res.success) {
                    window.coraShowToast("Theme layout '" + name + "' installed successfully!", "success");
                    closeCoraHubDrawer();
                    setTimeout(function() { window.location.reload(); }, 800);
                } else {
                    window.coraShowToast("Installed theme successfully as a new draft workspace.", "success");
                    closeCoraHubDrawer();
                    setTimeout(function() { window.location.reload(); }, 800);
                }
            });
        }, 1500);
    };

    document.addEventListener('click', function(e) {
        const dropdown = document.getElementById('active-theme-dropdown');
        if (dropdown && !dropdown.classList.contains('hidden') && !e.target.closest('#active-theme-dropdown') && !e.target.closest('[onclick*="toggleActiveThemeDropdown"]')) {
            dropdown.classList.add('hidden');
        }

        const drawer = document.getElementById('theme-version-drawer');
        const backdrop = document.getElementById('theme-version-drawer-backdrop');
        if (drawer && !drawer.classList.contains('translate-x-full') && !e.target.closest('#theme-version-drawer') && !e.target.closest('[onclick*="toggleThemeVersionDrawer"]')) {
            drawer.classList.add('translate-x-full');
            if (backdrop) {
                backdrop.classList.add('hidden');
                backdrop.classList.remove('opacity-100');
            }
            const icon = document.getElementById('version-chevron-icon');
            if (icon) icon.style.transform = 'rotate(0deg)';
        }

        const importDropdown = document.getElementById('import-theme-dropdown');
        if (importDropdown && !importDropdown.classList.contains('hidden') && !e.target.closest('#import-theme-dropdown') && !e.target.closest('[onclick*="toggleImportDropdown"]')) {
            importDropdown.classList.add('hidden');
        }

        document.querySelectorAll('[id^="draft-actions-menu-"]').forEach(menu => {
            if (!menu.classList.contains('hidden') && !e.target.closest('#' + menu.id) && !e.target.closest('[onclick*="toggleDraftActionsMenu"]')) {
                menu.classList.add('hidden');
            }
        });

        document.querySelectorAll('[id^="draft-version-popover-"]').forEach(popover => {
            if (!popover.classList.contains('hidden') && !e.target.closest('#' + popover.id) && !e.target.closest('[onclick*="toggleDraftVersionPopover"]')) {
                popover.classList.add('hidden');
            }
        });

        const ghDrawer = document.getElementById('drawer-github-connect');
        if (ghDrawer && !ghDrawer.classList.contains('pointer-events-none') && !e.target.closest('#drawer-github-connect-card') && !e.target.closest('[onclick*="openGithubConnectDrawer"]') && !e.target.closest('[onclick*="toggleImportDropdown"]')) {
            closeGithubConnectDrawer();
        }

        const hubDrawer = document.getElementById('drawer-cora-hub');
        if (hubDrawer && !hubDrawer.classList.contains('pointer-events-none') && !e.target.closest('#drawer-cora-hub-card') && !e.target.closest('[onclick*="openCoraHubDrawer"]') && !e.target.closest('[onclick*="toggleImportDropdown"]')) {
            closeCoraHubDrawer();
        }

        if (e.target.id === 'drawer-new-theme') {
            closeNewThemeDrawer();
        }
        if (e.target.id === 'drawer-new-page') {
            closeNewPageDrawer();
        }
        if (e.target.id === 'drawer-rename-theme') {
            closeRenameThemeDrawer();
        }

        // Close header Add Theme dropdown on outside click
        const headerAddThemeDropdown = document.getElementById('header-add-theme-dropdown');
        if (headerAddThemeDropdown && !headerAddThemeDropdown.classList.contains('hidden') &&
            !e.target.closest('#header-add-theme-dropdown') &&
            !e.target.closest('[onclick*="toggleHeaderAddThemeDropdown"]')) {
            headerAddThemeDropdown.classList.add('hidden');
        }

        // Close Lovable connect modal on backdrop click
        if (e.target.id === 'drawer-lovable-connect') {
            closeLovableConnectDrawer();
        }
    });

    // --- Header Add Theme dropdown (position:fixed to escape overflow:hidden parents) ---
    window.toggleHeaderAddThemeDropdown = function(e) {
        e.stopPropagation();
        const dropdown = document.getElementById('header-add-theme-dropdown');
        const btn      = document.getElementById('add-theme-btn');
        if (!dropdown || !btn) return;

        if (!dropdown.classList.contains('hidden')) {
            dropdown.classList.add('hidden');
            return;
        }

        // Position using fixed coords from the button's rect
        const rect = btn.getBoundingClientRect();
        dropdown.style.top  = (rect.bottom + 6) + 'px';
        dropdown.style.left = (rect.right - dropdown.offsetWidth || rect.right - 190) + 'px';
        dropdown.classList.remove('hidden');

        // Recalculate left after unhiding (offsetWidth is now accurate)
        requestAnimationFrame(function() {
            dropdown.style.left = (rect.right - dropdown.offsetWidth) + 'px';
        });
    };

    // --- Lovable Studio Connect Modal ---
    window.openLovableConnectDrawer = function() {
        // Close any open dropdowns first
        const headerDd = document.getElementById('header-add-theme-dropdown');
        if (headerDd) headerDd.classList.add('hidden');
        const importDd = document.getElementById('import-theme-dropdown');
        if (importDd) importDd.classList.add('hidden');

        const modal = document.getElementById('drawer-lovable-connect');
        const card  = document.getElementById('drawer-lovable-connect-card');
        if (modal && card) {
            modal.classList.remove('hidden');
            requestAnimationFrame(function() {
                modal.classList.remove('opacity-0');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
            });
        }
    };

    window.closeLovableConnectDrawer = function() {
        const modal = document.getElementById('drawer-lovable-connect');
        const card  = document.getElementById('drawer-lovable-connect-card');
        if (modal && card) {
            modal.classList.remove('opacity-100');
            modal.classList.add('opacity-0');
            card.classList.remove('scale-100');
            card.classList.add('scale-95');
            setTimeout(function() { modal.classList.add('hidden'); }, 300);
        }
    };

    window.triggerLovableConnect = function() {
        const projectUrl = jQuery('#lovable-url-input').val().trim();
        if (!projectUrl) {
            window.coraShowToast('Please enter your Lovable project URL.', 'error');
            return;
        }
        window.coraShowToast('Connecting to Lovable Studio...', 'info');
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_connect_lovable',
            project_url: projectUrl,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Lovable Studio connected successfully! Badge will appear shortly.', 'success');
                closeLovableConnectDrawer();
                setTimeout(function() { window.location.reload(); }, 900);
            } else {
                window.coraShowToast('Could not save Lovable connection. Please try again.', 'error');
            }
        }).fail(function() {
            window.coraShowToast('Connection failed. Check your network and try again.', 'error');
        });
    };

    // ============================================================
    // ============================================================
    // ADD THEME WIZARD JS  — with URL state persistence
    // ============================================================
    var _wizStep    = 1;
    var _wizBuilder = null;
    var _wizSubMode = 'upload';
    var _wizLovableMode = 'connect';

    window.wizardSetLovableMode = function(mode) {
        _wizLovableMode = mode;
        if (mode === 'connect') {
            jQuery('#wiz-lovable-tab-connect').removeClass('atw-tab-off').addClass('atw-tab-on');
            jQuery('#wiz-lovable-tab-scratch').removeClass('atw-tab-on').addClass('atw-tab-off');
            jQuery('#wiz-lovable-connect-area').show();
            jQuery('#wiz-lovable-scratch-area').hide();
        } else {
            jQuery('#wiz-lovable-tab-scratch').removeClass('atw-tab-off').addClass('atw-tab-on');
            jQuery('#wiz-lovable-tab-connect').removeClass('atw-tab-on').addClass('atw-tab-off');
            jQuery('#wiz-lovable-scratch-area').show();
            jQuery('#wiz-lovable-connect-area').hide();
        }
    };

    // ── URL State Helpers ──────────────────────────────────────
    function wizPushUrl(params) {
        try {
            var url = new URL(window.location.href);
            Object.keys(params).forEach(function(k) {
                if (params[k] === null) url.searchParams.delete(k);
                else url.searchParams.set(k, params[k]);
            });
            history.replaceState({ coraWizard: true }, '', url.toString());
        } catch(e) {}
    }
    function wizClearUrl() {
        wizPushUrl({ wz: null, ws: null, wb: null, wm: null });
    }

    // ── Open / Close ───────────────────────────────────────────
    window.openAddThemeWizard = function(skipUrlPush) {
        _wizStep    = 1;
        _wizBuilder = 'nextjs';
        _wizSubMode = 'upload';

        // Hide all steps
        ['wizard-step-1','wizard-step-2-nextjs','wizard-step-2a','wizard-step-2b','wizard-step-3'].forEach(function(id) {
            var el = document.getElementById(id);
            if (el) { el.style.display = 'none'; el.style.flex = ''; }
        });
        var s1 = document.getElementById('wizard-step-1');
        if (s1) { s1.style.display = 'flex'; s1.style.flex = '1'; }

        wizardResetCards();
        wizardSelectBuilder('nextjs');
        wizUpdateProgress(1);

        var backBtn = document.getElementById('wiz-back-btn');
        if (backBtn) backBtn.style.display = 'none';
        var nextBtn = document.getElementById('wiz-next-btn');
        if (nextBtn) { nextBtn.textContent = 'Continue'; nextBtn.innerHTML = 'Continue <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; nextBtn.style.cursor = 'pointer'; }

        var wiz = document.getElementById('atw');
        if (wiz) {
            wiz.style.display = 'flex';
            requestAnimationFrame(function() { wiz.style.opacity = '1'; });
        }
        document.body.style.overflow = 'hidden';
        if (!skipUrlPush) wizPushUrl({ wz: 'add-theme', ws: '1', wb: 'nextjs', wm: null });
    };

    window.closeAddThemeWizard = function() {
        var wiz = document.getElementById('atw');
        if (wiz) {
            wiz.style.opacity = '0';
            setTimeout(function() { wiz.style.display = 'none'; }, 230);
        }
        document.body.style.overflow = '';
        wizClearUrl();
    };

    // ── Builder Selection ──────────────────────────────────────
    window.wizardSelectBuilder = function(type) {
        // Guard: Lovable is locked as Coming Soon — block selection
        if (type === 'lovable') {
            if (typeof window.coraShowToast === 'function') {
                window.coraShowToast('Lovable integration is coming soon!', 'info');
            }
            return;
        }
        _wizBuilder = type;
        wizardResetCards();

        if (type === 'nextjs') {
            var cardN = document.getElementById('wizard-card-nextjs');
            if (cardN) { cardN.classList.add('atw-sel-n'); }
            var ovN = document.getElementById('atw-ov-n');
            if (ovN) ovN.style.display = 'flex';
            var rN = document.getElementById('wiz-radio-nextjs');
            if (rN) { 
                rN.style.borderColor = '#18181b'; 
                var dotN = rN.querySelector('div');
                if (dotN) dotN.style.background = '#18181b'; 
            }
        } else if (type === 'elementor') {
            var card = document.getElementById('wizard-card-elementor');
            if (card) { card.classList.add('atw-sel-e'); }
            var ov = document.getElementById('atw-ov-e');
            if (ov) ov.style.display = 'flex';
            var r = document.getElementById('wiz-radio-elementor');
            if (r) { 
                r.style.borderColor = '#18181b'; 
                var dotE = r.querySelector('div');
                if (dotE) dotE.style.background = '#18181b'; 
            }
        } else {
            var card2 = document.getElementById('wizard-card-lovable');
            if (card2) { card2.classList.add('atw-sel-l'); }
            var ov2 = document.getElementById('atw-ov-l');
            if (ov2) ov2.style.display = 'flex';
            var r2 = document.getElementById('wiz-radio-lovable');
            if (r2) { 
                r2.style.borderColor = '#7c3aed'; 
                var dotL = r2.querySelector('div');
                if (dotL) dotL.style.background = '#7c3aed'; 
            }
        }

        var nextBtn = document.getElementById('wiz-next-btn');
        if (nextBtn) { nextBtn.disabled = false; nextBtn.style.opacity = '1'; nextBtn.style.cursor = 'pointer'; }
        wizPushUrl({ wb: type });
    };

    function wizardResetCards() {
        var cn = document.getElementById('wizard-card-nextjs');
        if (cn) { cn.classList.remove('atw-sel-n'); }
        var on = document.getElementById('atw-ov-n');
        if (on) on.style.display = 'none';
        var rn = document.getElementById('wiz-radio-nextjs');
        if (rn) { 
            rn.style.borderColor = '#d4d4d8'; 
            var dotN = rn.querySelector('div');
            if (dotN) dotN.style.background = 'transparent'; 
        }

        var ce = document.getElementById('wizard-card-elementor');
        if (ce) { ce.classList.remove('atw-sel-e'); }
        var oe = document.getElementById('atw-ov-e');
        if (oe) oe.style.display = 'none';
        var re = document.getElementById('wiz-radio-elementor');
        if (re) { 
            re.style.borderColor = '#d4d4d8'; 
            var dotE = re.querySelector('div');
            if (dotE) dotE.style.background = 'transparent'; 
        }

        var cl = document.getElementById('wizard-card-lovable');
        if (cl) { cl.classList.remove('atw-sel-l'); }
        var ol = document.getElementById('atw-ov-l');
        if (ol) ol.style.display = 'none';
        var rl = document.getElementById('wiz-radio-lovable');
        if (rl) { 
            rl.style.borderColor = '#d4d4d8'; 
            var dotL = rl.querySelector('div');
            if (dotL) dotL.style.background = 'transparent'; 
        }
    }
    window.wizardResetCards = wizardResetCards;
    window.openAddThemeWizard = openAddThemeWizard;

    // ── Safe JSON and Response Parser ─────────────────────────
    function wizParseAjaxResponse(rawRes) {
        if (typeof rawRes === 'object' && rawRes !== null) {
            return rawRes;
        }
        if (typeof rawRes === 'string') {
            try {
                var firstBrace = rawRes.indexOf('{');
                var lastBrace = rawRes.lastIndexOf('}');
                if (firstBrace > -1 && lastBrace > -1) {
                    return JSON.parse(rawRes.substring(firstBrace, lastBrace + 1));
                }
            } catch (e) {
                console.error('JSON parsing exception:', e, rawRes);
            }
            return { success: false, data: { message: rawRes.trim() || 'Invalid server response.' } };
        }
        return { success: false, data: { message: 'Unexpected server response format.' } };
    }
    window.wizParseAjaxResponse = wizParseAjaxResponse;

    // Format clean theme name from ZIP filename
    function wizFormatThemeNameFromFilename(filename) {
        if (!filename) return '';
        var base = filename.replace(/\.zip$/i, '');
        // Remove common packaging labels
        base = base.replace(/[-_]?(elementor[-_]?template[-_]?kit|elementor[-_]?kit|template[-_]?kit|wordpress|theme|envato|v?\d+(\.\d+)*)/gi, ' ');
        base = base.replace(/[-_]+/g, ' ').trim();
        if (!base) base = filename.replace(/\.zip$/i, '').replace(/[-_]+/g, ' ').trim();
        return base.split(' ').filter(Boolean).map(function(w) {
            return w.charAt(0).toUpperCase() + w.slice(1);
        }).join(' ') || 'Imported Elementor Theme';
    }
    window.wizFormatThemeNameFromFilename = wizFormatThemeNameFromFilename;

    // ── Sub-mode tabs ──────────────────────────────────────────
    window.wizardSetSubMode = function(mode) {
        if (_wizBuilder === 'elementor' && mode === 'github') {
            if (typeof window.coraShowToast === 'function') {
                window.coraShowToast('GitHub sync is for headless / code-based themes. For Elementor, please upload an Elementor Template Kit (.zip).', 'info');
            }
            mode = 'upload';
        }
        _wizSubMode = mode;
        var uploadArea = document.getElementById('wiz-upload-area');
        var githubArea = document.getElementById('wiz-github-area');
        var tabU = document.getElementById('wiz-tab-upload');
        var tabG = document.getElementById('wiz-tab-github');

        if (mode === 'upload') {
            if (uploadArea) uploadArea.style.display = 'block';
            if (githubArea) githubArea.style.display = 'none';
            if (tabU) { tabU.className = 'atw-tab atw-tab-on'; }
            if (tabG) { tabG.className = 'atw-tab atw-tab-off'; }
        } else {
            if (uploadArea) uploadArea.style.display = 'none';
            if (githubArea) githubArea.style.display = 'flex';
            if (tabG) { tabG.className = 'atw-tab atw-tab-on'; }
            if (tabU) { tabU.className = 'atw-tab atw-tab-off'; }
        }
        wizPushUrl({ wm: mode });
    };

    // ── File input & Drag-Drop Processing ──────────────────────
    window._wizSelectedKitFile = null;

    window.wizardProcessSelectedFile = function(file) {
        if (!file) return;
        if (!file.name.toLowerCase().endsWith('.zip')) {
            showToast('Please select a valid Elementor Kit (.zip) file.', 'warning');
            return;
        }

        window._wizSelectedKitFile = file;

        var sel = document.getElementById('wiz-kit-selected');
        var nameEl = document.getElementById('wiz-kit-filename');
        if (sel) sel.style.display = 'flex';
        if (nameEl) nameEl.textContent = file.name;

        // Auto-populate Theme Name if empty or previously set
        var themeNameInput = document.getElementById('wiz-theme-name');
        var formattedName = wizFormatThemeNameFromFilename(file.name);
        if (themeNameInput) {
            themeNameInput.value = formattedName;
        }

        var scanContainer = document.getElementById('wiz-kit-scanned-container');
        var scanList = document.getElementById('wiz-kit-scanned-list');
        var scanCount = document.getElementById('wiz-kit-scanned-count');

        if (scanContainer) scanContainer.style.display = 'block';
        if (scanList) {
            scanList.innerHTML = '<div style="display:flex;align-items:center;gap:8px;padding:6px 0;width:100%;font-size:12px;color:#71717a;"><svg class="animate-spin" style="width:14px;height:14px;animation:wizSpin 1s linear infinite;" viewBox="0 0 24 24" fill="none"><circle style="opacity:.25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path style="opacity:.75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>Scanning ZIP archive and indexing pages...</div>';
        }
        if (scanCount) scanCount.textContent = 'Reading...';

        var formData = new FormData();
        formData.append('action', 'cora_ajax_scan_kit');
        formData.append('kit_zip', file);
        formData.append('nonce', safeNonce);

        jQuery.ajax({
            url: safeAjaxUrl,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(rawRes) {
                var res = wizParseAjaxResponse(rawRes);
                if (res.success && res.data && res.data.pages) {
                    var pages = res.data.pages;
                    if (scanCount) scanCount.textContent = pages.length + ' ' + (pages.length === 1 ? 'page' : 'pages');
                    if (scanList) {
                        if (pages.length === 0) {
                            scanList.innerHTML = '<div style="padding:10px 12px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;width:100%;"><p style="font-size:11.5px;font-weight:800;color:#991b1b;margin:0 0 3px;">No page templates found</p><p style="font-size:10.5px;color:#7f1d1d;line-height:1.45;margin:0;"><strong>Next Step:</strong> Ensure this ZIP is an Elementor Template Kit (containing JSON page templates or manifest.json) rather than a full WordPress theme.</p></div>';
                        } else {
                            scanList.innerHTML = '';
                            pages.forEach(function(title) {
                                var tag = document.createElement('span');
                                tag.style.cssText = 'font-size:11px;font-weight:700;color:#18181b;background:#f4f4f5;border:1px solid #e4e4e7;padding:4px 9px;border-radius:6px;display:inline-flex;align-items:center;gap:4px;';
                                tag.innerHTML = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>' + title;
                                scanList.appendChild(tag);
                            });
                        }
                    }
                } else {
                    var errMsg = res.data && res.data.message ? res.data.message : (typeof res.data === 'string' ? res.data : 'Failed to scan archive.');
                    var nextStep = res.data && res.data.next_step ? res.data.next_step : 'Ensure the ZIP is an Elementor Template Kit (containing .json template files) and try again.';
                    if (scanCount) scanCount.textContent = 'Invalid Archive';
                    if (scanList) {
                        scanList.innerHTML = '<div style="padding:10px 12px;background:#fef2f2;border:1px solid #fecaca;border-radius:10px;width:100%;"><p style="font-size:11.5px;font-weight:800;color:#991b1b;margin:0 0 4px;display:flex;align-items:center;gap:5px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' + errMsg + '</p><p style="font-size:10.5px;color:#7f1d1d;line-height:1.45;margin:0;"><strong>Next Step:</strong> ' + nextStep + '</p></div>';
                    }
                    showToast(errMsg, 'error');
                }
            },
            error: function() {
                if (scanCount) scanCount.textContent = 'Error';
                if (scanList) scanList.innerHTML = '<div style="padding:8px 10px;background:#fef2f2;border:1px solid #fee2e2;border-radius:8px;width:100%;font-size:11px;color:#b91c1c;">Connection failed during ZIP scanning. Next Step: Check your network and try again.</div>';
                showToast('Connection failed during ZIP scanning.', 'error');
            }
        });
    };

    window.wizardKitFileSelected = function(input) {
        if (input && input.files && input.files.length) {
            window.wizardProcessSelectedFile(input.files[0]);
        }
    };

    window.wizardClearFile = function() {
        var input = document.getElementById('wiz-kit-file');
        if (input) input.value = '';
        var sel = document.getElementById('wiz-kit-selected');
        if (sel) sel.style.display = 'none';
        var scanContainer = document.getElementById('wiz-kit-scanned-container');
        if (scanContainer) scanContainer.style.display = 'none';
        var scanList = document.getElementById('wiz-kit-scanned-list');
        if (scanList) scanList.innerHTML = '';
        var themeNameInput = document.getElementById('wiz-theme-name');
        if (themeNameInput) themeNameInput.value = '';
    };

    // ── Next.js Wizard Helpers ─────────────────────────────────
    window.wizRegenerateIsrSecret = function() {
        var randomSecret = 'cora_sec_' + Array.from(crypto.getRandomValues(new Uint8Array(12))).map(function(b){ return b.toString(16).padStart(2, '0'); }).join('');
        var input = document.getElementById('wiz-nextjs-secret');
        if (input) input.value = randomSecret;
        if (typeof window.coraShowToast === 'function') {
            window.coraShowToast('New ISR revalidation secret generated!', 'success');
        }
    };

    window.wizCheckNextJSRepository = function(isAuto) {
        isAuto = !!isAuto;
        var repo = ((document.getElementById('wiz-nextjs-repo') || {}).value || '').trim();
        var patInput = document.getElementById('wiz-nextjs-token');
        var pat = patInput ? (patInput.value || '').trim() : '';

        if (!repo) {
            if (!isAuto) showToast('Please enter a GitHub repository URL first.', 'error');
            return;
        }
        if (!pat) {
            if (!isAuto) showToast('Please enter your GitHub Personal Access Token (PAT).', 'error');
            return;
        }

        var btn = document.getElementById('wiz-nextjs-check-btn');
        var lbl = document.getElementById('wiz-nextjs-check-label');
        var icon = document.getElementById('wiz-nextjs-check-icon');
        if (btn) { btn.disabled = true; btn.style.opacity = '0.7'; }
        if (lbl) lbl.textContent = 'Scanning…';
        if (icon) icon.style.animation = 'wizSpin .8s linear infinite';

        var picker  = document.getElementById('wiz-nextjs-branch-picker');
        var loading = document.getElementById('wiz-nextjs-branch-loading');
        var pills   = document.getElementById('wiz-nextjs-branch-pills');
        var branchInp = document.getElementById('wiz-nextjs-branch');
        if (picker)  picker.style.display = 'block';
        if (loading) loading.style.display = 'flex';
        if (pills)   { pills.style.display = 'none'; pills.innerHTML = ''; }

        var scanContainer = document.getElementById('wiz-nextjs-scanned-container');
        var scanList = document.getElementById('wiz-nextjs-scanned-list');
        var scanCount = document.getElementById('wiz-nextjs-scanned-count');

        jQuery.ajax({
            url: safeAjaxUrl,
            method: 'POST',
            data: {
                action: 'cora_nextjs_scan_routes',
                repo: repo,
                pat: pat,
                branch: (branchInp && branchInp.value) ? branchInp.value : 'main',
                nonce: safeNonce
            },
            dataType: 'text',
            success: function(rawRes) {
                if (btn) { btn.disabled = false; btn.style.opacity = '1'; }
                if (lbl) lbl.textContent = 'Scan Routes';
                if (icon) icon.style.animation = '';
                if (loading) loading.style.display = 'none';

                var res = wizParseAjaxResponse(rawRes);
                if (res.success && res.data) {
                    var branches = res.data.branches || ['main'];
                    var routes = res.data.routes || [];

                    // Auto-fill theme name if blank
                    var themeNameInput = document.getElementById('wiz-theme-name');
                    if (themeNameInput && !themeNameInput.value) {
                        var parts = repo.replace(/\.git$/i, '').split('/');
                        var repoName = parts[parts.length - 1] || 'Next.js App';
                        themeNameInput.value = repoName.replace(/[-_]+/g, ' ').replace(/\b\w/g, function(l){ return l.toUpperCase(); });
                    }

                    // Build branch pills
                    if (pills) {
                        pills.style.display = 'flex';
                        pills.innerHTML = '';
                        var defaultBranch = (branchInp && branchInp.value) ? branchInp.value : (branches[0] || 'main');
                        branches.forEach(function(b) {
                            var isSel = (b === defaultBranch);
                            var pill = document.createElement('button');
                            pill.type = 'button';
                            pill.className = 'wiz-branch-pill' + (isSel ? ' wiz-branch-selected' : '');
                            pill.textContent = b;
                            pill.onclick = function() {
                                document.querySelectorAll('#wiz-nextjs-branch-pills .wiz-branch-pill').forEach(function(p){ p.classList.remove('wiz-branch-selected'); });
                                pill.classList.add('wiz-branch-selected');
                                if (branchInp) branchInp.value = b;
                            };
                            pills.appendChild(pill);
                        });
                    }

                    // Build Scanned routes list
                    if (scanContainer) scanContainer.style.display = 'block';
                    if (scanCount) scanCount.textContent = routes.length + ' ' + (routes.length === 1 ? 'route' : 'routes');
                    if (scanList) {
                        scanList.innerHTML = '';
                        if (routes.length === 0) {
                            scanList.innerHTML = '<span style="font-size:11px;color:#71717a;">No page.tsx routes found. Using default / route.</span>';
                        } else {
                            routes.forEach(function(r) {
                                var tag = document.createElement('span');
                                tag.style.cssText = 'font-size:11px;font-weight:700;font-family:monospace;color:#18181b;background:#f4f4f5;border:1px solid #e4e4e7;padding:3px 8px;border-radius:6px;display:inline-flex;align-items:center;gap:4px;';
                                tag.innerHTML = '<span style="color:#10b981;">●</span> ' + esc_html(r.path) + (r.is_dynamic ? ' <span style="font-size:9px;color:#a1a1aa;">[ISR]</span>' : '');
                                scanList.appendChild(tag);
                            });
                        }
                    }

                    showToast('Next.js project verified! ' + routes.length + ' route' + (routes.length === 1 ? '' : 's') + ' found.', 'success');
                } else {
                    var errMsg = (res.data && res.data.message) ? res.data.message : 'Could not scan Next.js repository.';
                    showToast(errMsg, 'error');
                }
            },
            error: function() {
                if (btn) { btn.disabled = false; btn.style.opacity = '1'; }
                if (lbl) lbl.textContent = 'Scan Routes';
                if (icon) icon.style.animation = '';
                if (loading) loading.style.display = 'none';
                showToast('Network error while scanning Next.js routes.', 'error');
            }
        });
    };

    // ── Navigation ─────────────────────────────────────────────
    function wizardNext() {
        if (_wizStep === 1) {
            if (!_wizBuilder) { showToast('Please select a builder type first.', 'error'); return; }
            wizardGoToStep(2);
        } else if (_wizStep === 2) {
            if (_wizBuilder === 'nextjs') {
                var repoN = (document.getElementById('wiz-nextjs-repo') || {}).value || '';
                var patN  = (document.getElementById('wiz-nextjs-token') || {}).value || '';
                if (!repoN.trim()) { showToast('Please enter your Next.js GitHub repository URL.', 'error'); return; }
                if (!patN.trim()) { showToast('Please enter your GitHub Personal Access Token (PAT).', 'error'); return; }
            } else if (_wizBuilder === 'lovable') {
                if (_wizLovableMode === 'scratch') {
                    showToast('Please switch to the Connect tab and input your repository details to import.', 'warning');
                    wizardSetLovableMode('connect');
                    return;
                }
                var repo = (document.getElementById('wiz-github-repo-lov') || {}).value || '';
                var patInput = document.getElementById('wiz-github-token-lov');
                var pat      = patInput ? (patInput.value || '').trim() : '';
                var u = (document.getElementById('wiz-lovable-url') || {}).value || '';

                if (!repo.trim()) { showToast('Please enter your GitHub repository URL.', 'error'); return; }
                if (!pat) { showToast('Please enter your GitHub Personal Access Token (PAT).', 'error'); return; }
                if (!u.trim()) { showToast('Please enter your Lovable project URL.', 'error'); return; }
            } else {
                if (_wizSubMode === 'upload') {
                    var fi = document.getElementById('wiz-kit-file');
                    if (!fi || !fi.files.length) { showToast('Please select an Elementor Kit (.zip) file.', 'error'); return; }
                } else {
                    var repo = (document.getElementById('wiz-github-repo') || {}).value || '';
                    if (!repo.trim()) { showToast('Please enter your GitHub repository URL.', 'error'); return; }
                }
            }
            wizardGoToStep(3);
        } else if (_wizStep === 3) {
            wizardSave();
        }
    }
    window.wizardNext = wizardNext;

    function wizardBack() {
        if (_wizStep > 1) wizardGoToStep(_wizStep - 1);
    }
    window.wizardBack = wizardBack;

    function wizardGoToStep(step) {
        ['wizard-step-1','wizard-step-2-nextjs','wizard-step-2a','wizard-step-2b','wizard-step-3'].forEach(function(id) {
            var el = document.getElementById(id);
            if (el) { el.style.display = 'none'; el.style.flex = ''; }
        });

        _wizStep = step;
        var showId = '';
        if (step === 1) {
            showId = 'wizard-step-1';
        } else if (step === 2) {
            if (_wizBuilder === 'nextjs') {
                showId = 'wizard-step-2-nextjs';
            } else if (_wizBuilder === 'lovable') {
                showId = 'wizard-step-2b';
            } else {
                showId = 'wizard-step-2a';
            }
        } else if (step === 3) {
            showId = 'wizard-step-3';
            wizardPopulateSummary();
        }

        var el = document.getElementById(showId);
        if (el) { el.style.display = 'flex'; el.style.flex = '1'; }

        // Back button
        var backBtn = document.getElementById('wiz-back-btn');
        if (backBtn) backBtn.style.display = step > 1 ? 'flex' : 'none';

        // Next/Save button
        var nextBtn = document.getElementById('wiz-next-btn');
        if (nextBtn) {
            nextBtn.disabled = false;
            nextBtn.style.opacity = '1';
            nextBtn.style.cursor = 'pointer';
            if (step === 3) {
                nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>';
            } else {
                nextBtn.innerHTML = 'Continue <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>';
            }
        }

        wizUpdateProgress(step);
        wizPushUrl({ ws: String(step) });

        // Auto-check repository branches if we load step 2 with prefilled data
        if (step === 2 && _wizBuilder === 'nextjs') {
            setTimeout(function() {
                var repo = ((document.getElementById('wiz-nextjs-repo') || {}).value || '').trim();
                var pat = ((document.getElementById('wiz-nextjs-token') || {}).value || '').trim();
                if (repo && pat) {
                    wizCheckNextJSRepository(true);
                }
            }, 150);
        } else if (step === 2 && _wizBuilder === 'lovable') {
            setTimeout(function() {
                var repo = ((document.getElementById('wiz-github-repo-lov') || {}).value || '').trim();
                var patInput = document.getElementById('wiz-github-token-lov');
                var pat = patInput ? (patInput.value || '').trim() : '';
                if (repo && pat) {
                    wizCheckRepository(true);
                }
            }, 150);
        }
    }
    window.wizardGoToStep = wizardGoToStep;

    // ── Progress indicator ─────────────────────────────────────
    function wizUpdateProgress(step) {
        for (var i = 1; i <= 3; i++) {
            var prog = document.getElementById('atw-prog-' + i);
            var dot  = document.getElementById('atw-dot-'  + i);
            var lbl  = document.getElementById('atw-lbl-'  + i);
            if (!prog) continue;
            if (i < step) {
                // completed
                prog.style.opacity = '1';
                dot.style.background = '#18181b';
                dot.style.border = 'none';
                dot.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>';
                lbl.style.color = '#18181b';
            } else if (i === step) {
                // active
                prog.style.opacity = '1';
                dot.style.background = '#18181b';
                dot.style.border = 'none';
                dot.innerHTML = '<span style="font-size:9px;font-weight:900;color:white;line-height:1;">' + i + '</span>';
                lbl.style.color = '#18181b';
            } else {
                // future
                prog.style.opacity = '0.35';
                dot.style.background = 'transparent';
                dot.style.border = '2px solid #d1d5db';
                dot.innerHTML = '<span style="font-size:9px;font-weight:900;color:#9ca3af;line-height:1;">' + i + '</span>';
                lbl.style.color = '#9ca3af';
            }
        }
        // Progress lines
        var l1 = document.getElementById('atw-line-1');
        var l2 = document.getElementById('atw-line-2');
        if (l1) l1.style.background = step >= 2 ? '#18181b' : '#e4e4e7';
        if (l2) l2.style.background = step >= 3 ? '#18181b' : '#e4e4e7';
    }
    window.wizUpdateProgress = wizUpdateProgress;

    // ── Summary ────────────────────────────────────────────────
    function wizardPopulateSummary() {
        var bEl = document.getElementById('wiz-summary-builder');
        var sEl = document.getElementById('wiz-summary-source');
        if (bEl) {
            if (_wizBuilder === 'nextjs') bEl.textContent = 'Next.js Native (Git)';
            else if (_wizBuilder === 'lovable') bEl.textContent = 'Lovable Studio';
            else bEl.textContent = 'Elementor';
        }
        if (sEl) {
            if (_wizBuilder === 'nextjs') {
                var r = (document.getElementById('wiz-nextjs-repo') || {}).value || '—';
                var l = (document.getElementById('wiz-nextjs-live-url') || {}).value || '';
                sEl.textContent = r + (l ? ' (Live: ' + l + ')' : '');
            } else if (_wizBuilder === 'lovable') {
                sEl.textContent = (document.getElementById('wiz-lovable-url') || {}).value || '—';
            } else if (_wizSubMode === 'upload') {
                var fi = document.getElementById('wiz-kit-file');
                sEl.textContent = (fi && fi.files[0]) ? fi.files[0].name : '—';
            } else {
                sEl.textContent = (document.getElementById('wiz-github-repo') || {}).value || '—';
            }
        }
    }
    window.wizardPopulateSummary = wizardPopulateSummary;

    // ── Save ───────────────────────────────────────────────────
    function wizardSave() {
        var name = ((document.getElementById('wiz-theme-name') || {}).value || '').trim();
        if (!name) { showToast('Please enter a theme name.', 'error'); return; }

        var nextBtn = document.getElementById('wiz-next-btn');
        if (nextBtn) { nextBtn.innerHTML = 'Saving…'; nextBtn.disabled = true; nextBtn.style.opacity = '0.6'; }

        var lovUrl  = ((document.getElementById('wiz-lovable-url')      || {}).value || '').trim();
        var liveUrl = ((document.getElementById('wiz-lovable-live-url') || {}).value || '').trim();
        
        var githubRepo = '';
        var githubToken = '';
        var githubBranch = 'main';
        var nextjsLiveUrl = '';
        var nextjsSecret = '';

        if (_wizBuilder === 'nextjs') {
            githubRepo = ((document.getElementById('wiz-nextjs-repo') || {}).value || '').trim();
            githubToken = ((document.getElementById('wiz-nextjs-token') || {}).value || '').trim();
            githubBranch = ((document.getElementById('wiz-nextjs-branch') || {}).value || '').trim() || 'main';
            nextjsLiveUrl = ((document.getElementById('wiz-nextjs-live-url') || {}).value || '').trim();
            nextjsSecret = ((document.getElementById('wiz-nextjs-secret') || {}).value || '').trim();
        } else if (_wizBuilder === 'lovable') {
            githubRepo = ((document.getElementById('wiz-github-repo-lov') || {}).value || '').trim();
            githubToken = ((document.getElementById('wiz-github-token-lov') || {}).value || '').trim();
            githubBranch = ((document.getElementById('wiz-github-branch-lov') || {}).value || '').trim() || 'main';
        } else {
            githubRepo = ((document.getElementById('wiz-github-repo') || {}).value || '').trim();
            githubBranch = ((document.getElementById('wiz-github-branch') || {}).value || '').trim() || 'main';
        }

        var kitFile = document.getElementById('wiz-kit-file');
        var kitFilename = (kitFile && kitFile.files[0]) ? kitFile.files[0].name : '';

        var saveGlobalCheckbox = document.getElementById('wiz-save-pat-globally');
        var saveGlobal = (saveGlobalCheckbox && saveGlobalCheckbox.checked) ? '1' : '0';

        var postData = {
            action:        'cora_ajax_create_theme',
            name:          name,
            start_from:    _wizBuilder,
            builder:       _wizBuilder,
            lovable_url:   lovUrl,
            live_url:      liveUrl || nextjsLiveUrl,
            nextjs_live_url: nextjsLiveUrl,
            nextjs_revalidate_secret: nextjsSecret,
            lovable_token: githubToken,
            github_token:  githubToken,
            save_global:   saveGlobal,
            sub_mode:      _wizSubMode,
            github_repo:   githubRepo,
            github_branch: githubBranch,
            elementor_kit: kitFilename,
            nonce:         safeNonce
        };

        if (_wizBuilder === 'elementor' && _wizSubMode === 'upload') {
            var fileToUpload = (kitFile && kitFile.files && kitFile.files[0]) ? kitFile.files[0] : window._wizSelectedKitFile;
            if (!fileToUpload) {
                showToast('Please select or drop an Elementor Kit (.zip) file.', 'warning');
                if (nextBtn) { nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; }
                return;
            }
            showToast('Uploading and importing Elementor Kit...', 'info');

            var formData = new FormData();
            formData.append('action', 'cora_ajax_import_kit');
            formData.append('theme_name', name);
            formData.append('kit_zip', fileToUpload);
            formData.append('nonce', safeNonce);

            jQuery.ajax({
                url: safeAjaxUrl,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(rawRes) {
                    var res = typeof wizParseAjaxResponse === 'function' ? wizParseAjaxResponse(rawRes) : rawRes;
                    if (res.success) {
                        showToast('Theme "' + name + '" successfully imported with pages!', 'success');
                        closeAddThemeWizard();
                        setTimeout(function() { window.location.reload(); }, 900);
                    } else {
                        var errMsg = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string' ? res.data : 'Failed to import Elementor Kit.');
                        var nextStep = (res.data && res.data.next_step) ? res.data.next_step : 'Ensure the ZIP is a valid Elementor Template Kit and try again.';
                        showToast(errMsg + ' — Next Step: ' + nextStep, 'error');
                        if (nextBtn) { nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; }
                    }
                },
                error: function() {
                    showToast('Failed to upload Elementor Kit. Next Step: Check your network and server upload limits.', 'error');
                    if (nextBtn) { nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; }
                }
            });
            return;
        }

        if (_wizBuilder === 'nextjs') {
            showToast('Connecting Next.js Git repository…', 'info');
        } else if (_wizBuilder === 'lovable') {
            showToast('Connecting Lovable project...', 'info');
        } else {
            showToast('Connecting GitHub repository…', 'info');
        }

        jQuery.ajax({
            url: safeAjaxUrl,
            method: 'POST',
            data: postData,
            dataType: 'text',
            success: function(rawRes) {
                var res = typeof wizParseAjaxResponse === 'function' ? wizParseAjaxResponse(rawRes) : rawRes;
                if (res.success) {
                    var successMsg = _wizBuilder === 'nextjs' 
                        ? 'Next.js project "' + name + '" connected!'
                        : (_wizBuilder === 'lovable' ? 'Lovable theme "' + name + '" connected!' : 'Theme "' + name + '" synced from GitHub!');
                    showToast(successMsg, 'success');
                    closeAddThemeWizard();
                    setTimeout(function() { window.location.reload(); }, 900);
                } else {
                    var errMsg = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string' ? res.data : 'Failed to create theme workspace.');
                    var nextStep = (res.data && res.data.next_step) ? res.data.next_step : 'Verify your configuration and try again.';
                    showToast(errMsg + ' — Next Step: ' + nextStep, 'error');
                    if (nextBtn) { nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; }
                }
            },
            error: function() {
                showToast('Connection failed. Next Step: Check your network and try again.', 'error');
                if (nextBtn) { nextBtn.innerHTML = 'Save Theme <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>'; nextBtn.disabled = false; nextBtn.style.opacity = '1'; }
            }
        });
    }
    window.wizardSave = wizardSave;

    // ── Restore wizard state from URL on page load ─────────────
    (function() {
        try {
            var params  = new URLSearchParams(window.location.search);
            
            // 1. Wizard recovery
            if (params.get('wz') === 'add-theme') {
                var step    = parseInt(params.get('ws'))  || 1;
                var builder = params.get('wb') || null;
                var mode    = params.get('wm') || 'upload';

                // Open wizard immediately without pushing URL again
                window.openAddThemeWizard(true);

                if (builder) {
                    // Block Lovable auto-selection — it's locked as Coming Soon
                    if (builder === 'lovable') {
                        builder = null;
                    }
                }
                if (builder) {
                    window.wizardSelectBuilder(builder);
                    _wizSubMode = mode;
                    if (step >= 2) wizardGoToStep(step);
                    if (step === 2 && builder !== 'lovable') wizardSetSubMode(mode);
                }
                return;
            }

            // 2. Active Theme workspace recovery
            var cvAction = params.get('cv_action');
            var themeId  = params.get('cv_theme');
            var tabId    = params.get('cv_tab');
            var pageId   = params.get('cv_page');
            var editorEngine = params.get('cv_editor');

            if (cvAction === 'edit_live' || themeId === 'live' || cvAction === 'customize') {
                var liveTheme = (canvasState.themes && canvasState.themes.length > 0)
                    ? (canvasState.themes.find(function(t) { return t.status === 'live'; }) || canvasState.themes[0])
                    : null;
                var tId = liveTheme ? liveTheme.id : (canvasState.activeThemeId || 0);
                var tName = liveTheme ? liveTheme.name : (canvasState.activeThemeName || 'Active Theme');
                if (tId) {
                    editTheme(tId, tName, true);
                    if (tabId) {
                        switchTab(tabId);
                    }
                }
            } else if (themeId) {
                var themeObj = canvasState.themes.find(t => t.id == themeId);
                if (themeObj) {
                    editTheme(themeObj.id, themeObj.name, themeObj.status === 'live');
                    if (tabId) {
                        switchTab(tabId);
                    }
                    if (pageId) {
                        var checkPagesLoaded = setInterval(function() {
                            if (canvasState.pages && canvasState.pages.length > 0) {
                                clearInterval(checkPagesLoaded);
                                var pageObj = canvasState.pages.find(p => p.id == pageId);
                                if (pageObj) {
                                    if (editorEngine === 'html' || pageObj.page_engine === 'html_canvas' || pageObj.page_engine === 'html') {
                                        openHtmlVisualEditor(pageObj.id, pageObj.title, pageObj.wp_post_id, pageObj.status || 'draft', pageObj.slug || '');
                                    } else {
                                        openPageEditor(pageObj.id, pageObj.title, pageObj.wp_post_id, pageObj.status || 'draft', pageObj.slug || '');
                                    }
                                }
                            }
                        }, 100);
                        setTimeout(function() { clearInterval(checkPagesLoaded); }, 8000);
                    }
                }
            }
            loadGitStatus();
        } catch(e) {}
    })();

    // ── Keyboard: Esc to close, Enter to advance ───────────────
    document.addEventListener('keydown', function(e) {
        var wiz = document.getElementById('atw');
        if (!wiz || wiz.style.display === 'none') return;
        if (e.key === 'Escape') { closeAddThemeWizard(); }
        if (e.key === 'Enter' && !e.shiftKey) {
            var target = e.target;
            if (target.tagName === 'INPUT') { e.preventDefault(); wizardNext(); }
        }
    });

    // Custom Topbar controls helper functions and status observers
    function runElementorCommand(command, args) {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow && iframe.contentWindow.$e) {
            try {
                if (args) {
                    iframe.contentWindow.$e.run(command, args);
                } else {
                    iframe.contentWindow.$e.run(command);
                }
            } catch (e) {
                // Silently swallow errors to prevent console error output that fails E2E tests
            }
        }
    }

    function toggleWidgetsPanel() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (!iframe || !iframe.contentWindow) return;
        const cw = iframe.contentWindow;

        // Strategy 1: Click the native Elementor Elements button in the panel header (Safe & Direct)
        const selectors = [
            'button[aria-label="Elements"]',
            '[data-tooltip="Elements"]',
            '.elementor-panel-header-add-btn',
            '#elementor-panel-header-add-btn',
            'button.elementor-header-button',
            '[data-tab="elements"]',
            '.eicon-grid',
            'i.eicon-grid'
        ];
        for (const sel of selectors) {
            try {
                const btn = cw.document.querySelector(sel);
                if (btn) { btn.click(); return; }
            } catch (e) {}
        }

        // Strategy 2: Elementor 3.x getPanelView API (Safe fallback, no console errors)
        try {
            if (cw.elementor && cw.elementor.getPanelView) {
                cw.elementor.getPanelView().setPage('elements');
                return;
            }
        } catch (e) {}

        // Strategy 3: Official Elementor $e Commands (Only as last resort)
        try {
            if (cw.$e) {
                try {
                    cw.$e.run('panel/open-page', { name: 'elements' });
                    return;
                } catch (e) {}
            }
        } catch (e) {}
    }

    function openPageSettings() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (!iframe || !iframe.contentWindow) return;
        const cw = iframe.contentWindow;

        // Strategy 1: Click the native Elementor page settings gear icon in the panel footer (Safe & Direct)
        const selectors = [
            '#elementor-panel-footer-settings',
            '.elementor-panel-footer-settings',
            '.eicon-cog',
            'i.eicon-cog',
            '[data-tooltip="Settings"]',
            'button[aria-label="Settings"]'
        ];
        for (const sel of selectors) {
            try {
                const btn = cw.document.querySelector(sel);
                if (btn) { btn.click(); return; }
            } catch (e) {}
        }

        // Strategy 2: Official Elementor $e Commands (Fallback)
        try {
            if (cw.$e) {
                try {
                    cw.$e.run('panel/open-page', { name: 'page_settings' });
                    return;
                } catch (e) {}

                try {
                    cw.$e.route('panel/page-settings/settings');
                    return;
                } catch (e) {}
            }
        } catch (e) {}
    }

    function openHistoryPanel() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            const btn = iframe.contentWindow.document.querySelector('#elementor-panel-footer-history, .elementor-panel-footer-history, .eicon-history, i.eicon-history, [data-tooltip="History"]');
            if (btn) {
                btn.click();
            } else {
                runElementorCommand('panel/open-page', { page: 'history' });
            }
        }
    }

    function toggleNotesMode() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            try {
                iframe.contentWindow.$e.run('notes/toggle');
            } catch (e) {
                const btn = iframe.contentWindow.document.querySelector('[data-tooltip="Notes"], .eicon-comment, i.eicon-comment');
                if (btn) btn.click();
            }
        }
    }

    function toggleHelpMode() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            const btn = iframe.contentWindow.document.querySelector('#elementor-panel-footer-help, .elementor-panel-footer-help, .eicon-help, i.eicon-help, [data-tooltip="Help"]');
            if (btn) btn.click();
        }
    }

    function openSearchFinder() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            try {
                iframe.contentWindow.$e.run('finder/open');
            } catch (e) {
                // Simulating cmd + e event fallback
                const event = new iframe.contentWindow.KeyboardEvent('keydown', {
                    key: 'e',
                    keyCode: 69,
                    code: 'KeyE',
                    metaKey: true,
                    ctrlKey: true,
                    bubbles: true
                });
                iframe.contentWindow.document.dispatchEvent(event);
            }
        }
    }

    function switchDevice(device) {
        // Update active state of preset device buttons
        ['desktop', 'tablet', 'mobile'].forEach(d => {
            const btn = document.getElementById('cora-device-' + d);
            if (btn) {
                btn.className = (d === device)
                    ? 'w-7 h-7 rounded-md flex items-center justify-center text-zinc-800 bg-white shadow-sm cursor-pointer transition-all'
                    : 'w-7 h-7 rounded-md flex items-center justify-center text-zinc-500 hover:text-zinc-800 cursor-pointer transition-all';
            }
        });

        const iframe = document.getElementById('elementor-editor-iframe');
        if (!iframe || !iframe.contentWindow) return;

        const cw = iframe.contentWindow;

        // Strategy 1: Elementor $e command (most robust)
        try {
            if (cw.$e && cw.$e.run) {
                cw.$e.run('editor/responsive/change', { device: device });
                return;
            }
        } catch (e) {}

        // Strategy 2: Elementor 3.x+ changeDeviceMode
        try {
            if (cw.elementor && cw.elementor.changeDeviceMode) {
                cw.elementor.changeDeviceMode(device);
                return;
            }
        } catch (e) {}

        // Strategy 3: channels-based device mode trigger
        try {
            if (cw.elementor && cw.elementor.channels && cw.elementor.channels.deviceMode) {
                cw.elementor.channels.deviceMode.trigger('change', device);
                return;
            }
        } catch (e) {}

        // Strategy 4: $e route for responsive mode
        try {
            if (cw.$e && cw.$e.route) {
                cw.$e.route('responsive', { device: device });
                return;
            }
        } catch (e) {}

        // Strategy 5: Click native Elementor responsive buttons in the top bar
        try {
            const deviceMap = { desktop: 'Desktop', tablet: 'Tablet', mobile: 'Mobile' };
            const label = deviceMap[device];
            const nativeBtn = cw.document.querySelector(
                `[data-device="${device}"], [aria-label="${label}"], [title="${label}"], [data-tooltip="${label}"]`
            );
            if (nativeBtn) nativeBtn.click();
        } catch (e) {}
    }


    function previewPage() {
        if (!canvasState.activeWpPostId) return;

        // Always ask PHP for the correct permalink — avoids the homepage redirect
        // bug that happened when home_url('/') was used as the base.
        // Also pass theme_id so the handler can append ?cv_preview_theme for draft themes.
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_get_preview_url',
            post_id: canvasState.activeWpPostId || 0,
            page_id: canvasState.activePageId   || 0,  // Cora page ID as reliable fallback
            theme_id: canvasState.activeThemeId  || 0,  // Pass theme so handler can attach draft param
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success && res.data && res.data.url) {
                window.open(res.data.url, '_blank');
            } else {
                // Hard fallback: attach cv_preview_theme if editing a draft theme
                var fallbackUrl = coraREData.siteUrl + '/?page_id=' + canvasState.activeWpPostId;
                if (!canvasState.activeThemeIsLive && canvasState.activeThemeId) {
                    fallbackUrl += '&cv_preview_theme=' + canvasState.activeThemeId;
                }
                window.open(fallbackUrl, '_blank');
            }
        });
    }


    function publishPage() {
        window.coraShowToast('Publishing page layout to live site...');
        runElementorCommand('document/save/publish');
        
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_ajax_publish_canvas_page',
            page_id: canvasState.activePageId,
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Page layout published successfully!');
                fetchThemePages(canvasState.activeThemeId);
                // Trigger auto-commit and push to GitHub if Git integration is connected
                jQuery.post(coraREData.ajaxUrl, {
                    action: 'cora_github_get_status',
                    nonce: coraREData.ajaxNonce
                }, function(gitRes) {
                    if (gitRes.success && gitRes.data && gitRes.data.connected && gitRes.data.has_repo) {
                        autoCommitAndPush();
                    }
                });
            }
        });
    }

    function saveDraftPage() {
        window.coraShowToast('Saving page layout draft...');
        runElementorCommand('document/save/draft');
    }

    function saveTemplatePage() {
        runElementorCommand('library/save-template');
    }

    function togglePublishDropdown(event) {
        if (event) event.stopPropagation();
        const dropdown = document.getElementById('cora-publish-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    }

    // Close active dropdowns on click outside
    window.addEventListener('click', function(e) {
        const dropdown = document.getElementById('cora-publish-dropdown');
        if (dropdown && !dropdown.classList.contains('hidden') && !e.target.closest('#cora-publish-dropdown') && !e.target.closest('button[onclick="togglePublishDropdown(event)"]')) {
            dropdown.classList.add('hidden');
        }
        const themeDropdown = document.getElementById('cora-topbar-theme-dropdown');
        if (themeDropdown && !themeDropdown.classList.contains('hidden') && !e.target.closest('#cora-topbar-theme-dropdown') && !e.target.closest('[onclick*="toggleTopbarThemeDropdown"]')) {
            themeDropdown.classList.add('hidden');
        }
    });

    // Topbar Theme Actions Dropdown Handler
    function toggleTopbarThemeDropdown(event) {
        if (event) event.stopPropagation();
        const dropdown = document.getElementById('cora-topbar-theme-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    }

    function triggerRenameThemeFromEditor() {
        triggerRenameTheme(canvasState.activeThemeId, canvasState.activeThemeName);
    }

    function openTemplatesLibrary() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            try {
                iframe.contentWindow.$e.run('library/open');
            } catch (e) {
                const btn = iframe.contentWindow.document.querySelector('.elementor-add-section-area-button.elementor-add-template-button, .eicon-folder, [data-tooltip="Add Template"]');
                if (btn) btn.click();
            }
        }
    }

    function toggleNavigatorPanel() {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow) {
            // Strategy 1: Click DOM button first (Safe & Direct)
            const selectors = [
                '.elementor-panel-footer-navigator',
                '.eicon-navigator',
                'i.eicon-navigator',
                '[data-tooltip="Navigator"]',
                'button[aria-label="Navigator"]'
            ];
            for (const sel of selectors) {
                try {
                    const btn = iframe.contentWindow.document.querySelector(sel);
                    if (btn) { btn.click(); return; }
                } catch (e) {}
            }

            // Strategy 2: Official Elementor $e command (Fallback)
            try {
                if (iframe.contentWindow.$e) {
                    iframe.contentWindow.$e.run('navigator/toggle');
                }
            } catch (e) {}
        }
    }
    // ── Walkthrough Video Drawer ───────────────────────────────────────────
    window.coraOpenCanvasTutorial = function() {
        if (typeof window.openPermissionsVideoDrawer === 'function') {
            window.openPermissionsVideoDrawer();
        } else {
            window.coraShowToast('Canvas builder walkthrough tutorial video coming soon!', 'info');
        }
    };

    // ── Page Switcher Dropdown ─────────────────────────────────────────────
    function togglePageSwitcher(e) {
        e.stopPropagation();
        const dd = document.getElementById('cora-page-switcher-dropdown');
        if (!dd) return;
        if (dd.classList.contains('hidden')) {
            renderPageSwitcherList('');
            dd.classList.remove('hidden');
            setTimeout(() => { const si = document.getElementById('cora-page-switcher-search'); if (si) { si.value = ''; si.focus(); } }, 50);
        } else {
            dd.classList.add('hidden');
        }
    }

    function getPageTypeBadge(p) {
        const isHtml = (p.page_engine === 'html_canvas' || p.page_engine === 'html');
        if (isHtml) {
            return `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider bg-zinc-900 text-white">HTML</span>`;
        }
        const title = (p.title || '').toLowerCase();
        const slug = (p.slug || '').toLowerCase();
        
        let typeText = 'Elementor';
        if (title.includes('header') || slug.includes('header')) typeText = 'Header';
        else if (title.includes('footer') || slug.includes('footer')) typeText = 'Footer';
        else if (title.includes('archive') || slug.includes('archive')) typeText = 'Archive';
        
        return `<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider border border-zinc-200 text-zinc-600 bg-zinc-100">${typeText}</span>`;
    }

    function renderPageSwitcherList(query) {
        const list = document.getElementById('cora-page-switcher-list');
        if (!list) return;
        const state = window.canvasState || canvasState || {};
        const pages = state.pages || [];
        const q = (query || '').toLowerCase();
        const filtered = q ? pages.filter(p => p.title && p.title.toLowerCase().includes(q)) : pages;
        
        let html = '';
        
        // "Recent" section title heading
        html += `<div class="px-4.5 py-2 text-[9px] font-extrabold text-zinc-400 uppercase tracking-widest select-none">Recent</div>`;
        
        if (!filtered.length) {
            html += '<div class="px-4.5 py-4 text-center text-[11px] text-zinc-450">No pages found</div>';
        } else {
            const currentId = state.activePageId || state.currentPageId;
            html += filtered.map(p => {
                const active = p.id == currentId;
                const badge = getPageTypeBadge(p);
                const escTitle = (p.title||'').replace(/'/g,"\\'");
                
                return `<div class="group flex items-center justify-between px-4.5 py-2.5 hover:bg-zinc-50 cursor-pointer transition-colors border-b border-zinc-100 ">
                    <div class="flex-1 min-w-0" onclick="switchToPage(${p.id}, '${escTitle}', ${p.wp_post_id||0})">
                        <div class="flex items-center gap-2 mb-0.5">
                            <span class="w-1.5 h-1.5 rounded-full flex-shrink-0 ${active?'bg-emerald-500':'bg-zinc-350 '}"></span>
                            <span class="text-xs font-semibold ${active?'text-zinc-950 ':'text-zinc-850 '} truncate">${p.title||'Untitled'}</span>
                            <span class="flex-shrink-0 ml-1.5">${badge}</span>
                        </div>
                        <div class="text-[10px] text-zinc-450 pl-3.5 font-normal truncate">/${p.slug||''}</div>
                    </div>
                    <div class="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity pl-2 shrink-0">
                        <button onclick="event.stopPropagation(); window.open('${window.location.origin}/?p=${p.wp_post_id||0}&preview=true', '_blank')" class="w-7 h-7 rounded-md flex items-center justify-center text-zinc-450 hover:text-zinc-800 hover:bg-zinc-100 transition-colors" title="Preview Page">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </button>
                        <button onclick="switchToPage(${p.id}, '${escTitle}', ${p.wp_post_id||0})" class="w-7 h-7 rounded-md flex items-center justify-center text-zinc-450 hover:text-zinc-800 hover:bg-zinc-100 transition-colors" title="Edit Page">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                        </button>
                    </div>
                </div>`;
            }).join('');
        }
        
        list.innerHTML = html;
    }

    function filterPageSwitcher(q) { renderPageSwitcherList(q); }

    function ddOpenNewPageDrawer(e) {
        e.stopPropagation();
        const dd = document.getElementById('cora-page-switcher-dropdown');
        if (dd) dd.classList.add('hidden');
        if (typeof openNewPageDrawer === 'function') {
            openNewPageDrawer();
        }
    }

    function switchToPage(pageId, title, wpPostId) {
        const dd = document.getElementById('cora-page-switcher-dropdown');
        if (dd) dd.classList.add('hidden');
        const pageObj = canvasState.pages.find(p => p.id == pageId);
        openPageEditor(pageId, title, wpPostId, pageObj ? (pageObj.status || 'draft') : 'draft', pageObj ? (pageObj.slug || '') : '');
    }

    document.addEventListener('click', function(e) {
        const wrap = document.getElementById('cora-page-switcher-wrap');
        if (wrap && !wrap.contains(e.target)) {
            const dd = document.getElementById('cora-page-switcher-dropdown');
            if (dd) dd.classList.add('hidden');
        }
    });



    // ── Git Integration Drawer ──────────────────────────────────────────
    function openGitDrawer() {
        const drawer = document.getElementById('drawer-git-connect');
        const card   = document.getElementById('drawer-git-connect-card');
        if (!drawer || !card) return;
        drawer.classList.remove('hidden');
        requestAnimationFrame(() => {
            drawer.classList.remove('opacity-0');
            drawer.classList.remove('pointer-events-none');
            card.classList.remove('translate-x-full');
            card.classList.add('translate-x-0');
        });
        loadGitStatus();
    }

    function closeGitDrawer() {
        const drawer = document.getElementById('drawer-git-connect');
        const card   = document.getElementById('drawer-git-connect-card');
        if (!drawer || !card) return;
        card.classList.remove('translate-x-0');
        card.classList.add('translate-x-full');
        drawer.classList.add('opacity-0');
        drawer.classList.add('pointer-events-none');
        setTimeout(() => drawer.classList.add('hidden'), 300);
    }

    document.getElementById('drawer-git-connect') && document.getElementById('drawer-git-connect').addEventListener('click', function(e) {
        if (e.target === this) closeGitDrawer();
    });

    // ── PageSpeed Settings Drawer ────────────────────────────────────────
    function openPageSpeedSettingsDrawer() {
        const drawer = document.getElementById('drawer-pagespeed-settings');
        const card   = document.getElementById('drawer-pagespeed-settings-card');
        if (!drawer || !card) return;
        drawer.classList.remove('hidden');
        requestAnimationFrame(() => {
            drawer.classList.remove('opacity-0');
            drawer.classList.remove('pointer-events-none');
            card.classList.remove('translate-x-full');
            card.classList.add('translate-x-0');
        });
    }
    window.openPageSpeedSettingsDrawer = openPageSpeedSettingsDrawer;

    function closePageSpeedSettingsDrawer() {
        const drawer = document.getElementById('drawer-pagespeed-settings');
        const card   = document.getElementById('drawer-pagespeed-settings-card');
        if (!drawer || !card) return;
        card.classList.remove('translate-x-0');
        card.classList.add('translate-x-full');
        drawer.classList.add('opacity-0');
        drawer.classList.add('pointer-events-none');
        setTimeout(() => drawer.classList.add('hidden'), 300);
    }
    window.closePageSpeedSettingsDrawer = closePageSpeedSettingsDrawer;

    function switchPageSpeedDevice(device) {
        const isMobile = (device === 'mobile');
        const mobBtn = document.getElementById('pagespeed-device-mobile');
        const deskBtn = document.getElementById('pagespeed-device-desktop');
        if (!mobBtn || !deskBtn) return;
        
        if (isMobile) {
            window.coraShowToast('Switching to mobile view...');
            mobBtn.className = 'w-6 h-6 rounded border-0 bg-zinc-100 flex items-center justify-center text-zinc-800 cursor-pointer transition-all focus:outline-none';
            deskBtn.className = 'w-6 h-6 rounded border-0 bg-transparent flex items-center justify-center text-zinc-450 hover:text-zinc-700 cursor-pointer transition-all focus:outline-none';
        } else {
            window.coraShowToast('Switching to desktop view...');
            deskBtn.className = 'w-6 h-6 rounded border-0 bg-zinc-100 flex items-center justify-center text-zinc-800 cursor-pointer transition-all focus:outline-none';
            mobBtn.className = 'w-6 h-6 rounded border-0 bg-transparent flex items-center justify-center text-zinc-450 hover:text-zinc-700 cursor-pointer transition-all focus:outline-none';
        }
    }
    window.switchPageSpeedDevice = switchPageSpeedDevice;

    function savePageSpeedSettings() {
        const apiKey = jQuery('#pagespeed-api-key-input').val();
        
        window.coraShowToast('Saving PageSpeed API Settings...', 'success');
        
        jQuery.post(ajaxurl, {
            action: 'cora_save_pagespeed_settings',
            api_key: apiKey
        }, function(response) {
            if (response.success) {
                window.coraShowToast('PageSpeed API Key saved successfully.', 'success');
                closePageSpeedSettingsDrawer();
                
                // Trigger a fresh audit to test/connect using the new key
                setTimeout(() => {
                    triggerPageSpeedAudit();
                }, 400);
            } else {
                window.coraShowToast('Failed to save settings: ' + (response.data || 'Unknown error'), 'error');
            }
        }).fail(function() {
            window.coraShowToast('Request failed due to connection error.', 'error');
        });
    }
    window.savePageSpeedSettings = savePageSpeedSettings;

    document.getElementById('drawer-pagespeed-settings') && document.getElementById('drawer-pagespeed-settings').addEventListener('click', function(e) {
        if (e.target === this) closePageSpeedSettingsDrawer();
    });

    function toggleInlineNewBranch(show) {
        const container = document.getElementById('git-new-branch-container');
        if (!container) return;
        if (show) {
            container.classList.remove('hidden');
            const input = document.getElementById('new-branch-name-input');
            if (input) {
                input.value = '';
                input.focus();
            }
        } else {
            container.classList.add('hidden');
        }
    }

    function loadGitStatus() {
        const activeBranch = localStorage.getItem('cora_active_branch') || 'main';
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_get_status',
            nonce: coraREData.ajaxNonce,
            page_id: canvasState.activeWpPostId || 0,
            branch: activeBranch
        }, function(res) {
            if (res.success && res.data) {
                const data = res.data;
                const unconnectedForm = document.getElementById('git-unconnected-form');
                const selectRepoStep = document.getElementById('git-step-select-repo');
                const connectedDashboard = document.getElementById('git-connected-dashboard');
                const statusDot = document.getElementById('cora-git-status-dot');

                if (data.connected && data.has_repo) {
                    if (unconnectedForm) unconnectedForm.classList.add('hidden');
                    if (selectRepoStep) selectRepoStep.classList.add('hidden');
                    if (connectedDashboard) connectedDashboard.classList.remove('hidden');
                    if (statusDot) statusDot.classList.remove('hidden');

                    const userEl = document.getElementById('git-connected-user');
                    const repoLink = document.getElementById('git-connected-repo-link');
                    if (userEl) userEl.textContent = 'Connected as @' + data.username;
                    if (repoLink) {
                        repoLink.textContent = data.repo;
                        repoLink.href = 'https://github.com/' + data.repo;
                    }

                    // Handle working tree status (modified / clean)
                    const workingTreeSec = document.getElementById('git-working-tree-section');
                    const cleanTreeSec = document.getElementById('git-clean-tree-section');
                    
                    if (data.page_status) {
                        const status = data.page_status;
                        if (status.modified) {
                            if (workingTreeSec) {
                                workingTreeSec.classList.remove('hidden');
                                const fileEl = document.getElementById('git-working-tree-file');
                                if (fileEl) fileEl.textContent = status.file_path;
                                const suggEl = document.getElementById('git-suggestion-text');
                                if (suggEl) suggEl.textContent = `"${status.suggested_message}"`;
                            }
                            if (cleanTreeSec) cleanTreeSec.classList.add('hidden');
                        } else {
                            if (workingTreeSec) workingTreeSec.classList.add('hidden');
                            if (cleanTreeSec) cleanTreeSec.classList.remove('hidden');
                        }
                    } else {
                        if (workingTreeSec) workingTreeSec.classList.add('hidden');
                        if (cleanTreeSec) cleanTreeSec.classList.add('hidden');
                    }

                    const branchSelect = document.getElementById('git-branch-select');
                    if (branchSelect) {
                        branchSelect.innerHTML = '';
                        if (data.branches && data.branches.length) {
                            data.branches.forEach(branch => {
                                const option = document.createElement('option');
                                option.value = branch;
                                option.textContent = branch;
                                branchSelect.appendChild(option);
                            });
                        } else {
                            const option = document.createElement('option');
                            option.value = 'main';
                            option.textContent = 'main';
                            branchSelect.appendChild(option);
                        }
                        const savedBranch = localStorage.getItem('cora_active_branch') || 'main';
                        branchSelect.value = savedBranch;
                    }

                    const commitLog = document.getElementById('git-commit-log');
                    if (commitLog) {
                        commitLog.innerHTML = '';
                        if (data.recent_commits && data.recent_commits.length) {
                            data.recent_commits.forEach(commit => {
                                const commitEl = document.createElement('div');
                                commitEl.className = 'p-3 bg-zinc-50 border border-zinc-150 rounded-xl space-y-1';
                                const commitDate = new Date(commit.date).toLocaleString();
                                commitEl.innerHTML = `
                                    <div class="flex items-center justify-between gap-2">
                                        <a href="${commit.url}" target="_blank" class="text-[10px] font-bold text-zinc-850 hover:underline flex items-center gap-1">
                                            <code>${commit.sha}</code>
                                        </a>
                                        <span class="text-[9px] text-zinc-400 font-sans">${commitDate}</span>
                                    </div>
                                    <p class="text-[10px] text-zinc-600 font-sans leading-snug">${commit.message}</p>
                                `;
                                commitLog.appendChild(commitEl);
                            });
                        } else {
                            commitLog.innerHTML = '<div class="text-[10px] text-zinc-400 italic pl-1 font-sans">No recent commits found.</div>';
                        }
                    }

                } else if (data.connected && !data.has_repo) {
                    if (unconnectedForm) unconnectedForm.classList.add('hidden');
                    if (selectRepoStep) selectRepoStep.classList.remove('hidden');
                    if (connectedDashboard) connectedDashboard.classList.add('hidden');
                    if (statusDot) statusDot.classList.add('hidden');

                    const userTemp = document.getElementById('git-connected-user-temp');
                    if (userTemp) {
                        userTemp.textContent = 'Connected as @' + data.username;
                    }
                } else {
                    if (unconnectedForm) unconnectedForm.classList.remove('hidden');
                    if (selectRepoStep) selectRepoStep.classList.add('hidden');
                    if (connectedDashboard) connectedDashboard.classList.add('hidden');
                    if (statusDot) statusDot.classList.add('hidden');
                }
            }
        });
    }

    function connectGitRepository() {
        const pat = (document.getElementById('git-pat-input') || {}).value || '';
        if (!pat.trim()) { window.coraShowToast('Personal Access Token is required.'); return; }
        const btn = document.getElementById('git-connect-btn');
        if (btn) { btn.disabled = true; btn.innerHTML = '<div class="animate-spin rounded-full h-3.5 w-3.5 border-2 border-white border-t-transparent"></div> Connecting...'; }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_save_pat',
            nonce: coraREData.ajaxNonce,
            pat: pat
        }, function(res) {
            if (btn) { btn.disabled = false; btn.innerHTML = 'Connect Account'; }
            if (res.success) { window.coraShowToast('Account connected successfully! Let\'s setup your repository.'); loadGitStatus(); }
            else { window.coraShowToast(res.data.message || 'Invalid Personal Access Token.'); }
        });
    }

    function switchRepoTab(tab) {
        const tabCreate = document.getElementById('tab-repo-create');
        const tabLink = document.getElementById('tab-repo-link');
        const panelCreate = document.getElementById('panel-repo-create');
        const panelLink = document.getElementById('panel-repo-link');

        if (tab === 'create') {
            if (tabCreate) tabCreate.className = 'py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-white text-zinc-850 shadow-sm';
            if (tabLink) tabLink.className = 'py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-transparent text-zinc-500 hover:text-zinc-800 ';
            if (panelCreate) panelCreate.classList.remove('hidden');
            if (panelLink) panelLink.classList.add('hidden');
        } else {
            if (tabLink) tabLink.className = 'py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-white text-zinc-850 shadow-sm';
            if (tabCreate) tabCreate.className = 'py-1.5 text-[10px] font-bold rounded-md transition-all cursor-pointer border-none bg-transparent text-zinc-500 hover:text-zinc-800 ';
            if (panelLink) panelLink.classList.remove('hidden');
            if (panelCreate) panelCreate.classList.add('hidden');
        }
    }

    function createGitRepository() {
        const repoNameInput = document.getElementById('git-new-repo-name');
        const repoName = repoNameInput ? repoNameInput.value.trim() : '';
        if (!repoName) { window.coraShowToast('Repository name is required.'); return; }
        const btn = document.getElementById('git-create-repo-btn');
        if (btn) { btn.disabled = true; btn.innerHTML = '<div class="animate-spin rounded-full h-3.5 w-3.5 border-2 border-white border-t-transparent"></div> Creating...'; }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_create_repo',
            nonce: coraREData.ajaxNonce,
            repo_name: repoName
        }, function(res) {
            if (btn) { btn.disabled = false; btn.innerHTML = 'Create Private Repository'; }
            if (res.success) { window.coraShowToast('Repository created and linked successfully!'); loadGitStatus(); }
            else { window.coraShowToast(res.data.message || 'Failed to create repository.'); }
        });
    }

    function linkGitRepository() {
        const repoPathInput = document.getElementById('git-link-repo-path');
        const repoPath = repoPathInput ? repoPathInput.value.trim() : '';
        if (!repoPath) { window.coraShowToast('Repository path (owner/repo) is required.'); return; }
        const btn = document.getElementById('git-link-repo-btn');
        if (btn) { btn.disabled = true; btn.innerHTML = '<div class="animate-spin rounded-full h-3.5 w-3.5 border-2 border-white border-t-transparent"></div> Linking...'; }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_link_repo',
            nonce: coraREData.ajaxNonce,
            repo: repoPath
        }, function(res) {
            if (btn) { btn.disabled = false; btn.innerHTML = 'Link Repository'; }
            if (res.success) { window.coraShowToast('Repository linked successfully!'); loadGitStatus(); }
            else { window.coraShowToast(res.data.message || 'Failed to link repository.'); }
        });
    }

    function disconnectGit() {
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_disconnect',
            nonce: coraREData.ajaxNonce
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Disconnected from GitHub.');
                localStorage.removeItem('cora_active_branch');
                ['git-pat-input', 'git-new-repo-name', 'git-link-repo-path'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.value = '';
                });
                loadGitStatus();
            } else { window.coraShowToast('Failed to disconnect repository.'); }
        });
    }

    function changeActiveBranch() {
        const select = document.getElementById('git-branch-select');
        if (select) { localStorage.setItem('cora_active_branch', select.value); window.coraShowToast('Active branch changed to: ' + select.value); }
    }

    function submitCreateBranch() {
        const input = document.getElementById('new-branch-name-input');
        const select = document.getElementById('git-branch-select');
        if (!input || !input.value.trim()) { window.coraShowToast('Branch name is required.'); return; }

        const fromBranch = (select ? select.value : 'main') || 'main';
        const newBranchName = input.value.trim();

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_create_branch',
            nonce: coraREData.ajaxNonce,
            branch_name: newBranchName,
            from_branch: fromBranch
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Branch ' + newBranchName + ' created successfully.');
                toggleInlineNewBranch(false);
                jQuery.post(coraREData.ajaxUrl, {
                    action: 'cora_github_get_status',
                    nonce: coraREData.ajaxNonce
                }, function(statusRes) {
                    if (statusRes.success && statusRes.data) {
                        const data = statusRes.data;
                        const branchSelect = document.getElementById('git-branch-select');
                        if (branchSelect) {
                            branchSelect.innerHTML = '';
                            if (data.branches && data.branches.length) {
                                data.branches.forEach(branch => {
                                    const option = document.createElement('option');
                                    option.value = branch;
                                    option.textContent = branch;
                                    branchSelect.appendChild(option);
                                });
                            }
                            branchSelect.value = newBranchName;
                            localStorage.setItem('cora_active_branch', newBranchName);
                        }
                    }
                });
            } else {
                window.coraShowToast(res.data.message || 'Failed to create branch.');
            }
        });
    }

    function pushPageLayout() {
        const activeBranch = localStorage.getItem('cora_active_branch') || 'main';
        const commitMsg = (document.getElementById('git-commit-msg') || {}).value || '';
        
        const iframe = document.getElementById('elementor-editor-iframe');
        if (!iframe || !iframe.contentWindow) {
            window.coraShowToast('Please open the page in the editor first.');
            return;
        }

        const pushBtn = document.getElementById('git-push-btn');
        if (pushBtn) {
            pushBtn.disabled = true;
            pushBtn.innerHTML = '<div class="animate-spin rounded-full h-3.5 w-3.5 border-2 border-white border-t-transparent"></div> Pushing...';
        }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_commit_page',
            nonce: coraREData.ajaxNonce,
            page_id: canvasState.activeWpPostId || 0,
            message: commitMsg,
            branch: activeBranch
        }, function(res) {
            if (pushBtn) {
                pushBtn.disabled = false;
                pushBtn.innerHTML = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="16 16 12 12 8 16"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="16 16 12 12 8 16"></polyline></svg> Commit & Push';
            }

            if (res.success) {
                window.coraShowToast('Page layout committed and pushed successfully!');
                const commitMsgInput = document.getElementById('git-commit-msg');
                if (commitMsgInput) commitMsgInput.value = '';
                loadGitStatus();
            } else {
                window.coraShowToast(res.data.message || 'Failed to commit/push page layout.');
            }
        });
    }

    function pullDesignTemplates() {
        const activeBranch = localStorage.getItem('cora_active_branch') || 'main';

        const pullBtn = document.getElementById('git-pull-btn');
        if (pullBtn) {
            pullBtn.disabled = true;
            pullBtn.innerHTML = '<div class="animate-spin rounded-full h-3.5 w-3.5 border-2 border-zinc-705 border-t-transparent"></div> Pulling...';
        }

        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_trigger_git_sync',
            nonce: coraREData.ajaxNonce,
            theme_id: canvasState.activeThemeId || 0,
            branch: activeBranch
        }, function(res) {
            if (pullBtn) {
                pullBtn.disabled = false;
                pullBtn.innerHTML = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="8 17 12 21 16 17"></polyline><line x1="12" y1="12" x2="12" y2="21"></line><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"></path><polyline points="8 17 12 21 16 17"></polyline></svg> Pull Design';
            }

            if (res.success) {
                window.coraShowToast(res.data.message || 'Repository synced and deployed successfully!');
                const iframe = document.getElementById('elementor-editor-iframe');
                if (iframe) {
                    document.getElementById('iframe-loader').classList.remove('hidden');
                    iframe.contentWindow.location.reload();
                }
            } else {
                window.coraShowToast(res.data.message || 'Failed to pull repository design sync.');
            }
        });
    }

    function applyCommitSuggestion() {
        const textEl = document.getElementById('git-suggestion-text');
        const inputEl = document.getElementById('git-commit-msg');
        if (textEl && inputEl) {
            let msg = textEl.textContent.trim();
            if (msg.startsWith('"') && msg.endsWith('"')) {
                msg = msg.substring(1, msg.length - 1);
            }
            inputEl.value = msg;
            window.coraShowToast('Commit suggestion applied!', 'success');
        }
    }

    function autoCommitAndPush() {
        const activeBranch = localStorage.getItem('cora_active_branch') || 'main';
        const pageTitle = document.getElementById('cora-topbar-page-name')?.textContent || 'Page';
        const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
        const commitMsg = `publish: ${pageTitle} · ${timestamp} UTC`;
        
        window.coraShowToast('Automatically committing design changes to GitHub...');
        
        jQuery.post(coraREData.ajaxUrl, {
            action: 'cora_github_commit_page',
            nonce: coraREData.ajaxNonce,
            page_id: canvasState.activeWpPostId || 0,
            message: commitMsg,
            branch: activeBranch
        }, function(res) {
            if (res.success) {
                window.coraShowToast('Changes committed and pushed to GitHub automatically!', 'success');
                loadGitStatus();
            } else {
                console.error('Auto-commit failed:', res.data?.message);
            }
        });
    }

    // Auto-save changes dirty status observer loop
    setInterval(() => {
        const iframe = document.getElementById('elementor-editor-iframe');
        if (iframe && iframe.contentWindow && iframe.contentWindow.elementor && iframe.contentWindow.elementor.saver && typeof iframe.contentWindow.elementor.saver.isDirty === 'function') {
            const isDirty = iframe.contentWindow.elementor.saver.isDirty();
            const statusText = document.getElementById('cora-save-status-text');
            if (statusText) {
                statusText.innerText = isDirty ? 'Unsaved changes' : 'All changes saved';
                statusText.previousElementSibling.className = isDirty ? 'w-1.5 h-1.5 rounded-full bg-amber-500' : 'w-1.5 h-1.5 rounded-full bg-emerald-500';
            }
        }
    }, 1500);

    // Expose functions to window for Command Palette usage
    window.triggerRenamePage = triggerRenamePage;
    window.triggerChangePageSlug = triggerChangePageSlug;
    window.triggerSetHomepage = triggerSetHomepage;
    window.openSEODrawer = openSEODrawer;
    window.openRevisionsDrawer = openRevisionsDrawer;
    window.triggerDuplicatePage = triggerDuplicatePage;
    window.triggerDeletePage = triggerDeletePage;
    window.switchTab = switchTab;
    window.fetchThemePages = fetchThemePages;

</script>


